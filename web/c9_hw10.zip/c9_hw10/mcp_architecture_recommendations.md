# MCP Server Strategy & ECS Architecture — Staff Engineer Recommendations

**Date:** 2026-09-01
**Scope:** Should this project build FastMCP servers for (1) file access and (2) code execution/plotting/calculation, and (3) how should they be deployed on AWS ECS?
**Grounded in:** `lab/MCP cheatsheet.pdf`, `src/app.py` (1688 lines), `src/util/func1.py` (file tools), `src/util/func2.py` (agent + sandbox + tools), `src/util/func3.py` (orchestration), `src/util/func.py` (storage), `temp/agentic_ai_api_improvement_plan.md` (Phases 0–6).

---

## 0. What the cheatsheet actually says, and what it does *not* say

The cheatsheet defines three primitives and two transports. The distinctions matter for these decisions:

| Primitive | Control model | Correct use here |
|---|---|---|
| **Tools** | *Model*-controlled — the LLM discovers and invokes them | `parse_*`, `generate_and_execute_code` |
| **Resources** | *Application*-driven — passive, addressable by URI, read-only | The uploaded-file corpus (`file://session/{sid}/{file_id}`), the artifact store |
| **Prompts** | *User*-controlled — reusable templates | The 5 entries in `SKILLS` are closer to this than to tools |

Two things the cheatsheet does **not** claim, which are the crux of your questions:

1. **MCP is not a sandbox.** It is a JSON-RPC message format plus a transport. Wrapping `SecureCodeExecutor` in FastMCP gives you a network hop, not an isolation boundary. Isolation is a *deployment* property (kernel, namespace, IAM role), not a protocol property.
2. **STDIO vs HTTP is a trust-boundary decision, not a preference.** The cheatsheet calls STDIO "ideal for local implementation and development." Claude Code uses STDIO because its MCP servers run as subprocesses *on the end user's own laptop* — the user already owns everything the server can reach. Your app is **multi-tenant server-side**. That model does not transfer. See §3.

**A correction you should make regardless of any decision below:** `src/app.py:221` declares a `/mcp` endpoint under a header reading `MCP-COMPLIANT JSON-RPC 2.0 ENDPOINTS`. It implements `tasks/create`, `tasks/get`, `tasks/stop`, `tasks/delete`. MCP defines `initialize`, `tools/list`, `tools/call`, `resources/list`, `resources/read`, `prompts/list`. **No MCP client can speak to this endpoint.** It is JSON-RPC-shaped, not MCP. Given the improvement plan's §4 root-cause finding about claims not matching reality, rename it `/rpc/tasks` or make it genuinely MCP — do not leave it labelled "MCP-compliant."

---

## 1. Question 1 — A FastMCP server for the file-access skill?

### Verdict: **Yes — but it is the *second* thing to do, not the first, and the reason to do it is not the one the lab implies.**

### The weak arguments (don't build on these)
- "MCP is the modern way to expose tools." Your tools already work in-process via `@tool`. Protocol fashion is not a reason.
- "Dynamic discovery." You have 21 static tools in one codebase you control. `create_planning_agent` (`func2.py:1874`) lists them literally. There is nothing to discover.

### The three genuine arguments

**(a) It converts an ambient-context security bug into a structurally impossible one — this is the real prize.**

Your codebase enforces the session boundary *inconsistently*, and I can point at it:

- `search_uploaded_files` (`func2.py:691`) — takes `runtime: ToolRuntime[AgentContext]`, calls `file_manager.list_files(session_id=session_id)`. **Guarded.**
- `_resolve_uploaded_files_for_sandbox` (`func2.py:1343`) — session-checked. **Guarded.**
- `parse_csv_file`, `parse_excel_file`, `parse_pdf_file`, `parse_docx_file`, `parse_pptx_file` (`func1.py:135–412`) — signature is `(file_id: str, query: str = "")`. **No `runtime` parameter at all.** Each calls `file_manager.get_file(file_id)` (`func1.py:94`), which is a bare `self.files.get(file_id)` with **no session filter whatsoever**.

So the guard sits on *enumeration* but not on *reads*. The Phase 3 fix hardened the tool that lists files and left the five tools that actually open them unguarded. Any path that yields a `file_id` from another session — a model hallucinating a UUID it saw in earlier context, a summarizer echoing a `file_id` from the `ARTIFACTS AND GENERATED CODE` section of a compacted transcript, a user pasting one — reads another tenant's document. This is a cross-session IDOR, and the system prompt's instruction "never attempt to reference a file from a different session" is a *request to the model*, not an access control.

An MCP server cannot use `ToolRuntime` or a `ContextVar`. It is a separate process; every call is a standalone JSON-RPC message. That forces `session_id` to become an **explicit, server-verified argument on every single tool**, which is exactly the property you want. MCP's constraint is the fix.

**(b) It gets CPU-bound parsing off the API event loop.**

`parse_csv_file` runs `pd.read_csv` synchronously; `parse_pdf_file` runs PyPDF2 page-by-page extraction. LangChain dispatches sync tools to a threadpool, so they do not hard-block the loop — but they contend on the GIL, and pandas/PyPDF2 work is genuinely CPU-heavy. With `asyncio.Semaphore(100)` (`app.py:73`) advertising 100 concurrent users, one user parsing a 26-page PDF degrades every other user's streaming latency. A separate process with its own CPU allocation fixes this properly.

**(c) Reuse — but only if you actually want it.** An HTTP MCP file server is consumable by Claude Desktop, other agents, or a future service. If nothing outside this app will ever call it, this argument is worth zero. Be honest with yourself about which is true.

### Concrete build

Create `src/mcp_servers/file_server.py`. **Do not re-implement the parsers** — import them, so there is one implementation:

```python
from fastmcp import FastMCP, Context
from pydantic import BaseModel

mcp = FastMCP("File Operations Server")

class SessionScopeError(Exception): ...

def _authorize(file_id: str, session_id: str) -> dict:
    """The check func1.py's parse_* tools currently skip entirely."""
    info = file_manager.get_file(file_id)
    if info is None:
        raise ValueError(f"File {file_id} not found.")
    if info.get("session_id") != session_id:
        # Never leak existence across a tenant boundary.
        raise ValueError(f"File {file_id} not found.")
    return info

@mcp.tool()
async def parse_csv_file(file_id: str, session_id: str, ctx: Context, query: str = "") -> str:
    """Parse and analyze an uploaded CSV file."""
    info = _authorize(file_id, session_id)
    await ctx.info(f"parsing csv {info['filename']}")
    return _parse_csv_impl(info["path"], query)   # shared impl, imported
```

Model the corpus as a **resource**, not a tool — it is passive, read-only data, exactly the cheatsheet's definition:

```python
@mcp.resource("file://session/{session_id}/manifest")
async def session_manifest(session_id: str) -> str:
    return json.dumps(file_manager.list_files(session_id=session_id))
```

Wire it into the agent alongside the existing in-process tools:

```python
from langchain_mcp_adapters.client import MultiServerMCPClient
client = MultiServerMCPClient({
    "files": {"url": "http://127.0.0.1:8081/mcp", "transport": "streamable_http"},
})
mcp_tools = await client.get_tools()
```

### Two real costs you must plan for, not discover later

1. **`session_id` becomes a model-supplied argument.** Right now the LLM never sees it (`AgentContext` injects it out-of-band, deliberately — see the comment at `func2.py:352`). Once it is an MCP tool parameter, the model *can* supply a wrong one. **Mitigation:** do not trust it. Terminate a signed, short-lived session token at the MCP server and derive `session_id` from the token, treating the model's argument as a cross-check only. Otherwise you have replaced an ambient-context bug with a prompt-injection surface.
2. **Token-budget plumbing must stay client-side.** `truncate_for_agent` / `TOOL_OUTPUT_TOKEN_BUDGET` / `large_output_store` / `read_output_chunk` (`func4.py:218–274`, `func2.py:800`) are what keep a 26-page PDF from blowing the context window. The MCP server returns the *full* blob over the wire; truncation and the large-output store must remain on the agent side, or you will reintroduce the `context_length_exceeded` failure Phase 3.5 fixed.

---

## 2. Question 2 — An MCP server for code execution / plotting / calculation?

### Verdict: **Split the skill. Yes for code execution (urgently, but MCP is the interface, not the fix). No for `calculate`/`analyze_text`. No for a separate plotting server.**

This is the question where a blanket "yes" would actively hurt you.

### 2a. `generate_and_execute_code` / `analyze_data_with_code` → **Yes, extract it — this is your highest-severity issue**

Your own improvement plan already reached this conclusion (§Phase 4, line 548): the sandbox *"runs in the same OS process as the FastAPI server itself; a sandbox escape is a full app compromise."* The code confirms it and adds two more specifics:

- `_write_` is `lambda ob: ob` (`func2.py:1117`) — the identity function. The reasoning documented there is sound (`full_write_guard` genuinely breaks pandas column assignment), but the consequence is that RestrictedPython's write-guard layer is **disabled**. Isolation now rests entirely on the `__import__` allowlist.
- That allowlist admits `pandas` and `numpy`. Reaching the real `os` module from inside pandas' object graph is not an exotic exploit; it is a well-known escape class in AST-guarded Python sandboxes.
- The timeout is a daemon thread with `worker.join(timeout=30)` (`func2.py:1232`). The docstring is admirably honest: *"the thread itself keeps consuming CPU until it naturally finishes or the process exits."* A `while True: pass` from one user burns a core of your API server for the life of the process. There is no kill.

An escape today yields: `OPENAI_API_KEY` from the process env, the ECS task role credentials from `169.254.170.2`, every session's files on local disk, and the `file_manager.files` dict for all tenants.

**But here is the part to get right:** if you wrap this in FastMCP and deploy that MCP server as another container that still runs `SecureCodeExecutor` in-process, **you have moved the vulnerability, not fixed it** — and possibly worsened it, since that process may now hold broader network reach. MCP is the *front door*. The isolation must come from the runtime behind it.

**Correct layering:**

```
Agent (ECS service, has OPENAI_API_KEY)
   │  MCP over HTTP (streamable_http), mTLS or signed token
   ▼
Execution MCP server  ← thin: validates, routes, enforces quota. No secrets.
   │  forwards to
   ▼
Isolated runtime  ← the ACTUAL boundary: per-session Fargate task / E2B / gVisor
```

Your plan's §Phase 4 table already researched the backend options and recommended **Path A (E2B managed)** first, **Path B (per-session Fargate + `jupyter_client`)** as the zero-third-party end-state. I concur with that recommendation and have nothing to add to it — it is correct. The only thing I would change is the framing: **build the MCP interface and the isolation runtime as one unit of work.** Shipping the MCP wrapper alone provides no security benefit and risks being mistaken for the fix.

Bonus: a real kernel-backed runtime also removes the "each call is a completely fresh environment" limitation that the system prompt currently spends ~200 words apologizing for and working around via the `artifacts` dict and `write_file`/`read_file` harness (`func2.py:1497–1564`). That whole workaround layer becomes deletable.

### 2b. `calculate` and `analyze_text` → **No. Keep them in-process.**

`calculate` (`func2.py:626`) is an `asteval` expression evaluation — sub-millisecond, no I/O, no filesystem, no secrets. `analyze_text` (`func2.py:648`) is string statistics. Putting these behind a network hop adds serialization, a connection, and a new failure mode to save nothing. A 200ms round-trip on a 0.2ms function is a 1000× overhead for zero benefit.

Not everything needs to be a service. Building an MCP server for `calculate` is the kind of decision that looks architecturally sophisticated in a diagram and is indefensible under review.

### 2c. Plotting → **No separate server. It is already a mode of code execution.**

There is no plot tool to extract. Charts are produced *inside* the sandbox: the agent writes Plotly/Matplotlib code and calls `write_artifact('chart.html', fig.to_html())` — `plotly`, `matplotlib`, `seaborn` are all in `_SANDBOX_ALLOWED_MODULES` (`func2.py:975`). This is the right design; ChatGPT Code Interpreter works the same way. A separate "plot server" would need its own parallel data-loading path and would fragment one coherent capability into two. Plotting comes along for free when you isolate code execution.

### 2d. The `save_as_*` family → **No.**

`save_as_csv/html/json/markdown/txt` (`func2.py:854–961`) write through the `StorageBackend`. They are already thin wrappers over an abstraction that has a working `S3Backend` (`func.py:411`). Point that at real S3 — an MCP layer adds nothing.

---

## 3. Question 3 — Same ECS container? And the right architecture.

### 3a. "Can I put them in the same ECS container?" — Technically yes. For code execution, doing so **forfeits the entire benefit.**

Same container means: same kernel, same PID namespace, same network namespace, same `/proc`, same environment variables, same IAM task role. The escape scenario in §2a is completely unchanged. You would have paid the full complexity cost of MCP for none of the security return.

Precise, differentiated guidance — these are three different answers, not one:

| Component | Placement | Transport | Rationale |
|---|---|---|---|
| **Agent API** (`app.py`) | Its own ECS service behind ALB | — | Holds `OPENAI_API_KEY`; the only internet-facing surface |
| **File MCP server** | **Sidecar container, same ECS task** | HTTP on `127.0.0.1:8081` | Shares the task's network namespace, so no ALB hop and no service discovery. Deploys atomically with the app. Gets its own CPU/memory reservation and crash isolation. Low risk — it reads files the app already reads. |
| **Code execution** | **Separate ECS task/service, ideally per-session** | HTTP via Service Connect / Cloud Map | This is a genuine trust boundary. It must not be co-located under any circumstances. |

**Why STDIO is wrong for your file server, despite the cheatsheet calling it "ideal for local development":** STDIO spawns a subprocess per client. Under `Semaphore(100)`, that is up to 100 Python subprocesses per ECS task, each importing pandas (~150MB RSS). You will OOM the task. STDIO is right for Claude Code (one user, one laptop, one subprocess). It is wrong for a multi-tenant server. Use HTTP over loopback.

### 3b. Hardening the execution task — the specifics that actually deliver the guarantee

If you build the per-session Fargate path (your plan's Path B), these are non-negotiable and each maps to a concrete config:

- **Distinct IAM task role**, scoped by resource policy to `arn:aws:s3:::bucket/sessions/${session_id}/*` only. This is materially stronger than the current app-level `Path(filename).name` check (`func2.py:1497`) because AWS enforces it even if the container is fully compromised, not just if the Python code behaves.
- **No `OPENAI_API_KEY`** — or any other secret — in the execution task's environment. It has no reason to call an LLM.
- **Block task metadata**: without this, an escape curls `169.254.170.2` and holds your task role credentials. Set `ECS_AWSVPC_BLOCK_IMDS=true` on ECS-on-EC2; on Fargate, control via the security group and keep the role minimal.
- **Egress denied by default** in the security group. Data-analysis code has no legitimate outbound need. This alone converts most exfiltration paths into failures.
- `readonlyRootFilesystem: true`, non-root `user`, `linuxParameters.capabilities.drop: ["ALL"]`, hard `cpu`/`memory` limits so a runaway loop starves only itself.
- **Idle-timeout self-termination** for cost control (the ECS-native equivalent of E2B's `pause`/`connect`).

### 3c. **The finding that outranks all MCP work: the app cannot horizontally scale on ECS today.**

You asked about "an AWS ECS deployment setup." Before any MCP question matters, this is disqualifying — set ECS desired count to 2 behind an ALB and the app breaks, because **all session state is per-process in memory**:

| State | Location | Failure at desired-count ≥ 2 |
|---|---|---|
| Conversation checkpoints | `InMemorySaver()` (`app.py:91`) | Turn 2 lands on task B → entire conversation history gone |
| Uploaded-file registry | `FileManager.files` dict (`func1.py:59`) | Upload hits task A, parse hits task B → "File not found" |
| Tasks / SSE streams | `task_manager` (`func3.py`) | `GET /tasks/{id}/stream` hits the task that doesn't own it → stream never resolves |
| User preferences | `short_term_memory` `InMemoryStore` | Preferences vanish per request |
| Artifacts | Local disk under `test/results/` | Download hits the wrong task → 404 |

Every one of these also dies on a routine ECS deployment or task replacement, even at desired-count 1.

The good news: **the abstractions to fix this already exist and are written.** `func.py:411` has a complete `S3Backend`; `get_storage()` (`func.py:448`) dispatches on `STORAGE_BACKEND`. Much of this is configuration plus a checkpointer swap, not new architecture:

- `STORAGE_BACKEND=s3` + real bucket → artifacts and uploads become shared. **Already built.**
- `file_manager.files` dict → derive from the storage backend (list the `uploads/{session_id}/` prefix) or Redis/DynamoDB. This dict is the single most load-bearing piece of in-memory state.
- `InMemorySaver` → `langgraph-checkpoint-postgres` on RDS/Aurora Serverless. Your `app.py:79–90` comment already anticipates exactly this and defers it to Phase 5; for ECS it is a prerequisite, not a later phase.
- `task_manager` / `short_term_memory` → ElastiCache Redis.
- **Interim stopgap only:** ALB sticky sessions get you running at count > 1 today, but do not survive deployments. Treat it as a bridge, not a solution.

**Also raise the ALB idle timeout** (default 60s) above your longest SSE stream, or `/tasks/{task_id}/stream` will be cut mid-task.

### 3d. Two security issues that block internet exposure entirely

1. **No authentication on any endpoint.** No `Depends`, no bearer scheme, nothing — verified across all of `app.py`. Anyone who reaches the ALB can upload files, run code in your sandbox, and read any session's artifacts. `session_id` is a bare UUID acting as a de facto bearer token with no verification.
2. **`allow_origins=["*"]` with `allow_credentials=True`** (`app.py:129–135`). This combination is rejected by browsers per the CORS spec and signals that the origin policy was never actually chosen. Set explicit origins.

Also: the global exception handler (`app.py:149`) returns raw exception types and messages to the client. It is correctly documented as a deliberate aid for the `/demo` observability UI, and it is genuinely useful there — but it must be gated behind an environment flag before production, or it becomes a stack-trace disclosure endpoint.

### 3e. How the industrial references actually work — and which one you should copy

You named three products; they use **three different models**, and picking the wrong one to imitate is a real risk:

| Product | MCP transport | Execution isolation | Trust boundary |
|---|---|---|---|
| **Claude Code** | STDIO subprocess on the user's own machine | The user's own machine | The laptop. The user already owns everything. |
| **ChatGPT Code Interpreter** | n/a (internal) | Per-user gVisor/Firecracker microVM, no network, ephemeral FS, hard timeout | Server-side, multi-tenant |
| **MS Copilot** | Remote MCP over HTTP with per-user OAuth | Server-side | Server-side, per-user identity |

Your app is **multi-tenant, server-side**. Therefore:

- **Copy ChatGPT's model for code execution** — per-session microVM-grade isolation with no network. Your plan's Path A/Path B are both faithful to this.
- **Copy Copilot's model for MCP transport** — HTTP with real per-user authentication.
- **Do not copy Claude Code's STDIO model.** It is the one most prominent in the lab material and the one least applicable to your deployment, because its security rests on an assumption — that the server runs on hardware the user already controls — that is false for you.

---

## 4. Prioritized action table

Ordered high-value/low-effort → low-value/high-effort. Effort assumes one engineer familiar with this codebase.

| # | Action | Value | Effort | Concrete first step |
|---|---|---|---|---|
| 1 | **Close the `parse_*` cross-session IDOR.** Add `runtime: ToolRuntime[AgentContext]` to all five parsers; add `session_id` param to `FileManager.get_file` and reject mismatches with an indistinguishable "not found" | **Critical** | ~1–2 h | `func1.py:94` `get_file`, then `func1.py:135/178/239/302/356` |
| 2 | **Fix CORS.** Replace `allow_origins=["*"]` + `allow_credentials=True` with an explicit origin list | **Critical** | 15 min | `app.py:129–135` |
| 3 | **Gate the global exception handler** behind `DEBUG_ERRORS` env flag; generic 500 otherwise | High | 30 min | `app.py:149` |
| 4 | **Rename `/mcp` → `/rpc/tasks`** and drop the "MCP-COMPLIANT" headers; it implements none of MCP's methods | Medium (trust/accuracy) | 30 min | `app.py:164, 217, 221` |
| 5 | **Turn on the S3 backend** you already wrote — `STORAGE_BACKEND=s3` + real bucket + task-role S3 perms | **High** | 2–4 h | `func.py:448`, already implemented |
| 6 | **Add authentication.** Bearer/JWT dependency on every route; bind `session_id` to the authenticated principal so it stops being a de facto bearer token | **Critical** | 1–2 d | `app.py`, FastAPI `Depends` |
| 7 | **Raise ALB idle timeout** above the longest SSE stream | Medium | 15 min | ALB attribute, infra config |
| 8 | **Externalize `FileManager.files`** to the storage backend or Redis — the single biggest blocker to desired-count > 1 | **High** | 1–2 d | `func1.py:59` |
| 9 | **Swap `InMemorySaver` → Postgres checkpointer** (`langgraph-checkpoint-postgres`, RDS/Aurora Serverless) | **High** | 2–3 d | `app.py:91` |
| 10 | **Move `task_manager` / `short_term_memory` to Redis** (ElastiCache) | High | 3–5 d | `func3.py` |
| 11 | **Build the file MCP server** (FastMCP, HTTP, sidecar in the same ECS task). Import existing parsers — do not reimplement. Expose the corpus as a **resource**; terminate a signed session token server-side | Medium–High | 3–5 d | New `src/mcp_servers/file_server.py` |
| 12 | **Isolate code execution — MCP interface + real runtime as ONE unit.** Start with Path A (E2B managed) per your Phase 4 decision; separate ECS task, scoped IAM role, no secrets, egress denied, IMDS blocked | **Critical (highest severity, highest effort)** | 1–2 wk | `func2.py:1041` `SecureCodeExecutor` |
| 13 | **Path B: per-session Fargate sandbox** (`jupyter_client` kernel gateway, Service Connect, warm pool, idle self-termination). Only if zero-third-party is a hard requirement | High | 3–4 wk | Plan §Phase 4, Path B |
| 14 | ~~MCP server for `calculate` / `analyze_text`~~ | **Negative** | — | **Do not build.** 1000× overhead on a sub-ms pure function |
| 15 | ~~Separate plotting MCP server~~ | **Negative** | — | **Do not build.** Already a mode of code execution; would fragment one capability |

### If you do only three things
**#1** (real, exploitable, one hour) → **#5 + #8** (makes ECS deployment actually viable) → **#12** (the one genuinely dangerous thing in the system).

### The single most important framing
**MCP is an interface decision. Isolation is a deployment decision. Do not let the first be mistaken for the second.** Your file server is a legitimate MCP use case whose real payoff is forcing session scoping to be explicit. Your code executor needs a kernel boundary, and wrapping it in FastMCP without one would produce the appearance of a fix while changing nothing about the actual risk.
