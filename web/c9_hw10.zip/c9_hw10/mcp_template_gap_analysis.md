# MCP Template Evaluation & Gap Analysis
## Target: ReAct agent on FastAPI + 150 streamable-HTTP MCP servers on AWS ECS, 100 concurrent users

**Date:** 2026-10-27
**Reviewed artifacts:**
- `lab/fastapi-multi-server-mcp-main/` — hereafter **R1** (multi-server-in-one-app, official `mcp` SDK 1.9.4)
- `lab/template-mcp-server-main/` — hereafter **R2** (Red Hat `template-mcp-server`, `fastmcp==2.14.2`)

**Review stance:** findings are grounded in the actual source of both repos (file:line cited throughout) and in the current FastMCP documentation for the two facts that drive the architectural recommendation (stateless HTTP for horizontal scaling; synchronous tool functions blocking the event loop). Nothing here is asserted from memory where the repo or the docs could be checked.

---

## 0. Executive summary — the five things that matter

1. **Neither repo is production-ready for your scale.** R2 *claims* it ("A production-ready template…", `README.md:9`); R1 makes no such claim (it says "comprehensive", and its own README only has a small "Production" deploy section). So the premise that *both* claim industrial grade is not accurate — only R2 does, and **that claim does not survive review**: R2 performs a *blocking, synchronous* HTTP call to your identity provider on the authorization path of every request (`oauth/introspection.py:46`, `:113`), inside an `async def` middleware. On a single-worker event loop that serializes all 100 concurrent users behind one IdP round trip each, with a 10s timeout. This is a hard throughput ceiling and the single most serious defect found in either repo.

2. **R2 is not horizontally scalable as shipped.** It calls `server.mcp.http_app(path="/mcp")` (`src/api.py:39`) and **never sets `stateless_http`**, which I confirmed is absent from the entire repo. FastMCP's documented default is stateful; the docs are explicit that *"For horizontally scaled deployments, enable stateless HTTP mode… each request creates a fresh transport context, eliminating the need for session affinity."* With a stateful in-memory session manager and no event store, a multi-task ECS service behind an ALB will hand clients `404 / session not found` whenever a request lands on a task that doesn't own the session. R2's own Kubernetes manifest sets `replicas: 1` (`deployment/openshift/deployment.yaml`) — the template is honest about being single-instance, just not loudly.
   **R1 gets this right**: every server is created with `stateless_http=True` (`servers/weather.py:13`, `servers/currency.py:13`, etc.). This is R1's one genuine architectural advantage and it is the single most important property for your deployment.

3. **Use neither as-is; take R1's transport/compose shape and R2's engineering scaffolding, and build a third thing.** The right split is in §5. Standardizing on one template is correct — but it must be *your* template, seeded from R2's repo hygiene with R1's statelessness and composition pattern, and with roughly a dozen production concerns neither repo has (connection pooling, token caching, concurrency limits, structured request-scoped logging, OTel, graceful drain, per-tool authz, idempotency).

4. **Your largest unsolved problem is not the server template — it is tool discovery across 150 servers.** Neither repo addresses it at all. 150 servers × ~5–20 tools = 750–3,000 tool definitions. Naively concatenating those into one ReAct prompt is 150k–600k+ tokens of tool schema per turn: economically and technically unworkable, and tool-selection accuracy collapses well before the context limit does. The industry answer is a **two-tier catalog/gateway**: a registry that indexes tool metadata and exposes a small fixed toolset (`search_tools`, `describe_tool`, `invoke_tool`) to the agent, which then binds only the 5–15 relevant tools per turn. R2 gestures at this — its tool docstrings carry structured `TOOL_NAME/USECASE/INSTRUCTIONS/INPUT_DESCRIPTION/RELATED_TOOLS` metadata (`tools/multiply_tool.py:21-32`) — but never builds an index or a search path. That metadata convention is R2's most underrated asset and you should keep it and make it machine-readable. See §6.

5. **Your `mcp_server.json` onboarding goal is directly supported by current FastMCP, and neither repo uses it.** `fastmcp.server.create_proxy(config)` accepts exactly the `{"mcpServers": {name: {url, transport}}}` shape VS Code/Windsurf use, and namespaces components automatically (`weather_get_forecast`, `calendar_add_event`). That is the mechanism for your single-config onboarding — but use it as the **gateway's loader**, not as a blind aggregator, for the token-cost reason in point 4.

> **One more hard constraint neither template respects:** R2 pins `fastmcp==2.14.2`. FastMCP has since shipped 3.x and 4.x lines. Composition and middleware existed in 2.x, but the current composition/proxy/transform/auth-provider APIs — including the `create_proxy(config)` and `mount(namespace=...)` signatures quoted below — are documented against the newer line and have moved. Building 150 servers on a pinned 2.14.2 commits you to a line you will have to migrate off. Confirm the current release and verify these signatures against it before you fix your floor version.

---

## 1. Are the "production-ready / industrial grade" claims correct?

| | R1 | R2 |
|---|---|---|
| Claim actually made | None of this kind. README says "comprehensive"; has a "Production" deployment section | **Yes** — `README.md:9` "A production-ready template for developing MCP servers…" |
| Verdict | **N/A — no claim to falsify.** It is an honest, well-shaped *tutorial* for multi-server mounting | **Not substantiated.** Correct on repo hygiene and packaging; wrong on the runtime characteristics that "production" means at concurrency |

**Where R2's claim is defensible:** CI/CD (4 GitHub workflows incl. pre-commit, test, release), dependabot, `ruff` + `mypy` + `bandit` + `safety`, pre-commit hooks, 80% coverage gate (`Makefile:62`), 13 test modules, `py.typed`, structured logging via `structlog`, settings as validated Pydantic `BaseSettings` with per-field metadata, container + Kubernetes/OpenShift manifests with liveness/readiness probes and resource limits, real docs (architecture, auth, deployment, CI/CD, tutorial), devcontainer, `CHANGELOG`, `SECURITY.md`, issue/PR templates, Makefile DX. **This is genuinely strong and well above average.** It is what you should copy.

**Where the claim fails** — these are production-*readiness* properties, not polish:

- **Blocking I/O on the hot path.** `Rfc7662Introspector.introspect` is a **sync `def`** issuing **sync `httpx.post`** (`introspection.py:43,46`), reached from `async def AuthorizationMiddleware.dispatch` (`api.py:82,121`). Every authenticated request stalls the entire event loop for the duration of the IdP call. No cache, no connection reuse (new TCP+TLS per call), no circuit breaker. Under 100 concurrent users this is the bottleneck, full stop.
- **Stateful transport, single replica.** §0.2. "Production-ready" and "cannot be scaled horizontally without code change" cannot both be true.
- **`BaseHTTPMiddleware` wrapping a streaming transport.** Two middlewares use `BaseHTTPMiddleware` (`api.py:82,134`). It is well known to interact badly with long-lived streaming/SSE responses and adds per-request task/queue overhead. For a *streamable HTTP* MCP server this is the wrong middleware primitive — pure ASGI middleware is.
- **The dev-auth middleware reads the whole request body** (`api.py` `await request.body()` in `LocalDevelopmentAuthorizationMiddleware`) and reconstructs `receive` — defeats streaming, and mutates private Starlette internals (`request.headers.__dict__["_list"].append(...)`). Dev-only, but it's in the shipped middleware stack and gated purely on env config.
- **Auth verifies then discards identity.** `token_info = OAuth2Handler.verify_authorization_header(...)` (`api.py:121`) is checked for truthiness and thrown away. No principal on `request.state`, no scope/claim enforcement, **no per-tool authorization**, no audience (`aud`) validation. The MCP authorization spec requires a server to reject tokens not issued *for it* (RFC 8707 resource indicators / RFC 9728 protected-resource metadata) precisely to prevent token-passthrough confusion. R2 publishes the discovery documents (`api.py` `.well-known/*`) but does not enforce audience.
- **It implements its own OAuth Authorization Server** (`/auth/authorize`, `/auth/token`, `/auth/register`, `/auth/revoke`, `/auth/introspect` + `oauth/service.py`, Postgres-backed). Rolling your own AS is a significant security liability and, at 150 servers, 150 copies of one. You want the servers to be **Resource Servers only**, delegating to one real IdP (Cognito / Entra / Okta / Keycloak).
- **Session cookie is never `Secure`** — `https_only=False` hardcoded (`api.py:253`), including when `ENVIRONMENT=production`.
- **CORS defaults are unsafe-by-shape:** `CORS_ORIGINS=["*"]` with `CORS_CREDENTIALS=True` (`settings.py`). That combination is rejected by browsers and signals the defaults weren't pressure-tested.
- **The template teaches the wrong async pattern.** `multiply_numbers` is a sync `def` whose docstring states *"CPU-bound operation - uses def for computational tasks"* (`multiply_tool.py:13,29`). FastMCP's own documentation says the opposite: *"While synchronous tools work seamlessly in FastMCP, they can block the event loop during execution. For CPU-intensive or potentially blocking synchronous operations…"* use `anyio.to_thread.run_sync`. A template that codifies this as guidance will propagate event-loop stalls into all 150 of your servers. **This is the highest-leverage single fix**, because it's a convention, not a line of code.
- **Liveness and readiness point at the same trivial handler** (`deployment.yaml`); `/health` returns a static dict (`api.py`) and never consults Postgres or the IdP, even though `StorageService.is_healthy()` exists (`storage_service.py:78`) and is used only inside the storage module itself (`storage_service.py:182`), never wired to the HTTP endpoint. A task that has lost its DB stays "ready" and keeps taking traffic.
- **No request-ID/correlation middleware, no OpenTelemetry, no metrics, no rate limiting, no concurrency cap, no graceful-drain handling, no request timeouts.**
- **`uvicorn.run(app, …)` with no `workers`, no `--proxy-headers`** (`src/main.py`). Behind an ALB, client IP and scheme will be wrong, which also breaks the OAuth redirect URLs it builds from `MCP_HOST_ENDPOINT`.
- **DSN built by f-string without URL-encoding** the password (`storage_service.py:54`) — breaks or misparses on `@`, `/`, `:`, `#` in a generated secret.

**And R1's real defects** (judged as a template, not against a claim it didn't make):

- **No HTTP connection pooling.** `async with httpx.AsyncClient() as client:` *inside each request method* (`utils/api_clients.py:21,36`) creates and tears down a client — and therefore a TCP+TLS handshake — per upstream call. At 100 concurrent users this is pure latency and socket churn, and forfeits HTTP/2 and keep-alive. A module-level pooled `AsyncClient` with explicit limits and timeouts, created in `lifespan`, is the correct pattern.
- **No timeouts anywhere.** httpx defaults apply; no per-tool deadline. A slow upstream pins a worker slot indefinitely.
- **No auth, no rate limiting, no input validation beyond type hints.**
- **Error handling leaks upstream internals to the model.** `except Exception as e: raise Exception(f"Failed to get weather data: {str(e)}")` (`servers/weather.py`, and the same shape in all four servers) — broad catch, loses the traceback, and feeds raw upstream error text (which can include URLs containing the API key, as in `currency.py`'s `/{api_key}/latest/...` path) into a model-visible error string. **Credential-leak-into-LLM-context risk.**
- **`retry_on_failure` is defined and never used** (`api_clients.py:43`) — dead code; and as written it retries *all* exceptions including non-idempotent POSTs and 4xx.
- **Fake health check:** `{"status": "healthy", "servers": 5}` with four servers mounted (`main.py:57`) — hardcoded, wrong, and checks nothing.
- **Redundant lifespan.** It enters `session_manager.run()` for all four servers (`main.py:19-24`) although all four are `stateless_http=True`; harmless but shows the pattern wasn't reasoned through.
- **No structured logging, no tests beyond happy-path mocks, no typing discipline, no CI, no lint/format config, single-stage Dockerfile, `version: '3.8'` obsolete compose key, hardcoded port 10000, Redis declared in compose and never used.**
- Uses `mcp.server.fastmcp` (official SDK's bundled FastMCP 1.x), which lacks the middleware / auth-provider / composition / transform machinery of the standalone FastMCP 2.x+ that you will need.

### Scorecard

| Dimension | R1 | R2 |
|---|---|---|
| Streamable HTTP correctness | ✅ stateless, scale-ready | ⚠️ stateful, needs affinity |
| Async / non-blocking discipline | ⚠️ async but no pooling/timeouts | ❌ blocking IdP call on hot path |
| Horizontal scalability | ✅ | ❌ (`replicas: 1`) |
| AuthN / AuthZ | ❌ none | ⚠️ extensive but flawed; no per-tool authz, no `aud` |
| Observability | ❌ | ⚠️ structlog only; no OTel/metrics/req-id |
| Testing & CI/CD | ❌ | ✅ |
| Packaging, typing, lint, docs | ❌ | ✅ |
| Container & deploy manifests | ⚠️ basic | ✅ (OpenShift; needs ECS translation) |
| Multi-server composition | ✅ the useful demo | ❌ single server only |
| Tool-metadata convention | ❌ | ✅ best idea in either repo |
| Tool discovery at 150-server scale | ❌ | ❌ |
| **Fit as your production base** | **~25%** | **~55%** |

---

## 2. Should you use one template or both?

**One — a new internal template, seeded from R2, with R1's transport decisions ported in.** Reasons:

1. **150 servers means the template *is* the product.** Every defect is multiplied 150×; every fix must be a template-version bump you can roll out, not 150 hand edits. Two templates = two divergent fleets.
2. **R1 and R2 answer different questions and are not alternatives.** R1 answers *"how do I put several MCP servers in one process/container?"* — which you explicitly need for the servers you're co-locating. R2 answers *"what does a well-engineered single-server repo look like?"* — which you need for the ones that get dedicated containers. Taking "both" as templates means maintaining two; taking both as *inputs* to one is correct.
3. **You need a shape neither has**: one template that supports **both** the co-located-multi-server and the one-server-per-container deployment modes from the same code, by making the server a *library object* (a `FastMCP` instance + its tool package) and the ASGI app a thin composition layer. Then "which container does this live in?" becomes a deployment decision, not a code rewrite.

**Concretely:** take R2's repository skeleton (packaging, CI, Makefile, settings, logging, tests, containerization, docs, and the tool-metadata docstring convention), **delete its OAuth Authorization Server entirely**, replace auth with a resource-server-only async validator, set `stateless_http=True`, replace `BaseHTTPMiddleware` with pure-ASGI middleware, and adopt R1's `app.mount(name, sub_app)` composition for the co-location mode.

---

## 3. What a professional MCP developer actually uses and does — and why

### 3.1 Protocol & framework
| Tool / practice | Why |
|---|---|
| **FastMCP (standalone, current major)** over the SDK's bundled FastMCP | Middleware, auth providers, server composition/`mount`, namespacing, tool transforms, proxying, `create_proxy(config)`. R2's pin at 2.14.2 predates most of it. |
| **`stateless_http=True` as the default** | The one switch that makes a server horizontally scalable; documented as the mechanism that removes session affinity. Opt *into* statefulness only where a tool genuinely needs a session. |
| **`json_response=True` for unary tools** | `http_app(json_response=...)` returns a plain JSON response instead of an SSE stream for request/response tools. Fewer long-lived connections, far friendlier to ALB idle timeouts and to your concurrency budget. Keep SSE only where a tool streams progress. |
| **Pin the protocol revision; test against it** | MCP revises (`2025-03-26`, `2025-06-18`, …). 150 servers must not drift independently. |
| **MCP Inspector** (`npx @modelcontextprotocol/inspector`) | Interactive conformance/dev loop. R1 ships Inspector screenshots (`inspector/*.png`) — good instinct, no automation. |
| **Protocol conformance test suite in CI** | Assert `initialize`, `tools/list`, `tools/call`, error codes, schema validity, and `stateless` behavior for *every* server from one shared pytest suite. At 150 servers, manual verification is not a plan. |

### 3.2 Async & concurrency (your explicit requirement)
| Practice | Why |
|---|---|
| **`async def` tools for all I/O; `anyio.to_thread.run_sync` for anything blocking or CPU-bound** | Per FastMCP docs, a sync tool body runs on and blocks the event loop. This is the #1 cause of "my MCP server falls over at load". R2 teaches the inverse. |
| **One pooled `httpx.AsyncClient` per upstream, created in `lifespan`** with `Limits(max_connections, max_keepalive_connections)` and explicit `Timeout(connect/read/write/pool)` | Eliminates per-call TLS handshakes (R1's defect), bounds fan-out, surfaces pool exhaustion as a fast error instead of unbounded queueing. |
| **Bounded concurrency per tool** (`asyncio.Semaphore`) + **server-level in-flight cap** | Backpressure. Without it 100 concurrent users × N tool calls can open unbounded upstream connections and OOM the task. Shed load with `429` instead. |
| **Hard per-tool deadline** (`asyncio.timeout`) shorter than the client's and the ALB's | Prevents one slow upstream from consuming the concurrency budget. Order must be: tool deadline < agent HTTP timeout < ALB idle timeout. |
| **`asyncio.gather` / `TaskGroup` for independent fan-out**, never sequential awaits in a loop | Latency. Relevant both inside tools and in the agent's parallel tool-call execution. |
| **Never block the loop with sync DB/crypto/file I/O**; `asyncpg` pool (R2 does this correctly) | Same reason. |
| **Retry with jittered exponential backoff + circuit breaker**, idempotent operations only | R1's unused `retry_on_failure` retries everything including POSTs with a fixed `2**n` — thundering herd. |
| **uvicorn workers sized to CPU, one event loop per worker; `--proxy-headers`** | Python is single-core per process. With ECS, prefer *more tasks* over more workers (cleaner scaling signal, simpler health), but never 1 worker on a 2+ vCPU task. |
| **Load-test with a realistic MCP client, not `ab`** | Must exercise `initialize` + `tools/list` + `tools/call` and streaming. Measure p50/p95/p99 and error rate at 1×, 2×, 5× expected concurrency. |

### 3.3 Security
OAuth 2.1 **Resource Server** posture only (never your own AS); **validate `aud`/resource indicator** (RFC 8707) and reject tokens not minted for this server; publish **RFC 9728** protected-resource metadata; **cache token introspection** (or prefer local JWT/JWKS verification with cached keys) — this removes R2's per-request IdP round trip entirely; **per-tool authorization** from scopes/claims, not a binary gate; secrets from **AWS Secrets Manager via ECS task-definition `secrets`** (never env-baked, never `.env` in image); **least-privilege task roles, one per server**; **tool-level input validation via Pydantic** beyond type hints; **output sanitization** so upstream errors and URLs containing API keys never reach model context (R1's live risk); **prompt-injection awareness** — tool *output* is untrusted input to your agent; **egress allow-lists** per task; **`bandit` + `safety`/`pip-audit` + SBOM + image scanning in CI** (R2 has the first two); **audit log of every tool invocation** with principal, args hash, outcome.

### 3.4 Observability
Structured JSON logs with a **request/trace/session correlation ID** propagated agent → gateway → server → upstream (neither repo has this and at 150 servers you cannot debug without it); **OpenTelemetry** traces with a span per tool call, exported to X-Ray/OTLP via the ADOT sidecar; **RED metrics per tool** (rate, errors, duration) — not just per server; **`/health` (liveness, trivial) and `/ready` (dependency-checked, drains on failure)** as separate endpoints; alarms on p99 latency, 5xx rate, pool saturation, task restarts.

### 3.5 Tool design — the part that decides whether your agent works
**Tool descriptions are prompt engineering, and they are your real product surface.** Practices: ≤ ~20 high-value tools visible per turn; name tools by intent (`get_customer_invoices`, not `query_db`); descriptions that state *when to use and when not to*, with examples and failure modes; **structured, machine-readable metadata per tool** (R2's `USECASE/INSTRUCTIONS/INPUT_DESCRIPTION/EXAMPLES/PREREQUISITES/RELATED_TOOLS` is the right idea — promote it from docstring prose to a typed annotation so it can be indexed); concise, token-budgeted outputs with pagination/truncation (a tool returning 50KB of JSON will wreck your context and your bill); **actionable** error messages that tell the model how to retry; annotations for `readOnlyHint`/`destructiveHint`/`idempotentHint`; **evaluate tool-selection accuracy with a regression set** — treat description changes like code changes.

### 3.6 Fleet operations at 150 servers
A **generator/cookiecutter** from the one template; **template versioning with automated fan-out PRs** (dependabot-style); a **central registry** of server name → URL → auth → owner → tools → schema hash, which *generates* `mcp_server.json` rather than being hand-maintained; **contract tests** so a tool-schema change is a detectable breaking change; **a shared library** (`mcp-common`) for middleware, auth, logging, HTTP clients, error mapping — so one fix ships once; **blue/green or canary** per server; cost controls (Fargate right-sizing, ARM/Graviton, scale-to-low off-hours, aggressive consolidation of low-traffic servers).

---

## 4. Gap analysis

Severity: **P0** = blocks your stated goal / production outage class. **P1** = will hurt badly at 100 concurrent or 150 servers. **P2** = quality/maintainability.

### 4.1 R2 (`template-mcp-server`)

| # | Gap | Sev | Evidence | Fix |
|---|---|---|---|---|
| 1 | Blocking sync `httpx` IdP call on every authenticated request, inside async middleware | **P0** | `oauth/introspection.py:43,46` & `:110,113`; `api.py:121` | Async `httpx.AsyncClient` from a pooled lifespan client; **or** local JWT+JWKS verification. Add a TTL cache. |
| 2 | Stateful transport; `stateless_http` never set | **P0** | `api.py:39`; absent repo-wide; `deployment.yaml` `replicas: 1` | `http_app(path="/mcp", stateless_http=True, json_response=True)` |
| 3 | No token-validation cache → IdP is a hard dependency on every call, and a SPOF | **P0** | `handler.py:68-80` | TTL cache keyed on token hash; circuit breaker + fail-closed |
| 4 | Template codifies sync `def` for CPU-bound tools | **P0** (convention) | `multiply_tool.py:13,29` | Rewrite guidance to `async def` + `anyio.to_thread.run_sync`; add a lint rule |
| 5 | `BaseHTTPMiddleware` around a streaming transport | **P1** | `api.py:82,134` | Pure ASGI middleware |
| 6 | Dev middleware buffers full body + mutates Starlette internals | **P1** | `api.py` `LocalDevelopmentAuthorizationMiddleware` | Delete from the production template |
| 7 | Identity verified then discarded; no scopes, no per-tool authz | **P1** | `api.py:121` | Attach principal to `request.state`; FastMCP middleware enforcing per-tool scopes |
| 8 | No `aud`/resource-indicator validation (token passthrough risk) | **P1** | `handler.py:82-101` | Enforce `aud` == this server's resource URI (RFC 8707) |
| 9 | Ships its own OAuth Authorization Server | **P1** | `oauth/{routes,service,controller}.py` | Delete; Resource Server only, one central IdP |
| 10 | Session cookie never `Secure`; CORS `*` + credentials | **P1** | `api.py:253`; `settings.py` | `https_only=True` in prod; explicit origin allow-list |
| 11 | Liveness == readiness == static dict; `is_healthy()` unused | **P1** | `api.py` `/health`; `storage_service.py:78` (not wired to `/health`); `deployment.yaml` | Split `/health` vs `/ready`; `/ready` checks DB + IdP |
| 12 | No correlation ID, no OTel, no metrics | **P1** | repo-wide | Request-ID ASGI middleware + OTel + per-tool RED metrics |
| 13 | No rate limiting, no concurrency cap, no request timeout | **P1** | repo-wide | Semaphore + `asyncio.timeout` + `429` shedding |
| 14 | Single uvicorn process, no `proxy_headers`, no graceful-drain tuning | **P1** | `src/main.py` | `proxy_headers=True`, `forwarded_allow_ips`, `timeout_graceful_shutdown`; SIGTERM drain |
| 15 | `fastmcp` pinned to 2.14.2, several majors behind | **P1** | `pyproject.toml` | Verify current release; adopt before building 150 servers |
| 16 | No ECS/Fargate artifacts (OpenShift only) | **P1** | `deployment/openshift/*` | Task definition, service, ALB target group, ASG policy, Terraform/CDK module |
| 17 | Single-server only; no multi-server co-location mode | **P1** | `api.py:372` `app.mount("/", mcp_app)` | Add composition mode (R1's pattern) |
| 18 | Tool metadata is prose in docstrings, not machine-readable | **P1** | `multiply_tool.py:21-32` | Typed `ToolMeta` model, emitted into annotations **and** the catalog index |
| 19 | DSN f-string without URL-encoding the password | **P2** | `storage_service.py:54` | `urllib.parse.quote_plus` or pass kwargs |
| 20 | Container: not multi-stage, `:latest` base, installs from `pyproject.toml` (no lockfile) → non-reproducible builds | **P2** | `Containerfile` | Multi-stage, digest-pinned base, `uv sync --frozen` with a committed lock |
| 21 | Broad `except Exception` returning `{"status":"error", "error": str(e)}` from tools | **P2** | `multiply_tool.py`, `code_review_tool.py` | Typed errors; MCP `isError`; never leak internals |
| 22 | Module-level mutable global `_local_development_token` | **P2** | `api.py:31` | Delete with the dev middleware |
| 23 | `mypy` configured permissively (`disallow_untyped_defs = false`) | **P2** | `pyproject.toml` | Strict mode for a template |

### 4.2 R1 (`fastapi-multi-server-mcp`)

| # | Gap | Sev | Evidence | Fix |
|---|---|---|---|---|
| 1 | No authentication or authorization of any kind | **P0** | repo-wide | Resource-server auth as above |
| 2 | New `httpx.AsyncClient` per call — TLS handshake per upstream request | **P0** | `utils/api_clients.py:21,36` | Pooled module/lifespan client with `Limits` + `Timeout` |
| 3 | No timeouts, no concurrency cap, no rate limiting | **P0** | repo-wide | As above |
| 4 | Upstream error text (incl. URLs containing API keys) propagated into model-visible errors | **P0** | `servers/weather.py` & all servers; `currency.py` puts the key in the URL path | Catch narrowly; map to sanitized typed errors; redact |
| 5 | Fake/incorrect health check; no readiness | **P1** | `main.py:57` | Real `/health` + `/ready` |
| 6 | No observability at all (no structured logs, IDs, metrics, traces) | **P1** | repo-wide | As §3.4 |
| 7 | `retry_on_failure` dead, and unsafe as written (retries non-idempotent + 4xx) | **P1** | `api_clients.py:43-58` | Use `tenacity` / `httpx` transport retries, idempotent-only, jittered |
| 8 | No CI, no lint/format/type config, happy-path-only mocked tests | **P1** | repo-wide | Adopt R2's CI, ruff/mypy/bandit, coverage gate |
| 9 | Redundant `session_manager.run()` despite `stateless_http=True` | **P2** | `main.py:19-24` | Remove |
| 10 | Dockerfile single-stage, `curl` installed only for healthcheck, no lockfile/digest pin | **P2** | `Dockerfile` | Multi-stage, pinned digest |
| 11 | Hardcoded port 10000, `config.py` uses deprecated `class Config` | **P2** | `main.py:61`; `utils/config.py` | Env-driven; `SettingsConfigDict` |
| 12 | Compose declares unused Redis; obsolete `version: '3.8'` | **P2** | `docker-compose.yml` | Remove or use |
| 13 | README project structure doesn't match actual filenames (`weather_server.py` vs `weather.py`) | **P2** | `README.md` vs `servers/` | Fix |
| 14 | Secrets via `.env` + `COPY . .` risks baking `.env` into the image (no `.dockerignore`) | **P1** | `Dockerfile`; no `.dockerignore` | Add `.dockerignore`; Secrets Manager |
| 15 | Uses bundled SDK FastMCP; no middleware/composition/auth primitives | **P1** | `servers/*.py` imports | Move to standalone FastMCP |

### 4.3 Gaps in **both** (your real backlog — nothing in either repo addresses these)

| # | Gap | Sev | Why it matters to you specifically |
|---|---|---|---|
| B1 | **No tool discovery / catalog for 150 servers** | **P0** | 750–3,000 tools cannot be put in one prompt. Blocks the core goal. §6 |
| B2 | **No `mcp_server.json` loader / gateway** | **P0** | Your stated onboarding model. `create_proxy(config)` is the primitive; the registry + gateway is the build. |
| B3 | **No central server registry / service discovery** | **P0** | 150 URLs, auth modes, owners, health. Must generate the config, not hand-edit it. |
| B4 | **No agent-side MCP client lifecycle management** | **P0** | 150 persistent client sessions × 100 concurrent turns. Needs a pooled, lazily-connected, circuit-broken client manager with per-server timeouts — or the agent app becomes the bottleneck. Neither repo has an agent-side story (R2's `examples/langgraph_client.py` is a single-server demo script). |
| B5 | **No graceful SIGTERM drain contract with the ALB** | **P1** | ECS deploys will kill in-flight tool calls and surface as agent errors. Needs deregistration delay + drain-aware shutdown. |
| B6 | **No ECS/ALB routing design** (path vs host based, 150 target groups vs a gateway) | **P1** | ALB has per-listener rule limits; 150 independent path rules is unwieldy and costly. Argues strongly for the gateway in §5. |
| B7 | **No idempotency keys / replay protection for mutating tools** | **P1** | Agents retry. Without idempotency, retries double-write. |
| B8 | **No cost/token governance on tool outputs** | **P1** | Unbounded tool output is the #1 driver of LLM spend in agentic systems. |
| B9 | **No tool-selection evaluation harness** | **P1** | With 3,000 tools, retrieval quality *is* your accuracy. Needs a labeled eval set + CI gate. |
| B10 | **No multi-tenant / per-user credential propagation design** | **P1** | 100 users hitting tools that act on *their* data requires per-request identity to flow agent → server → upstream. R2 discards identity (4.1 #7); R1 has none. |
| B11 | **No shared `mcp-common` library or server generator** | **P1** | Fleet maintainability. One fix × 150 repos is not viable. |
| B12 | **No load/soak testing** | **P1** | Every concurrency claim here is a hypothesis until measured. |
| B13 | **No contract/schema-drift detection** | **P2** | A silent tool-schema change breaks the agent at runtime. |

---

## 5. Recommended target architecture

```
                     ┌──────────────────────────────┐
  Browser UI ───────▶│  Agent API (FastAPI, ECS)    │
   (100 concurrent)  │  ReAct loop, SSE to UI       │
                     │  MCP client pool + breakers  │
                     └──────────┬───────────────────┘
                                │ streamable HTTP + Bearer
                     ┌──────────▼───────────────────┐
                     │  MCP Gateway / Catalog (ECS) │  ◀── mcp_server.json
                     │  search_tools / describe_tool│      (generated from registry)
                     │  invoke_tool  (+ index)      │
                     └──────────┬───────────────────┘
                   ┌────────────┼────────────┐
         ┌─────────▼───┐  ┌─────▼───────┐  ┌─▼─────────────────┐
         │ ECS svc A   │  │ ECS svc B   │  │ ECS svc C         │
         │ 1 server    │  │ 1 server    │  │ N co-located      │
         │ /mcp        │  │ /mcp        │  │ /a/mcp /b/mcp ... │
         └─────────────┘  └─────────────┘  └───────────────────┘
          all: stateless_http=True, json_response=True, RS-only auth
```

**Key decisions and why:**

1. **One internal template, two deployment modes.** The unit of code is a *tool package* + a `FastMCP` instance. `app_single.py` serves one; `app_composed.py` mounts many (R1's pattern) at `/{name}/mcp`. Co-location decided by traffic and blast radius, not by code.
2. **`stateless_http=True` everywhere, `json_response=True` for unary tools.** No session affinity, no sticky ALB config, trivially horizontally scalable, far fewer long-lived connections.
3. **Gateway, not 150 direct routes.** The gateway owns `mcp_server.json`, health, namespacing, and — critically — the tool catalog. It collapses B6 (ALB rule sprawl), B2, and B1 into one component. Keep it thin and stateless so it scales the same way.
4. **Resource-server auth, one IdP, local JWT+JWKS validation with cached keys.** Removes R2's P0 blocking introspection and its IdP SPOF. Enforce `aud` per server. Propagate principal for per-tool authz and per-user upstream credentials (B10).
5. **Registry as source of truth** → generates `mcp_server.json`, ECS task definitions, and the catalog index. Hand-maintaining 150 entries will not survive contact with reality.
6. **Observability baked into `mcp-common`**: request-ID propagation, OTel spans per tool call, per-tool RED metrics. Non-optional at 150 servers.

### Capacity reasoning (sanity math, to be replaced by measurement — B12)
100 concurrent *users* is not 100 RPS. Assume a turn every ~20s per active user and ~5 tool calls per turn → ~25 tool calls/sec aggregate across the fleet. Spread over 150 servers that is trivial *per server*; the pressure concentrates in two places:
- **The agent app**, which holds ~100 concurrent streaming responses to the UI *and* ~100 in-flight LLM calls. These are I/O-bound, so async handles it — **provided nothing blocks the loop**. Budget ≥2 tasks × 2 workers for redundancy, and measure.
- **The gateway**, which sees all 25 calls/sec plus catalog searches. Same discipline.
Each leaf MCP server can run 2 small Fargate tasks (for AZ redundancy, not throughput). **The binding constraint is almost never CPU — it is a blocked event loop, an unbounded connection pool, or a missing timeout.** Which is exactly why R2's §4.1 #1 and R1's §4.2 #2 are P0.

---

## 6. The 150-server tool-discovery problem (your biggest real risk)

Naive aggregation fails on token cost, latency, and — first — **selection accuracy**. The pattern that works:

1. **Index, don't inline.** At build/registration time, harvest every tool's name, namespaced id, description, structured metadata (R2's `USECASE/EXAMPLES/PREREQUISITES/RELATED_TOOLS`, promoted to a typed model), and JSON schema into a searchable index (hybrid BM25 + embeddings; pgvector or OpenSearch).
2. **Expose a small, fixed meta-toolset to the agent:** `search_tools(intent, k)` → ranked candidates with one-line descriptions; `describe_tool(id)` → full schema + usage; `invoke_tool(id, args)` → proxied execution with validation. The ReAct prompt then carries ~3 tools plus a handful of retrieved candidates instead of 3,000.
3. **Two-stage binding per turn:** retrieve → bind the top 5–15 full schemas into the model's tool list → execute. Cache the binding for the conversation.
4. **Scope by policy first:** filter candidates by the caller's entitlements *before* ranking, so the agent never sees tools it may not call.
5. **Evaluate it like a retrieval system** (B9): a labeled set of (user intent → correct tool) pairs, recall@k and selection-accuracy gates in CI. This is the metric that determines whether your product works.
6. **Keep namespacing strict** (`{server}_{tool}`), as FastMCP's `mount(namespace=...)` / `create_proxy` do automatically — with 3,000 tools, name collisions are certain.

---

## 7. Sequenced roadmap

**Phase 0 — Decide & spike (1 week).** Confirm current FastMCP major; spike one server with `stateless_http=True` + `json_response=True` on 2 Fargate tasks behind an ALB with **no** stickiness; prove no session errors. Spike JWT+JWKS local validation latency. Decide gateway-vs-direct with a load test. *Exit: the two P0 transport/auth assumptions are measured, not assumed.*

**Phase 1 — Build `mcp-common` + the template (2–3 weeks).** Fork R2's skeleton; strip the AS and dev middleware; add pooled async HTTP, pure-ASGI request-ID middleware, OTel, RED metrics, semaphore + timeout, `/health` vs `/ready`, RS-only async auth with cached JWKS and `aud` enforcement, typed `ToolMeta`, both app modes, multi-stage digest-pinned container, ECS task def + Terraform/CDK module, protocol conformance suite, strict mypy, lint rule banning sync tool bodies. *Exit: `cookiecutter` a new server, deploy to ECS, and pass conformance + load tests in CI.*

**Phase 2 — Registry, gateway, catalog (2–3 weeks).** Registry → generated `mcp_server.json`; gateway with `create_proxy` loading; catalog index + the three meta-tools; tool-selection eval harness.

**Phase 3 — Agent app hardening (2 weeks).** MCP client pool with lazy connect, per-server timeout + circuit breaker; two-stage tool binding; SSE to UI with correlation IDs; identity propagation; idempotency keys; output token budgets.

**Phase 4 — Fan out (ongoing).** Generate servers from the template; template-version fan-out PRs; soak test at 2–5× concurrency; cost review (Graviton, right-sizing, consolidation).

---

## 8. Caveats on the assessment above

- FastMCP's `stateless_http` semantics and the sync-tool/event-loop behavior were verified against current FastMCP documentation. Everything attributed to R1/R2 was read in the source and is cited by file:line.
- **The exact current FastMCP major/minor should be re-confirmed before you fix your floor version** — the line has moved several majors past R2's pinned 2.14.2, and the composition/proxy/transform APIs quoted in §0.5 and §6 live in the newer line, so verify their signatures against the release you pick.
- All capacity figures in §5 are reasoned estimates presented as hypotheses. They are not substitutes for the load testing in B12 / Phase 0.
- I did not review R2's `oauth/{service,controller,routes,models}.py` or its test suite line-by-line, because the recommendation is to delete the self-hosted Authorization Server rather than fix it. If you decide to keep it, that code needs a dedicated security review before it goes near production.

---
---

# PART II — THE BUILD SPECIFICATION

# §9. `mcp-fleet` Template Design — single source of truth

> **Audience: the coding agent.** Everything below is normative. Where a signature or
> behaviour is given, implement it exactly. Where a module is marked **SPEC-ONLY**, the
> signature and acceptance test are binding but you write the body. Nothing here may be
> delivered as a stub, mock, `pass`, `TODO`, or `NotImplementedError` — §10 has an
> explicit anti-stub gate. If a requirement here conflicts with §0–§7, §9 wins.

## 9.0 Verified API baseline (do not guess these)

These were confirmed against current FastMCP documentation. They are the load-bearing
APIs of the whole template:

| API | Import | Confirmed behaviour |
|---|---|---|
| `FastMCP(name, auth=..., stateless_http=True)` | `fastmcp` | `stateless_http=True` creates a fresh transport context per request → **no session affinity**. This is the scalability switch. |
| `mcp.http_app(path, json_response, stateless_http, transport, middleware)` | instance method | Returns a Starlette ASGI app. `json_response=True` returns plain JSON instead of an SSE stream for unary calls. |
| `combine_lifespans(*lifespans)` | `fastmcp.utilities.lifespan` | Enters in order, exits LIFO. **Required** when mounting into FastAPI — docs: *"You must pass the lifespan from the MCP app to FastAPI, otherwise the session manager won't initialize and requests will fail."* |
| `JWTVerifier(jwks_uri, issuer, audience, required_scopes, algorithm, jwks_refresh_interval)` | `fastmcp.server.auth.providers.jwt` | Validates signature + `iss` + `aud`; JWKS cached ~1h; refresh shared across concurrent requests. Replaces R2's blocking introspection entirely. |
| `get_access_token()` | `fastmcp.server.dependencies` | Returns `None` or an object with `.claims`, `.client_id`, `.scopes`. Already verified by the auth provider. Use for per-tool authz. |
| `Middleware`, `MiddlewareContext` | `fastmcp.server.middleware` | Hooks `on_call_tool(context, call_next)` → `ToolResult`, `on_list_tools(context, call_next)` → `list[Tool]`. `context.message.name` / `.arguments`. |
| `ToolError` | `fastmcp.exceptions` | Raise to deny/fail a call. Docs are explicit: **raise**, do not return an error value and do not skip `call_next()`. |
| `create_proxy(config)` | `fastmcp.server` | Accepts `{"mcpServers": {name: {url, transport}}}` — your `mcp_server.json` shape — and namespaces components. **Gateway only; not used by leaf servers.** |

**T0 gate — capability probe.** Before writing anything else, create
`tests/test_api_baseline.py` that imports every symbol above and asserts each callable's
signature contains the named parameters (via `inspect.signature`). Pin `fastmcp` to the
current major with a `>=X.Y,<X+1` floor and a committed lockfile. If this test fails, the
pinned version does not match this spec — **stop and report**, do not adapt the design
silently. This test is the mechanism that protects 150 servers from version drift.

## 9.1 Non-negotiable invariants

Every one of the 150 servers must satisfy all of these. Each is enforced by a test or a
lint rule named in §10, not by convention.

1. `stateless_http=True`. No server holds cross-request session state in process memory.
2. **No blocking call in any coroutine.** All I/O is `async`. CPU-bound or blocking-only
   libraries are wrapped in `anyio.to_thread.run_sync`. Enforced by lint rule + review.
3. **Exactly one pooled `httpx.AsyncClient` per upstream**, created in lifespan, closed on
   shutdown. Constructing a client inside a request path is a build failure.
4. Every tool has an explicit **timeout**, **concurrency bound**, and **output size budget**.
5. Auth is **resource-server only**. The template contains no authorization-server code,
   no token minting, no `/auth/*` routes.
6. `aud` is validated against this server's own resource URI. A token minted for another
   server is rejected.
7. `/health` (liveness, zero dependencies) and `/ready` (dependency-checked, drain-aware)
   are distinct endpoints with distinct semantics.
8. Every log line and span carries `request_id`, `server`, and — when present — `tool` and
   `principal`.
9. No secret, upstream URL, credential, or raw upstream error body may reach model-visible
   output or a log at INFO or below.
10. The same source builds **both** deployment modes. Co-location is a deploy-time
    decision expressed in config, never a code change.

## 9.2 Repository layout

Two artifacts: a versioned shared library, and a generator that emits per-server repos.

```
mcp-fleet/
├── packages/mcp_common/                 # THE shared library — pinned dep of all 150
│   ├── pyproject.toml
│   └── mcp_common/
│       ├── __init__.py                  # re-exports public API only
│       ├── settings.py                  # CommonSettings (BaseSettings)
│       ├── module.py                    # ServerModule — the unit of composition
│       ├── app.py                       # build_app() — both deployment modes
│       ├── runtime.py                   # uvicorn entrypoint + signal/drain wiring
│       ├── logging.py                   # structlog JSON + contextvars
│       ├── observability.py             # OTel tracer + RED metrics
│       ├── httpclient.py                # ClientRegistry (pooled AsyncClients)
│       ├── auth.py                      # build_token_verifier(), scope policy
│       ├── errors.py                    # typed errors, redaction, ToolError mapping
│       ├── toolmeta.py                  # ToolMeta model + @tool_meta + catalog export
│       ├── idempotency.py               # IdempotencyStore ABC + 2 real impls
│       ├── health.py                    # ReadinessRegistry + routers + DrainState
│       ├── asgi/
│       │   ├── request_context.py       # pure-ASGI: request-id, timing, headers
│       │   ├── concurrency.py           # pure-ASGI: in-flight cap → 503
│       │   └── body_limit.py            # pure-ASGI: max request body
│       ├── mcpmw/
│       │   ├── authorization.py         # per-tool scopes; filters tools/list
│       │   ├── timeout.py               # per-tool deadline
│       │   ├── telemetry.py             # span + RED metrics + audit per call
│       │   └── output_budget.py         # truncate oversized tool output
│       └── testing/
│           ├── conformance.py           # the shared suite all 150 servers run
│           └── fixtures.py              # auth/token/client fixtures
├── template/                            # copier/cookiecutter → one server repo
│   └── {{server_slug}}/
│       ├── src/{{pkg}}/server.py        # builds the ServerModule
│       ├── src/{{pkg}}/tools/*.py
│       ├── src/{{pkg}}/upstreams.py     # declares pooled clients + readiness checks
│       ├── app_single.py                # 1 server per container
│       ├── app_composed.py              # N servers per container
│       ├── tests/                       # imports the shared conformance suite
│       ├── Containerfile
│       ├── deploy/ecs/                  # task def + service + TG (Terraform module)
│       ├── Makefile  pyproject.toml  uv.lock  .dockerignore
│       └── catalog.json                 # GENERATED — feeds registry/gateway
└── registry/                            # fleet manifest → generates mcp_server.json
```

## 9.3 The composition unit — `ServerModule`

This type is what makes one template serve both deployment modes.

```python
# mcp_common/module.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Mapping

from fastmcp import FastMCP

ReadinessCheck = Callable[[], Awaitable[None]]  # raises on not-ready


@dataclass(frozen=True, slots=True)
class ServerModule:
    """One logical MCP server. Deployment-mode agnostic.

    `mount_path` is used only in composed mode; in single mode the server is
    served at the root MCP path. Identical code, identical behaviour.
    """
    name: str                                    # URL-safe, stable, unique in the fleet
    version: str
    mcp: FastMCP
    tool_scopes: Mapping[str, frozenset[str]] = field(default_factory=dict)
    tool_timeouts: Mapping[str, float] = field(default_factory=dict)
    readiness: Mapping[str, ReadinessCheck] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name or not self.name.replace("-", "").replace("_", "").isalnum():
            raise ValueError(f"ServerModule.name must be URL-safe: {self.name!r}")

    @property
    def mount_path(self) -> str:
        return f"/{self.name}"
```

**Authoring contract** — every server repo exposes exactly this:

```python
# src/<pkg>/server.py
def build_module() -> ServerModule: ...
```

Nothing else. `app_single.py` and `app_composed.py` both consume `build_module()`.

## 9.4 `build_app()` — the one function that serves both modes

The two subtleties a coding agent will otherwise get wrong, and which would break all 150
servers in ways that still pass a local smoke test:

- **Mounted ASGI apps do not get their lifespan run by Starlette.** You must hand every
  MCP sub-app's lifespan to the parent app. R1 did this manually with `AsyncExitStack`;
  R2 did it for its single app. Use `combine_lifespans`, which is built for exactly this.
- **Middleware ordering.** The last `add_middleware` call is the *outermost* layer. The
  concurrency limiter must sit outside the MCP apps but must **not** gate `/health` or
  `/ready` — otherwise a saturated task fails its health check and gets killed precisely
  when it is merely busy, converting a load spike into an outage.

```python
# mcp_common/app.py
from __future__ import annotations
from contextlib import asynccontextmanager
from typing import AsyncIterator, Sequence

from fastapi import FastAPI
from fastmcp.utilities.lifespan import combine_lifespans

from mcp_common.asgi.body_limit import BodyLimitMiddleware
from mcp_common.asgi.concurrency import ConcurrencyLimitMiddleware
from mcp_common.asgi.request_context import RequestContextMiddleware
from mcp_common.health import DrainState, ReadinessRegistry, build_health_router
from mcp_common.httpclient import ClientRegistry
from mcp_common.logging import get_logger
from mcp_common.mcpmw.authorization import ToolAuthorizationMiddleware
from mcp_common.mcpmw.output_budget import OutputBudgetMiddleware
from mcp_common.mcpmw.telemetry import TelemetryMiddleware
from mcp_common.mcpmw.timeout import ToolTimeoutMiddleware
from mcp_common.module import ServerModule
from mcp_common.observability import init_observability
from mcp_common.settings import CommonSettings

log = get_logger(__name__)

HEALTH_PATHS = frozenset({"/health", "/ready", "/metrics"})


def build_app(
    modules: Sequence[ServerModule],
    settings: CommonSettings,
    *,
    client_registry: ClientRegistry | None = None,
) -> FastAPI:
    """Build the ASGI app.

    len(modules) == 1 -> single mode:   MCP at /mcp
    len(modules)  > 1 -> composed mode: MCP at /<name>/mcp for each module
    """
    if not modules:
        raise ValueError("build_app requires at least one ServerModule")
    names = [m.name for m in modules]
    if len(set(names)) != len(names):
        raise ValueError(f"duplicate ServerModule names: {names}")

    init_observability(settings)
    clients = client_registry or ClientRegistry(settings)
    readiness = ReadinessRegistry()
    drain = DrainState()

    # --- MCP-layer middleware: sees tool names, not HTTP -------------------
    for module in modules:
        module.mcp.add_middleware(TelemetryMiddleware(server=module.name))
        module.mcp.add_middleware(
            ToolAuthorizationMiddleware(
                policy=module.tool_scopes,
                enforce=settings.AUTH_ENABLED,
            )
        )
        module.mcp.add_middleware(
            ToolTimeoutMiddleware(
                default_seconds=settings.TOOL_TIMEOUT_SECONDS,
                per_tool=module.tool_timeouts,
            )
        )
        module.mcp.add_middleware(
            OutputBudgetMiddleware(max_chars=settings.TOOL_OUTPUT_MAX_CHARS)
        )
        for check_name, check in module.readiness.items():
            readiness.register(f"{module.name}.{check_name}", check)

    single = len(modules) == 1
    mcp_apps = [
        m.mcp.http_app(
            path="/mcp",
            json_response=settings.MCP_JSON_RESPONSE,
            stateless_http=True,            # invariant 9.1.1 — never configurable
        )
        for m in modules
    ]

    @asynccontextmanager
    async def own_lifespan(_: FastAPI) -> AsyncIterator[None]:
        await clients.startup()
        readiness.register("http_clients", clients.healthcheck)
        log.info(
            "server.startup",
            mode="single" if single else "composed",
            modules=names,
            json_response=settings.MCP_JSON_RESPONSE,
        )
        try:
            yield
        finally:
            drain.begin()                    # /ready starts failing immediately
            await clients.shutdown()
            log.info("server.shutdown", modules=names)

    # own_lifespan first so clients exist before MCP accepts traffic;
    # exits LIFO so MCP drains before clients close.
    app = FastAPI(
        title=", ".join(names),
        lifespan=combine_lifespans(own_lifespan, *(a.lifespan for a in mcp_apps)),
        docs_url=None if settings.is_production else "/docs",
        redoc_url=None,
        openapi_url=None if settings.is_production else "/openapi.json",
    )

    app.include_router(build_health_router(readiness, drain, names))

    for module, mcp_app in zip(modules, mcp_apps):
        # Single mode -> "/" so the sub-app's own "/mcp" path lands at /mcp.
        # Composed   -> "/<name>" so it lands at /<name>/mcp.
        app.mount("/" if single else module.mount_path, mcp_app)

    # Added last == outermost. Request context must be outermost so every
    # downstream layer, including the limiter's 503, carries the request id.
    app.add_middleware(BodyLimitMiddleware, max_bytes=settings.MAX_REQUEST_BYTES)
    app.add_middleware(
        ConcurrencyLimitMiddleware,
        max_concurrent=settings.MAX_CONCURRENT_REQUESTS,
        max_wait_seconds=settings.CONCURRENCY_QUEUE_WAIT_SECONDS,
        exempt_paths=HEALTH_PATHS,
    )
    app.add_middleware(RequestContextMiddleware, service_names=names)
    return app
```

> **Mount-path warning.** Mounting a sub-app at `"/"` while the parent also serves
> `/health` and `/ready` is order-dependent in Starlette: routes registered *before* the
> mount win. `build_health_router` is included **before** the `app.mount` loop above for
> exactly this reason — do not reorder those two blocks. **T1 must assert that `/health`,
> `/ready`, `/mcp` (single mode) and `/<name>/mcp` (composed mode) all resolve correctly
> and that the MCP endpoints reject a request with no valid token**, because a path-shape
> regression here silently breaks every client in the fleet.

## 9.5 ASGI middleware — pure ASGI, never `BaseHTTPMiddleware`

R2's use of `BaseHTTPMiddleware` (`api.py:82,134`) is wrong for a streaming transport on
three counts: it impedes streaming responses, it adds a task + queue per request, and —
least known, most damaging here — **it runs the handler in a child task, which breaks
`contextvars` propagation**, so a request-id set in a `BaseHTTPMiddleware` would not reach
the tool. Pure ASGI avoids all three.

```python
# mcp_common/asgi/request_context.py
from __future__ import annotations
import time
import uuid
from typing import Sequence

from starlette.datastructures import MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from mcp_common.logging import bind_request_context, clear_request_context, get_logger

log = get_logger(__name__)
REQUEST_ID_HEADER = b"x-request-id"
TRACEPARENT_HEADER = b"traceparent"
_UNSAFE = str.maketrans({"\n": "", "\r": "", "\x00": ""})


class RequestContextMiddleware:
    """Assign/propagate a correlation id and emit one access log per request."""

    def __init__(self, app: ASGIApp, service_names: Sequence[str]) -> None:
        self.app = app
        self.service = ",".join(service_names)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = dict(scope.get("headers") or ())
        raw = headers.get(REQUEST_ID_HEADER)
        # Never trust an inbound id blindly: cap length, strip log-injection chars.
        request_id = (
            raw.decode("latin-1")[:128].translate(_UNSAFE) if raw else ""
        ) or uuid.uuid4().hex
        traceparent = headers.get(TRACEPARENT_HEADER, b"").decode("latin-1") or None

        token = bind_request_context(
            request_id=request_id, service=self.service, traceparent=traceparent
        )
        started = time.perf_counter()
        status_holder: dict[str, int] = {}

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                status_holder["status"] = message["status"]
                MutableHeaders(scope=message)["x-request-id"] = request_id
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            log.info(
                "http.request",
                method=scope.get("method"),
                path=scope.get("path"),
                status=status_holder.get("status"),
                duration_ms=round((time.perf_counter() - started) * 1000, 2),
            )
            clear_request_context(token)
```

```python
# mcp_common/asgi/concurrency.py
from __future__ import annotations
import asyncio
import json
from typing import AbstractSet

from starlette.types import ASGIApp, Receive, Scope, Send

from mcp_common.logging import get_logger
from mcp_common.observability import SHED_COUNTER

log = get_logger(__name__)


class ConcurrencyLimitMiddleware:
    """Bound in-flight requests; shed load with 503 + Retry-After.

    Health paths are exempt: a saturated task is busy, not unhealthy, and must
    stay able to answer probes or the platform will kill it under load.
    """

    def __init__(
        self,
        app: ASGIApp,
        max_concurrent: int,
        max_wait_seconds: float,
        exempt_paths: AbstractSet[str] = frozenset(),
    ) -> None:
        if max_concurrent < 1:
            raise ValueError("max_concurrent must be >= 1")
        self.app = app
        self.exempt_paths = frozenset(exempt_paths)
        self.max_wait = max_wait_seconds
        # Python >= 3.10: Semaphore binds to the running loop lazily, so
        # constructing it here (outside the loop) is safe.
        self._sem = asyncio.Semaphore(max_concurrent)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope.get("path") in self.exempt_paths:
            await self.app(scope, receive, send)
            return
        try:
            await asyncio.wait_for(self._sem.acquire(), timeout=self.max_wait)
        except (asyncio.TimeoutError, TimeoutError):
            SHED_COUNTER.add(1)
            log.warning("http.load_shed", path=scope.get("path"))
            await _send_json(
                send,
                503,
                {"error": "server_busy", "detail": "Concurrency limit reached."},
                extra_headers=((b"retry-after", b"1"),),
            )
            return
        try:
            await self.app(scope, receive, send)
        finally:
            self._sem.release()


async def _send_json(send: Send, status: int, payload: dict, extra_headers=()) -> None:
    body = json.dumps(payload).encode()
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode()),
                *extra_headers,
            ],
        }
    )
    await send({"type": "http.response.body", "body": body})
```

`BodyLimitMiddleware` — **SPEC-ONLY**. Pure ASGI. Reject with `413` when `content-length`
exceeds `max_bytes`; when that header is absent, count bytes across `http.request`
messages and abort once the limit is passed. Must not buffer the whole body. Acceptance:
an oversized declared body and an oversized chunked body both yield `413`, and a legal
body still streams through byte-identical.

## 9.6 Auth — resource server only

Deletes R2 gaps #1, #3, #8, #9, #10 and R1 gap #1 by replacing hand-rolled OAuth with a
verified library primitive.

```python
# mcp_common/auth.py
from __future__ import annotations
from fastmcp.server.auth.providers.jwt import JWTVerifier

from mcp_common.settings import CommonSettings


def build_token_verifier(settings: CommonSettings) -> JWTVerifier | None:
    """One IdP, one audience per server, signature verified locally via JWKS.

    No network call on the request path: JWKS keys are cached (~1h) and the
    refresh is shared across concurrent requests. This is the fix for R2's
    per-request blocking introspection.
    """
    if not settings.AUTH_ENABLED:
        if settings.is_production:
            raise ValueError("AUTH_ENABLED must be true when ENVIRONMENT=production")
        return None
    missing = [
        f for f in ("OIDC_JWKS_URI", "OIDC_ISSUER", "MCP_RESOURCE_AUDIENCE")
        if not getattr(settings, f)
    ]
    if missing:
        raise ValueError(f"AUTH_ENABLED=true but unset: {', '.join(missing)}")
    return JWTVerifier(
        jwks_uri=settings.OIDC_JWKS_URI,
        issuer=settings.OIDC_ISSUER,
        audience=settings.MCP_RESOURCE_AUDIENCE,   # per-server; blocks token passthrough
        required_scopes=list(settings.REQUIRED_BASE_SCOPES),
    )
```

Each server sets `MCP_RESOURCE_AUDIENCE` to its **own** resource URI. A token minted for
`mcp://crm` is then rejected by `mcp://billing` — the point of RFC 8707 resource
indicators, which R2 published metadata for but never enforced.

**Per-tool authorization.** The `on_list_tools` filter matters as much as the
`on_call_tool` check: the agent must never *see* a tool it may not call, both to stop
probing and to keep the retrieved toolset relevant.

```python
# mcp_common/mcpmw/authorization.py
from __future__ import annotations
from typing import Mapping

from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import get_access_token
from fastmcp.server.middleware import Middleware, MiddlewareContext

from mcp_common.logging import bind_principal, get_logger

log = get_logger(__name__)


class ToolAuthorizationMiddleware(Middleware):
    """Per-tool scope enforcement; hides unauthorized tools from tools/list."""

    def __init__(self, policy: Mapping[str, frozenset[str]], enforce: bool = True):
        self._policy = {k: frozenset(v) for k, v in policy.items()}
        self._enforce = enforce

    def _granted(self) -> frozenset[str] | None:
        token = get_access_token()
        if token is None:
            return None
        bind_principal(token.client_id, (token.claims or {}).get("sub"))
        return frozenset(token.scopes or ())

    async def on_call_tool(self, context: MiddlewareContext, call_next):
        if not self._enforce:
            return await call_next(context)
        required = self._policy.get(context.message.name, frozenset())
        granted = self._granted()
        if granted is None:
            raise ToolError("Unauthorized: no valid access token.")
        if not required <= granted:
            log.warning(
                "tool.forbidden",
                tool=context.message.name,
                required=sorted(required),
            )
            # Do not echo the granted scopes back to the model.
            raise ToolError(f"Forbidden: tool requires scope(s) {sorted(required)}.")
        return await call_next(context)

    async def on_list_tools(self, context: MiddlewareContext, call_next):
        tools = await call_next(context)
        if not self._enforce:
            return tools
        granted = self._granted() or frozenset()
        return [
            t for t in tools
            if self._policy.get(getattr(t, "name", ""), frozenset()) <= granted
        ]
```

> **Fail-closed note.** A tool absent from `tool_scopes` defaults to `frozenset()`, i.e.
> *no scope required*. That is deliberate (public read tools are common) but it means a
> forgotten entry is open, not closed. The T2 lint rule therefore **fails the build when a
> registered tool name is missing from `tool_scopes`** — the policy map must be explicit
> for every tool, including the public ones.

## 9.7 Per-tool deadline, telemetry, and output budget

```python
# mcp_common/mcpmw/timeout.py
from __future__ import annotations
from typing import Mapping

import anyio
from fastmcp.exceptions import ToolError
from fastmcp.server.middleware import Middleware, MiddlewareContext

from mcp_common.logging import get_logger
from mcp_common.observability import TIMEOUT_COUNTER

log = get_logger(__name__)


class ToolTimeoutMiddleware(Middleware):
    """Hard per-tool deadline. Must be shorter than the client and ALB timeouts."""

    def __init__(self, default_seconds: float, per_tool: Mapping[str, float]):
        if default_seconds <= 0:
            raise ValueError("default_seconds must be > 0")
        self._default = default_seconds
        self._per_tool = dict(per_tool)

    async def on_call_tool(self, context: MiddlewareContext, call_next):
        name = context.message.name
        budget = self._per_tool.get(name, self._default)
        try:
            with anyio.fail_after(budget):
                return await call_next(context)
        except TimeoutError:
            TIMEOUT_COUNTER.add(1, {"tool": name})
            log.warning("tool.timeout", tool=name, budget_s=budget)
            # Actionable for the model: tells it what to do differently.
            raise ToolError(
                f"Tool '{name}' exceeded its {budget:g}s budget. "
                "Retry with a narrower request or fewer items."
            ) from None
```

`TelemetryMiddleware` — **SPEC-ONLY**, behaviour binding. On `on_call_tool`: open an OTel
span `mcp.tool/<name>`; bind `tool` into the log context; record the RED triple
(`mcp_tool_calls_total{tool,outcome}`, `mcp_tool_duration_seconds{tool}`,
`mcp_tool_errors_total{tool,kind}`); emit one audit log with tool name, principal,
outcome, duration, and a **SHA-256 hash of the canonicalized arguments — never the
arguments themselves** (they carry user PII). Convert non-`ToolError` exceptions through
`errors.to_tool_error`; never swallow an exception into a success result.

`OutputBudgetMiddleware` — **SPEC-ONLY**. Measure total character length of text content in
the returned `ToolResult`. If over `max_chars`, truncate and append
`"\n\n[truncated N of M chars — narrow your query or use pagination]"`, increment
`mcp_tool_truncated_total{tool}`, log at WARNING. Iterate content blocks defensively
(`isinstance` guard for text blocks) and leave non-text blocks untouched. **Confirm the
content-block attribute names against the pinned FastMCP version in the T0 probe before
implementing.** Unbounded tool output is the largest single driver of LLM cost in agentic
systems; this is a cost control, not a nicety.

## 9.8 Pooled HTTP clients

Fixes R1 gap #2 (a TLS handshake per upstream call) and #3 (no timeouts).

```python
# mcp_common/httpclient.py
from __future__ import annotations
from dataclasses import dataclass

import httpx

from mcp_common.logging import get_logger
from mcp_common.settings import CommonSettings

log = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class UpstreamSpec:
    name: str
    base_url: str
    connect_timeout: float = 3.0
    read_timeout: float = 10.0
    max_connections: int = 50
    max_keepalive: int = 20
    health_path: str | None = None       # GET'd by /ready when set


class ClientRegistry:
    """Owns every outbound AsyncClient. Created once in lifespan, reused forever."""

    def __init__(self, settings: CommonSettings) -> None:
        self._settings = settings
        self._specs: dict[str, UpstreamSpec] = {}
        self._clients: dict[str, httpx.AsyncClient] = {}
        self._started = False

    def declare(self, spec: UpstreamSpec) -> None:
        if self._started:
            raise RuntimeError("declare() must be called before startup()")
        if spec.name in self._specs:
            raise ValueError(f"upstream already declared: {spec.name}")
        self._specs[spec.name] = spec

    async def startup(self) -> None:
        for name, spec in self._specs.items():
            self._clients[name] = httpx.AsyncClient(
                base_url=spec.base_url,
                timeout=httpx.Timeout(
                    connect=spec.connect_timeout,
                    read=spec.read_timeout,
                    write=spec.read_timeout,
                    pool=spec.connect_timeout,
                ),
                limits=httpx.Limits(
                    max_connections=spec.max_connections,
                    max_keepalive_connections=spec.max_keepalive,
                ),
                follow_redirects=False,   # redirects can leak Authorization headers
                http2=False,              # enable only after load-testing the upstream
            )
        self._started = True
        log.info("http_clients.started", upstreams=sorted(self._clients))

    def get(self, name: str) -> httpx.AsyncClient:
        try:
            return self._clients[name]
        except KeyError:
            raise RuntimeError(
                f"upstream {name!r} not declared or registry not started"
            ) from None

    async def healthcheck(self) -> None:
        """Raise if any upstream with a health_path is unreachable."""
        for name, spec in self._specs.items():
            if spec.health_path is None:
                continue
            resp = await self._clients[name].get(spec.health_path, timeout=2.0)
            resp.raise_for_status()

    async def shutdown(self) -> None:
        for name, client in self._clients.items():
            try:
                await client.aclose()
            except Exception:                       # never block shutdown
                log.warning("http_clients.close_failed", upstream=name, exc_info=True)
        self._clients.clear()
        self._started = False
```

## 9.9 Errors and redaction

Fixes R1 gap #4 — the live credential-leak path, where `currency.py` puts the API key in
the URL and then interpolates the upstream exception (URL included) into a model-visible
error string.

```python
# mcp_common/errors.py
from __future__ import annotations
import re

import httpx
from fastmcp.exceptions import ToolError

from mcp_common.logging import get_logger

log = get_logger(__name__)

# Order matters: most specific first.
_REDACTIONS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._\-~+/=]{8,}"), r"\1 [REDACTED]"),
    (re.compile(r"(?i)([?&](?:api_?key|access_?token|token|secret|sig|password)=)[^&\s]+"),
     r"\1[REDACTED]"),
    (re.compile(r"\beyJ[A-Za-z0-9._-]{20,}"), "[REDACTED_JWT]"),
    (re.compile(r"(?i)\b[a-z0-9_-]*(?:secret|passwd|password|apikey)[\"']?\s*[:=]\s*[\"']?[^\s,\"'}]+"),
     "[REDACTED_SECRET]"),
    # Credentials embedded in a URL userinfo section.
    (re.compile(r"://[^/\s:@]+:[^/\s@]+@"), "://[REDACTED]@"),
)


def redact(text: str) -> str:
    for pattern, repl in _REDACTIONS:
        text = pattern.sub(repl, text)
    return text


class UpstreamError(Exception):
    """An upstream dependency failed. Carries no upstream text by construction."""

    def __init__(self, upstream: str, status: int | None = None) -> None:
        self.upstream, self.status = upstream, status
        super().__init__(f"upstream {upstream} failed (status={status})")


class InvalidToolInput(Exception):
    """Caller-correctable bad input. This message IS shown to the model."""


def to_tool_error(exc: Exception, *, tool: str) -> ToolError:
    """Map any exception to a safe, actionable ToolError.

    Internal detail and upstream bodies go to the log (redacted); the model
    gets a short actionable sentence, never a secret and never a stack trace.
    """
    if isinstance(exc, InvalidToolInput):
        return ToolError(f"Invalid input: {exc}")
    if isinstance(exc, UpstreamError):
        log.warning("tool.upstream_error", tool=tool,
                    upstream=exc.upstream, status=exc.status)
        if exc.status and 400 <= exc.status < 500:
            return ToolError(
                f"The {exc.upstream} service rejected the request "
                "(client error). Check the arguments and retry."
            )
        return ToolError(
            f"The {exc.upstream} service is temporarily unavailable. Retry shortly."
        )
    if isinstance(exc, httpx.TimeoutException):
        log.warning("tool.upstream_timeout", tool=tool)
        return ToolError("The upstream service timed out. Retry with a smaller request.")
    log.error("tool.unhandled", tool=tool, detail=redact(repr(exc)), exc_info=True)
    return ToolError("Internal error. The request was not completed.")
```

**Tool authoring rule** (enforced in review + conformance): a tool never catches bare
`Exception` to build its own message, and never interpolates an upstream exception into
its output. It raises `InvalidToolInput` / `UpstreamError`; the telemetry middleware
converts via `to_tool_error`. `redact()` is also installed as a structlog processor, so no
log line can carry a secret either.

## 9.10 Health, readiness, and the ECS drain contract

Closes R2 gap #11, R1 gap #5, and B5 — the gap that otherwise makes every deploy drop
in-flight tool calls.

```python
# mcp_common/health.py  (abridged to the load-bearing logic)
from __future__ import annotations
import asyncio
import time
from typing import Awaitable, Callable, Sequence

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from mcp_common.logging import get_logger

log = get_logger(__name__)
ReadinessCheck = Callable[[], Awaitable[None]]


class DrainState:
    """Set on shutdown. Makes /ready fail so the load balancer deregisters us
    BEFORE in-flight work is cut off."""

    def __init__(self) -> None:
        self._draining = False
        self._since: float | None = None

    def begin(self) -> None:
        if not self._draining:
            self._draining, self._since = True, time.monotonic()
            log.info("server.draining")

    @property
    def draining(self) -> bool:
        return self._draining


class ReadinessRegistry:
    def __init__(self, timeout: float = 2.0) -> None:
        self._checks: dict[str, ReadinessCheck] = {}
        self._timeout = timeout

    def register(self, name: str, check: ReadinessCheck) -> None:
        self._checks[name] = check

    async def run(self) -> tuple[bool, dict[str, str]]:
        async def one(name: str, check: ReadinessCheck) -> tuple[str, str]:
            try:
                await asyncio.wait_for(check(), timeout=self._timeout)
                return name, "ok"
            except Exception as exc:
                return name, f"failed: {type(exc).__name__}"

        results = dict(
            await asyncio.gather(*(one(n, c) for n, c in self._checks.items()))
        )
        return all(v == "ok" for v in results.values()), results


def build_health_router(
    readiness: ReadinessRegistry, drain: DrainState, names: Sequence[str]
) -> APIRouter:
    router = APIRouter()

    @router.get("/health", include_in_schema=False)
    async def health() -> JSONResponse:
        # Liveness ONLY: the process is alive. Never checks dependencies — a
        # failed dependency must not make the orchestrator restart a live task.
        return JSONResponse({"status": "alive", "servers": list(names)})

    @router.get("/ready", include_in_schema=False)
    async def ready() -> JSONResponse:
        if drain.draining:
            return JSONResponse({"status": "draining"}, status_code=503)
        ok, detail = await readiness.run()
        return JSONResponse(
            {"status": "ready" if ok else "not_ready", "checks": detail},
            status_code=200 if ok else 503,
        )

    return router
```

**Entrypoint and signal wiring** (`mcp_common/runtime.py`). Must be the container `CMD` in
exec form so the process is PID 1 and actually receives `SIGTERM`.

```python
# mcp_common/runtime.py
from __future__ import annotations
import signal

import uvicorn
from fastapi import FastAPI

from mcp_common.logging import get_logger, uvicorn_log_config
from mcp_common.settings import CommonSettings

log = get_logger(__name__)


def _common_kwargs(settings: CommonSettings) -> dict:
    return dict(
        host=settings.BIND_HOST,
        port=settings.BIND_PORT,
        proxy_headers=True,                       # behind an ALB
        forwarded_allow_ips=settings.FORWARDED_ALLOW_IPS,
        timeout_graceful_shutdown=settings.GRACEFUL_SHUTDOWN_SECONDS,
        timeout_keep_alive=settings.KEEPALIVE_SECONDS,
        log_config=uvicorn_log_config(settings.LOG_LEVEL),
        access_log=False,                         # we emit our own structured one
        server_header=False,
    )


def serve(target: FastAPI | str, settings: CommonSettings) -> None:
    """Run the server.

    IMPORTANT: ``uvicorn.Server(config).run()`` IGNORES ``workers``. Multi-process
    mode requires ``uvicorn.run()`` with an **import string** ("pkg.module:app")
    so each child can import the app itself. Passing an app *object* with
    workers>1 silently runs a single process -- a capacity bug that looks like
    a mystery throughput ceiling in production. We therefore make the two paths
    explicit and refuse the invalid combination.
    """
    workers = settings.UVICORN_WORKERS
    if workers > 1:
        if not isinstance(target, str):
            raise TypeError(
                "UVICORN_WORKERS>1 requires an import string such as "
                "'myserver.app_single:app', not a FastAPI instance, because "
                "uvicorn must re-import the app in each worker process."
            )
        # uvicorn.run() owns the supervisor and signal handling in this mode.
        uvicorn.run(target, workers=workers, **_common_kwargs(settings))
        return

    config = uvicorn.Config(target, **_common_kwargs(settings))
    server = uvicorn.Server(config)
    original_handler = server.handle_exit

    def handle_exit(sig: int, frame) -> None:
        log.info("signal.received", signal=signal.Signals(sig).name)
        original_handler(sig, frame)

    server.handle_exit = handle_exit  # type: ignore[method-assign]
    server.run()
```

> **Why `UVICORN_WORKERS` defaults to 1.** Beyond the import-string constraint
> above, each worker is a separate process with its **own** concurrency semaphore
> (§9.5) and its own idempotency cache, so `MAX_CONCURRENT_REQUESTS` becomes
> *per worker* and `InProcessIdempotencyStore` stops being correct. Scale with
> **more ECS tasks**, not more workers: the limits stay meaningful, health
> checking stays per-instance, and the autoscaling signal stays clean.

> **Drain correctness and its one caveat.** `DrainState.begin()` fires in the lifespan
> `finally` (§9.4), which runs once uvicorn begins shutting down. For the ALB to
> deregister *before* in-flight requests are cut, the target group's
> `deregistration_delay` must be ≥ readiness interval × unhealthy threshold (numbers in
> §9.12). Note the ordering limitation honestly: uvicorn starts its graceful shutdown and
> the lifespan exit at roughly the same moment, so the *reliable* mechanism is the
> combination of a `deregistration_delay` that outlasts in-flight work and a
> `timeout_graceful_shutdown` ≥ the longest tool deadline — the `/ready` flip is the fast
> signal, not the guarantee. **If T9 (rolling deploy under load) shows any failed request,
> add an explicit pre-stop delay via an ECS `dependsOn`/wrapper rather than tuning these
> numbers blindly.** A drain contract that is configured but never exercised is not a
> drain contract.

## 9.11 Settings contract

`mcp_common/settings.py` — `CommonSettings(BaseSettings)` with `SettingsConfigDict`
(not R1's deprecated `class Config`), `env_prefix="MCP_"`, `extra="forbid"`.
**No secret has a default.** `validate()` runs at startup and exits non-zero on failure.

| Setting | Default | Notes |
|---|---|---|
| `ENVIRONMENT` | `development` | `production` tightens the rules below |
| `SERVER_NAME` / `SERVER_VERSION` | required | identity in logs, metrics, catalog |
| `BIND_HOST` / `BIND_PORT` | `0.0.0.0` / `8080` | |
| `UVICORN_WORKERS` | `1` | **keep at 1 and scale with ECS tasks.** >1 requires an import-string target and makes `MAX_CONCURRENT_REQUESTS` per-worker (§9.10) |
| `MCP_JSON_RESPONSE` | `true` | unary tools; false only for genuinely streaming tools |
| `AUTH_ENABLED` | `true` | **must** be true when `ENVIRONMENT=production` (hard fail) |
| `OIDC_ISSUER`, `OIDC_JWKS_URI` | required when auth on | one central IdP |
| `MCP_RESOURCE_AUDIENCE` | required when auth on | **unique per server** |
| `REQUIRED_BASE_SCOPES` | `[]` | coarse gate; per-tool scopes live in `ServerModule` |
| `MAX_CONCURRENT_REQUESTS` | `64` | tune from load tests |
| `CONCURRENCY_QUEUE_WAIT_SECONDS` | `0.5` | then shed with 503 |
| `MAX_REQUEST_BYTES` | `1048576` | |
| `TOOL_TIMEOUT_SECONDS` | `15` | per-tool override in `ServerModule.tool_timeouts` |
| `TOOL_OUTPUT_MAX_CHARS` | `40000` | cost control |
| `GRACEFUL_SHUTDOWN_SECONDS` | `60` | ≥ longest tool timeout |
| `KEEPALIVE_SECONDS` | `75` | **>** ALB idle timeout (60s), so the ALB never reuses a connection we just closed |
| `FORWARDED_ALLOW_IPS` | VPC CIDR | never `*` in production |
| `LOG_LEVEL` | `INFO` | |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | unset | ADOT sidecar when set |
| `IDEMPOTENCY_BACKEND` | `inprocess` | `dynamodb` required for multi-instance write servers |
| `MULTI_INSTANCE` | `false` | set to true by Terraform when `desired_count > 1`; drives the §9.14 check |
| `CORS_ENABLED` | `false` | servers are called by the agent, not browsers |
| `CORS_ORIGINS` | `[]` | **explicit list; `*` rejected when credentials are on** |

Hard validation rules, each with a test: production ⇒ `AUTH_ENABLED=true`; auth on ⇒
issuer + JWKS + audience all set; `CORS_ORIGINS` may not contain `*` while CORS
credentials are enabled (R2's unsafe default); `GRACEFUL_SHUTDOWN_SECONDS ≥ max(tool
timeouts)`; `KEEPALIVE_SECONDS >` the documented ALB idle timeout;
`FORWARDED_ALLOW_IPS != "*"` in production.

## 9.12 The timeout and drain ladder (every number must hold)

Each layer must be strictly shorter than the one outside it, or a timeout surfaces as the
wrong error at the wrong layer and retries stack.

| Layer | Value | Constraint |
|---|---|---|
| Upstream HTTP read timeout | **10s** | < tool deadline |
| Per-tool deadline | **15s** (max override 60s) | the inner bound |
| MCP request / ASGI | **30s** | > tool deadline |
| Agent's MCP client timeout | **45s** | > server request timeout |
| ALB idle timeout | **60s** | > agent timeout |
| uvicorn `timeout_keep_alive` | **75s** | **>** ALB idle (see note) |
| uvicorn graceful shutdown | **60s** | ≥ max tool deadline |
| TG `deregistration_delay` | **30s** | ≥ readiness interval (5s) × threshold (2) |
| ECS `stopTimeout` | **120s** | > drain + graceful |

> **Keep-alive direction matters and is easy to get backwards.** The backend's
> keep-alive timeout must be **longer** than the ALB's idle timeout. If the backend closes
> an idle connection first, the ALB can still pick that socket for the next request and
> the client sees a spurious `502`. So: agent timeout (45s) < ALB idle (60s) < uvicorn
> keep-alive (75s). An earlier draft of this table had this inverted; the order above is
> the correct one.

ECS/ALB wiring: **ALB target-group health check → `/ready`** (so draining removes the
task) and **ECS container health check → `/health`** (so a dependency outage does not
restart-loop a healthy task). Pointing both at the same endpoint is the classic error, and
is what R2's manifest does.

## 9.13 Tool authoring contract

A tool is accepted only if all of these hold. At 150 servers the descriptions *are* the
product surface — this is where agent accuracy is won or lost.

1. `async def`. Blocking or CPU-bound work goes through `anyio.to_thread.run_sync`. (R2's
   template teaches the opposite; the T2 lint rule makes it impossible here.)
2. Pydantic-validated arguments — type hints alone are not validation. Raise
   `InvalidToolInput` on bad input.
3. Listed in `ServerModule.tool_scopes`, explicitly, even when the value is `frozenset()`.
4. Carries a `ToolMeta` via `@tool_meta(...)` — machine-readable, promoting R2's good
   docstring convention into typed data:

```python
# mcp_common/toolmeta.py  (model shape — binding)
class ToolMeta(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    display_name: str
    usecase: str                      # WHEN to use it
    not_for: str                      # WHEN NOT to — materially improves selection
    inputs: str
    outputs: str
    examples: tuple[str, ...]
    prerequisites: tuple[str, ...] = ()
    related_tools: tuple[str, ...] = ()
    side_effects: Literal["none", "read", "write", "destructive"] = "read"
    idempotent: bool = True
    typical_latency_ms: int | None = None
    cost_hint: Literal["free", "cheap", "expensive"] = "cheap"
```

5. Output is bounded and paginated — return a `next_cursor`, never a 50KB blob.
6. Errors are actionable: say what to change, not only what failed.
7. `side_effects` in `{"write","destructive"}` ⇒ accepts `idempotency_key` and uses §9.14.
8. Names are `snake_case` and intent-revealing (`get_customer_invoices`, never
   `query_db`). The `<server>_<tool>` namespacing is applied by the gateway, not here.

`@tool_meta` writes the metadata into the FastMCP tool's `tags`/`meta` **and** registers it
for `make catalog`, which emits `catalog.json`. That file is this server's contribution to
the fleet tool index of §6. The template's job is to *emit* it correctly; building the
index and the `search_tools` gateway is Phase 2 and explicitly **out of this template's
scope** (§11.3).

## 9.14 Idempotency (B7) — real implementation, no mock

Agents retry. Without this, a retried write double-writes.

`IdempotencyStore` is an ABC: `async def reserve(key, ttl) -> ReservationResult` and
`async def complete(key, result_digest)`. Two **real** implementations ship:

- `InProcessIdempotencyStore` — TTL + bounded LRU dict. **Correct only within one process.**
  The default for local dev and genuinely single-task servers. Its docstring must state
  that limitation in the first line.
- `DynamoDbIdempotencyStore` — conditional `PutItem` on `attribute_not_exists(pk)` with a
  TTL attribute, giving cross-task mutual exclusion. **Required for any server with
  write/destructive tools running more than one task.**

Startup validation: a process cannot discover its own ECS `desiredCount`, so this is
driven by an explicit setting the deployment owns. If any registered tool declares
`side_effects` in `{"write","destructive"}`, `MCP_MULTI_INSTANCE=true` **or**
`UVICORN_WORKERS > 1`, and `IDEMPOTENCY_BACKEND=inprocess`, **fail startup with an explicit
message**. The Terraform module in §9.15 sets `MCP_MULTI_INSTANCE=true` whenever
`desired_count > 1`, so the check is driven by deployment reality rather than by a comment.
A silent correctness hole is worse than a crash.

## 9.15 Container and ECS

```dockerfile
# Containerfile — multi-stage, reproducible, non-root, signal-correct
FROM python:3.12-slim@sha256:<PIN_DIGEST> AS builder
ENV UV_COMPILE_BYTECODE=1 UV_LINK_MODE=copy
COPY --from=ghcr.io/astral-sh/uv:0.5.11 /uv /bin/uv
WORKDIR /app
COPY pyproject.toml uv.lock ./
RUN uv sync --frozen --no-dev --no-install-project
COPY src ./src
RUN uv sync --frozen --no-dev

FROM python:3.12-slim@sha256:<PIN_DIGEST> AS runtime
RUN useradd --uid 10001 --no-create-home --shell /usr/sbin/nologin appuser
WORKDIR /app
COPY --from=builder --chown=10001:10001 /app /app
ENV PATH="/app/.venv/bin:$PATH" PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1
USER 10001
EXPOSE 8080
# Exec form: the process is PID 1 and receives SIGTERM directly. Required for
# the drain contract in §9.10 — a shell-form CMD would swallow the signal.
CMD ["python", "-m", "myserver.entrypoint"]
```

- `uv sync --frozen` + a committed `uv.lock` ⇒ reproducible builds. R2 installs straight
  from `pyproject.toml` with no lock; R1 has no lock discipline either.
- Digest-pinned base, not `:latest` (R2 uses `:latest`).
- `.dockerignore` **must** exclude `.env`, `.git`, `tests`, `.venv`. R1 has no
  `.dockerignore` and does `COPY . .`, which bakes `.env` into the image if one exists.
- No `HEALTHCHECK curl` in the image (R1 installs `curl` solely for this). ECS and the ALB
  own health checking; a smaller image has less attack surface.
- Secrets come from the ECS task definition's `secrets` block (Secrets Manager /
  Parameter Store ARNs) — never `environment`, never baked, never `.env`.
- Per-server least-privilege task role; read-only root filesystem wherever the toolset
  allows it.

The Terraform module in `deploy/ecs/` is parameterized by mode — `single` (one module,
path `/mcp`) or `composed` (N modules, paths `/<name>/mcp`) — and emits the task
definition, service, target group with the §9.12 numbers, ALB listener rule, log group,
and alarms on p99 latency, 5xx rate, load-shed count, and task restarts.

## 9.16 Testing contract

`mcp_common.testing.conformance` exports `build_conformance_suite(app_factory, modules)`.
**Every one of the 150 server repos imports and runs it** — that is how a fleet-wide fix
becomes a fleet-wide guarantee instead of 150 hopeful code reviews.

The suite asserts: `initialize` → `tools/list` → `tools/call` round trip; every tool has a
non-empty description and a valid JSON schema; every tool has a `ToolMeta`; every
registered tool appears in `tool_scopes`; **statelessness** (two independent calls with no
session header both succeed); `/health` returns 200 with dependencies down; `/ready`
returns 503 on a failed check and 503 while draining; missing token → 401; token with the
wrong `aud` → rejected; token missing a tool's scope → denied **and** that tool absent
from `tools/list`; a tool exceeding its deadline → `ToolError`, not a hang; oversized
output truncated with the marker; oversized body → 413; the concurrency limit → 503 with
`Retry-After` while `/health` still answers 200; no response body or log line matches the
`redact()` patterns; and both mount shapes (`/mcp`, `/<name>/mcp`) resolve.

Beyond the suite: unit tests with `respx`-mocked upstreams; **a real load test** (k6 or
Locust driving an actual MCP client through `initialize`/`tools/list`/`tools/call`) at 1×,
2× and 5× target concurrency asserting p99 and error rate; a rolling-deploy-under-load
test asserting **zero** failed requests; mutation testing on `mcp_common`; ≥90% coverage
on `mcp_common` and ≥80% on generated servers.

---

# §10. Execution plan — ordered, verifiable tasks

Rules for the coding agent, binding on every task:

- **Dependency order is strict.** Do not start a task before its `After:` tasks pass.
- **A task is done only when its `Accept:` tests exist, run in CI, and pass.** "Implemented"
  is not done.
- **Anti-stub gate.** No `TODO`, `FIXME`, `pass`-as-body, `NotImplementedError`, `...`
  placeholder, hardcoded fake return, mock in non-test code, or commented-out
  implementation may be committed. CI greps for these and fails the build (T2). If a
  requirement cannot be met, **stop and report** — do not stub it.
- **No scope drift.** Anything not named in §9 or §10 needs an explicit decision first.
- Every task states the gap IDs it closes; §11 proves the set is complete.

| ID | Task | After | Deliverable & acceptance | Closes |
|---|---|---|---|---|
| **T0** | **API baseline probe.** Monorepo skeleton, `uv` workspace, pin `fastmcp` to the current major (`>=X.Y,<X+1`) + committed `uv.lock`. | — | `tests/test_api_baseline.py` imports all 8 symbols in §9.0 and asserts each signature contains the named parameters via `inspect.signature`. **Accept:** passes; the resolved `fastmcp` version is recorded in the README. If it fails, STOP and report the API delta. | R2-15, R1-15 |
| **T1** | **Foundations:** `settings.py`, `logging.py`, `observability.py`. `SettingsConfigDict`, `env_prefix="MCP_"`, `extra="forbid"`, no secret defaults, all §9.11 validation rules. structlog JSON renderer + contextvars (`bind_request_context`, `bind_principal`, `clear_request_context`) + `redact` processor. OTel tracer + `SHED_COUNTER`/`TIMEOUT_COUNTER` and the RED instruments. | T0 | **Accept:** `test_settings.py` — production without `AUTH_ENABLED` exits non-zero; auth-on without issuer/JWKS/audience fails; `CORS_ORIGINS=["*"]` with credentials fails; `GRACEFUL_SHUTDOWN < max tool timeout` fails; `FORWARDED_ALLOW_IPS="*"` in production fails. `test_logging.py` — output is valid JSON, carries `request_id`, and a line containing a Bearer token / `?api_key=` / a JWT is redacted. | R2-12, R1-6, R1-11 |
| **T2** | **Policy gates.** `ruff` (strict select), `mypy --strict`, `bandit`, `pip-audit`, pre-commit. Three **custom** gates: (a) **no-blocking-call-in-coroutine** — flags `httpx.get/post/...`, `requests.*`, `time.sleep`, `open()`, sync DB drivers inside `async def`; (b) **anti-stub grep** per the gate above; (c) **tool-policy completeness** — every tool registered on a `ServerModule` appears in `tool_scopes`. | T1 | **Accept:** each gate has a positive and a negative fixture under `tests/policy/` and fails the build on the positive. `mypy --strict` clean on `mcp_common`. | R2-4, R2-23, R1-8 |
| **T3** | **`errors.py`** exactly as §9.9: `UpstreamError`, `InvalidToolInput`, `to_tool_error`, `redact`, the 5 redaction patterns. | T1 | **Accept:** `test_errors.py` — a URL carrying `?api_key=SECRET`, a `Bearer` header, a `user:pass@host` DSN, and a JWT are each redacted; `to_tool_error` never returns a message containing the original secret or a traceback; `InvalidToolInput` text *is* passed through; unknown exceptions map to the generic message and log at ERROR. **Property test:** for a corpus of synthetic secrets, `redact(s)` never contains the secret. | R1-4, R2-21 |
| **T4** | **`httpclient.py`** as §9.8, plus a **retry policy** helper: jittered exponential backoff, bounded attempts, **idempotent methods and 429/5xx only** (never 4xx, never non-idempotent POST unless an idempotency key is supplied), plus a circuit breaker per upstream. Also a `build_dsn()` helper using `quote_plus` for any server that needs a database — f-string DSN assembly is banned by review. | T1 | **Accept:** `test_httpclient.py` with `respx` — N sequential calls reuse one client (assert client identity and that `startup` was called once); timeouts and limits are set as configured; `get()` on an undeclared upstream raises; `declare()` after `startup()` raises; `shutdown()` closes all and tolerates a failing `aclose`. `test_retry.py` — POST without an idempotency key is not retried; 404 is not retried; 503 is retried with growing jitter; the breaker opens after the threshold and recovers. `test_dsn.py` — a password containing `@:/#` round-trips. | R1-2, R1-3, R1-7, R2-19 |
| **T5** | **`health.py` + `runtime.py`** as §9.10: `DrainState`, `ReadinessRegistry` (concurrent, per-check timeout, never raises), `/health` and `/ready`, `serve()` with `proxy_headers`, `forwarded_allow_ips`, `timeout_graceful_shutdown`, `timeout_keep_alive`, `access_log=False`. | T1 | **Accept:** `test_health.py` — `/health` is 200 while every readiness check fails; `/ready` is 503 with one failing check and names it; `/ready` is 503 once `drain.begin()`; a hanging check is bounded by the per-check timeout rather than hanging the endpoint. `test_runtime.py` — the uvicorn `Config` carries each required field; **`serve(app_object, workers=2)` raises `TypeError`** and `serve("pkg:app", workers=2)` routes through `uvicorn.run` (the regression test for the silent single-process bug). | R2-11, R2-14, R1-5, B5 (partly) |
| **T6** | **ASGI middleware:** `request_context.py` and `concurrency.py` verbatim from §9.5; `body_limit.py` to its SPEC-ONLY contract. | T1 | **Accept:** `test_asgi.py` — an inbound `x-request-id` is echoed, and a forged one containing `\n` is sanitized; absent, one is generated; the id appears in the access log **and** in the response header; a `lifespan`/`websocket` scope passes through untouched; at `max_concurrent=1` a second concurrent request gets 503 + `Retry-After` while `/health` still returns 200; the semaphore is released after an exception in the inner app (assert by issuing N+1 sequential requests after a failure); oversized declared and chunked bodies each give 413. | R2-5, R2-6, R2-13, R1-3 |
| **T7** | **`auth.py`** as §9.6. Document the on-behalf-of pattern for per-user upstream credentials (exchange the validated principal for an upstream token; never forward the inbound token to an upstream). | T1 | **Accept:** `test_auth.py` against a local JWKS fixture — a valid token passes; wrong `aud` rejected; wrong `iss` rejected; expired rejected; bad signature rejected; unknown `kid` triggers at most one JWKS refresh and is then rejected; **no outbound HTTP occurs on the verification path once keys are cached** (assert via a request-counting fake JWKS server — this is the regression test for R2's defect). | R2-1, R2-3, R2-8, R2-9, R2-10, R1-1 |
| **T8** | **MCP middleware:** `authorization.py` and `timeout.py` verbatim from §9.7/§9.6; `telemetry.py` and `output_budget.py` to their SPEC-ONLY contracts. | T2, T3, T7 | **Accept:** `test_mcpmw.py` — a tool needing a scope the principal lacks raises `ToolError` **and** is absent from `tools/list`; a public tool is reachable with no scopes; a tool sleeping past its budget raises `ToolError` within budget + 1s (not a hang); a per-tool override beats the default; telemetry emits exactly one audit record per call whose `args_sha256` is present and whose payload contains **none** of the argument values; oversized output is truncated with the marker and counted; an exception raised inside a tool arrives as a mapped `ToolError`, never as a success result. | R2-7, R2-13, R2-21, B8 |
| **T9** | **`toolmeta.py`:** `ToolMeta` model, `@tool_meta` decorator writing to the tool's `tags`/`meta` and a module registry, and `make catalog` emitting `catalog.json` (tool id, description, full `ToolMeta`, JSON schema, **schema SHA-256**, server name/version). | T2 | **Accept:** `test_toolmeta.py` — a tool without `ToolMeta` fails the conformance check; `catalog.json` validates against a committed JSON Schema; the schema hash changes when a tool signature changes and is stable otherwise (this is the schema-drift detector). | R2-18, B13, B1 (partly) |
| **T10** | **`idempotency.py`:** ABC + `InProcessIdempotencyStore` + `DynamoDbIdempotencyStore`, both real; startup validation per §9.14. | T1 | **Accept:** `test_idempotency.py` — a duplicate key within TTL returns the reservation rather than re-executing; TTL expiry allows re-execution; the LRU bound holds under 10k keys; **concurrent** `reserve` of one key yields exactly one winner (`asyncio.gather` of 50); the DynamoDB impl is tested against `moto`; startup fails when a write tool + multi-task + `inprocess` are combined. | B7 |
| **T11** | **`module.py` + `app.py`** verbatim from §9.3/§9.4. | T5, T6, T8, T10 | **Accept:** `test_app.py` — single mode serves `/mcp`, composed serves `/a/mcp` and `/b/mcp`; `/health` and `/ready` resolve in **both** modes (the mount-at-`/` ordering trap); duplicate module names raise; empty `modules` raises; `stateless_http=True` is passed for every module (assert on the call); lifespans run in order and exit LIFO (assert with an ordered event list); `clients.startup()` completes before the app accepts a request. | R2-2, R2-17, R1-9, 9.1-10 |
| **T12** | **`testing/conformance.py`** implementing every assertion listed in §9.16, as a reusable suite + fixtures (JWKS fixture, token minter, in-memory MCP client). | T11 | **Accept:** the suite runs green against the T13 reference server and **red** against four deliberately broken variants committed under `tests/negative/`: stateful transport, a sync blocking tool, a tool with no `ToolMeta`, and a tool leaking a secret in its error. A conformance suite that cannot fail is not a test. | R1-8, B11 |
| **T13** | **Reference server, single mode** — a real one, not a demo: one `async` tool calling a real HTTP upstream through the registry, one tool wrapping a blocking library via `anyio.to_thread.run_sync`, one write tool with an idempotency key, full `ToolMeta`, `tool_scopes`, readiness check, `app_single.py`, `entrypoint.py`. | T12 | **Accept:** conformance green; `make run` serves `/mcp` locally; MCP Inspector completes `initialize`/`tools/list`/`tools/call`; `make catalog` emits a valid `catalog.json`. | R2-4, R1-4, 9.13 |
| **T14** | **Composed mode** — a second `ServerModule` and `app_composed.py` driven by a `MCP_MODULES` list, sharing one `ClientRegistry`. | T13 | **Accept:** both servers answer on their own paths in one process; conformance runs green against **each** module through the composed app; a readiness failure in module A makes `/ready` 503 for the whole task and names A (shared-fate is intended and must be documented); tool name collisions across modules are allowed (paths differ) but logged at startup. | R2-17, 9.1-10 |
| **T15** | **Container** per §9.15: multi-stage, digest-pinned, `uv sync --frozen`, non-root, exec-form CMD, `.dockerignore`. | T13 | **Accept:** the build is dependency-reproducible — two builds from the same commit resolve an identical package set (assert by diffing `uv pip freeze` inside both images; do **not** assert identical layer digests, which timestamps and base-image metadata make infeasible); `docker run` passes `/health`; the image contains no `.env`, `.git`, or test files (assert by `docker run --entrypoint ls`); the container exits 0 within the graceful window on `docker stop` (SIGTERM reaches PID 1); image runs with a read-only root filesystem. | R2-20, R1-10, R1-14 |
| **T16** | **ECS Terraform module** `deploy/ecs/`: task definition (secrets from Secrets Manager ARNs, per-server task role, log group), service, target group with the §9.12 numbers, ALB listener rule, autoscaling policy, CloudWatch alarms (p99, 5xx, load-shed, restarts). Parameterized `single` \| `composed`. | T15 | **Accept:** `terraform validate` + `plan` clean for both modes; `checkov`/`tfsec` clean; **a test asserts the TG health check path is `/ready` and the container health check is `/health`**, that `deregistration_delay >= readiness_interval * threshold`, and that `stopTimeout > graceful + drain`; no secret appears in `environment`. | R2-16, B6 |
| **T17** | **CI/CD.** Reusable GitHub workflow: lint → type → policy gates → unit → conformance → coverage (≥90% `mcp_common`, ≥80% servers) → mutation test on `mcp_common` → bandit/pip-audit → SBOM → build + scan image → push to ECR → deploy. Dependabot. Release automation for `mcp_common`. | T12, T15, T16 | **Accept:** the workflow is green on the reference server and **red** when any gate is deliberately violated (one negative commit per gate, proven in a PR). | R1-8, B11 |
| **T18** | **Generator.** `copier`/`cookiecutter` emitting a complete server repo: both app modes, tests importing the conformance suite, Containerfile, `deploy/ecs`, Makefile, pinned `mcp_common`, `.dockerignore`, README. Plus `make upgrade-template` to re-apply a newer template version. | T17 | **Accept:** generating a fresh server and running `make ci` passes **with zero manual edits**; generating two servers and composing them passes T14's assertions; the generated repo contains no placeholder text. | B11 |
| **T19** | **Load, soak, and deploy testing.** k6/Locust driving a genuine MCP client (`initialize` → `tools/list` → `tools/call`) at 1×, 2×, 5× target concurrency. A 30-minute soak checking for FD/memory growth. A rolling-deploy-under-load test. | T16 | **Accept:** published p50/p95/p99 and error rate at each level; **zero** failed requests during the rolling deploy (if not, fix per the §9.10 caveat before proceeding); load shedding engages as 503 + `Retry-After` rather than latency collapse beyond capacity; no FD or RSS growth over the soak; `MAX_CONCURRENT_REQUESTS` and task sizing are then set **from these numbers**, replacing the §9.11 defaults. | B12, B5, §5 capacity |
| **T20** | **Fleet registry.** One manifest per server (name, URL, audience, auth mode, owner, scopes, tags, catalog ref). Generators: `mcp_server.json` (the VS Code/Windsurf shape) and the merged fleet catalog. CI validates uniqueness of name + audience across the fleet. | T9, T18 | **Accept:** `make fleet` emits a schema-valid `mcp_server.json` and a merged catalog from ≥3 registered servers; duplicate name or duplicate audience fails CI; a server whose `catalog.json` hash changed is flagged as a contract change. | B2 (partly), B3, B13 |
| **T21** | **Docs and runbook**, generated from code where possible: architecture, tool-authoring guide, the §9.12 ladder, auth setup, an incident runbook (load shedding, IdP outage, breaker open, drain failure), and a template-upgrade guide. | T18 | **Accept:** a second engineer builds and deploys a new server from the docs alone, with no verbal help. That is the acceptance test. | R1-13 |
| **T22** | **Pilot migration.** Port R1's four real servers (weather, news, currency, quotes) onto the template as the first consumers — one composed container for all four. | T21 | **Accept:** conformance + load green; the currency server's API key appears in **no** log line and **no** tool output (the explicit regression test for R1-4); behaviour matches the originals on a golden-output comparison. | R1-4, validates the whole template |

**Sequencing note.** T0–T12 are the library and must be done in order; T13/T14 prove it;
T15–T18 industrialize it; T19 calibrates it; T20–T22 operationalize it. Do **not** begin
generating the 150 servers before T19 publishes real numbers — tuning 150 deployed
services after the fact is the expensive path.

---

# §11. Coverage audit — self-review of this document

## 11.1 Every R2 gap, traced

| Gap | Where closed | Status |
|---|---|---|
| 1 blocking sync introspection | T7 `JWTVerifier` + local JWKS; T7 asserts zero outbound HTTP on the cached path | Closed |
| 2 stateful transport | T11 — `stateless_http=True` hardcoded, asserted | Closed |
| 3 no token cache | T7 — JWKS cache is built into the verifier | Closed |
| 4 sync `def` CPU-bound guidance | T2 lint gate (a) + §9.13 rule 1 + T13 demonstrates the correct wrapper | Closed |
| 5 `BaseHTTPMiddleware` | T6 — pure ASGI only; §9.5 explains the contextvar breakage | Closed |
| 6 dev middleware body buffering / internals mutation | Not ported. §9.1-5 bans `/auth/*` and dev-only middleware | Removed by design |
| 7 identity verified then discarded | T8 `ToolAuthorizationMiddleware` binds principal + enforces per-tool scopes | Closed |
| 8 no `aud` validation | T7 — per-server `MCP_RESOURCE_AUDIENCE` | Closed |
| 9 self-hosted Authorization Server | Not ported; §9.1-5 invariant | Removed by design |
| 10 cookie not `Secure`; CORS `*`+credentials | No cookies/sessions exist in a stateless server; T1 rejects `*` + credentials | Closed |
| 11 liveness == readiness | T5 — split, with opposite failure semantics | Closed |
| 12 no correlation id / OTel / metrics | T1 + T6 + T8 | Closed |
| 13 no rate limit / concurrency cap / timeout | T6 limiter + T8 per-tool deadline | Closed |
| 14 single process, no `proxy_headers`, no drain | T5 `runtime.py` | Closed |
| 15 `fastmcp` pinned stale | T0 probe + current-major pin | Closed |
| 16 no ECS artifacts | T16 | Closed |
| 17 single-server only | T11 + T14 | Closed |
| 18 tool metadata as prose | T9 typed `ToolMeta` + `catalog.json` | Closed |
| 19 DSN f-string, unencoded password | T4 `build_dsn()` + review ban | Closed |
| 20 container not multi-stage, no lockfile, `:latest` | T15 | Closed |
| 21 broad `except` returning an error dict | T3 + T8 (middleware maps exceptions) + §9.9 rule | Closed |
| 22 module-level mutable global | Not ported | Removed by design |
| 23 permissive `mypy` | T2 `--strict` | Closed |

## 11.2 Every R1 gap, traced

| Gap | Where closed | Status |
|---|---|---|
| 1 no auth | T7 | Closed |
| 2 client per call | T4 `ClientRegistry`, asserted by identity test | Closed |
| 3 no timeouts / concurrency / rate limit | T4 timeouts + T6 limiter + T8 deadline | Closed |
| 4 upstream error text (API key in URL) reaching the model | T3 `redact` + typed errors; T22 is the explicit regression test | Closed |
| 5 fake health check | T5 | Closed |
| 6 no observability | T1 | Closed |
| 7 `retry_on_failure` dead and unsafe | T4 retry policy — idempotent-only, jittered, breaker | Closed |
| 8 no CI / lint / type / real tests | T2 + T12 + T17 | Closed |
| 9 redundant `session_manager.run()` | T11 `combine_lifespans` | Closed |
| 10 single-stage Dockerfile, no lock | T15 | Closed |
| 11 hardcoded port, deprecated `class Config` | T1 `SettingsConfigDict` | Closed |
| 12 unused Redis, obsolete compose key | Not ported | Removed by design |
| 13 README does not match the code | T21 (docs generated where possible) | Closed |
| 14 `.env` bakeable into the image | T15 `.dockerignore` + asserted image contents | Closed |
| 15 bundled SDK FastMCP | T0 standalone FastMCP | Closed |

## 11.3 Cross-cutting gaps — and the ones this template deliberately does **not** close

Stating these plainly matters more than claiming full coverage: four of the thirteen are
not server-template problems, and pretending otherwise would hide real work.

| Gap | Status | Where it actually lives |
|---|---|---|
| B3 registry / service discovery | **Closed** | T20 |
| B5 SIGTERM drain contract | **Closed, pending proof** | T5 config + **T19 proves it**. §9.10 states the ordering caveat honestly rather than asserting a guarantee. |
| B6 ECS/ALB routing design | **Closed** | T16 (+ the §5 gateway decision) |
| B7 idempotency | **Closed** | T10, two real stores |
| B8 output/token governance | **Closed** | T8 `OutputBudgetMiddleware` + §9.13 pagination rule |
| B11 shared library + generator | **Closed** | T1–T18; this is the template's whole purpose |
| B12 load / soak testing | **Closed** | T19 |
| B13 contract / schema drift | **Closed** | T9 schema hash + T20 fleet CI check |
| B1 tool discovery across 150 servers | **PARTIAL — enabling only** | The template *emits* `catalog.json` with typed metadata and a schema hash (T9), and T20 merges the fleet catalog. **The index, `search_tools`/`describe_tool`/`invoke_tool`, and two-stage binding are Phase 2 gateway work (§6) and are out of scope here.** This remains your largest unsolved risk. |
| B2 `mcp_server.json` onboarding | **PARTIAL** | T20 *generates* the file. The gateway that *consumes* it via `create_proxy` is Phase 2. |
| B4 agent-side MCP client lifecycle | **OUT OF SCOPE** | Agent application, Phase 3. 150 pooled sessions, per-server breakers, lazy connect. Nothing in a server template can solve it. |
| B9 tool-selection evaluation harness | **OUT OF SCOPE — enabled** | Phase 2. T9's typed metadata and T20's merged catalog are its inputs. |
| B10 per-user credential propagation | **PARTIAL** | T7/T8 validate and bind the principal and T7 documents the on-behalf-of exchange, but the actual upstream token exchange is per-server domain work, not template code. |

## 11.4 Risks I am deliberately leaving in, and why

Listing these is part of the deliverable — an unflagged risk is the one that bites.

1. **FastMCP version drift is the top risk.** Five of the APIs in §9.0 are load-bearing. T0
   exists precisely so a version mismatch fails loudly at hour one instead of at server 90.
   Two items are explicitly marked "confirm against the pinned version": the
   `ToolResult` content-block attribute names (§9.7, `OutputBudgetMiddleware`) and the
   `Tool.name`/`tags` attributes used by the `on_list_tools` filter (§9.6).
2. **The drain ordering is configuration-dependent**, not provable from code alone (§9.10
   caveat). T19 is the gate. If it fails, add an explicit pre-stop delay rather than
   tuning timeouts by guesswork.
3. **`tool_scopes` fails open** for an unlisted tool. Mitigated by the T2 completeness
   gate, which is a build-time check rather than a runtime guarantee — if that lint rule
   is ever disabled, the posture silently loosens.
4. **Composed mode means shared fate**: one module's failed readiness check takes the
   whole task out of service, and one module's runaway tool consumes the shared
   concurrency budget. This is intended (it is what co-location means) and must be a
   documented input to the which-servers-share-a-container decision, not a surprise.
5. **All §9.11/§9.12 numbers are informed defaults, not measurements.** T19 replaces them.
   Treat every one as provisional until then.
6. **Per-tool scope policy is static config.** If entitlements become dynamic (per-tenant
   tool visibility), `ToolAuthorizationMiddleware` needs a policy *provider* rather than a
   frozen map — a known extension point, not a defect today.

## 11.5 Anti-stub self-check on this document

- Every code block in §9 is complete and runnable as written, except the four modules
  explicitly labelled **SPEC-ONLY** (`BodyLimitMiddleware`, `TelemetryMiddleware`,
  `OutputBudgetMiddleware`, and the `ToolMeta` model's surrounding decorator/export
  machinery), each of which carries a binding behavioural contract and named acceptance
  tests in §10. No block contains `pass`, `TODO`, `...`, or a fabricated return value.
- No mock, fake, or in-memory substitute is proposed for a production path. The one
  in-memory component (`InProcessIdempotencyStore`) is a legitimate implementation for
  single-process deployments, is paired with a real distributed implementation, and its
  misuse is caught by a startup check (§9.14) rather than left to documentation.
- `health_path`, `UpstreamSpec.http2=False`, and `REQUIRED_BASE_SCOPES=[]` are defaults
  with stated rationale, not placeholders.
- Where I could not verify something, §11.4 says so rather than the prose implying
  certainty.

**Defects found and fixed during this document's own review pass.** Recorded because a
spec that claims to be a single source of truth should show its corrections rather than
present itself as having been right the first time:

1. **`serve()` silently ignored `workers`.** `uvicorn.Server(config).run()` does not
   honour `workers`; multi-process mode requires `uvicorn.run()` with an import string.
   As first written, `UVICORN_WORKERS=4` would have run **one** process — a capacity bug
   that surfaces only as an unexplained throughput ceiling. Now an explicit two-path
   implementation that raises `TypeError` on the invalid combination, with a regression
   test in T5.
2. **The keep-alive / ALB idle relationship was inverted.** The original ladder had
   uvicorn `timeout_keep_alive` (75s) *below* the ALB idle timeout (120s). That is
   backwards: if the backend closes an idle connection first, the ALB can reuse the dead
   socket and the client sees a spurious 502. Corrected to agent 45s < ALB idle 60s <
   keep-alive 75s, with the reasoning stated inline at §9.12.
3. **T15 demanded an infeasible test.** "Two builds → identical layer digests" cannot pass
   with timestamps and base-image metadata in play. Replaced with dependency
   reproducibility, which is both meaningful and achievable.
4. **The §9.14 idempotency check was unimplementable as specified** — a process cannot read
   its own ECS `desiredCount`. Rewired to an explicit `MCP_MULTI_INSTANCE` setting that the
   Terraform module sets when `desired_count > 1`.
5. **`ConcurrencyLimitMiddleware` is per-process**, so `MAX_CONCURRENT_REQUESTS` multiplies
   by worker count. This was unstated and would have made the limit silently wrong under
   `workers>1`; now documented at §9.10 and reflected in the settings table.

Items 1, 2 and 4 would each have shipped a real production defect into all 150 servers.
