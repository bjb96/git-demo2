# 17 — Gold-KB Fixture (the canonical test corpus referenced everywhere)

> **Purpose** — every test in `10_tdd_acceptance.md`, every UAT case in `16_user_uat_script.md`, every nightly bench run, and every integration test calls into `tests/fixtures/corpora/lint_clean/`. Without a defined fixture, the junior agent invents content and the UAT fails in subtle ways. **This file defines the fixture verbatim.** Closing PM gap GAP-1.
>
> **Audience** — junior agent at the start of Phase 1.
>
> **Files this contract drives**:
> - `tests/fixtures/corpora/lint_clean/manifest.yaml`
> - `tests/fixtures/corpora/lint_clean/wiki/*.md` (3 files)
> - `tests/fixtures/corpora/lint_clean/engineering_raw/**/*.md` (4 files)
> - `tests/fixtures/expected_results.json`
> - `tests/fixtures/bench/nightly_queries.jsonl`
> - `tests/fixtures/corpora/lint_broken/*` (for negative-path lint tests)

---

## §1. The 7-document gold KB at a glance

```
tests/fixtures/corpora/lint_clean/
├── manifest.yaml                                             # canonical 2-collection manifest
├── wiki/                                                     # 3 curated wiki pages
│   ├── index.md                                              # TOC
│   ├── kafka-consumer-lag.md                                 # the canonical runbook page
│   └── authentication.md                                     # the canonical auth page
└── engineering_raw/                                          # 4 raw source documents
    ├── README.md                                             # top-level README
    ├── adr/
    │   └── 001-bm25-choice.md                                # ADR doc
    └── runbooks/
        └── kafka.md                                          # raw runbook source (less curated than wiki version)
```

**Total: 7 markdown files. ~3,800 words total. Builds in < 5 sec; embeds in < 30 sec against LocalStack-mocked Bedrock.**

### Why this exact shape

- **2 collections** (`wiki`, `engineering_raw`) — minimum to exercise wiki-first / raw-fallback (ADR-013)
- **3 wiki pages** + **4 raw docs** = 7 — gives the chunker enough variety to exercise H1/H2/H3/code-fence break points without exploding test data
- **Path-prefix contexts** for both collections — exercises the CTX zone (§4.2 of `00_*.md`)
- **One overlapping topic** (Kafka exists in both `wiki/kafka-consumer-lag.md` AND `engineering_raw/runbooks/kafka.md`) — UAT case 1 verifies wiki wins
- **One topic ONLY in raw** (`engineering_raw/README.md`) — UAT case 2 verifies fallback fires
- **One topic ONLY in wiki** (`wiki/authentication.md`) — UAT case 6 verifies expansion + rerank against curated content

---

## §2. `tests/fixtures/corpora/lint_clean/manifest.yaml` (verbatim)

```yaml
# tests/fixtures/corpora/lint_clean/manifest.yaml
#
# Canonical 2-collection test manifest. Used by:
#  - tests/integration/test_build_pipeline.py
#  - tests/integration/test_query_pipeline.py
#  - tests/integration/test_mcp_endpoints.py
#  - tests/e2e/test_demo_scenarios.py
#  - tests/load/locustfile.py (smoke profile)
#  - 16_user_uat_script.md (cases 1-8)
#  - scripts/nightly_bench.py (sourced from s3://kb-{env}/bench/nightly_queries.jsonl)

build_info:
  kbm_version: "0.1.0"
  embedding_model_id: "amazon.titan-embed-text-v2:0"
  embedding_dim: 1024
  rerank_model: "gpt-4.1"
  expand_model: "gpt-4.1"
  chunk_size_tokens: 900
  chunk_overlap_tokens: 135
  chunk_window_tokens: 200

global_context: |
  Knowledge base for the doc_agent product. Cite results by qmd:// path + docid.
  Wiki pages (kind=wiki) are curated synthesis; raw documents are immutable sources.

collections:
  wiki:
    kind: wiki
    path: "./wiki"
    pattern: "**/*.md"
    ignore:
      - "log.md"                              # changelog (per ADR-013)
      - ".obsidian/**"                        # Obsidian metadata if present
    context:
      "/":         "Engineering wiki — curated synthesis. Primary retrieval target."
      "/index":    "Table of contents."
    include_by_default: true
    chunk_strategy: "regex"

  engineering_raw:
    kind: raw
    path: "./engineering_raw"
    pattern: "**/*.md"
    ignore: []
    context:
      "/":         "Engineering raw documents. Fallback when wiki is silent."
      "/adr":      "Architecture Decision Records — cite ADR numbers when relevant."
      "/runbooks": "Raw on-call runbooks (pre-wiki). May be partial or stale."
    include_by_default: false                  # ADR-013: raw is fallback only
    chunk_strategy: "regex"
```

---

## §3. The 3 wiki files (verbatim)

### §3.1 `tests/fixtures/corpora/lint_clean/wiki/index.md`

```markdown
# Engineering Wiki — Index

**Summary**: Table of contents for the curated engineering wiki.

**Sources**: This page is hand-maintained; not derived from any single raw doc.

**Last updated**: 2026-05-19

---

## Curated pages

- [[kafka-consumer-lag]] — diagnosis + mitigation for Kafka consumer lag in production
- [[authentication]] — how users authenticate; JWT bearer tokens; refresh-token flow

## Conventions

- Every wiki page has a Summary, Sources, Last updated header.
- Every factual claim cites its raw source file in the format `(source: path/to/file.md)`.
- Wiki-links use double-bracket syntax `[[other-page]]` for transitive retrieval.

## Related raw collections

- `engineering_raw/runbooks/` — raw on-call runbooks before wiki curation
- `engineering_raw/adr/` — Architecture Decision Records
```

### §3.2 `tests/fixtures/corpora/lint_clean/wiki/kafka-consumer-lag.md`

```markdown
# Kafka Consumer Lag — Diagnosis & Mitigation

**Summary**: How to detect Kafka consumer lag in production and the three mitigation paths (scale-up, rebalance, repartition).

**Sources**: `engineering_raw/runbooks/kafka.md`

**Last updated**: 2026-05-18

---

## What is consumer lag?

Consumer lag is the difference between the latest message offset in a Kafka topic
partition and the offset the consumer group has committed. Sustained lag means
consumers are falling behind producers; eventually downstream systems see stale data.

## Detection signals

1. **Datadog dashboard** — `kafka.consumer.lag` metric, alerting threshold is **1000 messages**.
   When the threshold is exceeded for 5 minutes, PagerDuty fires `kafka-consumer-lag-high`.
2. **Manual check** — run `kafka-consumer-groups --bootstrap-server <broker> --describe --group <group>`.
   Look at the `LAG` column for any partition reporting > 1000.
3. **Symptom-side** — downstream services report stale data; user-facing freshness drops.

## The 3 mitigation paths

### Path A — Scale up the consumer group

When the lag is rising linearly with traffic, the consumers are CPU-bound.

```bash
# Increase the consumer group's replica count (depends on deployment)
kubectl scale deployment orders-consumer --replicas=8
```

Verify: `kafka.consumer.lag` should drop within 5-10 minutes.

### Path B — Trigger a rebalance

If the lag is concentrated in 1-2 partitions, the consumer group's partitions are
unevenly distributed.

```bash
# Force a rebalance by restarting the consumer group
kafka-consumer-groups --bootstrap-server <broker> --group orders --reset-offsets --to-current --execute --topic orders
```

### Path C — Repartition the topic

If lag is sustained even after scaling, the topic itself has too few partitions
for the throughput. **This requires planned downtime.** See the runbook at
`engineering_raw/runbooks/kafka.md` for the full repartition procedure.

## Related pages

- [[authentication]] — relevant if the consumer is auth-protected and tokens are
  about to expire (a niche cause of "lag")

## When to escalate

If the lag exceeds 50,000 messages OR if scaling Path A doesn't help within 15 minutes,
escalate to the platform team via PagerDuty.
```

### §3.3 `tests/fixtures/corpora/lint_clean/wiki/authentication.md`

```markdown
# Authentication API

**Summary**: How users authenticate with the platform. JWT bearer tokens signed with RS256; 60-minute access tokens with refresh-token rotation.

**Sources**: `engineering_raw/adr/001-bm25-choice.md` (no direct source — this page synthesizes API behavior from the codebase)

**Last updated**: 2026-05-15

---

## Token shape

Access tokens are JWT bearer tokens signed with RS256. The payload contains:

- `sub` — user UUID
- `iss` — `https://auth.example.com`
- `aud` — service name
- `exp` — Unix timestamp (60 minutes from issue)
- `iat` — Unix timestamp at issue

## Endpoints

### `POST /v1/auth/login`

Request: `{"email": "...", "password": "..."}`
Response: `{"access_token": "<jwt>", "refresh_token": "<opaque>", "expires_in": 3600}`

### `POST /v1/auth/refresh`

Request: `{"refresh_token": "..."}`
Response: same shape as login.

Refresh tokens rotate on every use — the previous refresh token becomes invalid.

### `POST /v1/auth/logout`

Invalidates the current refresh token. Access tokens remain valid until `exp`.

## How services validate

Services include a `JWT_PUBLIC_KEY` env var (the auth service's public key). On every
inbound request:

1. Read `Authorization: Bearer <token>` header
2. Verify signature using the public key (RS256)
3. Check `exp` is in the future
4. Use `sub` as the user ID

## Common errors

- `401 invalid_token` — signature mismatch OR `exp` in the past
- `403 forbidden` — token valid but user lacks the required scope
- `429 rate_limited` — too many auth attempts in 5 minutes

## Related pages

- [[kafka-consumer-lag]] — if a consumer is auth-protected, expired tokens can
  surface as lag (consumer can't read from upstream)
```

---

## §4. The 4 engineering_raw files (verbatim)

### §4.1 `tests/fixtures/corpora/lint_clean/engineering_raw/README.md`

```markdown
# Engineering — Raw Documents

This folder holds raw engineering documents (runbooks, ADRs, transcripts).
Content here is **immutable** — the build pipeline reads but never writes.

Curated synthesis lives in the `wiki/` collection (see [[../wiki/index.md|wiki index]]
for guidance on how to use it).

## Subfolders

- `runbooks/` — on-call runbooks (pre-wiki curation)
- `adr/` — Architecture Decision Records

## Conventions

- File names use `kebab-case.md`
- Every doc has a `# Title` H1 as the first line
- Code blocks must be fenced with ```` ``` ````
- Hand-maintained changelogs go in `log.md` (per-folder) and are NOT indexed
```

### §4.2 `tests/fixtures/corpora/lint_clean/engineering_raw/adr/001-bm25-choice.md`

```markdown
# ADR 001 — Choose SQLite FTS5 BM25 over OpenSearch for Knowledge-Base Retrieval

**Status**: Accepted (2026-03-12)

**Decision-maker**: Platform team

## Context

We need a BM25-capable full-text search backend for the doc_agent knowledge base.
Three options were considered:

1. **SQLite FTS5** — built into stdlib; column weights via `bm25(t, w1, w2, w3)`
2. **OpenSearch / Elasticsearch BM25** — managed service; mature BM25 implementation
3. **Pure-Python `bm25s`** — fast NumPy implementation; no column weights

## Decision

We choose **SQLite FTS5**.

## Rationale

- Column weights — we need `filepath=1.5, title=4.0, body=1.0` to boost titles
  in the ranking. FTS5 supports this natively via `bm25(documents_fts, 1.5, 4.0, 1.0)`.
- Zero infrastructure — ships in stdlib `sqlite3`. No service to manage.
- Per-collection isolation — one SQLite file per collection; trivial to ship
  artifacts via S3.

## Alternatives considered

### OpenSearch

Pros: managed; battle-tested at scale. Cons: an extra managed service per env;
significantly higher cost at our scale; complex auth and IAM. Rejected for v1.

### `bm25s`

Pros: ~500× faster than `rank_bm25` for pure-text. Cons: no column-weight API;
compensating via 3 parallel indexes is more complex than just using FTS5.

## Consequences

- Per-collection `.sqlite` files ship as immutable artifacts via S3
- Container boot pulls them to local disk; queries hit the local file
- Builders pay a small write-time cost (~5s for 7 docs); query-time cost is FTS5-fast
- See also: ADR-005 (FAISS for vector search)

## Notes

The choice mirrors doc_search's architecture (see `temp/deep_dives/doc_search_tool/24_audit_and_corrections.md §1`
row 11 for the verified column-weight values).
```

### §4.3 `tests/fixtures/corpora/lint_clean/engineering_raw/runbooks/kafka.md`

```markdown
# Kafka On-Call Runbook (raw)

This is the raw runbook source for Kafka issues. The curated synthesis is in
`wiki/kafka-consumer-lag.md`.

## Common incidents

### Consumer lag spike

See `wiki/kafka-consumer-lag.md` for full diagnosis. TL;DR:
- Check Datadog `kafka.consumer.lag` metric
- Threshold: 1000 messages sustained for 5 min
- 3 mitigation paths: scale up, rebalance, repartition

### Broker memory pressure

Symptom: brokers OOM-killed by k8s; followers fall out of ISR.

Mitigation:
1. Check `kafka.server.JvmInfo.HeapMemoryUsage.used` in CloudWatch.
2. If > 80% of `HeapMemoryUsage.max`: bump heap size via `KAFKA_HEAP_OPTS`.
3. Rolling restart of broker pods (one at a time; wait for ISR to recover).

### Partition leader election storms

Symptom: producers report `NotLeaderForPartition` errors.

Mitigation:
1. `kafka-leader-election --bootstrap-server <broker> --election-type PREFERRED --all-topic-partitions`
2. Wait 30 seconds; verify with `kafka-topics --describe`.

### Disk full on a broker

Symptom: broker stops accepting writes; producer 503s.

Mitigation:
1. Delete old log segments: NOT recommended (data loss).
2. Bump broker EBS volume (live resize on EBS gp3).
3. Trigger log compaction earlier via `cleanup.policy=compact` on idle topics.

## Long-term: repartitioning

If lag is sustained even after scaling consumers, the topic needs more partitions.

**Procedure** (planned downtime):

1. Announce maintenance window (30 min).
2. Stop producers.
3. `kafka-topics --alter --bootstrap-server <broker> --topic <topic> --partitions <new-count>`
4. Wait for consumer group to rebalance.
5. Restart producers.

**Risks**: increased partition count is irreversible. Don't over-provision.

## Contact

PagerDuty: `kafka-oncall`. Slack: `#kafka-help`.
```

---

## §5. `tests/fixtures/expected_results.json` (verbatim)

The single source-of-truth for "what should each test query return?" Used by `tests/integration/test_query_pipeline.py` and the UAT cases in `16_*.md`.

```json
{
  "_meta": {
    "purpose": "Maps a test query to the expected top-3 docids (in order). Generated by running the full kbm pipeline against the gold KB once and inspecting outputs by hand.",
    "regenerate_when": "manifest.yaml, any wiki/raw file, or any retrieval constant changes",
    "regenerate_via": "python scripts/regenerate_expected_results.py --fixture lint_clean"
  },

  "queries": [
    {
      "id": "uat_case_1_kafka_runbook",
      "query": "kafka consumer lag",
      "collections": ["wiki"],
      "intent": null,
      "expected_top_docid": "be7a1c",
      "expected_top_path": "qmd://wiki/kafka-consumer-lag.md",
      "expected_top_3_paths_unordered": [
        "qmd://wiki/kafka-consumer-lag.md"
      ],
      "expected_min_top_score": 0.85,
      "notes": "UAT case 1. Strong-signal bypass MUST trigger here (wiki has 1 exact match)."
    },
    {
      "id": "uat_case_2_engineering_readme_fallback",
      "query": "engineering README",
      "collections": ["wiki", "engineering_raw"],
      "intent": null,
      "expected_top_docid": "a13fbb",
      "expected_top_path": "qmd://engineering_raw/README.md",
      "expected_top_3_paths_unordered": [
        "qmd://engineering_raw/README.md"
      ],
      "expected_min_top_score": 0.60,
      "notes": "UAT case 2. wiki query yields empty/low-score; agent falls back to multi-collection; raw README wins."
    },
    {
      "id": "uat_case_3_kafka_runbook_and_bm25_adr",
      "query": "kafka runbook and BM25 ADR",
      "collections": ["wiki", "engineering_raw"],
      "intent": null,
      "expected_top_docid": "be7a1c",
      "expected_top_path": "qmd://wiki/kafka-consumer-lag.md",
      "expected_top_3_paths_unordered": [
        "qmd://wiki/kafka-consumer-lag.md",
        "qmd://engineering_raw/adr/001-bm25-choice.md",
        "qmd://engineering_raw/runbooks/kafka.md"
      ],
      "expected_min_top_score": 0.50,
      "notes": "UAT case 3 multi-get target. Top 3 should include both the wiki kafka page AND the ADR doc."
    },
    {
      "id": "uat_case_6_authentication_expansion",
      "query": "how do users get authenticated in our system",
      "collections": ["wiki"],
      "intent": null,
      "expected_top_docid": "c2e9da",
      "expected_top_path": "qmd://wiki/authentication.md",
      "expected_top_3_paths_unordered": [
        "qmd://wiki/authentication.md"
      ],
      "expected_min_top_score": 0.70,
      "notes": "UAT case 6. Strong-signal bypass should NOT fire (paraphrased). Expansion + rerank should land authentication.md at #1."
    },
    {
      "id": "uat_case_8_not_found_with_suggestions",
      "query": "deployment runbook for our prod service",
      "collections": ["wiki", "engineering_raw"],
      "intent": null,
      "expected_top_docid": null,
      "expected_top_path": null,
      "expected_top_3_paths_unordered": [],
      "expected_min_top_score": 0.50,
      "fallback_expected": "empty_or_low_score",
      "notes": "UAT case 8. KB has no deployment runbook. Result list should be empty (after min_score=0.50 filter) OR contain only low-confidence hits the agent can present as 'I couldn't find...'."
    }
  ],

  "_docid_table": {
    "_note": "Computed once via `python -c 'import hashlib; print(hashlib.sha256(open(p,\"rb\").read()).hexdigest()[:6])'`. Regenerate if you edit any wiki/raw file.",
    "qmd://wiki/index.md":                                   "8f3b21",
    "qmd://wiki/kafka-consumer-lag.md":                      "be7a1c",
    "qmd://wiki/authentication.md":                          "c2e9da",
    "qmd://engineering_raw/README.md":                       "a13fbb",
    "qmd://engineering_raw/adr/001-bm25-choice.md":          "d05e87",
    "qmd://engineering_raw/runbooks/kafka.md":               "7e44b2"
  }
}
```

**Note for the junior agent**: the docids above are PLACEHOLDERS — your job on Phase 1 is to run `python scripts/regenerate_expected_results.py` after writing the fixture, then commit the regenerated `expected_results.json` with the REAL docids. The placeholders prevent the file from being empty; the script ensures truth.

---

## §6. `tests/fixtures/bench/nightly_queries.jsonl` (verbatim — 10 golden queries)

One JSON object per line (JSONL format). Consumed by `scripts/nightly_bench.py` (per `12_*.md §8`).

```jsonl
{"id": "q1_kafka_lag",           "query": "kafka consumer lag",                              "collections": ["wiki"],                       "expected_top_docids": ["be7a1c"]}
{"id": "q2_kafka_paraphrase",    "query": "what to do when kafka consumers fall behind",     "collections": ["wiki"],                       "expected_top_docids": ["be7a1c"]}
{"id": "q3_auth_direct",         "query": "JWT bearer token verification",                   "collections": ["wiki"],                       "expected_top_docids": ["c2e9da"]}
{"id": "q4_auth_paraphrase",     "query": "how do users log in",                             "collections": ["wiki"],                       "expected_top_docids": ["c2e9da"]}
{"id": "q5_readme_fallback",     "query": "engineering README contents",                     "collections": ["wiki", "engineering_raw"],    "expected_top_docids": ["a13fbb"]}
{"id": "q6_bm25_adr",            "query": "why did we choose SQLite FTS5 for BM25",          "collections": ["engineering_raw"],            "expected_top_docids": ["d05e87"]}
{"id": "q7_raw_kafka_repartition","query": "repartitioning kafka topics procedure",          "collections": ["engineering_raw"],            "expected_top_docids": ["7e44b2"]}
{"id": "q8_kafka_disambig",      "query": "kafka broker OOM-killed",                         "collections": ["engineering_raw"],            "expected_top_docids": ["7e44b2"]}
{"id": "q9_cross_collection",    "query": "kafka",                                           "collections": ["wiki", "engineering_raw"],    "expected_top_docids": ["be7a1c", "7e44b2"]}
{"id": "q10_not_found",          "query": "kubernetes ingress controller",                   "collections": ["wiki", "engineering_raw"],    "expected_top_docids": []}
```

**Scoring** (in `scripts/nightly_bench.py`):
- For each query: if `expected_top_docids` is non-empty, score = 1 if the expected docid is the actual top result, 0.5 if it's in the top-3, else 0.
- For `q10_not_found`: score = 1 if returned list is empty OR all returned scores < 0.5, else 0.
- Aggregate: sum of 10 scores. **SLO target: ≥ 7.0/10** (per `12_*.md §1` row "Nightly bench recall@3").
- Alert at `≥ 2 consecutive nights < 6.0`.

---

## §7. The lint-broken corpus (negative-path fixtures)

`tests/fixtures/corpora/lint_broken/` is a copy of `lint_clean/` with 3 deliberate bugs to verify each lint check (L1, L2, L6, L9) fires:

```
tests/fixtures/corpora/lint_broken/
├── manifest.yaml                                # same as lint_clean BUT with corruption hooks below
├── wiki/
│   ├── index.md                                 # ← L1 trigger: doc under wiki/ but no context for path "/orphan-zone"
│   ├── kafka-consumer-lag.md
│   ├── authentication.md
│   └── orphan-zone/
│       └── orphan-doc.md                        # ← L1: this path has no matching context prefix
├── engineering_raw/
│   ├── README.md
│   ├── empty-doc.md                             # ← L6 trigger: zero-length body
│   ├── adr/
│   │   └── 001-bm25-choice.md
│   └── runbooks/
│       └── kafka.md
└── _broken_meta_parquet_marker.txt              # signal to the lint test to drop 1 row from vectors/wiki/meta.parquet before re-running lint (causes L2)
```

**Manifest difference** (only `context:` is changed):
```yaml
collections:
  wiki:
    kind: wiki
    path: "./wiki"
    pattern: "**/*.md"
    ignore: ["log.md"]
    context:
      "/":      "Engineering wiki — curated synthesis."
      "/index": "Table of contents."
      # NOTE: no entry for "/orphan-zone" — L1 must fire on orphan-doc.md
```

**Pseudo-code for the L9 trigger** (used in `test_kbm_lint_catches_dim_mismatch`):

```python
def test_kbm_lint_catches_dim_mismatch(tmp_path, gold_kb_dir):
    """Verify lint check L9 (embedding_dim_mismatch) fires."""
    # 1. Run kbm build + embed against the clean fixture
    build_and_embed(gold_kb_dir, output=tmp_path)
    # 2. Corrupt the embedding_model.txt sidecar to claim wrong dim
    (tmp_path / "vectors" / "wiki" / "embedding_model.txt").write_text(
        "amazon.titan-embed-text-v2:0\n384\n"  # claim 384-dim; actual is 1024
    )
    # 3. Run lint
    result = run_kbm_lint(output=tmp_path)
    assert result.exit_code == 1
    assert any(e["check"] == "L9_embedding_dim_mismatch" for e in result.lint_errors)
```

---

## §8. The `tests/integration/conftest.py` `gold_kb` fixture (verbatim)

```python
"""tests/integration/conftest.py — gold-KB fixture loader.

Builds + embeds the gold KB ONCE per test session against LocalStack S3 +
fakeredis. Returns paths the test code can use.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Iterator

import boto3
import pytest


@pytest.fixture(scope="session")
def gold_kb_build_dir(tmp_path_factory, gold_kb_dir: Path) -> Iterator[Path]:
    """Run `kbm build && kbm embed && kbm lint` against the gold-KB fixture.
    Yields the build-output dir."""
    out = tmp_path_factory.mktemp("gold_kb_build")

    # Copy the fixture content into a writable tmp dir (the build CLI reads
    # `path:` values from manifest.yaml as-is)
    src = out / "src"
    shutil.copytree(gold_kb_dir, src, dirs_exist_ok=True)

    # Symlink/copy manifest into the parent of `src/` so paths resolve relative
    manifest = src / "manifest.yaml"
    assert manifest.exists(), f"Gold-KB fixture missing manifest.yaml at {manifest}"

    # Run kbm build → embed → lint
    env = {"KBM_ENV": "test", **dict_os_environ()}
    subprocess.check_call(
        ["kbm", "build", "--manifest", str(manifest), "--output", str(out / "kb")],
        env=env, cwd=str(src),
    )
    subprocess.check_call(
        ["kbm", "embed", "--output", str(out / "kb")],
        env=env,
    )
    subprocess.check_call(
        ["kbm", "lint", "--output", str(out / "kb")],
        env=env,
    )

    yield out / "kb"


@pytest.fixture(scope="session")
def gold_kb_uploaded(gold_kb_build_dir: Path, localstack_s3) -> Iterator[str]:
    """Uploads the built KB to LocalStack S3. Yields the bucket prefix."""
    bucket = "kb-test"
    localstack_s3.create_bucket(Bucket=bucket)

    # Upload every file in gold_kb_build_dir to s3://kb-test/
    for path in gold_kb_build_dir.rglob("*"):
        if path.is_file():
            key = str(path.relative_to(gold_kb_build_dir)).replace("\\", "/")
            with open(path, "rb") as f:
                localstack_s3.put_object(Bucket=bucket, Key=key, Body=f.read())

    yield f"s3://{bucket}/"
```

---

## §9. How to regenerate `expected_results.json` after editing the fixture

```sh
# 1. Build + embed against the (edited) gold KB
kbm build --manifest tests/fixtures/corpora/lint_clean/manifest.yaml \
          --output ./tmp-build/
kbm embed --output ./tmp-build/
kbm lint  --output ./tmp-build/   # MUST exit 0

# 2. Compute new docids
python -c "
import hashlib, pathlib
fixt = pathlib.Path('tests/fixtures/corpora/lint_clean')
for p in sorted(fixt.rglob('*.md')):
    if 'log.md' in p.name: continue
    rel = p.relative_to(fixt).as_posix()
    coll = rel.split('/', 1)[0]
    rest = rel.split('/', 1)[1] if '/' in rel else ''
    sha = hashlib.sha256(p.read_bytes()).hexdigest()
    print(f'  \"qmd://{coll}/{rest}\": \"{sha[:6]}\"')
"

# 3. Run each query in expected_results.json against the fresh KB
python scripts/regenerate_expected_results.py \
    --fixture tests/fixtures/corpora/lint_clean \
    --build-dir ./tmp-build/ \
    --output tests/fixtures/expected_results.json

# 4. Visually inspect the diff
git diff tests/fixtures/expected_results.json

# 5. Commit
git add tests/fixtures/expected_results.json
git commit -m "fix(fixture): regenerate expected_results.json after fixture edit"
```

The `regenerate_expected_results.py` script is itself a Phase 1 deliverable; its body is straightforward (~80 LOC) — load the queries from a starter file, run each via `kbm.search.query.hybrid_query()`, capture the top-3 docids, write back.

---

## §10. Definition of Done (Phase 1 fixture)

When this checklist is complete, the bundle's UAT cases + integration tests + nightly bench all become executable:

- [ ] `tests/fixtures/corpora/lint_clean/manifest.yaml` matches §2 verbatim
- [ ] All 7 markdown files (§3 + §4) exist with the bodies specified
- [ ] `tests/fixtures/expected_results.json` exists with REAL docids (regenerated per §9)
- [ ] `tests/fixtures/bench/nightly_queries.jsonl` matches §6 (10 lines)
- [ ] `tests/fixtures/corpora/lint_broken/` exists with the 4 deliberate breakages from §7
- [ ] `tests/integration/conftest.py` has the `gold_kb_build_dir` + `gold_kb_uploaded` fixtures from §8
- [ ] Running `kbm build && kbm embed && kbm lint` against the gold KB exits 0
- [ ] Running `kbm lint` against the lint-broken fixture exits 1 with at least 3 lint errors (L1, L2, L6 minimum)
- [ ] `scripts/regenerate_expected_results.py` exists and is deterministic on the gold KB

---

*End of gold-KB fixture spec. With this in place, every integration test and UAT case has a concrete substrate. Closes PM gap GAP-1.*
