# 04 — MCP Tool Contract (5 MCP tools + 5 CLI commands, every input, every output, every error)

> **Purpose** — the single source of truth for **what `kbm` exposes** to (a) the parent `target_product_bundle` chatbot agent via MCP, and (b) the developer via the local CLI. Every input field, every output field, every status code, every error envelope, and every verbatim tool description lives here. **A junior agent who deviates from this contract breaks the chatbot integration.**
>
> **Phase**: Phase 3 (MCP layer) + Phase 4 (search-half wires in). Files this contract drives: `src/kbm/mcp/server.py`, `src/kbm/mcp/tools.py`, `src/kbm/mcp/auth.py`, `src/kbm/mcp/health.py`, `src/kbm/mcp/instructions.py`, `src/kbm/build/cli.py`.

---

## §1. The two surfaces

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Surface A — MCP server  (ECS-hosted, called by chatbot agent)          │
│  ─────────────────────────────────────────────────────────────────────  │
│  POST /mcp                  JSON-RPC 2.0 (stateful sessions)            │
│  POST /query                REST shortcut (one-shot, no session)         │
│  GET  /health               Liveness                                     │
│  GET  /ready                Readiness                                    │
│  GET  /metrics              Prometheus-compatible (optional v2)          │
│                                                                          │
│  5 MCP tools exposed via tools/list:                                    │
│    query, get, multi_get, status, ls                                     │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│  Surface B — Local CLI  (developer's laptop)                            │
│  ─────────────────────────────────────────────────────────────────────  │
│  kbm build                  Walk + hash + content-addressable write     │
│  kbm embed                  Chunk + embed + dual-index per collection    │
│  kbm lint                   Run 9 lint checks; produce build_info.json   │
│  kbm plan-upload            Diff local vs S3; show what would change    │
│  kbm upload                 Atomic aws s3 sync                          │
└─────────────────────────────────────────────────────────────────────────┘
```

The two surfaces share **zero runtime code** but share **all Pydantic models** (see [03_data_contracts.md](03_data_contracts.md)).

---

## §2. MCP transport mechanics

### §2.1 `POST /mcp` — JSON-RPC 2.0 (the canonical surface)

The agent's first call after connection is `initialize`. Server replies with `serverInfo` + `capabilities` + a long-form `instructions` string. Subsequent calls require the `mcp-session-id` header returned by `initialize`.

**Verbatim request shapes** (the agent will send these; the server MUST accept exactly these shapes):

```jsonc
// 1. Initialize a session
POST /mcp
Content-Type: application/json
Authorization: Bearer <KBM_BEARER_TOKEN>
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "protocolVersion": "2025-06-18",
    "clientInfo": { "name": "target_product_bundle", "version": "1.0.0" }
  }
}

// Response (verbatim shape):
HTTP/1.1 200 OK
mcp-session-id: <uuid>
Content-Type: application/json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "protocolVersion": "2025-06-18",
    "serverInfo": { "name": "kbm", "version": "0.1.0" },
    "capabilities": {
      "tools": { "listChanged": false },
      "resources": { "subscribe": false, "listChanged": false }
    },
    "instructions": "<the buildInstructions(catalog) output — see §10>"
  }
}
```

```jsonc
// 2. List tools
POST /mcp
mcp-session-id: <uuid>
{ "jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {} }

// Response:
{
  "jsonrpc": "2.0", "id": 2,
  "result": {
    "tools": [
      { "name": "query",     "description": "<verbatim from §3>", "inputSchema": {...} },
      { "name": "get",       "description": "<verbatim from §4>", "inputSchema": {...} },
      { "name": "multi_get", "description": "<verbatim from §5>", "inputSchema": {...} },
      { "name": "status",    "description": "<verbatim from §6>", "inputSchema": {...} },
      { "name": "ls",        "description": "<verbatim from §7>", "inputSchema": {...} }
    ]
  }
}
```

```jsonc
// 3. Call a tool
POST /mcp
mcp-session-id: <uuid>
{
  "jsonrpc": "2.0", "id": 3, "method": "tools/call",
  "params": {
    "name": "query",
    "arguments": { "query": "kafka consumer lag", "collections": ["wiki", "raw"], "limit": 5 }
  }
}

// Response (success):
{
  "jsonrpc": "2.0", "id": 3,
  "result": {
    "content": [{ "type": "text", "text": "<human-readable result summary>" }],
    "structuredContent": { "results": [ ... per §3.2 ... ] },
    "isError": false
  }
}

// Response (error — example: unknown collection):
{
  "jsonrpc": "2.0", "id": 3,
  "result": {
    "content": [{ "type": "text", "text": "Collection 'finance' not found. Available: wiki, raw." }],
    "isError": true
  }
}
```

### §2.2 Status codes

| Code | When |
|---|---|
| **200** | Tool call succeeded (even logical errors; MCP convention puts them inside `result.isError`) |
| **400** | Malformed JSON-RPC, missing `jsonrpc:"2.0"`, missing `method`, missing `params.name` |
| **401** | Missing or invalid `Authorization: Bearer` header |
| **404** | `POST /mcp` to an unknown session ID (header `mcp-session-id` not recognized) |
| **422** | `tools/call` arguments fail Pydantic validation |
| **429** | Per-tenant rate limit exceeded (v2 — defer in v1) |
| **500** | Unhandled server error |
| **503** | Service not ready: S3 unreachable, Bedrock probe failing, Redis down, first KB load pending |

JSON-RPC errors use code numbers PER MCP spec:
- `-32700` Parse error → HTTP 400
- `-32600` Invalid Request → HTTP 400
- `-32601` Method not found → HTTP 400
- `-32602` Invalid params → HTTP 422
- `-32603` Internal error → HTTP 500
- `-32000` (custom) Unknown session → HTTP 404

### §2.3 `POST /query` — REST shortcut (one-shot, no session)

For simpler chatbot agents that don't want to manage MCP sessions. Same input as `tools/call name=query`, but flatter.

```http
POST /query
Authorization: Bearer <token>
Content-Type: application/json

{ "query": "kafka consumer lag", "collections": ["wiki"], "limit": 5, "rerank": true }
```

Response: same `structuredContent.results` payload without the JSON-RPC envelope.

### §2.4 Authentication (v1)

- Single shared bearer token. Loaded at boot from AWS Secrets Manager (key `kbm/bearer-token/{env}`) or `KBM_BEARER_TOKEN` env var (dev only).
- Middleware rejects any request to `/mcp`, `/query`, `/get`, `/multi_get`, `/status`, `/ls` without `Authorization: Bearer <token>` matching the configured value.
- `/health` and `/ready` are NOT authenticated (ALB needs them).
- v2 will move to SigV4 (IAM) or Cognito. ADR-014.

---

## §3. MCP Tool 1 — `query` (the workhorse)

### §3.1 Verbatim description (REGISTER THIS STRING, NEVER EDIT)

```
Search the knowledge base with hybrid BM25 + semantic + LLM-rerank retrieval.

**When to use this vs `get`:**
- Use `query` when you don't already know the exact file. Returns top-N ranked matches with snippets.
- Use `get` when you have a specific path or docid from a previous `query` result.

**Two input modes:**

1. **Simple query** — pass `query: "natural language question"`. The system auto-expands to lex/vec/hyde sub-queries.
2. **Structured query** — pass `searches: [{type, query}, ...]` with up to 10 typed sub-queries.

**The 3 sub-query types:**

| Type | What it does | Use when |
|------|--------------|----------|
| `lex` | BM25 keyword search. Supports "phrases", -negation, prefix matching | The query has exact keywords/names/codes. |
| `vec` | Vector semantic search on the query as-is | The query is conceptual ("how does X work"). |
| `hyde` | Vector search on a hypothetical answer passage | The query is broad and you can imagine what the answer would say. |

**Best practice for structured queries:**
- Put your **best/most-specific** query FIRST — it gets 2x weight in fusion.
- Use `intent:` (1 line, optional) to disambiguate ambiguous terms.
- Mix types: lex for exact terms, vec for paraphrase, hyde to describe target docs.
- Query `wiki` collection first (curated synthesis); fall back to `raw` only if wiki misses.

**Example structured query:**
```json
{
  "searches": [
    {"type": "lex", "query": "\"kafka consumer lag\" -test"},
    {"type": "vec", "query": "how to debug message backlog in streaming pipelines"},
    {"type": "hyde", "query": "Runbook: when Kafka consumers fall behind, increase parallelism and check ..."}
  ],
  "intent": "production incident debugging",
  "collections": ["wiki", "raw"],
  "limit": 5
}
```

**Returns:** ranked list of `{docid, file, title, score, context, line, snippet}`. Cite `file` (qmd:// URI) and `docid` in your answer.

**Performance:** p50 ~800ms cold / ~50ms warm; p95 ~2s. Set `rerank: false` for sub-200ms responses (slightly lower quality).
```

### §3.2 Input schema (Pydantic — lives in `src/kbm/types.py`)

```python
from typing import Literal, Optional
from pydantic import BaseModel, Field, model_validator


class TypedSubQuery(BaseModel):
    type: Literal["lex", "vec", "hyde"]
    query: str = Field(min_length=1, max_length=500)


class QueryToolInput(BaseModel):
    """Mirror of doc_search MCP query input (server.ts:301-317).

    Either `query` OR `searches` is required (mutually exclusive). Validation
    enforced by model_validator.
    """
    query: Optional[str] = Field(default=None, max_length=500, description="Plain natural-language query. Will be auto-expanded.")
    searches: Optional[list[TypedSubQuery]] = Field(default=None, min_length=1, max_length=10, description="Pre-expanded queries. Skip auto-expansion.")
    intent: Optional[str] = Field(default=None, max_length=300, description="Disambiguation hint. Steers expansion + rerank + snippet.")
    collections: Optional[list[str]] = Field(default=None, max_length=20, description="Restrict to these collections; None = all default-include.")
    limit: int = Field(default=10, ge=1, le=100, description="Max results.")
    candidate_limit: int = Field(default=40, ge=1, le=100, description="Max candidates to rerank. DO NOT exceed 40 without ADR amendment.")
    min_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Score floor [0,1].")
    rerank: bool = Field(default=True, description="Enable LLM reranking. Disable for sub-200ms responses.")
    explain: bool = Field(default=False, description="Include RRF + rerank traces.")

    @model_validator(mode="after")
    def _require_query_or_searches(self) -> "QueryToolInput":
        if (self.query is None) == (self.searches is None):
            raise ValueError("Exactly one of `query` or `searches` must be provided.")
        return self
```

### §3.3 Output schema

```python
class HybridQueryExplain(BaseModel):
    """Per-result trace when explain=True."""
    fts_scores: list[float]
    vec_scores: list[float]
    rrf_rank: int
    rrf_score: float
    rrf_weight: float
    rerank_score: Optional[float]
    blended_score: float
    strong_signal_bypass: bool


class SearchResultItem(BaseModel):
    """Mirror of doc_search MCP query result (server.ts:39-47)."""
    docid: str = Field(min_length=6, max_length=6, pattern=r"^[a-f0-9]{6}$", description="6-char SHA-256 prefix")
    file: str = Field(description="Virtual path 'qmd://<collection>/<path>'")
    title: str
    score: float = Field(ge=0.0, le=1.0, description="Blended final score [0,1]")
    context: Optional[str] = Field(default=None, description="Global context + most-specific prefix context")
    line: int = Field(ge=1, description="1-indexed starting line of snippet in source file")
    snippet: str = Field(description="~500-char excerpt with query terms in **bold**")
    explain: Optional[HybridQueryExplain] = None


class QueryToolOutput(BaseModel):
    results: list[SearchResultItem]
    total_candidates: int = Field(ge=0, description="Total fused candidates before reranking")
    bypass_reason: Optional[Literal["strong_signal_bypass"]] = None
    latency_ms: int = Field(ge=0)
    cache_hits: dict[Literal["expand", "rerank"], int] = Field(default_factory=lambda: {"expand": 0, "rerank": 0})
```

### §3.4 Sample request / response

```bash
# REST shortcut (simpler path)
curl -X POST http://localhost:8080/query \
  -H "Authorization: Bearer $KBM_BEARER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "kafka consumer lag debugging",
    "collections": ["wiki", "raw"],
    "limit": 5,
    "rerank": true
  }'
```

Response (200):
```json
{
  "results": [
    {
      "docid": "ab12c3",
      "file": "qmd://wiki/runbooks/kafka-lag.md",
      "title": "Kafka Consumer Lag — Diagnosis & Mitigation",
      "score": 0.92,
      "context": "Knowledge base for the doc_agent product.\n\nEngineering wiki: on-call runbooks.",
      "line": 1,
      "snippet": "# **Kafka** **Consumer** **Lag** — Diagnosis & Mitigation\nWhen **consumers** fall behind, check the lag metric in Datadog. The threshold is 1000 messages..."
    },
    {
      "docid": "f9d7e2",
      "file": "qmd://raw/transcripts/2025-Q1-incident-review.md",
      "title": "Q1 Incident Review — Kafka Lag Episode",
      "score": 0.71,
      "context": "Knowledge base for the doc_agent product.\n\nMeeting transcripts (raw — fall back to wiki if available).",
      "line": 42,
      "snippet": "...we saw **kafka** **consumer** **lag** spike to 50k at 14:30 UTC..."
    }
  ],
  "total_candidates": 18,
  "bypass_reason": null,
  "latency_ms": 743,
  "cache_hits": { "expand": 0, "rerank": 12 }
}
```

### §3.5 Errors

| Condition | Status | Response body |
|---|---|---|
| Both `query` and `searches` provided | 422 | `{"error":"invalid_input", "detail":"Exactly one of `query` or `searches` must be provided."}` |
| Neither provided | 422 | Same |
| Unknown collection in `collections` | 422 | `{"error":"unknown_collection", "detail":"Collection 'finance' not found. Available: wiki, raw."}` |
| `searches` empty list | 422 | `{"error":"invalid_input", "detail":"`searches` must have at least 1 element."}` |
| Bedrock probe fails mid-request | 503 | `{"error":"upstream_unavailable", "detail":"Bedrock embedding service unreachable. Retry in 30s."}` |
| OpenAI rate-limited (rerank step) | 200 with degraded result | Returns RRF-only ranking (no rerank), with `bypass_reason: null` and a `warnings: ["rerank_skipped_rate_limit"]` field added |
| Search returns 0 candidates | 200 | `{"results": [], "total_candidates": 0, ...}` (NOT an error) |

---

## §4. MCP Tool 2 — `get` (fetch one document)

### §4.1 Verbatim description (REGISTER THIS STRING, NEVER EDIT)

```
Retrieve a single document by path or docid.

**When to use:** you have a specific path or docid (e.g., from a previous `query` result).

**Accepted `file` forms:**
- Docid: `"#abc123"` or `"abc123"` (6-hex chars)
- Virtual path: `"qmd://wiki/runbooks/kafka.md"`
- Collection-relative: `"wiki/runbooks/kafka.md"`
- With line: `"qmd://wiki/runbooks/kafka.md:42"` (jumps `from_line` to 42)

**Returns:** `{docid, file, title, context, body}` where body is the full markdown
(or sliced by `from_line` / `max_lines`).

**Auto-prepends a `<!-- Context: ... -->` comment** to the body so the consuming
LLM sees the path-prefix context without an extra call.

**Fuzzy matching:** if the file is not found, returns `{"error": "not_found",
"similar_files": [...]}` with up to 5 close matches.
```

### §4.2 Input schema

```python
class GetToolInput(BaseModel):
    """Mirror of doc_search MCP get (server.ts:368-428)."""
    file: str = Field(min_length=1, description="docid '#abc123', virtual path 'qmd://coll/path', or 'coll/path[:line]'")
    from_line: Optional[int] = Field(default=None, ge=1, description="1-indexed line to start from")
    max_lines: Optional[int] = Field(default=None, ge=1, le=10000, description="Cap on lines returned")
    line_numbers: bool = Field(default=False, description="Prepend 'N: ' to each line")
```

### §4.3 Output schema

```python
class DocumentBody(BaseModel):
    docid: str = Field(min_length=6, max_length=6)
    file: str
    title: str
    context: Optional[str] = None
    body: str
    total_lines: int = Field(ge=0)
    body_starts_at_line: int = Field(default=1, ge=1)


class GetNotFound(BaseModel):
    error: Literal["not_found"] = "not_found"
    requested: str
    similar_files: list[str] = Field(default_factory=list, max_length=5)


class GetToolOutput(BaseModel):
    # Pydantic-discriminated union via Annotated[Union[...], Field(discriminator='kind')]
    # Implementation detail: the handler returns either DocumentBody or GetNotFound
    # serialized via .model_dump(exclude_none=True)
    pass  # placeholder — actual return type is Union[DocumentBody, GetNotFound]
```

### §4.4 Sample request / response

```bash
curl -X POST http://localhost:8080/get \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"file":"qmd://wiki/runbooks/kafka.md", "from_line":1, "max_lines":50, "line_numbers":true}'
```

Response (200, found):
```json
{
  "docid": "ab12c3",
  "file": "qmd://wiki/runbooks/kafka.md",
  "title": "Kafka Consumer Lag — Diagnosis & Mitigation",
  "context": "Knowledge base for the doc_agent product.\n\nEngineering wiki: on-call runbooks.",
  "body": "<!-- Context: Engineering wiki: on-call runbooks. -->\n\n1: # Kafka Consumer Lag — Diagnosis & Mitigation\n2: \n3: When consumers fall behind, check the lag metric in Datadog. The threshold is 1000 messages.\n...",
  "total_lines": 47,
  "body_starts_at_line": 1
}
```

Response (200, not found — note: HTTP 200, error inside body per MCP convention):
```json
{
  "error": "not_found",
  "requested": "qmd://wiki/runbooks/kafkaaa.md",
  "similar_files": [
    "qmd://wiki/runbooks/kafka.md",
    "qmd://wiki/runbooks/kafka-consumer.md",
    "qmd://raw/transcripts/2024-kafka-incident.md"
  ]
}
```

### §4.5 Errors

| Condition | Status | Response body |
|---|---|---|
| `file` is empty | 422 | `{"error":"invalid_input", "detail":"`file` is required"}` |
| docid format invalid (not 6 hex chars after `#` strip) | 422 | `{"error":"invalid_docid", "detail":"docid must be 6 hex chars"}` |
| `from_line > total_lines` | 422 | `{"error":"out_of_range", "detail":"from_line=99 exceeds total_lines=47"}` |
| S3 read fails | 503 | `{"error":"storage_unavailable", "detail":"S3 read failed. Retry in 30s."}` |

---

## §5. MCP Tool 3 — `multi_get` (parallel batch fetch)

### §5.1 Verbatim description (REGISTER THIS STRING, NEVER EDIT)

```
Batch retrieve documents by glob, comma-separated list, or docid list.

**Pattern forms:**
- Glob: `"runbooks/**/*.md"` (returns all matching docs)
- Comma list: `"auth.md, runbooks/kafka.md, #abc123"` (each item: virtual path, relative path, or docid)
- Single docid: `"#abc123"`

**Output:** up to 50 documents in ONE call. Documents exceeding `max_bytes`
are skipped with a hint to use `get` instead.

**Use case:** comparing several hits or gathering context across pages
identified by an earlier `query` result.

**Performance:** ~50ms warm for 5 docs (parallel S3 + cache hits).
```

### §5.2 Input schema

```python
class MultiGetToolInput(BaseModel):
    pattern: str = Field(min_length=1, max_length=2000, description="Glob, comma-list, or docid list")
    max_bytes: int = Field(default=10240, ge=1, le=1_000_000, description="Per-file size cap. Default 10KB.")
    max_lines: Optional[int] = Field(default=None, ge=1, le=10_000)
    line_numbers: bool = Field(default=False)
    limit: int = Field(default=50, ge=1, le=200, description="Max number of docs to return")
```

### §5.3 Output schema

```python
class MultiGetItem(BaseModel):
    docid: str
    file: str
    title: str
    context: Optional[str] = None
    body: Optional[str] = None  # null if skipped
    skipped: bool = False
    skip_reason: Optional[str] = None  # "too_large" | "not_found" | "fuzzy_no_match"


class MultiGetToolOutput(BaseModel):
    items: list[MultiGetItem]
    total_matched: int = Field(ge=0)
    total_returned: int = Field(ge=0)
    total_skipped: int = Field(ge=0)
```

### §5.4 Sample

```bash
curl -X POST http://localhost:8080/multi_get \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"pattern":"runbooks/**/*.md", "max_bytes":20480, "limit":10}'
```

```json
{
  "items": [
    {"docid":"ab12c3", "file":"qmd://wiki/runbooks/kafka.md", "title":"Kafka Consumer Lag", "context":"...", "body":"...", "skipped":false},
    {"docid":"f9d7e2", "file":"qmd://wiki/runbooks/oncall-prep.md", "title":"On-call Prep", "context":"...", "body":null, "skipped":true, "skip_reason":"too_large"}
  ],
  "total_matched": 12,
  "total_returned": 10,
  "total_skipped": 2
}
```

### §5.5 Errors

| Condition | Status | Response |
|---|---|---|
| `pattern` empty | 422 | `{"error":"invalid_input"}` |
| 0 docs matched | 200 | `{"items":[], "total_matched":0, "total_returned":0, "total_skipped":0}` (NOT an error) |
| Glob too broad (would match > 1000) | 422 | `{"error":"glob_too_broad", "detail":"Pattern would match 5234 docs > limit*20=1000. Refine pattern."}` |

---

## §6. MCP Tool 4 — `status` (KB health probe)

### §6.1 Verbatim description (REGISTER THIS STRING, NEVER EDIT)

```
Knowledge base health probe. Returns:
- Total document count per collection
- Last build timestamp + build_info (model, dim, chunker constants)
- Capability gaps (e.g., "No vector index yet for collection X — run `kbm embed`")
- Probe results for S3 + Bedrock + Redis

Call this when retrieval seems broken or before assuming the KB has up-to-date info.
```

### §6.2 Input schema

```python
class StatusToolInput(BaseModel):
    include_capability_gaps: bool = Field(default=True)
    probe_upstreams: bool = Field(default=True, description="If False: skip Bedrock/Redis probes (faster, dev-only)")
```

### §6.3 Output schema

```python
class CollectionStatus(BaseModel):
    name: str
    kind: Literal["wiki", "raw"]
    doc_count: int = Field(ge=0)
    chunk_count: int = Field(ge=0)
    total_bytes: int = Field(ge=0)
    last_modified: Optional[datetime] = None
    has_fts_index: bool
    has_vector_index: bool
    embedding_model: Optional[str] = None
    embedding_dim: Optional[int] = None


class UpstreamProbe(BaseModel):
    s3: Literal["ok", "degraded", "down"]
    bedrock: Literal["ok", "degraded", "down", "not_probed"]
    openai: Literal["ok", "degraded", "down", "not_probed"]
    redis: Literal["ok", "degraded", "down", "not_probed"]
    last_probed_at: datetime


class StatusToolOutput(BaseModel):
    kbm_version: str
    kb_version: str  # from build_info.json
    total_documents: int = Field(ge=0)
    total_chunks: int = Field(ge=0)
    collections: list[CollectionStatus]
    last_kb_uploaded_at: Optional[datetime] = None
    global_context: Optional[str] = None
    upstream: UpstreamProbe
    capability_gaps: list[str] = Field(default_factory=list, description="Human-readable gaps the agent should know about")
```

### §6.4 Sample

```json
{
  "kbm_version": "0.1.0",
  "kb_version": "wiki-2026-05-18-r3",
  "total_documents": 147,
  "total_chunks": 1284,
  "collections": [
    {"name":"wiki", "kind":"wiki", "doc_count":67, "chunk_count":543, "total_bytes":2104320, "last_modified":"2026-05-19T18:30:00Z", "has_fts_index":true, "has_vector_index":true, "embedding_model":"amazon.titan-embed-text-v2:0", "embedding_dim":1024},
    {"name":"raw", "kind":"raw", "doc_count":80, "chunk_count":741, "total_bytes":3502016, "last_modified":"2026-05-19T18:30:00Z", "has_fts_index":true, "has_vector_index":true, "embedding_model":"amazon.titan-embed-text-v2:0", "embedding_dim":1024}
  ],
  "last_kb_uploaded_at": "2026-05-19T19:01:00Z",
  "global_context": "Knowledge base for the doc_agent product.",
  "upstream": {"s3":"ok","bedrock":"ok","openai":"ok","redis":"ok","last_probed_at":"2026-05-20T10:14:00Z"},
  "capability_gaps": []
}
```

---

## §7. MCP Tool 5 — `ls` (folder listing)

### §7.1 Verbatim description (REGISTER THIS STRING, NEVER EDIT)

```
List files or folders in the knowledge base.

**Path forms:**
- Empty: list collections
- "<collection>": list top-level files + folders in that collection
- "<collection>/<prefix>": list contents of that prefix

**Returns:** entries with `kind=collection|folder|file`, `doc_count`, `last_modified`.

**Use when:** the agent needs to discover what's available before deciding what to query.

**Performance:** DuckDB scan over catalog.parquet; sub-50ms for catalogs < 100K docs.
```

### §7.2 Input schema

```python
class LsToolInput(BaseModel):
    path: Optional[str] = Field(default=None, max_length=500, description="Empty → list collections. Else 'coll' or 'coll/prefix/'.")
    recursive: bool = Field(default=False, description="If True: list all descendants flat. If False: one level only.")
    limit: int = Field(default=200, ge=1, le=1000)
```

### §7.3 Output schema

```python
class LsEntry(BaseModel):
    name: str
    kind: Literal["collection", "folder", "file"]
    doc_count: int = Field(ge=1, description="For collection/folder: descendant count. For file: 1.")
    last_modified: Optional[datetime] = None
    context: Optional[str] = None  # only for collections


class LsToolOutput(BaseModel):
    entries: list[LsEntry]
    path: Optional[str] = None
    total_count: int = Field(ge=0)
    truncated: bool = False
```

### §7.4 Sample

```bash
curl -X POST http://localhost:8080/ls \
  -H "Authorization: Bearer $TOKEN" -d '{"path":"wiki/runbooks/"}'
```

```json
{
  "path": "wiki/runbooks/",
  "entries": [
    {"name":"kafka.md", "kind":"file", "doc_count":1, "last_modified":"2026-05-18T10:00:00Z"},
    {"name":"oncall-prep.md", "kind":"file", "doc_count":1, "last_modified":"2026-05-17T14:22:00Z"},
    {"name":"postgres/", "kind":"folder", "doc_count":7, "last_modified":"2026-05-19T18:30:00Z"}
  ],
  "total_count": 3,
  "truncated": false
}
```

---

## §8. Health endpoints

### §8.1 `GET /health` (liveness, unauthenticated)

```http
GET /health

200 OK
{ "status": "ok", "uptime_seconds": 12345, "kbm_version": "0.1.0" }
```

Returns 200 as long as the FastAPI process is alive. ALB target-group health check uses this.

### §8.2 `GET /ready` (readiness, unauthenticated)

```http
GET /ready

200 OK
{ "status": "ready", "checks": { "s3":"ok", "redis":"ok", "bedrock":"ok", "openai":"not_probed", "kb_loaded":"ok" } }

503 Service Unavailable
{ "status": "not_ready", "checks": { ..., "kb_loaded":"loading" } }
```

`/ready` returns 503 until:
1. S3 manifest + catalog + first collection's FTS5 + FAISS pulled to local disk
2. Redis connectivity confirmed
3. Bedrock probe succeeds (one embed of literal "ping")

This gates ALB traffic to the container. ECS task definition: `startPeriod: 60`, `interval: 30`, `timeout: 10`, `retries: 3`.

OpenAI is NOT probed at boot (rate limits make it costly); probed lazily on first `query` call.

---

## §9. CLI surface (Surface B)

### §9.1 Command structure

```
kbm <command> [options]

Commands:
  build           Walk + hash + content-addressable write
  embed           Chunk + embed + dual-index per collection
  lint            Run 9 lint checks; produce build_info.json
  plan-upload     Diff local artifacts vs S3; show what would change
  upload          Atomic aws s3 sync; idempotent
```

Implementation: Typer-based, single `kbm` entry point declared in `pyproject.toml [project.scripts]`.

### §9.2 `kbm build`

```sh
kbm build \
  --manifest manifest.yaml \
  --output ./local-build/ \
  [--force]                       # rebuild even if catalog hash unchanged
  [--collection wiki,raw]         # restrict to these collections (default: all)
```

**Inputs**: `manifest.yaml`, source folders referenced by collections.
**Outputs**:
- `<output>/manifest.yaml` (canonicalized — same fields, sorted keys)
- `<output>/catalog.parquet` (one row per active doc; columns per `03_*.md §3.1`)
- `<output>/content/{hash[:2]}/{hash}.md` (content-addressable bodies)
- `<output>/contexts.json` (snapshot of context maps)

**Exit codes**:
- `0` success
- `1` manifest validation failed
- `2` source folder unreadable
- `3` collision: same hash across collections with different bodies (impossible by definition; flag bug)
- `4` `--force` required but absent (catalog already present, would skip otherwise)

**Idempotency**: re-running with no source changes is a no-op except updating `build_info.json` `last_attempted_at`.

### §9.3 `kbm embed`

```sh
kbm embed \
  --output ./local-build/ \
  [--collection wiki,raw]
  [--max-docs-per-batch 64]       # default 64
  [--max-batch-mb 4]              # default 4 MB
  [--chunk-strategy auto|regex]   # default regex; auto = AST-aware for code
  [--force]                       # re-embed even if vectors exist
```

**Inputs**: `<output>/catalog.parquet`, `<output>/content/...`
**Outputs**:
- `<output>/fts/{collection}.sqlite` (FTS5 with porter+unicode61 tokenizer)
- `<output>/vectors/{collection}/index.faiss`
- `<output>/vectors/{collection}/meta.parquet` (one row per chunk: hash_seq, hash, seq, pos, end_pos, text_preview)
- `<output>/vectors/{collection}/embedding_model.txt` (model_id + dim, one line each)

**Exit codes**:
- `0` success
- `1` catalog missing (run `kbm build` first)
- `2` Bedrock unavailable
- `5` chunk count exceeds 1M per collection (operational sanity cap)
- `6` partial embedding detected without `--force` (some chunks missing vectors; resume mode)

**Resumability**: `kbm embed` checkpoints per-collection every 100 docs to `<output>/.embed-progress-{coll}.json`. Re-running after interruption resumes from the last checkpoint unless `--force`.

### §9.4 `kbm lint`

```sh
kbm lint \
  --output ./local-build/
```

Runs the 9 checks from [07_build_pipeline_spec.md §6](07_build_pipeline_spec.md). Writes `<output>/build_info.json`:

```json
{
  "kbm_version": "0.1.0",
  "kb_version": "wiki-2026-05-18-r3",
  "build_started_at": "...",
  "build_finished_at": "...",
  "manifest_sha256": "...",
  "lint_passed": true,
  "lint_errors": [],
  "lint_warnings": [
    {"check":"L1_missing_context", "severity":"warn", "count":3, "details":[...]}
  ]
}
```

**Exit codes**:
- `0` lint_passed=true (no error-level checks failed)
- `1` lint_passed=false (≥1 error-level check failed)

### §9.5 `kbm plan-upload`

```sh
kbm plan-upload \
  --output ./local-build/ \
  --to s3://kb-dev/
```

Compares local artifacts to current S3 state. Output to stdout:

```text
PLAN — uploading ./local-build/ → s3://kb-dev/

  ADD    : content/ab/ab12c3...md (12 KB)
  UPDATE : catalog.parquet (304 KB → 312 KB)
  DELETE : content/9f/9f1234...md (orphaned)

Summary: 47 add, 12 update, 3 delete (estimated 8.4 MB to transfer)

To execute: kbm upload --output ./local-build/ --to s3://kb-dev/
```

**Exit codes**:
- `0` plan computed (no I/O changes proposed)
- `1` S3 unreachable
- `7` lint NOT passed; `kbm upload` will refuse (run `kbm lint` first)

### §9.6 `kbm upload`

```sh
kbm upload \
  --output ./local-build/ \
  --to s3://kb-dev/ \
  [--yes]                         # skip "ARE YOU SURE?" interactive prompt
```

**Pre-flight checks**:
1. `build_info.json` exists AND `lint_passed=true`
2. Source files in `<output>` haven't changed since `kbm build` (catalog hash matches)
3. Destination prefix is in env-allowed list (`KBM_S3_BUCKET_DEV/STAGING/PROD`)

**Behavior**: atomic `aws s3 sync` with ETag verification. Uses S3 batch upload for content blobs (parallel). Writes a tombstone `_uploaded_at.txt` last so search-half boot can verify completeness.

**Exit codes**:
- `0` success
- `1` lint not passed; upload refused
- `2` S3 unreachable
- `8` catalog hash mismatch (source changed since build); re-run `kbm build`

**The `kbm upload` command is NEVER triggered automatically by the parent chatbot.** Per H4 in `00_start_here.md §7`: only the developer runs it.

---

## §10. `buildInstructions(catalog)` — the MCP initialize text

When the parent chatbot agent connects, `initialize` returns an `instructions` string. The server builds this dynamically at boot per `src/kbm/mcp/instructions.py`.

**Template** (must match this shape; substitute the bracketed values from catalog state):

```text
# kbm — Knowledge Base Search

You are connected to the knowledge_base_management MCP server. There are
{N_COLLECTIONS} collections totaling {TOTAL_DOCS} documents.

## Collections

{FOR_EACH_COLLECTION}
- **{name}** ({kind}, {doc_count} docs, last updated {last_modified}):
  {context_first_line}
{END_FOR}

## Global context

{global_context_or_empty_string}

## Tools

- **query** (workhorse) — hybrid BM25 + semantic + LLM rerank. Use for any search.
- **get** — fetch one document by docid, virtual path, or fuzzy name.
- **multi_get** — batch fetch up to 50 documents.
- **status** — KB health probe.
- **ls** — list contents of a collection or folder.

## Strategy

1. **Query `wiki` collection FIRST** — it's curated synthesis. If wiki misses, fall back to `raw`.
2. **For exact terms / names / codes**: put a `lex:` query first.
3. **For conceptual / paraphrased questions**: use `vec:` and `hyde:`.
4. **Use `intent:` to disambiguate** ambiguous terms.
5. **Cite results by `file` URI + `docid`** in your answer.

## Capability gaps

{IF_CAPABILITY_GAPS}
The following limitations apply right now:
{FOR_EACH_GAP}
- {gap}
{END_FOR}
{ELSE}
None.
{END_IF}
```

Maximum size: 4 KB. If the catalog has > 20 collections, list only the first 20 + a `... and {n} more` line.

---

## §11. Verbatim-port assertion (CI-enforced)

`scripts/check_mcp_tool_descriptions_unchanged.py` enforces that every tool description in `src/kbm/mcp/tools.py` is **byte-identical** to the corresponding §3.1/§4.1/§5.1/§6.1/§7.1 block in THIS file. To change a description:

1. Update this file (§3.1 / §4.1 / §5.1 / §6.1 / §7.1)
2. Update `src/kbm/mcp/tools.py` in the same PR
3. The CI script re-reads both and confirms byte-equality

**Never** edit one without the other. The descriptions are agent-facing inline manuals — the chatbot learns to use the tools by reading them.

---

## §12. MCP capabilities NOT supported (out of scope for v1)

Per `14_adr_catalog.md ADR-015`:

| Capability | Why not in v1 | When | Defer to |
|---|---|---|---|
| MCP `resources` (`subscribe`, `listChanged`) | Not needed by parent chatbot agent | v2 if a use case appears | ADR-015 |
| MCP `prompts` capability | Parent product owns its own prompts | v2 maybe | — |
| Streaming responses | gpt-4.1 batched rerank is fast enough to skip streaming | maybe v3 | — |
| Per-tenant data isolation | Single-tenant v1 | v2 (multi-tenant) | ADR-020 |
| Real-time index updates | Build → upload model only | v2 if needed | — |
| Per-tool rate limiting | Single bearer token, infrequent use | v2 | — |
| WebSocket transport | HTTP suffices | not planned | — |

**Hard rule**: do not implement any of the above without an ADR amendment. Implementing speculatively triggers a Phase-rollback request.

---

## §13. Definition of Done (Phase 3 + Phase 4)

Phase 3 (MCP layer stubs) is done when:
- [ ] `GET /health` returns 200
- [ ] `GET /ready` returns 503 until first KB load, then 200
- [ ] `POST /mcp initialize` returns valid server info + capabilities + instructions
- [ ] `POST /mcp tools/list` returns the 5 tools with verbatim descriptions
- [ ] `POST /mcp tools/call` accepts the 5 tool names; rejects unknown ones with code -32601
- [ ] Bearer-token middleware rejects unauthenticated calls to all paths except `/health` + `/ready`
- [ ] `scripts/check_mcp_tool_descriptions_unchanged.py` is green

Phase 4 (search wires in) adds:
- [ ] `query` returns ranked results (handler delegates to `kbm.search.query`)
- [ ] `get` returns body or `not_found` envelope with `similar_files`
- [ ] `multi_get` returns ≤ 50 docs with `total_matched/returned/skipped`
- [ ] `status` returns full payload including upstream probes
- [ ] `ls` returns entries from DuckDB scan
- [ ] Every Pydantic input model has at least 5 unit tests in `tests/unit/search/`
- [ ] Sample curl sequence from each tool's §X.4 runs against LocalStack and returns the documented shape

---

*End of MCP tool contract. Open `05_chunker_spec.md` next.*
