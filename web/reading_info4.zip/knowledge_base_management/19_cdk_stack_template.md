# 19 — CDK Stack Template (working starter for `cdk/{app,stack,cdk.json}`)

> **Purpose** — verbatim CDK template the junior agent copy-pastes in Phase 5 to provision the kbm-search service on AWS. Without this template, the junior agent re-derives CDK from AWS docs and gets subtle things wrong (wrong IAM scoping, missing alarm dimensions, hard-coded thresholds in code). Closing PM gap GAP-3.
>
> **Audience** — junior agent at the start of Phase 5 (Observability + IaC).
>
> **Phase**: Phase 5. Files this contract drives: `cdk/app.py`, `cdk/stack.py`, `cdk/cdk.json`, `cdk/__init__.py`.

---

## §1. What this stack provisions

```
┌────────────────────────────────────────────────────────────────────────┐
│  AWS resources created by cdk/stack.py:KbmStack                        │
│  ────────────────────────────────────────────────────────────────────  │
│                                                                         │
│  S3:                                                                    │
│    - Bucket: kb-{env}                       (KB artifacts)              │
│    - Bucket: kb-{env}-backups               (rollback snapshots, 30d)   │
│                                                                         │
│  ECS:                                                                   │
│    - Cluster reference: kbm-cluster (imports main bundle's cluster)     │
│    - TaskDefinition: kbm-search-task                                    │
│        - 1 vCPU, 2GB RAM, ephemeralStorage 21GB                         │
│        - Container `kbm`: image from ECR, port 8080                     │
│        - Env vars from §6                                               │
│        - Log group: /aws/ecs/kbm-search                                 │
│    - Service: kbm-search                                                │
│        - desiredCount: 2 (prod), 1 (dev)                                │
│        - rollingUpdate maxHealthyPercent=200, minHealthyPercent=50      │
│                                                                         │
│  ALB:                                                                   │
│    - TargetGroup: kbm-search-tg, health check on GET /health            │
│    - Listener rule: forwards path /kbm/* to kbm-search-tg               │
│      (re-uses main bundle's ALB; only adds the rule)                    │
│                                                                         │
│  ElastiCache:                                                           │
│    - SubnetGroup: kbm-redis-subnets                                     │
│    - ReplicationGroup: kbm-redis (cache.t4g.small, 1 primary, 0 read)   │
│    - SecurityGroup: kbm-redis-sg (allow 6379 from ECS service SG)       │
│                                                                         │
│  Secrets Manager:                                                       │
│    - kbm/bearer-token/{env}                 (rotated quarterly)         │
│    - kbm/openai-api-key/{env}                                            │
│                                                                         │
│  IAM:                                                                   │
│    - Task role: kbm-search-task-role                                    │
│        - s3:GetObject, s3:ListBucket on kb-{env}*                       │
│        - secretsmanager:GetSecretValue on kbm/*                         │
│        - bedrock:InvokeModel on titan-embed-text-v2:0                   │
│        - logs:CreateLogStream / PutLogEvents on its log group           │
│        - cloudwatch:PutMetricData (kbm namespace only)                  │
│    - Execution role: kbm-search-exec-role                               │
│        - ECR pull + log writes                                          │
│                                                                         │
│  CloudWatch Alarms (9, all from `12_*.md §3` constants — NO LITERALS):  │
│    - kbm-{env}-query-availability-low                                   │
│    - kbm-{env}-query-latency-p95-high                                   │
│    - kbm-{env}-query-latency-p99-high                                   │
│    - kbm-{env}-health-unhealthy                                         │
│    - kbm-{env}-cache-hit-low                                            │
│    - kbm-{env}-rerank-cost-high                                         │
│    - kbm-{env}-nightly-bench-recall-low                                 │
│    - kbm-{env}-build-cost-high                                          │
│    - kbm-{env}-error-rate-high                                          │
│                                                                         │
│  CloudWatch Dashboard:                                                  │
│    - kbm-{env}-overview (8 widgets from `15_*.md §0`)                   │
│                                                                         │
│  EventBridge:                                                           │
│    - kbm-nightly-bench (rule: cron(0 3 * * ? *))                        │
│        → Lambda: kbm-nightly-bench-lambda                               │
│                                                                         │
│  SNS:                                                                   │
│    - kbm-{env}-alarms (topic; alarms publish here)                      │
│        → subscriptions configured outside CDK (PagerDuty / email)       │
└────────────────────────────────────────────────────────────────────────┘
```

Total resources: ~25. Initial `cdk deploy` time: ~6-8 minutes.

---

## §2. `cdk/cdk.json` (verbatim)

```json
{
  "app": "python3 app.py",
  "watch": {
    "include": ["**"],
    "exclude": [
      "README.md", "cdk*.json", "requirements*.txt", "source.bat",
      "**/__init__.py", "python/__pycache__", "tests"
    ]
  },
  "context": {
    "@aws-cdk/aws-iam:minimizePolicies": true,
    "@aws-cdk/core:checkSecretUsage": true,
    "@aws-cdk/core:target-partitions": ["aws"],
    "@aws-cdk-containers/ecs-service-extensions:enableDefaultLogDriver": true,
    "@aws-cdk/aws-ec2:uniqueImdsv2TemplateName": true,
    "@aws-cdk/aws-ecs:arnFormatIncludesClusterName": true,
    "@aws-cdk/aws-iam:standardizedServicePrincipals": true,
    "@aws-cdk/aws-cloudwatch-actions:changeLambdaPermissionLogicalIdForLambdaAction": true,

    "envs": {
      "dev": {
        "account": "${AWS_ACCOUNT_DEV}",
        "region":  "us-east-1",
        "desired_count": 1,
        "redis_node_type": "cache.t4g.micro",
        "s3_bucket_name":  "kb-dev",
        "alb_listener_arn_ssm_param": "/main-bundle/dev/alb-listener-arn",
        "ecs_cluster_arn_ssm_param":  "/main-bundle/dev/ecs-cluster-arn",
        "vpc_id_ssm_param":           "/main-bundle/dev/vpc-id",
        "log_retention_days": 14
      },
      "staging": {
        "account": "${AWS_ACCOUNT_STAGING}",
        "region":  "us-east-1",
        "desired_count": 2,
        "redis_node_type": "cache.t4g.small",
        "s3_bucket_name":  "kb-staging",
        "alb_listener_arn_ssm_param": "/main-bundle/staging/alb-listener-arn",
        "ecs_cluster_arn_ssm_param":  "/main-bundle/staging/ecs-cluster-arn",
        "vpc_id_ssm_param":           "/main-bundle/staging/vpc-id",
        "log_retention_days": 30
      },
      "prod": {
        "account": "${AWS_ACCOUNT_PROD}",
        "region":  "us-east-1",
        "desired_count": 2,
        "redis_node_type": "cache.t4g.small",
        "s3_bucket_name":  "kb-prod",
        "alb_listener_arn_ssm_param": "/main-bundle/prod/alb-listener-arn",
        "ecs_cluster_arn_ssm_param":  "/main-bundle/prod/ecs-cluster-arn",
        "vpc_id_ssm_param":           "/main-bundle/prod/vpc-id",
        "log_retention_days": 90
      }
    }
  }
}
```

---

## §3. `cdk/__init__.py` (verbatim)

```python
"""kbm CDK app — provisions kbm-search ECS service + dependencies."""
```

---

## §4. `cdk/app.py` (verbatim)

```python
#!/usr/bin/env python3
"""cdk/app.py — kbm CDK app entry point.

Usage:
    cdk synth --context env=dev
    cdk deploy --context env=dev --require-approval never
"""
from __future__ import annotations

import os

import aws_cdk as cdk
from aws_cdk import Environment

from stack import KbmStack


def main() -> None:
    app = cdk.App()

    # Pick env from context: `cdk synth --context env=dev`
    env_name = app.node.try_get_context("env")
    if env_name not in {"dev", "staging", "prod"}:
        raise ValueError(
            f"Required --context env=<dev|staging|prod>, got: {env_name!r}. "
            "Example: cdk synth --context env=dev"
        )

    env_config = app.node.try_get_context("envs")[env_name]

    # Resolve AWS account from env var or context
    aws_account = os.environ.get("CDK_DEFAULT_ACCOUNT") or env_config["account"]
    aws_region = os.environ.get("CDK_DEFAULT_REGION") or env_config["region"]
    if aws_account.startswith("$"):
        raise ValueError(
            f"AWS account not resolved: {aws_account!r}. "
            f"Set CDK_DEFAULT_ACCOUNT or replace placeholder in cdk.json"
        )

    KbmStack(
        app,
        construct_id=f"kbm-{env_name}",
        env=Environment(account=aws_account, region=aws_region),
        env_name=env_name,
        config=env_config,
    )

    app.synth()


if __name__ == "__main__":
    main()
```

---

## §5. `cdk/stack.py` (verbatim — the main template)

```python
"""cdk/stack.py — KbmStack: every AWS resource for kbm-search.

PRINCIPLES:
1. NO numeric literals for alarms — every threshold imported from kbm.constants
   (enforced by scripts/check_ci_alarms_use_slo_file.py).
2. ECS cluster + ALB are IMPORTED from the main bundle via SSM Parameter Store
   (kbm doesn't own them).
3. Task role permissions are TIGHTLY scoped — no AWS-managed policies, only
   inline statements limited to the specific resources kbm needs.
4. All log groups have explicit retention.
"""
from __future__ import annotations

from typing import Any

import aws_cdk as cdk
from aws_cdk import (
    Duration,
    RemovalPolicy,
    Stack,
    aws_cloudwatch as cloudwatch,
    aws_cloudwatch_actions as cw_actions,
    aws_ec2 as ec2,
    aws_ecs as ecs,
    aws_elasticache as elasticache,
    aws_elasticloadbalancingv2 as elbv2,
    aws_events as events,
    aws_events_targets as event_targets,
    aws_iam as iam,
    aws_lambda as lambda_,
    aws_logs as logs,
    aws_s3 as s3,
    aws_secretsmanager as secretsmanager,
    aws_sns as sns,
    aws_ssm as ssm,
)
from constructs import Construct


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _import_slo_constants() -> dict[str, Any]:
    """Import alarm thresholds from src/kbm/constants.py (no magic numbers in
    CDK). Returns a dict so the import is centralized.

    This indirection makes scripts/check_ci_alarms_use_slo_file.py simpler —
    it walks the AST of stack.py and confirms every alarm `threshold=` arg
    is sourced from this returned dict (not a literal).
    """
    # `cdk synth` invokes this from cdk/. Make sure src/ is on PYTHONPATH.
    import sys
    from pathlib import Path
    src_root = Path(__file__).resolve().parents[1] / "src"
    if str(src_root) not in sys.path:
        sys.path.insert(0, str(src_root))

    from kbm.constants import (  # noqa: E402
        ALARM_QUERY_AVAILABILITY_MIN_PCT,
        ALARM_QUERY_LATENCY_P95_MS,
        ALARM_QUERY_LATENCY_P99_MS,
        ALARM_HEALTH_UNHEALTHY_5MIN,
        ALARM_CACHE_HIT_RATE_MIN_PCT,
        ALARM_RERANK_COST_PER_QUERY_USD,
        ALARM_NIGHTLY_BENCH_RECALL_MIN,
        ALARM_BUILD_COST_USD,
        ALARM_ERROR_RATE_MAX,
    )
    return {
        "QUERY_AVAILABILITY_MIN_PCT":   ALARM_QUERY_AVAILABILITY_MIN_PCT,
        "QUERY_LATENCY_P95_MS":         ALARM_QUERY_LATENCY_P95_MS,
        "QUERY_LATENCY_P99_MS":         ALARM_QUERY_LATENCY_P99_MS,
        "HEALTH_UNHEALTHY_5MIN":        ALARM_HEALTH_UNHEALTHY_5MIN,
        "CACHE_HIT_RATE_MIN_PCT":       ALARM_CACHE_HIT_RATE_MIN_PCT,
        "RERANK_COST_PER_QUERY_USD":    ALARM_RERANK_COST_PER_QUERY_USD,
        "NIGHTLY_BENCH_RECALL_MIN":     ALARM_NIGHTLY_BENCH_RECALL_MIN,
        "BUILD_COST_USD":               ALARM_BUILD_COST_USD,
        "ERROR_RATE_MAX":               ALARM_ERROR_RATE_MAX,
    }


# ─────────────────────────────────────────────────────────────────────────────
# The stack
# ─────────────────────────────────────────────────────────────────────────────

class KbmStack(Stack):
    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_name: str,
        config: dict[str, Any],
        **kwargs: Any,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        self.env_name = env_name
        self.config = config
        self.slo = _import_slo_constants()

        # Imports (from main bundle's SSM params)
        vpc = self._import_vpc()
        cluster = self._import_ecs_cluster(vpc)
        alb_listener = self._import_alb_listener()

        # Owned resources
        s3_bucket, backup_bucket = self._make_buckets()
        secrets = self._make_secrets()
        redis_endpoint, redis_sg = self._make_redis(vpc)
        log_group = self._make_log_group()
        task_role, exec_role = self._make_iam_roles(s3_bucket, secrets)
        task_def = self._make_task_definition(
            task_role=task_role,
            exec_role=exec_role,
            log_group=log_group,
            secrets=secrets,
            redis_endpoint=redis_endpoint,
        )
        service = self._make_service(cluster, task_def, redis_sg)
        target_group = self._make_target_group(vpc, service)
        self._make_listener_rule(alb_listener, target_group)
        sns_topic = self._make_sns_topic()
        self._make_alarms(target_group, sns_topic)
        self._make_dashboard()
        self._make_nightly_bench_lambda(s3_bucket, alb_listener)

        # Stack outputs
        cdk.CfnOutput(self, "KbmServiceName", value=service.service_name)
        cdk.CfnOutput(self, "KbmTargetGroupArn", value=target_group.target_group_arn)
        cdk.CfnOutput(self, "KbmS3Bucket", value=s3_bucket.bucket_name)
        cdk.CfnOutput(self, "KbmRedisEndpoint", value=redis_endpoint)

    # ─── imports from main bundle ──────────────────────────────────────────

    def _import_vpc(self) -> ec2.IVpc:
        vpc_id = ssm.StringParameter.value_from_lookup(self, self.config["vpc_id_ssm_param"])
        return ec2.Vpc.from_lookup(self, "MainBundleVpc", vpc_id=vpc_id)

    def _import_ecs_cluster(self, vpc: ec2.IVpc) -> ecs.ICluster:
        cluster_arn = ssm.StringParameter.value_from_lookup(self, self.config["ecs_cluster_arn_ssm_param"])
        # ARN like arn:aws:ecs:us-east-1:123:cluster/main-bundle
        cluster_name = cluster_arn.rsplit("/", 1)[1]
        return ecs.Cluster.from_cluster_attributes(
            self, "MainBundleCluster",
            cluster_name=cluster_name,
            vpc=vpc,
            security_groups=[],
        )

    def _import_alb_listener(self) -> elbv2.IApplicationListener:
        listener_arn = ssm.StringParameter.value_from_lookup(self, self.config["alb_listener_arn_ssm_param"])
        return elbv2.ApplicationListener.from_lookup(
            self, "MainBundleAlbListener", listener_arn=listener_arn,
        )

    # ─── owned: S3 ─────────────────────────────────────────────────────────

    def _make_buckets(self) -> tuple[s3.Bucket, s3.Bucket]:
        bucket = s3.Bucket(
            self,
            "KbmKbBucket",
            bucket_name=self.config["s3_bucket_name"],
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            encryption=s3.BucketEncryption.S3_MANAGED,
            versioned=False,
            removal_policy=RemovalPolicy.RETAIN,
        )
        backup_bucket = s3.Bucket(
            self,
            "KbmKbBackupBucket",
            bucket_name=f"{self.config['s3_bucket_name']}-backups",
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            encryption=s3.BucketEncryption.S3_MANAGED,
            versioned=False,
            removal_policy=RemovalPolicy.RETAIN,
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="expire-old-backups",
                    expiration=Duration.days(30),
                    abort_incomplete_multipart_upload_after=Duration.days(1),
                )
            ],
        )
        return bucket, backup_bucket

    # ─── owned: Secrets Manager ────────────────────────────────────────────

    def _make_secrets(self) -> dict[str, secretsmanager.ISecret]:
        bearer = secretsmanager.Secret(
            self, "KbmBearerToken",
            secret_name=f"kbm/bearer-token/{self.env_name}",
            description="Shared bearer token between main bundle and kbm-search.",
            generate_secret_string=secretsmanager.SecretStringGenerator(
                exclude_punctuation=True, password_length=48,
            ),
        )
        openai = secretsmanager.Secret(
            self, "KbmOpenAiApiKey",
            secret_name=f"kbm/openai-api-key/{self.env_name}",
            description="OpenAI API key for query expansion + rerank.",
            # Created empty — rotated manually
            secret_string_value=cdk.SecretValue.unsafe_plain_text("REPLACE_AFTER_DEPLOY"),
        )
        return {"bearer": bearer, "openai": openai}

    # ─── owned: Redis ──────────────────────────────────────────────────────

    def _make_redis(self, vpc: ec2.IVpc) -> tuple[str, ec2.SecurityGroup]:
        redis_sg = ec2.SecurityGroup(
            self, "KbmRedisSg",
            vpc=vpc,
            description="Allow 6379 from kbm-search ECS tasks only",
            allow_all_outbound=False,
        )

        subnet_group = elasticache.CfnSubnetGroup(
            self, "KbmRedisSubnetGroup",
            description="Private subnets for kbm Redis",
            subnet_ids=[s.subnet_id for s in vpc.private_subnets],
            cache_subnet_group_name=f"kbm-redis-{self.env_name}",
        )

        redis = elasticache.CfnReplicationGroup(
            self, "KbmRedis",
            replication_group_id=f"kbm-redis-{self.env_name}",
            replication_group_description="kbm-search expand + rerank cache",
            cache_node_type=self.config["redis_node_type"],
            engine="redis",
            engine_version="7.1",
            num_cache_clusters=1,
            cache_subnet_group_name=subnet_group.cache_subnet_group_name,
            security_group_ids=[redis_sg.security_group_id],
            at_rest_encryption_enabled=True,
            transit_encryption_enabled=False,  # within VPC; v2 candidate to enable
            automatic_failover_enabled=False,  # single primary; multi-AZ in prod is a v2 candidate
        )
        redis.add_dependency(subnet_group)

        endpoint = f"{redis.attr_primary_end_point_address}:{redis.attr_primary_end_point_port}"
        return endpoint, redis_sg

    # ─── owned: log group ──────────────────────────────────────────────────

    def _make_log_group(self) -> logs.LogGroup:
        return logs.LogGroup(
            self, "KbmLogGroup",
            log_group_name=f"/aws/ecs/kbm-search/{self.env_name}",
            retention=getattr(logs.RetentionDays, f"DAYS_{self.config['log_retention_days']}"),
            removal_policy=RemovalPolicy.RETAIN,
        )

    # ─── owned: IAM roles ──────────────────────────────────────────────────

    def _make_iam_roles(
        self,
        s3_bucket: s3.Bucket,
        secrets: dict[str, secretsmanager.ISecret],
    ) -> tuple[iam.Role, iam.Role]:

        # Task role — runtime permissions the container needs
        task_role = iam.Role(
            self, "KbmTaskRole",
            assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            description="kbm-search runtime permissions",
        )

        # S3 read on the KB bucket (only)
        task_role.add_to_policy(iam.PolicyStatement(
            actions=["s3:GetObject", "s3:ListBucket", "s3:HeadObject"],
            resources=[s3_bucket.bucket_arn, f"{s3_bucket.bucket_arn}/*"],
        ))

        # Secrets read on kbm/* only
        for secret in secrets.values():
            secret.grant_read(task_role)

        # Bedrock invoke on Titan-Embed-Text-v2 only (NOT *)
        task_role.add_to_policy(iam.PolicyStatement(
            actions=["bedrock:InvokeModel"],
            resources=[
                f"arn:aws:bedrock:{self.region}::foundation-model/amazon.titan-embed-text-v2:0",
            ],
        ))

        # CloudWatch metrics: only PutMetricData on the kbm/* namespace
        task_role.add_to_policy(iam.PolicyStatement(
            actions=["cloudwatch:PutMetricData"],
            resources=["*"],
            conditions={"StringEquals": {"cloudwatch:namespace": ["kbm"]}},
        ))

        # Logs: write to its own log group only
        task_role.add_to_policy(iam.PolicyStatement(
            actions=["logs:CreateLogStream", "logs:PutLogEvents"],
            resources=[f"arn:aws:logs:{self.region}:{self.account}:log-group:/aws/ecs/kbm-search/*"],
        ))

        # Execution role — used by ECS to pull image + write boot logs
        exec_role = iam.Role(
            self, "KbmExecRole",
            assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name(
                    "service-role/AmazonECSTaskExecutionRolePolicy"
                ),
            ],
        )
        # Execution role also needs to read the secrets (to inject as env vars)
        for secret in secrets.values():
            secret.grant_read(exec_role)

        return task_role, exec_role

    # ─── owned: task definition + service ──────────────────────────────────

    def _make_task_definition(
        self,
        *,
        task_role: iam.Role,
        exec_role: iam.Role,
        log_group: logs.LogGroup,
        secrets: dict[str, secretsmanager.ISecret],
        redis_endpoint: str,
    ) -> ecs.FargateTaskDefinition:
        td = ecs.FargateTaskDefinition(
            self, "KbmTaskDef",
            family=f"kbm-search-{self.env_name}",
            cpu=1024,
            memory_limit_mib=2048,
            ephemeral_storage_gib=21,
            task_role=task_role,
            execution_role=exec_role,
        )
        td.add_container(
            "kbm",
            image=ecs.ContainerImage.from_registry(
                # The container image is built + pushed by .github/workflows/cd.yml
                # to ECR. The tag follows kbm-vMAJOR.MINOR.PATCH.
                f"{self.account}.dkr.ecr.{self.region}.amazonaws.com/kbm:{cdk.Token.as_string(cdk.Aws.STACK_NAME)}"
            ),
            essential=True,
            port_mappings=[ecs.PortMapping(container_port=8080, protocol=ecs.Protocol.TCP)],
            logging=ecs.LogDrivers.aws_logs(
                stream_prefix="kbm",
                log_group=log_group,
            ),
            environment={
                "KBM_ENV":           self.env_name,
                "KBM_S3_BUCKET":     self.config["s3_bucket_name"],
                "KBM_S3_REGION":     self.region,
                "KBM_REDIS_HOST":    redis_endpoint.split(":")[0],
                "KBM_REDIS_PORT":    redis_endpoint.split(":")[1],
                "KBM_BEDROCK_REGION": self.region,
                "KBM_LOG_LEVEL":     "INFO",
            },
            secrets={
                "KBM_BEARER_TOKEN": ecs.Secret.from_secrets_manager(secrets["bearer"]),
                "KBM_OPENAI_API_KEY": ecs.Secret.from_secrets_manager(secrets["openai"]),
            },
            health_check=ecs.HealthCheck(
                command=["CMD-SHELL", "curl -fsS http://localhost:8080/health || exit 1"],
                interval=Duration.seconds(30),
                timeout=Duration.seconds(10),
                start_period=Duration.seconds(60),
                retries=3,
            ),
        )
        return td

    def _make_service(
        self,
        cluster: ecs.ICluster,
        task_def: ecs.FargateTaskDefinition,
        redis_sg: ec2.SecurityGroup,
    ) -> ecs.FargateService:
        service_sg = ec2.SecurityGroup(
            self, "KbmServiceSg",
            vpc=cluster.vpc,
            description="kbm-search ECS service",
            allow_all_outbound=True,
        )
        # Allow service → Redis on 6379
        redis_sg.add_ingress_rule(
            service_sg,
            ec2.Port.tcp(6379),
            description="kbm-search → Redis",
        )

        return ecs.FargateService(
            self, "KbmService",
            service_name=f"kbm-search-{self.env_name}",
            cluster=cluster,
            task_definition=task_def,
            desired_count=self.config["desired_count"],
            security_groups=[service_sg],
            assign_public_ip=False,
            min_healthy_percent=50,
            max_healthy_percent=200,
            health_check_grace_period=Duration.seconds(60),
            enable_execute_command=True,  # for `aws ecs execute-command` debug
            circuit_breaker=ecs.DeploymentCircuitBreaker(rollback=True),
        )

    # ─── owned: ALB plumbing ───────────────────────────────────────────────

    def _make_target_group(self, vpc: ec2.IVpc, service: ecs.FargateService) -> elbv2.ApplicationTargetGroup:
        tg = elbv2.ApplicationTargetGroup(
            self, "KbmTargetGroup",
            target_group_name=f"kbm-tg-{self.env_name}",
            target_type=elbv2.TargetType.IP,
            protocol=elbv2.ApplicationProtocol.HTTP,
            port=8080,
            vpc=vpc,
            deregistration_delay=Duration.seconds(30),
            health_check=elbv2.HealthCheck(
                path="/health",
                healthy_http_codes="200",
                healthy_threshold_count=2,
                unhealthy_threshold_count=3,
                interval=Duration.seconds(30),
                timeout=Duration.seconds(10),
            ),
        )
        service.attach_to_application_target_group(tg)
        return tg

    def _make_listener_rule(
        self,
        listener: elbv2.IApplicationListener,
        tg: elbv2.ApplicationTargetGroup,
    ) -> None:
        elbv2.ApplicationListenerRule(
            self, "KbmListenerRule",
            listener=listener,
            priority=1000 + (0 if self.env_name == "prod" else 10 if self.env_name == "staging" else 20),
            conditions=[elbv2.ListenerCondition.path_patterns(["/kbm/*", "/health", "/ready"])],
            action=elbv2.ListenerAction.forward([tg]),
        )

    # ─── owned: SNS topic for alarms ───────────────────────────────────────

    def _make_sns_topic(self) -> sns.Topic:
        return sns.Topic(
            self, "KbmAlarmsTopic",
            topic_name=f"kbm-{self.env_name}-alarms",
            display_name="kbm alarms",
        )

    # ─── owned: 9 CloudWatch alarms ────────────────────────────────────────

    def _make_alarms(
        self,
        target_group: elbv2.ApplicationTargetGroup,
        sns_topic: sns.Topic,
    ) -> None:
        """All 9 alarms from `12_*.md §3`. Thresholds come from
        `kbm.constants.ALARM_*` (no literals here — enforced by
        scripts/check_ci_alarms_use_slo_file.py)."""
        slo = self.slo
        action = cw_actions.SnsAction(sns_topic)

        # 1. Query availability low (5xx > 1 - SLO%)
        avail = cloudwatch.Alarm(
            self, "AlarmQueryAvailabilityLow",
            alarm_name=f"kbm-{self.env_name}-query-availability-low",
            metric=cloudwatch.MathExpression(
                expression="(m_5xx / m_total) * 100",
                using_metrics={
                    "m_5xx":   target_group.metric_http_code_target(elbv2.HttpCodeTarget.TARGET_5XX_COUNT, period=Duration.minutes(5)),
                    "m_total": target_group.metric_request_count(period=Duration.minutes(5)),
                },
                period=Duration.minutes(5),
            ),
            threshold=100 - slo["QUERY_AVAILABILITY_MIN_PCT"],
            evaluation_periods=3,
            datapoints_to_alarm=3,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        avail.add_alarm_action(action)

        # 2. p95 latency high
        p95 = cloudwatch.Alarm(
            self, "AlarmQueryLatencyP95High",
            alarm_name=f"kbm-{self.env_name}-query-latency-p95-high",
            metric=target_group.metric_target_response_time(
                statistic="p95",
                period=Duration.minutes(5),
            ),
            threshold=slo["QUERY_LATENCY_P95_MS"] / 1000.0,
            evaluation_periods=3,
            datapoints_to_alarm=3,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        p95.add_alarm_action(action)

        # 3. p99 latency high
        p99 = cloudwatch.Alarm(
            self, "AlarmQueryLatencyP99High",
            alarm_name=f"kbm-{self.env_name}-query-latency-p99-high",
            metric=target_group.metric_target_response_time(
                statistic="p99",
                period=Duration.minutes(5),
            ),
            threshold=slo["QUERY_LATENCY_P99_MS"] / 1000.0,
            evaluation_periods=3,
            datapoints_to_alarm=3,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        p99.add_alarm_action(action)

        # 4. Health probe unhealthy (any unhealthy target for 5 min)
        unhealthy = cloudwatch.Alarm(
            self, "AlarmHealthUnhealthy",
            alarm_name=f"kbm-{self.env_name}-health-unhealthy",
            metric=target_group.metric_unhealthy_host_count(period=Duration.minutes(1)),
            threshold=slo["HEALTH_UNHEALTHY_5MIN"],
            evaluation_periods=5,
            datapoints_to_alarm=5,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.BREACHING,
        )
        unhealthy.add_alarm_action(action)

        # 5. Cache hit rate low (custom metric emitted by kbm.obs.metrics)
        cache_hit = cloudwatch.Alarm(
            self, "AlarmCacheHitLow",
            alarm_name=f"kbm-{self.env_name}-cache-hit-low",
            metric=cloudwatch.Metric(
                namespace="kbm",
                metric_name="cache_hit_rate",
                dimensions_map={"env": self.env_name, "layer": "expand"},
                statistic="Average",
                period=Duration.hours(1),
            ),
            threshold=slo["CACHE_HIT_RATE_MIN_PCT"],
            evaluation_periods=1,
            comparison_operator=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        cache_hit.add_alarm_action(action)

        # 6. Rerank cost per query high
        rerank_cost = cloudwatch.Alarm(
            self, "AlarmRerankCostHigh",
            alarm_name=f"kbm-{self.env_name}-rerank-cost-high",
            metric=cloudwatch.Metric(
                namespace="kbm",
                metric_name="rerank_cost_usd_per_query",
                dimensions_map={"env": self.env_name},
                statistic="p90",
                period=Duration.hours(1),
            ),
            threshold=slo["RERANK_COST_PER_QUERY_USD"],
            evaluation_periods=1,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        rerank_cost.add_alarm_action(action)

        # 7. Nightly bench recall low
        bench_recall = cloudwatch.Alarm(
            self, "AlarmNightlyBenchRecallLow",
            alarm_name=f"kbm-{self.env_name}-nightly-bench-recall-low",
            metric=cloudwatch.Metric(
                namespace="kbm",
                metric_name="nightly_recall_at_3",
                dimensions_map={"env": self.env_name},
                statistic="Average",
                period=Duration.days(1),
            ),
            threshold=slo["NIGHTLY_BENCH_RECALL_MIN"],
            evaluation_periods=2,
            datapoints_to_alarm=2,
            comparison_operator=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.BREACHING,
        )
        bench_recall.add_alarm_action(action)

        # 8. Build cost high (per-build event metric)
        build_cost = cloudwatch.Alarm(
            self, "AlarmBuildCostHigh",
            alarm_name=f"kbm-{self.env_name}-build-cost-high",
            metric=cloudwatch.Metric(
                namespace="kbm",
                metric_name="build_cost_usd",
                dimensions_map={"env": self.env_name},
                statistic="Sum",
                period=Duration.hours(1),
            ),
            threshold=slo["BUILD_COST_USD"],
            evaluation_periods=1,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        build_cost.add_alarm_action(action)

        # 9. Error rate high (errors / total > 5%)
        error_rate = cloudwatch.Alarm(
            self, "AlarmErrorRateHigh",
            alarm_name=f"kbm-{self.env_name}-error-rate-high",
            metric=cloudwatch.MathExpression(
                expression="m_err / m_total",
                using_metrics={
                    "m_err":   cloudwatch.Metric(namespace="kbm", metric_name="search_error_count",
                                                  dimensions_map={"env": self.env_name}, statistic="Sum",
                                                  period=Duration.minutes(5)),
                    "m_total": target_group.metric_request_count(period=Duration.minutes(5)),
                },
                period=Duration.minutes(5),
            ),
            threshold=slo["ERROR_RATE_MAX"],
            evaluation_periods=3,
            datapoints_to_alarm=3,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        error_rate.add_alarm_action(action)

    # ─── owned: dashboard ──────────────────────────────────────────────────

    def _make_dashboard(self) -> None:
        cloudwatch.Dashboard(
            self, "KbmOverviewDashboard",
            dashboard_name=f"kbm-{self.env_name}-overview",
            widgets=[
                [
                    cloudwatch.GraphWidget(
                        title="Query latency (p50/p95/p99)",
                        width=12,
                        left=[
                            cloudwatch.Metric(namespace="kbm", metric_name="query_latency_ms",
                                              statistic="p50", label="p50"),
                            cloudwatch.Metric(namespace="kbm", metric_name="query_latency_ms",
                                              statistic="p95", label="p95"),
                            cloudwatch.Metric(namespace="kbm", metric_name="query_latency_ms",
                                              statistic="p99", label="p99"),
                        ],
                    ),
                    cloudwatch.GraphWidget(
                        title="Cache hit rate",
                        width=12,
                        left=[
                            cloudwatch.Metric(namespace="kbm", metric_name="cache_hit_rate",
                                              dimensions_map={"layer": "expand"}, label="expand"),
                            cloudwatch.Metric(namespace="kbm", metric_name="cache_hit_rate",
                                              dimensions_map={"layer": "rerank"}, label="rerank"),
                        ],
                    ),
                ],
                [
                    cloudwatch.GraphWidget(
                        title="Strong-signal bypass rate",
                        width=8,
                        left=[cloudwatch.Metric(namespace="kbm", metric_name="strong_signal_bypass_rate")],
                    ),
                    cloudwatch.GraphWidget(
                        title="Per-tool call rate",
                        width=8,
                        stacked=True,
                        left=[
                            cloudwatch.Metric(namespace="kbm", metric_name="tool_call_count",
                                              dimensions_map={"tool": t})
                            for t in ["query", "get", "multi_get", "status", "ls"]
                        ],
                    ),
                    cloudwatch.GraphWidget(
                        title="OpenAI token usage / hour",
                        width=8,
                        left=[
                            cloudwatch.Metric(namespace="kbm", metric_name="rerank_tokens_in"),
                            cloudwatch.Metric(namespace="kbm", metric_name="rerank_tokens_out"),
                        ],
                    ),
                ],
            ],
        )

    # ─── owned: nightly bench Lambda ───────────────────────────────────────

    def _make_nightly_bench_lambda(
        self,
        s3_bucket: s3.Bucket,
        alb_listener: elbv2.IApplicationListener,
    ) -> None:
        """Lambda invoked by EventBridge daily at 03:00 UTC. Pulls
        bench/nightly_queries.jsonl from S3, runs each via the kbm /query
        endpoint, scores recall@3, emits to CloudWatch."""
        bench_fn = lambda_.Function(
            self, "NightlyBenchFn",
            function_name=f"kbm-nightly-bench-{self.env_name}",
            runtime=lambda_.Runtime.PYTHON_3_12,
            handler="nightly_bench.handler",
            code=lambda_.Code.from_asset("../scripts/nightly_bench"),  # packaged separately
            timeout=Duration.minutes(15),
            memory_size=512,
            environment={
                "KBM_ENV": self.env_name,
                "KBM_S3_BUCKET": s3_bucket.bucket_name,
                "KBM_ALB_URL": "http://INTERNAL_PLACEHOLDER",  # actual URL inferred at runtime from listener
            },
        )
        s3_bucket.grant_read(bench_fn)
        bench_fn.add_to_role_policy(iam.PolicyStatement(
            actions=["cloudwatch:PutMetricData"],
            resources=["*"],
            conditions={"StringEquals": {"cloudwatch:namespace": ["kbm"]}},
        ))
        bench_fn.add_to_role_policy(iam.PolicyStatement(
            actions=["secretsmanager:GetSecretValue"],
            resources=[f"arn:aws:secretsmanager:{self.region}:{self.account}:secret:kbm/bearer-token/*"],
        ))

        rule = events.Rule(
            self, "NightlyBenchRule",
            rule_name=f"kbm-nightly-bench-{self.env_name}",
            schedule=events.Schedule.cron(minute="0", hour="3"),
        )
        rule.add_target(event_targets.LambdaFunction(bench_fn))
```

---

## §6. Env-var contract — what `cdk/stack.py` reads from where

| Env var (in the container) | Source | Used by |
|---|---|---|
| `KBM_ENV` | Container env (set in task def) | every module — settings.py |
| `KBM_S3_BUCKET` | Container env | search/s3.py + build/cli.py |
| `KBM_S3_REGION` | Container env | boto3 |
| `KBM_REDIS_HOST` / `KBM_REDIS_PORT` | Container env (from Redis endpoint output) | search/cache.py |
| `KBM_BEDROCK_REGION` | Container env | search/vec.py |
| `KBM_LOG_LEVEL` | Container env | logger.py |
| `KBM_BEARER_TOKEN` | ECS Secret (from Secrets Manager) | mcp/auth.py |
| `KBM_OPENAI_API_KEY` | ECS Secret (from Secrets Manager) | search/expand.py + search/rerank.py |

**Hard rule**: every env var the container expects MUST be declared in `task_def.add_container(... environment=..., secrets=...)`. CI script `scripts/check_env_vars_documented.py` (Family D extension) cross-checks `src/kbm/settings.py` Pydantic model fields against the keys in this stack.

---

## §7. Deploy / synth procedure (verbatim — for the junior agent)

```sh
# 1. Bootstrap (one-time per account)
cd cdk/
cdk bootstrap aws://$AWS_ACCOUNT_DEV/us-east-1

# 2. Synth (verifies the stack compiles before deploying)
cdk synth --context env=dev

# 3. Deploy
cdk deploy --context env=dev --require-approval never
# ~6-8 minutes; cdk reports progress to stdout

# 4. Verify the stack outputs
aws cloudformation describe-stacks --stack-name kbm-dev \
  --query 'Stacks[0].Outputs' --output table

# Expected outputs:
#   KbmServiceName       kbm-search-dev
#   KbmTargetGroupArn    arn:aws:elasticloadbalancing:...:targetgroup/kbm-tg-dev/...
#   KbmS3Bucket          kb-dev
#   KbmRedisEndpoint     kbm-redis-dev.xyz.cache.amazonaws.com:6379

# 5. Smoke-test
curl https://<main-bundle-alb>/health  # via the listener rule we attached
# Expected: {"status":"ok","uptime":<N>}

# 6. Rollback (if needed)
cdk deploy --context env=dev --rollback
# OR aws ecs update-service to a previous task def revision
```

---

## §8. Common CDK gotchas the junior agent will hit

| Gotcha | Symptom | Fix |
|---|---|---|
| Forgot `aws cdk bootstrap` | First `cdk deploy` fails with "no SSM parameter" | One-time `cdk bootstrap aws://ACCOUNT/REGION` |
| ECR image tag doesn't exist yet | `cdk deploy` fails with "image not found" | Run `cd.yml` build+push BEFORE first deploy; OR seed ECR with a placeholder image |
| SSM parameter `vpc_id_ssm_param` not set by main bundle | `cdk synth` fails on `value_from_lookup` | Main bundle's CDK must export VPC/cluster/ALB ARNs to SSM; document the contract in main bundle |
| Redis transit-encryption causes auth-token requirement | Redis client fails with `AUTH required` | v1 has `transit_encryption_enabled=False`; v2 will add auth tokens |
| `cdk synth --context env=foo` succeeds with unknown env | Stack created in wrong account | The `KbmStack.__init__` raises on unknown env — confirm `app.py` validates |
| Task fails health check during deploy | `kbm/health` is not yet returning 200 (still loading from S3) | `health_check_grace_period=60s` accommodates this |
| Service security group doesn't allow Redis | App logs `ConnectionError` to Redis | `_make_service` MUST add ingress to redis_sg (already does in template) |
| `cdk deploy` keeps re-creating SecurityGroup | SG references between stacks | Use `from_security_group_id` for cross-stack refs; this template imports only from SSM |

---

## §9. Definition of Done (Phase 5 CDK)

- [ ] `cdk/cdk.json`, `cdk/app.py`, `cdk/stack.py`, `cdk/__init__.py` checked in verbatim from §2-§5
- [ ] `cdk synth --context env=dev` succeeds (compiles to CloudFormation)
- [ ] `cdk diff --context env=dev` against an empty deployment shows only the expected ~25 resources from §1
- [ ] Main bundle has exported SSM parameters: `vpc_id_ssm_param`, `ecs_cluster_arn_ssm_param`, `alb_listener_arn_ssm_param` (coordinate with main bundle owner)
- [ ] `cdk deploy --context env=dev` succeeds against a real (dev) AWS account
- [ ] `aws cloudformation describe-stacks --stack-name kbm-dev` shows `StackStatus: CREATE_COMPLETE`
- [ ] `aws ecs describe-services --cluster <main-bundle-cluster> --services kbm-search-dev` shows `runningCount: 1`
- [ ] `curl https://<main-bundle-alb>/health` returns 200 within 5 minutes of deploy
- [ ] `scripts/check_ci_alarms_use_slo_file.py` passes (every `threshold=` in stack.py is sourced from `kbm.constants.ALARM_*`)
- [ ] `make ci` green

---

*End of CDK template. With this in place, the junior agent has a working CDK starter and doesn't re-derive AWS infrastructure from scratch. Closes PM gap GAP-3.*
