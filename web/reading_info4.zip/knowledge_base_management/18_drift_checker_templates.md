# 18 — Drift-Checker Templates (verbatim sources for `scripts/check_*.py`)

> **Purpose** — the bundle references **16+ drift-checker scripts** that CI runs on every PR. Without complete templates, a junior agent will write the checkers wrong and CI will green-light real drift. This file provides 4 representative checkers in full; the remaining 12 follow the same pattern (described in §6). Closing PM gap GAP-2.
>
> **Audience** — junior agent at the start of Phase 0 (the scripts are needed by `make ci` from day 1).
>
> **Phase**: Phase 0 (drop in the 4 verbatim templates) + Phase 1 (extend by analogy for the remaining 12).

---

## §1. The 16 drift-checkers, grouped by template family

The 16 scripts split into **4 families**, each with a representative template below.

| Family | Representative template (§N) | Other scripts in family | What they enforce |
|---|---|---|---|
| **A. Constant table → Python module** | §2 — `check_chunker_constants.py` | `check_break_patterns.py`, `check_retrieval_constants.py`, `check_constants_match_source.py`, `check_metric_names.py` | A markdown table's rows match Python module's `Final[T] = ...` assignments byte-equal |
| **B. Verbatim string → source file** | §3 — `check_mcp_tool_descriptions_unchanged.py` | `check_adr_references_intact.py`, `check_no_print_in_prod.py`, `check_no_stubs_in_src.py` | A multi-line code-block in a markdown file is byte-equal to a Python triple-quoted string |
| **C. Determinism / byte-equality** | §4 — `check_chunker_byte_identical.py` | `check_schemas_unchanged.py`, `check_s3_layout.py` | Running a deterministic builder twice produces identical output |
| **D. Code-style / structural** | §5 — `check_test_docstrings.py` | `check_route_response_models.py`, `check_ci_alarms_use_slo_file.py`, `check_coverage_changed_lines.py` | Source files conform to a structural pattern (every test has Given/When/Then; every route declares `response_model=`) |

Each checker is ~80-150 LOC, single-purpose, stdlib-only (no `pytest` import — they run before/outside the test suite).

---

## §2. Family A template — `scripts/check_chunker_constants.py` (verbatim)

This is the **canonical drift-checker**. Copy this exact shape for `check_break_patterns.py`, `check_retrieval_constants.py`, `check_constants_match_source.py`, `check_metric_names.py`.

```python
#!/usr/bin/env python3
"""
scripts/check_chunker_constants.py — Family A (constant-table drift)

Asserts that the constants table in `05_chunker_spec.md §1` matches the
`Final[T] = ...` declarations in `src/kbm/constants.py`. Byte-equal values;
any drift fails CI.

Exit codes:
    0 — all 8 chunker constants match
    1 — at least one drift (logged with file:line on both sides)
    2 — spec or source file missing / unparseable

Usage:
    python scripts/check_chunker_constants.py
    python scripts/check_chunker_constants.py --verbose       # log every match
"""
from __future__ import annotations

import argparse
import ast
import re
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SPEC_PATH = REPO_ROOT / "05_chunker_spec.md"
SOURCE_PATH = REPO_ROOT / "src" / "kbm" / "constants.py"

# The 8 constants declared in 05_*.md §1's table. CI fails if either side
# (spec or source) drops or renames any.
EXPECTED_CONSTANTS: dict[str, object] = {
    "CHUNK_SIZE_TOKENS":    900,
    "CHUNK_OVERLAP_TOKENS": 135,
    "CHUNK_SIZE_CHARS":     3600,
    "CHUNK_OVERLAP_CHARS":  540,
    "CHUNK_WINDOW_TOKENS":  200,
    "CHUNK_WINDOW_CHARS":   800,
    "DECAY_FACTOR":         0.7,
    "MAX_CHUNKS_PER_DOC":   200,
}


def parse_spec_table(spec_text: str) -> dict[str, str]:
    """Extract the §1 constants table. Returns {name: value_as_str}.

    The §1 table format (from 05_*.md):
        | Constant | Value | doc_search source | Audit row |
        |---|---|---|---|
        | `CHUNK_SIZE_TOKENS` | 900 | `store.ts:55` | row 2 |
        | `CHUNK_OVERLAP_TOKENS` | 135 (= floor(900 × 0.15)) | ... |
    """
    found: dict[str, str] = {}
    # Match table rows: pipes, constant name in backticks, value column
    row_re = re.compile(
        r"^\|\s*`([A-Z_][A-Z0-9_]*)`\s*\|\s*([^|]+?)\s*\|", re.MULTILINE
    )
    for m in row_re.finditer(spec_text):
        name = m.group(1)
        # Value column may have annotations like "135 (= floor(900 × 0.15))".
        # Take the leading numeric/literal token.
        raw_val = m.group(2).strip()
        # Strip trailing parens/comments
        cleaned = re.split(r"\s*\(", raw_val, maxsplit=1)[0].strip()
        # Strip backticks if any
        cleaned = cleaned.strip("`").strip()
        found[name] = cleaned
    return found


def parse_source_constants(source_text: str) -> dict[str, object]:
    """Extract `Final[T] = literal` assignments from `src/kbm/constants.py`.

    Only matches the pattern:
        NAME: Final[int]   = 900
        NAME: Final[float] = 0.7
        NAME: Final[str]   = "..."

    Returns {name: parsed_value}.
    """
    found: dict[str, object] = {}
    # Match assignments: NAME: Final[...] = literal
    assign_re = re.compile(
        r"^([A-Z_][A-Z0-9_]*)\s*:\s*Final\[[^\]]+\]\s*=\s*(.+?)\s*$",
        re.MULTILINE,
    )
    for m in assign_re.finditer(source_text):
        name = m.group(1)
        raw = m.group(2).rstrip("# ").rstrip()
        # Strip trailing comment if present
        if "  #" in raw:
            raw = raw.split("  #", 1)[0].rstrip()
        try:
            value = ast.literal_eval(raw)
        except (ValueError, SyntaxError):
            # If it's an arithmetic expression like 900 * 4, evaluate safely
            try:
                value = eval(raw, {"__builtins__": {}}, {})  # noqa: S307 — eval limited to numeric expressions
            except Exception:
                continue
        found[name] = value
    return found


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    if not SPEC_PATH.exists():
        print(f"[FAIL] spec missing: {SPEC_PATH}", file=sys.stderr)
        return 2
    if not SOURCE_PATH.exists():
        print(f"[FAIL] source missing: {SOURCE_PATH}", file=sys.stderr)
        return 2

    spec_table = parse_spec_table(SPEC_PATH.read_text(encoding="utf-8"))
    source_consts = parse_source_constants(SOURCE_PATH.read_text(encoding="utf-8"))

    drifts: list[str] = []

    for name, expected_value in EXPECTED_CONSTANTS.items():
        # Check spec table
        if name not in spec_table:
            drifts.append(f"  ✗ {name}: MISSING from 05_chunker_spec.md §1 table")
            continue
        spec_str = spec_table[name]
        # Check source
        if name not in source_consts:
            drifts.append(f"  ✗ {name}: MISSING from src/kbm/constants.py")
            continue
        source_val = source_consts[name]

        # Compare both against the expected value
        if str(expected_value) != spec_str.replace(",", ""):
            drifts.append(
                f"  ✗ {name}: spec table says {spec_str!r}, expected {expected_value!r}"
            )
        if source_val != expected_value:
            drifts.append(
                f"  ✗ {name}: src/kbm/constants.py = {source_val!r}, expected {expected_value!r}"
            )
        if not drifts and args.verbose:
            print(f"  ✓ {name} = {expected_value}")

    if drifts:
        print("Drift detected in chunker constants:", file=sys.stderr)
        for d in drifts:
            print(d, file=sys.stderr)
        print(
            "\nFix: update BOTH 05_chunker_spec.md §1 AND src/kbm/constants.py "
            "in the same PR. Constants must be byte-equal to EXPECTED_CONSTANTS in this script.",
            file=sys.stderr,
        )
        return 1

    print(f"[OK] All {len(EXPECTED_CONSTANTS)} chunker constants match.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

### §2.1 How to extend for the other Family-A checkers

- **`check_break_patterns.py`**: parse the `BREAK_PATTERNS` Python list in `src/kbm/build/chunker.py` (using `ast` not regex — the list has tuples), compare to the 12-row table in `05_*.md §2`. Expected entries hard-coded in the script as a list of `(regex_pattern_str, score, type_tag)` triples.
- **`check_retrieval_constants.py`**: same shape as §2 but reads `06_*.md §2` (18 constants) and the retrieval section of `src/kbm/constants.py`.
- **`check_constants_match_source.py`** *(parent-bundle consistency)*: same shape but compares `src/kbm/constants.py` against `temp/deep_dives/doc_search_tool/24_audit_and_corrections.md §1` (the 44-claim audit table).
- **`check_metric_names.py`**: parses CloudWatch metric names from `12_*.md §2` and asserts they match `src/kbm/obs/metrics.py` `CW_METRIC_*` constants.

---

## §3. Family B template — `scripts/check_mcp_tool_descriptions_unchanged.py` (verbatim)

The MCP tool descriptions in `04_*.md §3-§7` MUST be byte-equal to the registration strings in `src/kbm/mcp/tools.py`. This checker enforces it.

```python
#!/usr/bin/env python3
"""
scripts/check_mcp_tool_descriptions_unchanged.py — Family B (verbatim-string drift)

Each of the 5 MCP tool descriptions in `04_mcp_tool_contract.md §3.1, §4.1, §5.1, §6.1, §7.1`
MUST be byte-equal to the corresponding TOOL_DESCRIPTION constant in
`src/kbm/mcp/tools.py`. CI fails on any character drift.

Exit codes:
    0 — all 5 descriptions match
    1 — at least one byte-mismatch (offset reported)
    2 — spec or source file missing

Usage:
    python scripts/check_mcp_tool_descriptions_unchanged.py
    python scripts/check_mcp_tool_descriptions_unchanged.py --tool query  # check one
"""
from __future__ import annotations

import argparse
import ast
import re
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SPEC_PATH = REPO_ROOT / "04_mcp_tool_contract.md"
SOURCE_PATH = REPO_ROOT / "src" / "kbm" / "mcp" / "tools.py"

# Maps tool name → (spec section header that precedes its verbatim block,
# variable name in tools.py).
TOOLS: list[tuple[str, str, str]] = [
    ("query",     "## §3. MCP Tool 1 — `query`",       "QUERY_DESCRIPTION"),
    ("get",       "## §4. MCP Tool 2 — `get`",         "GET_DESCRIPTION"),
    ("multi_get", "## §5. MCP Tool 3 — `multi_get`",   "MULTI_GET_DESCRIPTION"),
    ("status",    "## §6. MCP Tool 4 — `status`",      "STATUS_DESCRIPTION"),
    ("ls",        "## §7. MCP Tool 5 — `ls`",          "LS_DESCRIPTION"),
]


def extract_spec_block(spec_text: str, section_header: str) -> str:
    """Extract the first fenced code block (``` ... ```) AFTER `section_header`
    and BEFORE the next `### §X.2` subsection.

    Format expected in spec (per 04_*.md):
        ## §3. MCP Tool 1 — `query` (the workhorse)
        ### §3.1 Verbatim description (REGISTER THIS STRING, NEVER EDIT)
        ```
        Search the knowledge base ...
        ```
        ### §3.2 Input schema ...
    """
    # Locate the §X.1 subsection
    sec_idx = spec_text.find(section_header)
    if sec_idx < 0:
        raise ValueError(f"Section header not found in spec: {section_header!r}")

    # From there, look for the "### §X.1 Verbatim description" line
    subsec_re = re.compile(r"^### §\d+\.1 Verbatim description", re.MULTILINE)
    m = subsec_re.search(spec_text, sec_idx)
    if not m:
        raise ValueError(f"§X.1 'Verbatim description' subsection missing after {section_header!r}")

    # First triple-backtick block after that
    after = spec_text[m.end():]
    fence_re = re.compile(r"^```(?:[a-zA-Z]+)?\n(.*?)^```", re.MULTILINE | re.DOTALL)
    fm = fence_re.search(after)
    if not fm:
        raise ValueError(f"No fenced code block after {section_header!r} §X.1")
    return fm.group(1).rstrip("\n")


def extract_source_constant(source_text: str, var_name: str) -> str:
    """Extract a `var_name: Final[str] = """..."""` triple-quoted assignment.

    Returns the raw string content (no quotes).
    """
    pattern = rf'^{var_name}\s*(?::\s*Final\[str\])?\s*=\s*"{{3,}}(.+?)"{{3,}}'
    m = re.search(pattern, source_text, re.DOTALL | re.MULTILINE)
    if not m:
        # Try with f-string prefix or `r"""`-raw prefix
        pattern_r = rf'^{var_name}\s*(?::\s*Final\[str\])?\s*=\s*[rfRF]?"{{3,}}(.+?)"{{3,}}'
        m = re.search(pattern_r, source_text, re.DOTALL | re.MULTILINE)
    if not m:
        raise ValueError(f"{var_name} not found in src/kbm/mcp/tools.py")
    return m.group(1).rstrip("\n")


def first_diff_offset(a: str, b: str) -> int:
    """Return first character offset where a and b differ, or -1 if equal."""
    for i, (ca, cb) in enumerate(zip(a, b)):
        if ca != cb:
            return i
    if len(a) != len(b):
        return min(len(a), len(b))
    return -1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tool", help="Check only one tool", choices=[t[0] for t in TOOLS])
    args = parser.parse_args()

    if not SPEC_PATH.exists() or not SOURCE_PATH.exists():
        print(f"[FAIL] missing file ({SPEC_PATH} or {SOURCE_PATH})", file=sys.stderr)
        return 2

    spec_text = SPEC_PATH.read_text(encoding="utf-8")
    source_text = SOURCE_PATH.read_text(encoding="utf-8")

    failed = False
    for tool_name, section, var_name in TOOLS:
        if args.tool and tool_name != args.tool:
            continue
        try:
            spec_block = extract_spec_block(spec_text, section)
            source_str = extract_source_constant(source_text, var_name)
        except ValueError as e:
            print(f"  ✗ {tool_name}: {e}", file=sys.stderr)
            failed = True
            continue

        if spec_block == source_str:
            print(f"  ✓ {tool_name}: descriptions match ({len(spec_block)} bytes)")
            continue

        # Byte-level diff
        offset = first_diff_offset(spec_block, source_str)
        ctx_start = max(0, offset - 40)
        ctx_end = min(max(len(spec_block), len(source_str)), offset + 40)
        print(f"  ✗ {tool_name}: byte mismatch at offset {offset}", file=sys.stderr)
        print(f"      spec [{ctx_start}:{ctx_end}]:   {spec_block[ctx_start:ctx_end]!r}", file=sys.stderr)
        print(f"      source [{ctx_start}:{ctx_end}]: {source_str[ctx_start:ctx_end]!r}", file=sys.stderr)
        failed = True

    if failed:
        print(
            "\nFix: update BOTH 04_mcp_tool_contract.md §3.1/§4.1/§5.1/§6.1/§7.1 "
            "AND src/kbm/mcp/tools.py in the same PR.",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

### §3.1 How to extend for other Family-B checkers

- **`check_adr_references_intact.py`**: greps every `ADR-\d+` reference across the bundle markdown files; confirms each resolves to an entry in `14_adr_catalog.md`.
- **`check_no_print_in_prod.py`**: greps `^\s*print\(` in `src/kbm/` (excluding tests); CI fails if any match.
- **`check_no_stubs_in_src.py`**: greps `TODO|FIXME|XXX|NotImplementedError` in `src/kbm/` (excluding tests + docstrings); CI fails if any match.

---

## §4. Family C template — `scripts/check_chunker_byte_identical.py` (verbatim)

The chunker MUST be deterministic. Running it twice on the same input must produce byte-equal output. This checker calls the chunker on a small fixture twice and diffs.

```python
#!/usr/bin/env python3
"""
scripts/check_chunker_byte_identical.py — Family C (determinism check)

Verifies that `kbm.build.chunker.chunk_document_by_tokens` is deterministic:
running it twice on the same input must produce byte-equal Chunk lists.

Exit codes:
    0 — chunker is deterministic across 3 runs on each of 5 fixtures
    1 — non-determinism detected
    2 — chunker module not importable (Phase 1 not yet complete)

Usage:
    python scripts/check_chunker_byte_identical.py
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SRC = REPO_ROOT / "src"

# Add src to path so we can import kbm.* without installing
sys.path.insert(0, str(SRC))

try:
    from kbm.build.chunker import chunk_document_by_tokens, Chunk
except ImportError as e:
    print(f"[FAIL] chunker not yet implemented: {e}", file=sys.stderr)
    print("This check fails in Phase 0; should pass once Phase 1 lands.", file=sys.stderr)
    sys.exit(2)


# Fixture docs — embed verbatim so this script has no external dep.
# Each fixture covers a different chunker code-path.
FIXTURES: list[tuple[str, str]] = [
    (
        "short_doc",
        "# Title\nshort body\n"
    ),
    (
        "long_doc_with_h1",
        "# Section A\n" + ("filler. " * 800) + "\n# Section B\n" + ("more filler. " * 600) + "\n# Section C\n" + ("end. " * 200),
    ),
    (
        "code_fence",
        "# Title\n\nIntro.\n\n```python\n" + ("def foo():\n    return 1\n" * 100) + "```\n\nAfter.\n",
    ),
    (
        "mixed_headings_and_lists",
        "# Title\n## Subsection\n- item 1\n- item 2\n\n### Sub-subsection\n\nMore text.\n" * 50,
    ),
    (
        "deterministic_check_via_repeating_pattern",
        ("# H1\n## H2\n### H3\nbody body body. " * 200),
    ),
]


def chunk_signature(chunks: list[Chunk]) -> str:
    """Stable hash of (text, pos, end_pos) for every chunk."""
    h = hashlib.sha256()
    for c in chunks:
        h.update(c.text.encode("utf-8"))
        h.update(b"\x00")
        h.update(str(c.pos).encode("utf-8"))
        h.update(b"\x00")
        h.update(str(c.end_pos).encode("utf-8"))
        h.update(b"\x00")
    return h.hexdigest()


def main() -> int:
    failed = False
    for fname, content in FIXTURES:
        sigs: list[str] = []
        for run in range(3):
            chunks = chunk_document_by_tokens(content, chunk_strategy="regex")
            sigs.append(chunk_signature(chunks))
        if len(set(sigs)) != 1:
            print(
                f"  ✗ {fname}: NON-DETERMINISTIC. "
                f"3 runs produced {len(set(sigs))} different signatures: {sigs}",
                file=sys.stderr,
            )
            failed = True
        else:
            print(f"  ✓ {fname}: deterministic across 3 runs (sig {sigs[0][:8]}...)")

    if failed:
        print(
            "\nFix: check `kbm.build.chunker.chunk_document_by_tokens` for any "
            "use of `set()`, `dict()` iteration without sorting, `random`, "
            "or `os.path.walk` (use sorted() instead of walk).",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

### §4.1 How to extend for other Family-C checkers

- **`check_schemas_unchanged.py`**: dumps every Pydantic model's JSON schema, sha256s them, compares against checked-in `docs/schemas/*.json` (regenerate via `make schemas`).
- **`check_s3_layout.py`**: imports `kbm.shared.paths` helpers + walks a built fixture; asserts every path matches the layout in `03_data_contracts.md §3.1`.

---

## §5. Family D template — `scripts/check_test_docstrings.py` (verbatim)

Every test function MUST have a docstring containing `Given:`, `When:`, `Then:` (per `10_*.md §2`).

```python
#!/usr/bin/env python3
"""
scripts/check_test_docstrings.py — Family D (structural pattern)

Enforces that every `def test_*` in `tests/` has a docstring containing
'Given:', 'When:', 'Then:' (per 10_tdd_acceptance.md §2 — TDD discipline).

Exit codes:
    0 — every test function has the Given/When/Then docstring
    1 — at least one test missing the docstring (paths reported)

Usage:
    python scripts/check_test_docstrings.py
    python scripts/check_test_docstrings.py --path tests/unit/test_chunker.py  # one file
"""
from __future__ import annotations

import argparse
import ast
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
TESTS_ROOT = REPO_ROOT / "tests"

# Phrases required in test docstrings (case-insensitive substring match)
REQUIRED_PHRASES = ("given:", "when:", "then:")


def check_file(path: Path) -> list[str]:
    """Returns a list of error messages (empty if file is clean)."""
    errors: list[str] = []
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as e:
        return [f"{path}:{e.lineno}: SYNTAX ERROR — {e.msg}"]

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if not node.name.startswith("test_"):
            continue

        ds = ast.get_docstring(node, clean=True)
        if ds is None:
            errors.append(f"{path}:{node.lineno}: test `{node.name}` MISSING docstring")
            continue

        ds_lower = ds.lower()
        missing = [phrase for phrase in REQUIRED_PHRASES if phrase not in ds_lower]
        if missing:
            errors.append(
                f"{path}:{node.lineno}: test `{node.name}` docstring missing: {', '.join(missing)}"
            )

    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", help="Check one specific file", type=Path)
    args = parser.parse_args()

    if args.path:
        paths = [args.path]
    else:
        paths = list(TESTS_ROOT.rglob("test_*.py"))

    all_errors: list[str] = []
    for path in paths:
        all_errors.extend(check_file(path))

    if all_errors:
        print(f"Test docstring drift — {len(all_errors)} test(s) missing Given/When/Then:", file=sys.stderr)
        for err in all_errors:
            print(f"  ✗ {err}", file=sys.stderr)
        print(
            "\nFix: add a docstring to each test with the format:\n"
            "    def test_x():\n"
            '        """\n'
            '        Given: ...\n'
            '        When:  ...\n'
            '        Then:  ...\n'
            '        """\n',
            file=sys.stderr,
        )
        return 1

    print(f"[OK] {len(paths)} test file(s) checked; all tests have Given/When/Then docstrings.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

### §5.1 How to extend for other Family-D checkers

- **`check_route_response_models.py`**: AST-walks `src/kbm/mcp/server.py`; every `@app.post(...)` / `@app.get(...)` decorator must include `response_model=...`. CI fails on any missing.
- **`check_ci_alarms_use_slo_file.py`**: AST-walks `cdk/stack.py`; asserts no numeric literals appear in `CloudWatchAlarm(..., threshold=<literal>)` — must be `threshold=ALARM_*` constant from `src/kbm/constants.py`.
- **`check_coverage_changed_lines.py`**: shells `coverage report --include=$(git diff --name-only HEAD~1 -- 'src/kbm/*.py')` and parses output; fails if coverage on changed lines < 90%.

---

## §6. The remaining 12 checkers (recipe per family)

| Script | Family | What it does | LOC estimate |
|---|---|---|---|
| `check_break_patterns.py` | A | Like §2 but reads `05_*.md §2` 12-row table → `BREAK_PATTERNS` list in `chunker.py` | 120 |
| `check_retrieval_constants.py` | A | Like §2 but reads `06_*.md §2` 18 constants → `constants.py` retrieval section | 100 |
| `check_constants_match_source.py` | A | Cross-bundle: kbm's `constants.py` vs `temp/deep_dives/doc_search_tool/24_audit_and_corrections.md §1` | 130 |
| `check_metric_names.py` | A | `12_*.md §2` 8 metric names → `obs/metrics.py` `CW_METRIC_*` constants | 90 |
| `check_adr_references_intact.py` | B | Grep `ADR-\d+` across `*.md`; each must resolve in `14_*.md` | 80 |
| `check_no_print_in_prod.py` | B | Grep `^\s*print\(` in `src/kbm/`; fail on any match | 50 |
| `check_no_stubs_in_src.py` | B | Grep `TODO\|FIXME\|XXX\|raise NotImplementedError` in `src/kbm/` (excl. docstrings) | 70 |
| `check_schemas_unchanged.py` | C | Dump every Pydantic model schema → hash → compare against `docs/schemas/*.json` | 150 |
| `check_s3_layout.py` | C | Walk a built gold-KB fixture; every path must match the layout in `03_*.md §3.1` | 110 |
| `check_route_response_models.py` | D | AST-walk every FastAPI route decorator in `src/kbm/mcp/server.py`; fail if any lacks `response_model=` | 100 |
| `check_ci_alarms_use_slo_file.py` | D | AST-walk `cdk/stack.py`; no numeric literals in alarm `threshold=` args (must be constant) | 90 |
| `check_coverage_changed_lines.py` | D | Parse `coverage report` filtered to PR-changed files; fail if < 90% | 70 |

**Estimated total**: ~1180 LOC. With templates from §2-§5, each remaining script is mechanical translation.

---

## §7. CI wiring (Makefile + ci.yml)

After the 16 scripts exist, the Makefile `ci:` target (already in `02_*.md §8`) runs them:

```makefile
ci: lint type test
	$(BIN)/python scripts/check_chunker_constants.py
	$(BIN)/python scripts/check_break_patterns.py
	$(BIN)/python scripts/check_retrieval_constants.py
	$(BIN)/python scripts/check_constants_match_source.py
	$(BIN)/python scripts/check_metric_names.py
	$(BIN)/python scripts/check_mcp_tool_descriptions_unchanged.py
	$(BIN)/python scripts/check_adr_references_intact.py
	$(BIN)/python scripts/check_no_print_in_prod.py
	$(BIN)/python scripts/check_no_stubs_in_src.py
	$(BIN)/python scripts/check_schemas_unchanged.py
	$(BIN)/python scripts/check_s3_layout.py
	$(BIN)/python scripts/check_chunker_byte_identical.py
	$(BIN)/python scripts/check_test_docstrings.py
	$(BIN)/python scripts/check_route_response_models.py
	$(BIN)/python scripts/check_ci_alarms_use_slo_file.py
	$(BIN)/python scripts/check_coverage_changed_lines.py
```

The `.github/workflows/ci.yml` already invokes `make ci` (per `02_*.md §12`).

---

## §8. Anti-pattern: drift-checkers that pass too easily

The four templates above all guard against one common pitfall: a drift-checker that's TOO PERMISSIVE silently green-lights real drift.

**Mistakes to avoid in your checkers**:

1. **Skipping when the file is missing**. Always treat a missing file as exit code 2 (fail loudly). Don't silently pass with "nothing to check."
2. **Wildcard matching that's too forgiving**. E.g., `re.search` instead of `re.fullmatch` for constant names lets `CHUNK_SIZE_TOKENS_LEGACY` (a hypothetical typo) pass the check for `CHUNK_SIZE_TOKENS`.
3. **`str(value)` comparison instead of `ast.literal_eval`**. `str(0.7)` and `str(0.700000000001)` can differ in subtle ways; always `literal_eval` the spec value to a Python primitive, then compare.
4. **Forgetting to assert exit code in CI**. Make sure `make ci` runs each check WITHOUT `|| true`; the script's exit code must propagate.
5. **Comparing to "any" value instead of expected value**. The `EXPECTED_*` dict at the top of each Family-A checker is intentional — both sides of the cross-file check must agree with a THIRD source-of-truth (this script). That's the only way to catch "both sides drifted together."

---

## §9. Definition of Done (drift-checker suite)

- [ ] §2 `check_chunker_constants.py` checked in and passes against an EMPTY `src/kbm/constants.py` (it should fail with code 1 — the assertion that the source file has the constants)
- [ ] §3 `check_mcp_tool_descriptions_unchanged.py` checked in
- [ ] §4 `check_chunker_byte_identical.py` checked in and exits 2 (Phase 0 — chunker not yet implemented; expected)
- [ ] §5 `check_test_docstrings.py` checked in
- [ ] The remaining 12 scripts from §6 exist as either full implementations OR stubs that exit 0 with a TODO comment pointing at the family template (the stubs get fleshed out when the corresponding feature lands in Phase 1-4)
- [ ] `make ci` invokes all 16 scripts; CI red on any failure
- [ ] All 16 scripts pass `ruff check` and `mypy --strict`

---

*End of drift-checker templates. With these in place, every "verbatim port" assertion in the bundle has a runnable enforcer. Closes PM gap GAP-2.*
