# 10 — TDD Acceptance (per-artifact Given/When/Then, mutation policy, coverage gates)

> **Purpose** — the rule book that turns "junior agent finished implementing X" into "X is provably done." For every chunker function, retrieval step, MCP tool, build CLI command, and Pydantic model, this file specifies the test cases that must pass, the coverage threshold, and the mutation-survival threshold.
>
> **Two CI-enforced anti-drift commitments:**
> 1. **No artifact is "done" without its acceptance test passing.** PR template `02_*.md §14` has the checklist; the matching test under `tests/{unit,integration,e2e}/` is the proof.
> 2. **No test is allowed to be tautological.** Mutation testing on signature files (`chunker.py`, `rrf.py`, `blend.py`) catches tests that pass against any implementation.

---

## §1. Coverage + mutation gates (the numerical bar)

| Layer | Coverage gate | Mutation gate | CI command |
|---|---|---|---|
| Unit tests on changed lines | **≥ 90%** | n/a (most code is non-security) | `pytest --cov-fail-under=90 -m unit` |
| Signature files (`chunker.py`, `ast_chunker.py`, `rrf.py`, `blend.py`, `query.py`) | ≥ 95% | **≥ 90% survival** | `make mutate` |
| Integration tests | ≥ 80% on the integration code path | n/a | `pytest -m integration` |
| E2E tests | smoke only (1 happy path + 1 error path) | n/a | `pytest -m e2e` |

**A PR that drops coverage below 90% on changed lines is auto-rejected by CI.** The 5pp jump from main bundle's 85% reflects kbm's small, algorithm-heavy surface — there's no excuse for un-tested code.

---

## §2. TDD inner loop (already in `00_*.md §5` — repeat here for tab visibility)

```
1. RED       Write a failing test that encodes the §-section acceptance criterion.
2. GREEN     Write the minimum code that passes.
3. REFACTOR  Clean up, keeping tests green.
4. SCOPE     `git diff --stat` shows only files in the PR's stated phase.
5. COMPLETE  `grep -rE "TODO|FIXME|XXX" src/` returns empty.
6. REVIEW    Code review.
7. REFINE    Apply fixes; re-run 4-5.
8. TEST      `make ci`.
9. DEBUG     If anything fails, root-cause the code — NEVER weaken the test.
10. RECONCILE Verify every acceptance criterion in the relevant §-section is MET (not PARTIAL).
```

**Test docstring template (CI-enforced):**

```python
def test_chunker_h1_at_edge_beats_blank_at_target():
    """
    Given: a doc with an H1 800 chars before the target-end-pos AND a blank line AT the target
    When:  find_best_cutoff is called with window_chars=800, decay_factor=0.7
    Then:  the returned position is the H1 position (effective score 30 > blank's 20)
    """
    ...
```

CI script `scripts/check_test_docstrings.py` greps for the Given/When/Then pattern. Missing docstring = CI fail.

---

## §3. Chunker tests (per `05_chunker_spec.md §8`)

Test file: `tests/unit/test_chunker.py`.

### §3.1 — Core unit tests (18 of them)

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_chunk_short_doc_no_split` | content of 100 chars, `chunk_strategy="regex"` | `chunk_document(body)` | returns `[Chunk(text=body, pos=0, end_pos=100)]` |
| 2 | `test_chunk_long_doc_h1_split` | content of 5000 chars with `# Section A`, `# Section B`, `# Section C` | `chunk_document(body)` | returns ≥ 2 chunks; chunk[1].pos coincides with a `# Section` H1 position |
| 3 | `test_chunk_code_fence_protected` | content with ```` ``` ```` ... ```` ``` ```` around a 1000-char block + H2 inside | `chunk_document(body)` | no chunk boundary falls inside the fence range (per `find_code_fences`) |
| 4 | `test_chunk_code_fence_unclosed` | content with one unclosed ```` ``` ```` near the end | `find_code_fences(body)` | returns 1 region with `end == len(body)` |
| 5 | `test_decay_h1_at_edge_beats_blank_at_target` | break points = `[BP(pos=0, score=100, type="h1"), BP(pos=800, score=20, type="blank")]`, target=800, window=800 | `find_best_cutoff(...)` | returns `0` (the H1) — `100 * 0.30 = 30 > 20 * 1.0 = 20` |
| 6 | `test_decay_math_table_exact` | break point with score 100 at distance d ∈ {0, 200, 400, 600, 800} | `find_best_cutoff(...)` | effective score equals the §3.4 table row exactly (within 1e-9) |
| 7 | `test_scan_break_points_per_position_dedup` | content where `\n##` and `\n###` start at the same position (impossible in practice; construct via mock) | `scan_break_points(body)` | only one BreakPoint at that pos, score=90 (the higher) |
| 8 | `test_scan_break_points_returns_sorted` | content with H1 at pos 100, H2 at pos 50, blank at pos 200 | `scan_break_points(body)` | returned list is strictly ascending by `pos` |
| 9 | `test_find_code_fences_pairs` | 4 ` \n``` ` markers → 2 regions; 5 markers → 3 regions (last extends to EOF) | `find_code_fences(body)` | regions count + last region's `end` match |
| 10 | `test_overlap_no_infinite_loop` | content of 700 chars (less than max_chars but more than overlap), max_chars=600, overlap=540 | `chunk_document_with_break_points(...)` | terminates in ≤ 3 chunks (loop guard activates) |
| 11 | `test_chunk_deterministic_3_runs` | content of 3000 chars with multi-tier headings | `chunk_document(body)` called 3 times | all 3 runs return identical Chunk lists (HC-2) |
| 12 | `test_chunk_empty_input` | content = `""` | `chunk_document(body)` | returns `[]` |
| 13 | `test_merge_break_points_keeps_higher_score` | list A has BP(pos=10, score=20), list B has BP(pos=10, score=80) | `merge_break_points(A, B)` | returned list has BP(pos=10, score=80) |
| 14 | `test_ast_chunker_python_class` | `.py` content with `class Foo:` at pos 50 | `get_ast_break_points(body, "x.py")` | returns BreakPoint(pos=50, score=100, type="ast:class") |
| 15 | `test_ast_chunker_grammar_missing_falls_back` | mock `tree_sitter` to raise on `Language.load`, `.py` content | `get_ast_break_points(body, "x.py")` | returns `[]`, logs ONE warning |
| 16 | `test_ast_merge_with_regex` | `.py` content with `class Foo:` AND `# Heading` | `chunk_document(body, "x.py", "auto")` vs `chunk_document(body, "x.py", "regex")` | the "auto" call produces a chunk boundary at the `class` position that "regex" does NOT |
| 17 | `test_verify_chunks_recursive_halving` | a Chunk with text dense enough that `tiktoken` returns 2000 tokens | `verify_chunks_by_token_count([chunk])` | returns ≥ 2 chunks, each with `n_tokens ≤ 900` |
| 18 | `test_verify_chunks_truncation_last_resort` | a Chunk with 4500-token dense text (won't halve to ≤ 900 in 4 levels) | `verify_chunks_by_token_count([chunk])` | the offending chunk is tokenizer-truncated to exactly 900 tokens |

**Coverage: 95%. Mutation survival on `chunker.py`: 90%.** The most-attacked invariants are: (a) per-position dedup keeps higher score, (b) decay multiplier formula, (c) loop guard against infinite loops.

### §3.2 — Property-based tests (`tests/unit/test_chunker_properties.py`)

Three properties using `hypothesis` (per `05_*.md §9`):

1. `test_chunker_does_not_lose_chars` — joined chunk texts cover every char in input.
2. `test_chunker_chunks_within_size_bound` — every chunk `≤ CHUNK_SIZE_CHARS * 1.1`.
3. `test_chunker_deterministic_property` — `chunk_document(x) == chunk_document(x)` for 20 random inputs.

---

## §4. Data-contract tests (per `03_data_contracts.md`)

Test file: `tests/unit/test_types.py`.

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_manifest_validates_minimal_example` | bytes of canonical `manifest.yaml` from `03_*.md §2.1` | `Manifest.model_validate(yaml.safe_load(bytes))` | parses without error |
| 2 | `test_manifest_rejects_no_wiki_collection` | manifest with only `kind="raw"` collections | `Manifest.model_validate(...)` | raises `ValueError` matching "at least one collection with kind='wiki'" (per `03_*.md §2.1` validator) |
| 3 | `test_manifest_rejects_bad_embed_model` | `build_info.embedding_model_id="random/model"` | `Manifest.model_validate(...)` | raises pydantic ValidationError (Literal type-check) |
| 4 | `test_query_input_either_query_or_searches` | `QueryToolInput(query=None, searches=None)` | construct | raises `ValueError` "Must provide either 'query' or 'searches'" |
| 5 | `test_query_input_not_both` | `QueryToolInput(query="x", searches=[...])` | construct | raises "Provide only one" |
| 6 | `test_docid_first_6_chars` | hash = "abc1234567..." (full SHA-256) | `get_docid(hash)` | returns "abc123" |
| 7 | `test_normalize_docid_strips_hash` | s = `'  "#ABC123"  '` | `normalize_docid(s)` | returns "abc123" |
| 8 | `test_is_docid_accepts_6_chars` | s = "abc123" | `is_docid(s)` | True |
| 9 | `test_is_docid_rejects_short` | s = "abc12" (5 chars) | `is_docid(s)` | False |
| 10 | `test_is_docid_rejects_non_hex` | s = "abcxyz" | `is_docid(s)` | False |
| 11 | `test_parse_virtual_path` | s = "qmd://engineering/runbooks/kafka.md" | `parse_virtual_path(s)` | returns ("engineering", "runbooks/kafka.md") |
| 12 | `test_build_virtual_path` | coll="x", path="a/b.md" | `build_virtual_path(coll, path)` | returns "qmd://x/a/b.md" |
| 13 | `test_constants_match_audit_source` | (no input) | run `scripts/check_constants_match_source.py` | exits 0; every constant in `kbm/constants.py` is found in `24_audit §1` |

---

## §5. Build pipeline tests (per `07_build_pipeline_spec.md`)

Test file: `tests/integration/test_build_pipeline.py`.

Uses LocalStack S3 fixture (`tests/integration/conftest.py`) and the gold KB fixture (`tests/fixtures/gold_kb/`).

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_kbm_build_walks_collections` | gold KB with 7 source files across `wiki` + `engineering_raw` | `kbm build --manifest gold_kb/manifest.yaml --output ./kb-test/` | `kb-test/catalog.parquet` has 7 rows |
| 2 | `test_kbm_build_dedupes_identical_bodies` | gold KB with two identical files in different collections | `kbm build ...` | `kb-test/content/{hash[:2]}/{hash}.md` is written ONCE; both catalog rows reference the same hash |
| 3 | `test_kbm_embed_writes_faiss_per_collection` | post-build state | `kbm embed --output ./kb-test/` | each `kb-test/vectors/{coll}/index.faiss` + `meta.parquet` exists; row counts match catalog `chunk_count` sum |
| 4 | `test_kbm_embed_writes_embedding_model_txt` | post-embed state | inspect each `vectors/{c}/embedding_model.txt` | line 1 == `amazon.titan-embed-text-v2:0`, line 2 == `1024` |
| 5 | `test_kbm_lint_passes_clean_fixture` | gold KB clean fixture | `kbm lint --output ./kb-test/` | exits 0; `build_info.json.lint_passed=true`; `lint_errors=[]` |
| 6 | `test_kbm_lint_catches_partial_embedding` | gold KB but mutate `meta.parquet` to drop 1 row | `kbm lint` | exits 1; `lint_errors` contains `L2` for the affected hash |
| 7 | `test_kbm_lint_catches_zero_length_doc` | gold KB + empty file in `raw/` | `kbm build && kbm lint` | exits 1; `lint_errors` contains `L6` |
| 8 | `test_kbm_lint_catches_missing_context` | gold KB with a doc under `raw/orphan/` not matched by any context prefix | `kbm lint` | `lint_warnings` contains `L1` for that doc |
| 9 | `test_kbm_lint_catches_dim_mismatch` | gold KB then overwrite `embedding_model.txt` to claim dim=384 | `kbm lint` | exits 1; `lint_errors` contains `L9` |
| 10 | `test_kbm_upload_refuses_lint_failed` | `build_info.json.lint_passed=false` | `kbm upload --to s3://localstack-bucket/` | exits 1; nothing uploaded; error message references HC-5 |
| 11 | `test_kbm_plan_upload_shows_diff` | LocalStack bucket has v1 of build; new local build is v2 (1 doc changed) | `kbm plan-upload --to s3://localstack-bucket/` | output lists changed files only |
| 12 | `test_kbm_upload_atomic` | mid-upload, S3 returns 503 on the 3rd PUT | `kbm upload` retries per `RETRY_POLICIES[UploadError]` | succeeds after retry; no partial state left in bucket |
| 13 | `test_kbm_build_idempotent_no_changes` | gold KB → `kbm build` → `kbm build` again on same input | second run | byte-identical `catalog.parquet`, `content/*`, `chunks/*` |

---

## §6. Retrieval pipeline tests (per `06_retrieval_pipeline_spec.md`)

Test file: `tests/unit/test_*.py` per function + `tests/integration/test_query_pipeline.py` for E2E.

### §6.1 — RRF tests (`test_rrf.py`)

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_rrf_formula_k_60` | one list `[A]`, weights=[1.0], k=60 | `reciprocal_rank_fusion(...)` | A's rrf_score == `1.0 / (60 + 0 + 1) + 0.05` (top-rank bonus) == `0.06639...` |
| 2 | `test_rrf_original_query_2x_weight` | list_l1=[A,B], list_l2=[B,A], weights=[2.0, 1.0] | `reciprocal_rank_fusion(...)` | A scores higher than B (A: 2/61+1/62+0.05; B: 2/62+1/61+0.05) |
| 3 | `test_top_rank_bonus_plus_05_rank_0` | one list `[A]` | RRF | A.rrf_score includes the +0.05 |
| 4 | `test_top_rank_bonus_plus_02_rank_2` | one list `[A, B, C]` (C at rank 2) | RRF | C gets +0.02, A gets +0.05, B gets +0.02 |
| 5 | `test_no_bonus_rank_3_plus` | one list `[A, B, C, D]` (D at rank 3) | RRF | D's rrf_score does NOT include any bonus |
| 6 | `test_rrf_deduplicates_by_file` | two lists, both containing the same `file` | RRF | result has 1 entry for that file; rrf_score is the sum of contributions; top_rank is the min |

### §6.2 — Position-aware blend tests (`test_blend.py`)

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_blend_top_3_is_75_25` | rrf_rank=1, rerank_score=0.2 | `position_aware_blend(...)` | blended = 0.75 * (1/1) + 0.25 * 0.2 = 0.80 |
| 2 | `test_blend_top_4_10_is_60_40` | rrf_rank=5, rerank_score=0.6 | blend | 0.60 * (1/5) + 0.40 * 0.6 = 0.12 + 0.24 = 0.36 |
| 3 | `test_blend_rank_11_plus_is_40_60` | rrf_rank=15, rerank_score=0.9 | blend | 0.40 * (1/15) + 0.60 * 0.9 = 0.0267 + 0.54 = 0.567 |
| 4 | `test_blend_no_rerank_returns_rrf_only` | rerank_score=None | blend | returns rrf_score unchanged |
| 5 | `test_blend_reorders_by_blended_score` | 3 candidates with mixed RRF + rerank values | blend | output sorted by blended_score desc |

### §6.3 — Strong-signal bypass tests (`test_query.py`)

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_bypass_triggers_at_0_85_and_0_15_gap` | FTS top=0.92, FTS#2=0.65 (gap 0.27 ≥ 0.15), no intent | `hybrid_query(...)` | bypass_reason="strong_signal_bypass"; expansion never called |
| 2 | `test_no_bypass_when_score_too_low` | FTS top=0.80 (below 0.85) | hybrid_query | bypass_reason=None; expansion called |
| 3 | `test_no_bypass_when_gap_too_small` | FTS top=0.90, FTS#2=0.85 (gap 0.05 < 0.15) | hybrid_query | bypass_reason=None |
| 4 | `test_no_bypass_when_intent_present` | FTS top=0.92, gap 0.27, intent="x" | hybrid_query | bypass_reason=None (intent disables bypass) |
| 5 | `test_no_bypass_for_multi_collection_v1` | collections=["a","b"], FTS top=0.92 in "a" | hybrid_query | bypass_reason=None (kbm's HC-7 + ADR-014: bypass only fires on single-collection or no-filter — see `06_*.md §2` "port discrepancy") |

### §6.4 — Cache tests (`test_cache.py`)

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_cache_key_is_sha256_of_url_plus_sorted_json` | url="expandQuery", body={"q":"x","model":"m"} | `cache_key(url, body)` | hex matches `hashlib.sha256(b"expandQueryx_serialized_body").hexdigest()` |
| 2 | `test_cache_set_and_get` | fakeredis instance | `cache.set(k, v); cache.get(k)` | returns v |
| 3 | `test_cache_get_miss_returns_none` | fakeredis instance, key not set | `cache.get(k)` | returns None |
| 4 | `test_cache_ttl_24h` | set a key | check TTL via `redis.ttl(k)` | TTL is between 86_390 and 86_400 |
| 5 | `test_cache_failure_does_not_crash_query` | mock redis.get to raise ConnectionError | call `query` against KBStore | query still returns valid results (graceful degradation per `RETRY_POLICIES[CacheError]`) |

### §6.5 — End-to-end retrieval pipeline (`test_query_pipeline.py`)

Uses gold-KB fixture in LocalStack S3 + mock Bedrock + mock OpenAI.

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_query_returns_expected_top_3` | gold KB with 7 docs; query "kafka consumer lag debugging" | `POST /mcp tools/call query` | top-3 includes `qmd://wiki/kafka-consumer-lag.md` (the wiki page wins, per ADR-013) |
| 2 | `test_wiki_collection_queried_first` | gold KB; query that matches both `wiki` and `engineering_raw` | `POST /query` with `collections=null` | results are predominantly from `wiki` (≥ 2 of top 3) |
| 3 | `test_fallback_to_raw_when_wiki_empty` | gold KB but with `wiki/` empty | `POST /query "kafka"` | results come from `engineering_raw`; latency budget honored |
| 4 | `test_explain_flag_includes_rrf_trace` | any query, `explain=true` | `POST /query` | response includes `explain.contributing_lists`, `explain.rerank_score`, `explain.blend_weight` |
| 5 | `test_min_score_filter` | gold KB query that produces 5 results with scores [0.9, 0.7, 0.5, 0.3, 0.1] | `POST /query min_score=0.4` | returns only the top-3 |
| 6 | `test_collection_filter_restricts` | gold KB, query that matches both collections | `POST /query collections=["engineering_raw"]` | no result has `file` starting with `qmd://wiki/` |

---

## §7. MCP server tests (per `04_mcp_tool_contract.md`)

Test file: `tests/integration/test_mcp_endpoints.py`. Uses FastAPI `TestClient`.

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_health_returns_status_ok` | running app | `GET /health` | 200; `{"status":"ok","uptime":<int>}` |
| 2 | `test_ready_returns_503_when_s3_down` | mock S3 to raise on `list_objects_v2` | `GET /ready` | 503 |
| 3 | `test_ready_returns_200_when_all_probes_pass` | LocalStack S3 up + fakeredis up + mocked Bedrock ok | `GET /ready` | 200 |
| 4 | `test_auth_rejects_missing_bearer` | request without `Authorization` header | any non-health route | 401 |
| 5 | `test_auth_rejects_wrong_bearer` | request with `Authorization: Bearer wrong` | any non-health route | 401 |
| 6 | `test_mcp_query_via_json_rpc` | valid JSON-RPC envelope: `{"jsonrpc":"2.0","method":"tools/call","params":{"name":"query","arguments":{"query":"x"}},"id":1}` | `POST /mcp` | 200; result has `structuredContent.results` |
| 7 | `test_mcp_get_returns_resource_block` | valid file path | `POST /mcp tools/call name=get` | response shape: `{"content":[{"type":"resource","resource":{"uri":"qmd://...","mimeType":"text/markdown","text":...}}]}` |
| 8 | `test_mcp_get_not_found_returns_isError` | nonexistent docid `#zzzzzz` | `POST /mcp tools/call name=get` | response: `{"content":[{"type":"text","text":"Not found..."}],"isError":true}` |
| 9 | `test_mcp_multi_get_size_cap` | a doc larger than `max_bytes=1024` | `POST /mcp tools/call name=multi_get pattern="**/*.md" max_bytes=1024` | that doc's entry has `"skipped":true, "reason":"File too large..."` |
| 10 | `test_mcp_status_returns_collections` | gold KB loaded | `POST /mcp tools/call name=status` | response has `structuredContent.collections` listing all manifest collections + counts |
| 11 | `test_mcp_ls_no_path_lists_collections` | gold KB loaded | `POST /mcp tools/call name=ls` | response: `entries` lists `wiki` + `engineering_raw` with `kind="collection"` |
| 12 | `test_mcp_ls_with_path_lists_files` | gold KB | `POST /mcp tools/call name=ls path="engineering_raw/runbooks"` | entries lists `kafka.md` |
| 13 | `test_mcp_initialize_injects_instructions` | fresh session | `POST /mcp method=initialize` | response has `instructions` text including doc-count + collection list + capability gaps |
| 14 | `test_post_query_rest_shortcut` | bearer-authed | `POST /query "x"` (REST, NOT JSON-RPC) | returns `{"results":[...]}`  |
| 15 | `test_tool_descriptions_byte_identical` | server boot | inspect each tool's `description` field via `tools/list` | byte-equal to the verbatim text in `04_*.md §3.X` (drift-checker `scripts/check_mcp_tool_descriptions_unchanged.py`) |

---

## §8. Wiki integration tests (per `claude.md` workflow)

Test file: `tests/unit/test_wiki_pattern.py`.

`claude.md` describes the wiki maintenance workflow (ingest, page format, citation rules, lint, QA). `kbm` implements the storage + retrieval; the wiki itself is human-curated. Tests here verify that:

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_wiki_collection_built_separately_from_raw` | manifest with `wiki` AND `engineering_raw` collections | `kbm build && kbm embed` | `fts/wiki.sqlite` and `fts/engineering_raw.sqlite` are separate files |
| 2 | `test_wiki_index_md_required` | wiki collection missing `index.md` | `kbm lint` | warning `L1` (missing context) for the wiki root |
| 3 | `test_wiki_links_dont_break_chunker` | wiki page with `[[other-page]]` inline | `chunk_document(body)` | chunker treats `[[other-page]]` as regular text; no special handling needed |
| 4 | `test_wiki_log_md_excluded_from_index` | wiki collection contains `log.md` | `kbm build` | `log.md` is NOT in `catalog.parquet` (default `ignore: ["log.md"]` in the wiki collection spec — see ADR-013) |

---

## §9. Main-app integration tests (per `08_main_app_integration.md`)

Live in `target_product_bundle/tests/integration/test_kbm_integration.py` (not in `kbm/` repo — they live in the main bundle).

| # | Test | Given | When | Then |
|---|---|---|---|---|
| 1 | `test_main_agent_calls_kbm_query` | kbm-search service running in Docker Compose; gold KB loaded | main agent receives a user message "what's the kafka runbook?" | agent invokes `mp_tools.kbm.kbm_query(...)`; result includes `qmd://wiki/kafka-consumer-lag.md` |
| 2 | `test_main_agent_falls_back_to_get_after_query` | post-query state with top-3 docids | agent decides to read full body of top result | `mp_tools.kbm.kbm_get("#abc123")` returns body |
| 3 | `test_kbm_skill_passes_main_bundle_drift_check` | `target_product_bundle/src/skills/kbm-search/SKILL.md` | run `target_product_bundle/scripts/check_skills.py` | passes — every `tools_used:` in the skill is a real `mp_tools.kbm.*` function |
| 4 | `test_kbm_tool_descriptions_in_main_prompts` | `target_product_bundle/src/prompts/library.py` | inspect | contains `KBM_TOOL_DESCRIPTION` constant equal to `08_*.md §5` |

---

## §10. Definition of Done (per-PR checklist — print and tick)

Every PR opened against `kbm/` MUST satisfy:

- [ ] **TDD inner loop**: failing test pushed in commit BEFORE implementation commit (PR template box ticked)
- [ ] **Phase scope**: `git diff --stat` shows only files in the PR's stated phase from `00_*.md §4`
- [ ] **No TODO/FIXME/XXX in production code**: `grep -rE "TODO|FIXME|XXX" src/kbm/ | grep -v test` returns empty
- [ ] **Coverage on changed lines ≥ 90%** (CI gate)
- [ ] **Mutation testing**: if you touched `chunker.py`, `ast_chunker.py`, `rrf.py`, `blend.py`, or `query.py` → `make mutate` survival ≥ 90%
- [ ] **All drift-checkers pass**:
  - `scripts/check_chunker_constants.py`
  - `scripts/check_break_patterns.py`
  - `scripts/check_retrieval_constants.py`
  - `scripts/check_mcp_tool_descriptions_unchanged.py`
  - `scripts/check_schemas_unchanged.py`
  - `scripts/check_s3_layout.py`
  - `scripts/check_constants_match_source.py`
  - `scripts/check_test_docstrings.py`
- [ ] **Pre-commit clean**: `pre-commit run --all-files`
- [ ] **`make ci` green locally + in GitHub Actions**
- [ ] **PR description**:
  - Phase number quoted (e.g. "Phase 4 — Search half")
  - Bundle files referenced (e.g. "implements `06_*.md §3.1-§3.5`")
  - Sign-off checkbox ticked (per `00_*.md §12`)
- [ ] **Tag created on merge**: `git tag kbm-v0.x.y-<phase>` (e.g. `kbm-v0.0.5-search`)
- [ ] **If a constant changed**: ADR added in `14_adr_catalog.md` AND bundle file (`05_*.md` etc.) updated in same PR

---

## §11. Mutation testing — what to expect

`make mutate` runs `mutmut` on `chunker.py`, `rrf.py`, `blend.py`. It introduces small code mutations (flip `<` to `>`, change `0.05` to `0.06`, etc.) and checks that at least one test catches each mutation.

**Target survival rate: ≥ 90%.** A mutation that "survives" means it passed all tests despite being wrong code — that's a test gap.

**Common surviving mutations + the tests that catch them:**

| Mutation | Caught by |
|---|---|
| `rrf_score = weight / (k + rank + 1)` → `weight / (k + rank)` | `test_rrf_formula_k_60` (exact float compare) |
| `if topRank === 0 → += 0.05` becomes `=== 1` | `test_top_rank_bonus_plus_05_rank_0` |
| `if rrf_rank <= 3 → 0.75` becomes `<= 2` | `test_blend_top_3_is_75_25` AND `test_blend_top_4_10_is_60_40` (boundary at rank=3) |
| `0.85` strong-signal threshold → `0.80` | `test_no_bypass_when_score_too_low` (uses 0.80 exactly) |
| `0.15` gap threshold → `0.10` | `test_no_bypass_when_gap_too_small` (uses 0.05 — too small under both) |

If a mutation survives, ADD a boundary test — don't widen tolerance.

---

## §12. Live-OpenAI tests (nightly)

Marked `@pytest.mark.live_openai`. CI does NOT run these on PRs; nightly EventBridge invokes them.

| # | Test | Why nightly |
|---|---|---|
| 1 | `test_live_expand_actually_calls_gpt41` | catches API contract changes (e.g. structured-output schema regression) |
| 2 | `test_live_rerank_returns_40_scores` | catches gpt-4.1 max-output-length changes |
| 3 | `test_live_embed_dim_matches` | catches Bedrock model deprecation (Titan v2 → v3 silent swap) |

If any nightly test fails: SNS alarm → ops runbook §6 (model-API outage).

---

## §13. Test fixtures (cross-reference to `11_test_fixtures.md`)

All fixtures live in `tests/fixtures/`. See `11_test_fixtures.md` for:
- `conftest.py` (LocalStack, fakeredis, mock Bedrock, mock OpenAI)
- `gold_kb/` (7-doc canonical KB for build + query tests)
- `golden_chunks/` (snapshot tests for the chunker)
- `recorded_openai/` (recorded gpt-4.1 responses for unit tests — no live calls)
- `recorded_bedrock/` (recorded Bedrock embed responses)
- `bench/nightly_queries.jsonl` (10 golden queries for nightly bench Lambda)
