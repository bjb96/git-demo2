# 07 — Build Pipeline Spec (Phase 2 contract — the `kbm` CLI)

> **Purpose** — byte-level contract for the 5 `kbm` CLI commands (`build`, `embed`, `lint`, `plan-upload`, `upload`) and the modules they invoke. The CLI is the developer's interface for turning a folder tree into S3-uploadable artifacts.
>
> **Audience** — junior agent at Phase 2 start. Must have shipped Phase 1 (chunker + data contracts).

---

## §1. The 5 CLI commands

All under `kbm` (entry point declared in `02_*.md §6` `pyproject.toml [project.scripts]`).

| Command | Stages | Reads | Writes | Time budget (gold KB) |
|---|---|---|---|---|
| `kbm build` | walk → hash → chunk → write content+chunks parquet | `./<raw or wiki>/` per manifest | `./{out}/{catalog.parquet, content/, chunks/, build_info.json}` | < 5s for 7-doc gold KB; < 60s for 1k docs |
| `kbm embed` | embed every chunk via Bedrock-Titan; build FAISS + FTS5 | output of `build` | `./{out}/{vectors/, fts/, embedding_model.txt}` updated `build_info.json` | < 30s for gold KB (cache hit); < 10min for 1k docs (cold) |
| `kbm lint` | run the 9 lint checks | output of `embed` | updates `build_info.json` with lint_passed + findings | < 5s |
| `kbm plan-upload` | compute diff vs current S3 | `./{out}/` + `s3://kb-{env}/` | (stdout only — no writes) | < 5s |
| `kbm upload` | aws s3 sync (atomic, ETag-verified) | `./{out}/` | `s3://kb-{env}/` | depends on diff size; < 60s for gold KB |

---

## §2. `kbm build` — Stages 1+2 from Q1

### §2.1 Command-line interface

```sh
kbm build --manifest ./manifest.yaml --output ./kb-dev/
```

**Flags:**

| Flag | Required | Default | Description |
|---|---|---|---|
| `--manifest <path>` | yes | n/a | Path to `manifest.yaml` |
| `--output <dir>` | yes | n/a | Local output dir (will be created) |
| `--force` | no | false | Wipe `--output` dir before building |
| `--max-workers <int>` | no | 4 | Parallel walker workers (for I/O concurrency) |
| `--strict` | no | false | Fail on first L7 (decode error) rather than skip |

### §2.2 Behavior contract (`src/kbm/build/cli.py`)

```python
# Pseudo-code; full implementation per 17_*.md (the per-function spec is in this file's §3-§4)
@app.command()
def build(manifest: Path, output: Path, force: bool = False, max_workers: int = 4, strict: bool = False) -> None:
    """
    Pipeline (deterministic, idempotent):

    1. Load manifest.yaml + Pydantic validate (kbm.build.manifest.load)
    2. If --force: shutil.rmtree(output, ignore_errors=True)
       Else if output exists with prior build_info.json: read manifest_sha256 — if matches current
       manifest, return early ("idempotent skip — already built")
    3. mkdir output/{content,chunks,fts,vectors}
    4. For each collection in manifest.collections:
       4a. Walk path with pattern + ignore (kbm.build.walker.walk)
       4b. For each file:
           - read bytes; UTF-8 decode (skip on UnicodeDecodeError; log L7; unless --strict)
           - body = decoded text
           - hash = sha256(body.encode("utf-8")).hexdigest()
           - docid = hash[:6]
           - title = extract_title(body, default=path.stem)
           - modified_at = path.stat().st_mtime
           - if content/{hash[:2]}/{hash}.md does not exist: atomically write it
           - chunks = chunk_document(body, file_path=str(path),
                                     chunk_strategy=collection.chunk_strategy)
           - write chunks/{hash[:2]}/{hash}_chunks.parquet (idempotent — overwrites OK)
           - append Document(...) to in-memory catalog list
    5. Write output/catalog.parquet from the in-memory list (Polars; deterministic — sort by (collection, path) before write)
    6. Write output/contexts.json (snapshot of every collection.context map)
    7. Write output/manifest.yaml (verbatim copy of input)
    8. Write output/build_info.json with stats; lint_passed=null (filled by `kbm lint`)
    """
    ...
```

### §2.3 Deterministic write order (HC-2)

`catalog.parquet` rows MUST be sorted by `(collection, path)` before write. Without this, run-to-run row order is non-deterministic and `scripts/check_chunker_byte_identical.py` fails.

### §2.4 Idempotency

`kbm build` is a no-op if `build_info.json.manifest_sha256` matches the SHA-256 of the current `manifest.yaml`. Exit 0 with message "already built". Use `--force` to override.

### §2.5 Tests (per `10_*.md §5`)

- `test_kbm_build_walks_collections` — 7 source files → 7 catalog rows
- `test_kbm_build_dedupes_identical_bodies` — same body in 2 collections → 1 content blob, 2 catalog rows
- `test_kbm_build_idempotent_no_changes` — 2nd run produces byte-identical files
- `test_kbm_build_skips_bad_utf8` (warn mode) — file with `\x80\x81` bytes is skipped, L7 in build_info.lint_warnings
- `test_kbm_build_strict_fails_on_bad_utf8` — same input + `--strict` → exits 1

---

## §3. `kbm embed` — Stage 3+4 from Q1

### §3.1 CLI

```sh
kbm embed --output ./kb-dev/
kbm embed --output ./kb-dev/ --force                    # re-embed even if chunks unchanged
kbm embed --output ./kb-dev/ --max-batch-size 32        # tune Bedrock batch
kbm embed --output ./kb-dev/ --collection wiki          # only re-embed one collection
```

### §3.2 Behavior

```python
@app.command()
def embed(output: Path, force: bool = False, max_batch_size: int = 64, collection: str | None = None) -> None:
    """
    1. Load output/manifest.yaml + output/build_info.json
    2. For each collection (or just the named one if --collection):
       2a. Find every chunk under chunks/{hash[:2]}/{hash}_chunks.parquet whose hash
           is present in catalog.parquet filter[collection=name]
       2b. If --force OR vectors/{name}/index.faiss does not exist OR meta.parquet row
           count != chunk count: re-embed; else skip
       2c. Open Bedrock-Titan client (boto3 'bedrock-runtime')
       2d. Batch embed chunks in groups of max_batch_size (Bedrock supports up to 96 inputs;
           cap at 64 to stay under request size limits)
       2e. Each text is formatted as: f"title: {doc.title} | text: {chunk.text}"
           (verbatim port of doc_search llm.ts:99-106)
       2f. Vectors are L2-normalized BEFORE indexing
       2g. Build FAISS index per §3.3 below
       2h. Write vectors/{name}/{index.faiss, meta.parquet, embedding_model.txt}
       2i. Build SQLite FTS5 per §3.4 below
       2j. Write fts/{name}.sqlite
    3. Update build_info.json: chunks_emitted, embeddings_emitted, per-collection stats
    """
    ...
```

### §3.3 FAISS index construction

Per `03_data_contracts.md §3.8`:

```python
def select_faiss_index_type(n_vectors: int, dim: int = 1024) -> faiss.Index:
    if n_vectors < 100_000:
        return faiss.IndexFlatIP(dim)
    elif n_vectors < 10_000_000:
        idx = faiss.IndexHNSWFlat(dim, FAISS_HNSW_M, faiss.METRIC_INNER_PRODUCT)
        idx.hnsw.efConstruction = FAISS_HNSW_EF_CONSTRUCTION
        idx.hnsw.efSearch = FAISS_HNSW_EF_SEARCH
        return idx
    else:
        quantizer = faiss.IndexFlatIP(dim)
        nlist = int(n_vectors ** 0.5)
        return faiss.IndexIVFPQ(quantizer, dim, nlist, 16, 8)
```

**meta.parquet** rows MUST be written in `row_id` ascending order (matches FAISS insertion order). Use Polars `sort("row_id")` before write.

### §3.4 SQLite FTS5 build

```python
def build_fts5(collection_name: str, catalog: pl.DataFrame, content_dir: Path, out_db: Path) -> None:
    """
    1. sqlite3.connect(out_db) — overwrite existing
    2. CREATE VIRTUAL TABLE documents_fts USING fts5(filepath, title, body, tokenize='porter unicode61')
    3. For each catalog row WHERE collection == collection_name:
       INSERT INTO documents_fts VALUES (?, ?, ?) with (f"{collection}/{row.path}", row.title, read_body(row.hash))
    4. INSERT INTO documents_fts(documents_fts) VALUES('optimize')
    5. db.commit(); db.close()
    """
    ...
```

### §3.5 Bedrock retry policy

Per `03_data_contracts.md §7` `RETRY_POLICIES[EmbedderError]`: 4 attempts, backoff `[1, 2, 4, 8]` seconds. Implement via `tenacity` or roll your own. On final failure: raise `EmbedderError`; the CLI command exits non-zero.

### §3.6 Tests (per `10_*.md §5`)

- `test_kbm_embed_writes_faiss_per_collection`
- `test_kbm_embed_writes_embedding_model_txt` (HC-3)
- `test_kbm_embed_skips_unchanged_chunks` (incremental)
- `test_kbm_embed_normalizes_vectors_to_l2_unit_length` (`np.linalg.norm(v) ≈ 1.0`)
- `test_kbm_embed_retries_on_bedrock_503`

---

## §4. `kbm lint` — the 9 lint checks (per `03_*.md §3.11`)

### §4.1 CLI

```sh
kbm lint --output ./kb-dev/
kbm lint --output ./kb-dev/ --json                      # machine-readable output
kbm lint --output ./kb-dev/ --exit-on-warn              # treat warnings as errors
```

### §4.2 Behavior

```python
@app.command()
def lint(output: Path, json_out: bool = False, exit_on_warn: bool = False) -> None:
    """
    Run all 9 lint checks (Lint9Validator). Write findings to build_info.json.

    Exit code:
      0  if no errors (warnings OK)
      1  if any error
      1  if --exit-on-warn AND any warning

    Stdout:
      Default: pretty table grouped by severity
      --json:  json.dumps(build_info.lint_errors + build_info.lint_warnings, indent=2)
    """
    ...
```

### §4.3 The 9 checks (verbatim from `03_*.md §3.11`)

| Code | Severity | Detection (pseudo) |
|---|---|---|
| **L1** | warn  | `for path in catalog.path: if no prefix in collection.context matches path: emit L1` |
| **L2** | error | `for hash in catalog.hash: actual_chunks = count rows in meta.parquet WHERE hash=h; expected = catalog.chunk_count; if !=: emit L2` |
| **L3** | info  | `for hash in catalog.hash: collections_containing = catalog.filter(hash=h).collection.unique(); if len > 1: emit L3` |
| **L4** | warn  | `for chunk row in chunks/*: if chunk.n_tokens > LINT_L4_OVERSIZED_TOKENS (1100): emit L4` |
| **L5** | info  | `for chunk row: if chunk.n_tokens < LINT_L5_UNDERSIZED_TOKENS (100): emit L5` |
| **L6** | error | `for catalog row: if body_len == 0: emit L6` |
| **L7** | error | walker emits L7 during build; lint reads existing findings from build_info |
| **L8** | warn  | chunker emits L8 during build; lint reads existing findings |
| **L9** | error | `for coll: declared = read embedding_model.txt; if != BuildInfo.embedding_model_id or dim != BuildInfo.embedding_dim: emit L9` |

### §4.4 Tests (per `10_*.md §5`)

13 tests: `test_kbm_lint_*`. Covered exhaustively in `10_*.md §5`.

---

## §5. `kbm plan-upload` — preview diff vs S3

### §5.1 CLI

```sh
kbm plan-upload --output ./kb-dev/ --to s3://kb-dev/
```

### §5.2 Behavior

```python
@app.command(name="plan-upload")
def plan_upload(output: Path, to: str) -> None:
    """
    1. Parse to: as s3://<bucket>/<prefix>
    2. For every file under output/: compute local MD5
    3. List S3 objects under prefix; for each: read ETag (== MD5 for non-multipart)
    4. Diff:
       - Files only in local: 'NEW    {key}'
       - Files only in S3:    'REMOVE {key}'
       - ETag mismatch:       'CHANGE {key} ({local_md5} -> {s3_etag})'
       - Match:               (omit)
    5. Print summary: 'X new, Y changed, Z removed, W unchanged'
    """
    ...
```

### §5.3 Tests

- `test_kbm_plan_upload_shows_diff`
- `test_kbm_plan_upload_empty_diff` (idempotent re-upload shows 0 changes)

---

## §6. `kbm upload` — atomic S3 sync

### §6.1 CLI

```sh
kbm upload --output ./kb-dev/ --to s3://kb-dev/
kbm upload --output ./kb-dev/ --to s3://kb-dev/ --dry-run    # alias for plan-upload
```

### §6.2 Behavior contract (HC-5: refuse if lint_failed)

```python
@app.command()
def upload(output: Path, to: str, dry_run: bool = False) -> None:
    """
    1. Load output/build_info.json
    2. HARD STOP if build_info.lint_passed is not True: print "Lint did not pass; refusing upload (HC-5)"; exit 1
    3. If dry_run: delegate to plan_upload; return
    4. Parse to: bucket, prefix
    5. For every local file:
       5a. Compute MD5
       5b. Upload via s3.put_object with content_md5 header
       5c. Verify response.ETag == local_md5 (else: re-upload with --force, max 3 retries per RETRY_POLICIES[UploadError])
    6. For files in S3 but not local: skip by default (use --prune-remote to delete)
    7. Print summary: "Uploaded N new + M changed; W unchanged"
    """
    ...
```

### §6.3 Atomicity guarantee

If upload is interrupted mid-way:
- Already-uploaded files remain
- Subsequent `kbm upload` resumes from where it stopped (idempotent: re-uploading same ETag is a no-op via the MD5-check)

S3 itself does NOT provide multi-key atomicity. **A successful `kbm upload` guarantees every file written has correct ETag.** A partial upload is detectable via `kbm plan-upload`: it shows remaining diff.

### §6.4 Tests

- `test_kbm_upload_refuses_lint_failed` (HC-5)
- `test_kbm_upload_atomic` (retry on 503)
- `test_kbm_upload_idempotent` (re-upload is no-op)
- `test_kbm_upload_etag_verified`

---

## §7. CLI shared concerns

### §7.1 Logging

Every CLI command initializes structlog (`src/kbm/logger.py`). Log to STDERR (NOT STDOUT — STDOUT is reserved for command output). JSON format in `--json` modes; pretty in default.

### §7.2 Exit codes

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | Operation failed (validation, lint, upload, etc.) |
| 2 | CLI usage error (Typer prints help) |

### §7.3 Progress indicators

`kbm build` and `kbm embed` print a progress bar via `typer.progressbar` for collections with > 50 docs. Suppress with `--no-progress`.

### §7.4 No subprocess shelling

Per HC-7 in 00_start_here.md: no `subprocess.run("aws s3 sync ...")` from inside `kbm upload`. Use `boto3` directly. (subprocess is OK in the CLI command file itself only for git-status-like inspection; never for I/O.)

---

## §8. The CLI entry point (`src/kbm/build/cli.py`)

Boilerplate skeleton (junior agent fills in command bodies):

```python
"""kbm CLI — `kbm build`, `kbm embed`, `kbm lint`, `kbm plan-upload`, `kbm upload`."""
import typer
from kbm.logger import configure_logging
from kbm.settings import get_settings

app = typer.Typer(help="Knowledge Base Management — local build CLI.", no_args_is_help=True)


@app.callback()
def _root() -> None:
    """Initialize logger + settings on every invocation."""
    configure_logging(get_settings())


@app.command()
def build(manifest: Path, output: Path, force: bool = False, max_workers: int = 4, strict: bool = False) -> None:
    """Walk source files, hash, chunk, write content-addressable + chunks parquet."""
    from kbm.build.walker import build_pipeline
    build_pipeline(manifest, output, force=force, max_workers=max_workers, strict=strict)


@app.command()
def embed(output: Path, force: bool = False, max_batch_size: int = 64, collection: str | None = None) -> None:
    """Embed chunks via Bedrock, build FAISS + FTS5 per collection."""
    from kbm.build.embedder import embed_pipeline
    embed_pipeline(output, force=force, max_batch_size=max_batch_size, collection_filter=collection)


@app.command()
def lint(output: Path, json_out: bool = typer.Option(False, "--json"), exit_on_warn: bool = False) -> None:
    """Run 9 lint checks; write findings to build_info.json."""
    from kbm.build.lint import lint_pipeline
    exit_code = lint_pipeline(output, json_output=json_out, exit_on_warn=exit_on_warn)
    raise typer.Exit(exit_code)


@app.command(name="plan-upload")
def plan_upload(output: Path, to: str) -> None:
    """Show diff between local output and S3 destination."""
    from kbm.build.uploader import plan_upload as _do_plan
    _do_plan(output, to)


@app.command()
def upload(output: Path, to: str, dry_run: bool = typer.Option(False, "--dry-run"), prune_remote: bool = False) -> None:
    """Atomic aws s3 sync with ETag verification. Refuses if lint_passed != True (HC-5)."""
    from kbm.build.uploader import upload as _do_upload
    _do_upload(output, to, dry_run=dry_run, prune_remote=prune_remote)


if __name__ == "__main__":
    app()
```

---

## §9. Definition of Done — Phase 2 build shipment

Tag `kbm-v0.0.3-build`:

- [ ] All 5 CLI commands work against gold KB fixture
- [ ] `kbm build && kbm embed && kbm lint` on lint_clean fixture → exit 0
- [ ] Same on lint_broken fixture → exit 1 with the expected error code
- [ ] `kbm upload --to s3://localstack-bucket/` succeeds; `kbm plan-upload` shows 0 diff after
- [ ] Idempotent: 2nd `kbm build` after no source change is byte-identical (HC-2)
- [ ] All 13 build-pipeline tests in `10_*.md §5` green
- [ ] No subprocess calls
- [ ] `make ci` green
