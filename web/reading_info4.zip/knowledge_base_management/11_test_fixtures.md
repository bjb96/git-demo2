# 11 — Test Fixtures (conftest, factories, gold KB, mock LLM endpoints)

> **Purpose** — every fixture the junior agent needs to run unit / integration / E2E tests **without** hitting real AWS or real OpenAI. LocalStack S3 + fakeredis + recorded LLM responses. **Reading this file is a Phase 1 prerequisite.**
>
> **Audience** — junior agent writing the tests called out in `10_tdd_acceptance.md`.

---

## §1. Fixture layout

```
tests/
├── conftest.py                                # root — see §2
├── unit/
│   └── (test files only — fixtures from root conftest)
├── integration/
│   ├── conftest.py                            # LocalStack + fakeredis + mock LLM — see §3
│   └── docker-compose.yml                     # LocalStack + redis container for `make test-integration`
└── fixtures/
    ├── corpora/
    │   ├── lint_clean/                        # gold-KB clean fixture (§4)
    │   ├── lint_broken/                       # for negative-path lint tests (§5)
    │   └── bench_golden/                      # 10-query golden bench (§6)
    ├── golden_chunks/
    │   ├── sample_doc.md                      # input
    │   └── expected_chunks_for_sample.json    # snapshot
    ├── recorded_openai/                       # gpt-4.1 expand + rerank responses (§7)
    │   ├── expand_kafka_consumer_lag.json
    │   ├── expand_how_users_log_in.json
    │   ├── rerank_batch_40_docs.json
    │   └── ...
    └── recorded_bedrock/                      # Titan-Embed response shape (§8)
        └── embed_sample_chunk.json
```

---

## §2. Root `conftest.py` (verbatim)

```python
"""tests/conftest.py — fixtures shared across unit + integration + e2e."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Iterator

import pytest


# ── path fixtures ─────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def repo_root() -> Path:
    return Path(__file__).parent.parent


@pytest.fixture(scope="session")
def fixtures_dir(repo_root: Path) -> Path:
    return repo_root / "tests" / "fixtures"


@pytest.fixture(scope="session")
def gold_kb_dir(fixtures_dir: Path) -> Path:
    return fixtures_dir / "corpora" / "lint_clean"


# ── env hardening ─────────────────────────────────────────────────────────

@pytest.fixture(autouse=True, scope="session")
def _force_test_env() -> Iterator[None]:
    """Hard-set test-only env vars so a test never accidentally hits prod AWS/OpenAI."""
    saved = {k: os.environ.get(k) for k in [
        "KBM_ENV", "KBM_LOG_LEVEL", "KBM_S3_BUCKET", "KBM_REDIS_URL",
        "OPENAI_API_KEY", "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY",
    ]}
    os.environ.update({
        "KBM_ENV": "test",
        "KBM_LOG_LEVEL": "WARNING",
        "KBM_S3_BUCKET": "kb-test",
        "KBM_REDIS_URL": "redis://localhost:6379/15",   # test-only DB
        "OPENAI_API_KEY": "sk-test-DO-NOT-USE",
        "AWS_ACCESS_KEY_ID": "test",
        "AWS_SECRET_ACCESS_KEY": "test",
        "AWS_DEFAULT_REGION": "us-east-1",
        "LOCALSTACK_ENDPOINT_URL": "http://localhost:4566",
    })
    yield
    for k, v in saved.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v


# ── frozen clock ──────────────────────────────────────────────────────────

@pytest.fixture
def frozen_now() -> Iterator[float]:
    """Freeze time.time() and datetime.now() to 2026-05-20T12:00:00Z."""
    import time
    from unittest.mock import patch
    fixed = 1747742400.0   # 2026-05-20T12:00:00Z
    with patch("time.time", return_value=fixed):
        yield fixed


# ── recorded LLM responses ────────────────────────────────────────────────

@pytest.fixture(scope="session")
def recorded_openai_dir(fixtures_dir: Path) -> Path:
    return fixtures_dir / "recorded_openai"


def load_recorded_openai(fixtures_dir: Path, fixture_name: str) -> dict:
    """Load a recorded gpt-4.1 response from tests/fixtures/recorded_openai/."""
    path = fixtures_dir / "recorded_openai" / f"{fixture_name}.json"
    return json.loads(path.read_text())


# ── deterministic randomness ──────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _seed_random() -> None:
    """Seed Python random + numpy random to ensure deterministic tests."""
    import random
    random.seed(42)
    try:
        import numpy as np
        np.random.seed(42)
    except ImportError:
        pass
```

---

## §3. Integration `conftest.py` — LocalStack + mock LLM clients

```python
"""tests/integration/conftest.py — LocalStack S3, fakeredis, mock OpenAI, mock Bedrock."""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Iterator
from unittest.mock import AsyncMock, patch

import boto3
import fakeredis
import pytest
from moto import mock_aws


# ── LocalStack S3 (via moto) ─────────────────────────────────────────────

@pytest.fixture(scope="function")
def s3_bucket(monkeypatch) -> Iterator[str]:
    """Create an empty S3 bucket via moto. Yields bucket name."""
    with mock_aws():
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket="kb-test")
        monkeypatch.setenv("KBM_S3_BUCKET", "kb-test")
        yield "kb-test"


@pytest.fixture
def gold_kb_in_s3(s3_bucket: str, gold_kb_dir: Path) -> str:
    """Upload the gold KB fixture (already built) to LocalStack S3.

    NOTE: tests/fixtures/corpora/lint_clean/ has the SOURCE files.
    A separate fixture tests/fixtures/built_gold_kb/ has the BUILT output
    (catalog.parquet, fts.sqlite, index.faiss, etc.) — uploaded here.

    Returns: bucket name.
    """
    s3 = boto3.client("s3", region_name="us-east-1")
    built_dir = gold_kb_dir.parent / "built_gold_kb"
    for path in built_dir.rglob("*"):
        if path.is_file():
            key = str(path.relative_to(built_dir)).replace("\\", "/")
            s3.upload_file(str(path), s3_bucket, key)
    return s3_bucket


# ── fakeredis ─────────────────────────────────────────────────────────────

@pytest.fixture
def redis_client() -> Iterator[fakeredis.FakeRedis]:
    """In-memory Redis. No network."""
    r = fakeredis.FakeRedis(decode_responses=True)
    r.flushall()
    yield r
    r.flushall()


# ── Mock OpenAI client (always returns recorded fixtures) ─────────────────

@pytest.fixture
def mock_openai(recorded_openai_dir: Path) -> Iterator[AsyncMock]:
    """Mock AsyncOpenAI with a router: dispatch on the user-message prefix to a
    pre-recorded response file.

    USAGE:
      def test_expansion(mock_openai):
          # mock_openai.register("kafka consumer lag", "expand_kafka_consumer_lag")
          ...

    Recorded fixture format (tests/fixtures/recorded_openai/expand_kafka_consumer_lag.json):
      {
        "method": "beta.chat.completions.parse",
        "model": "gpt-4.1",
        "parsed_object": {
          "lines": [
            {"type": "lex", "query": "kafka lag debug"},
            {"type": "vec", "query": "how to debug consumer backlog"},
            {"type": "hyde", "query": "Runbook: when consumers fall behind, ..."}
          ]
        },
        "usage": {"prompt_tokens": 150, "completion_tokens": 60}
      }
    """
    mock = AsyncMock()
    registry: dict[str, dict] = {}

    def register(prefix: str, fixture_name: str) -> None:
        registry[prefix] = json.loads((recorded_openai_dir / f"{fixture_name}.json").read_text())

    async def route(*args, **kwargs):
        msgs = kwargs.get("messages", [])
        user_msg = next((m["content"] for m in msgs if m.get("role") == "user"), "")
        for prefix, recorded in registry.items():
            if prefix.lower() in user_msg.lower():
                # Construct a mock response object matching openai SDK shape
                resp = AsyncMock()
                resp.choices = [AsyncMock(message=AsyncMock(parsed=_make_parsed(recorded)))]
                resp.usage = AsyncMock(**recorded.get("usage", {}))
                return resp
        raise ValueError(f"No mock fixture matched user msg prefix: {user_msg[:80]}")

    mock.beta.chat.completions.parse.side_effect = route
    mock.register = register
    yield mock


def _make_parsed(recorded: dict):
    """Convert the JSON 'parsed_object' into a Pydantic instance matching the schema."""
    from kbm.search.expand import ExpansionResult
    from kbm.search.rerank import RerankBatchResult
    obj = recorded["parsed_object"]
    if "lines" in obj:
        return ExpansionResult(**obj)
    if "scores" in obj:
        return RerankBatchResult(**obj)
    raise ValueError("Unknown parsed_object shape")


# ── Mock Bedrock (Titan-Embed) ────────────────────────────────────────────

@pytest.fixture
def mock_bedrock_embed():
    """Returns deterministic pseudo-1024-dim vectors based on input text hash.

    NOT semantic — but deterministic, repeatable, and shape-correct (1024 floats, L2-normalized).
    """
    import hashlib
    import numpy as np

    def fake_embed(text: str) -> list[float]:
        seed = int(hashlib.md5(text.encode()).hexdigest()[:8], 16)
        rng = np.random.default_rng(seed)
        v = rng.standard_normal(1024)
        v = v / np.linalg.norm(v)
        return v.tolist()

    with patch("kbm.build.embedder.bedrock_embed", side_effect=fake_embed):
        with patch("kbm.search.vec.bedrock_embed_async", side_effect=lambda t: asyncio.sleep(0, result=fake_embed(t))):
            yield fake_embed
```

---

## §4. The gold-KB fixture (`tests/fixtures/corpora/lint_clean/`)

The "lint_clean" fixture is a small but realistic KB used by the build-pipeline integration tests, retrieval E2E tests, and UAT script. **7 source documents across 2 collections.**

```
tests/fixtures/corpora/lint_clean/
├── manifest.yaml                              # see §4.1
├── raw/
│   └── engineering/
│       ├── runbooks/
│       │   └── kafka.md                       # ~1800 chars
│       ├── api/
│       │   └── auth.md                        # ~1200 chars
│       ├── adr/
│       │   └── 001-bm25-choice.md             # ~900 chars
│       └── README.md                          # ~400 chars
└── wiki/
    ├── index.md                               # TOC; lists kafka-consumer-lag.md + authentication.md
    ├── log.md                                 # append-only changelog (3 entries)
    ├── kafka-consumer-lag.md                  # curated synthesis of raw/runbooks/kafka.md + raw/adr/001
    └── authentication.md                      # curated synthesis of raw/api/auth.md
```

**Why 7 docs (not more):** large enough to exercise multi-doc retrieval; small enough that gold-truth expected results are hand-curated in `expected_outputs/`.

### §4.1 `manifest.yaml` for the gold KB

```yaml
build_info:
  kbm_version: "0.1.0"
  embedding_model_id: "amazon.titan-embed-text-v2:0"
  embedding_dim: 1024
  rerank_model: "gpt-4.1"
  expand_model: "gpt-4.1"
  chunk_size_tokens: 900
  chunk_overlap_tokens: 135
  chunk_window_tokens: 200

global_context: |
  Test fixture KB — represents a 'planning a trip to Japan'-style knowledge base.
  Wiki has curated synthesis pages; raw has source documents.

collections:
  wiki:
    kind: "wiki"
    path: "./wiki"
    pattern: "**/*.md"
    ignore: ["log.md"]                          # log is append-only changelog; not retrievable
    context:
      "/":      "Curated wiki pages with citations to raw sources."
      "/index": "Table of contents — scan first."
    include_by_default: true

  engineering_raw:
    kind: "raw"
    path: "./raw/engineering"
    pattern: "**/*.md"
    context:
      "/":          "Engineering raw source docs."
      "/runbooks":  "On-call runbooks. Use for incident-response queries."
      "/adr":       "Architecture Decision Records."
    include_by_default: false                   # only queried when wiki returns nothing
```

### §4.2 Expected outputs (`tests/fixtures/corpora/lint_clean/expected_outputs/`)

Committed to git for snapshot-testing:

```
expected_outputs/
├── catalog.parquet                            # 7 rows
├── build_info.json                            # lint_passed=true, lint_errors=[], lint_warnings=[]
├── chunk_counts.json                          # {hash: expected_n_chunks} for each doc
├── expected_top3_for_query.json               # {query_text: [expected_docids]} for the 10 bench queries
└── expected_status_response.json              # the StatusToolOutput for this KB
```

`scripts/regenerate_demo_data.py` rebuilds these from scratch after a chunker/build change is approved via ADR.

---

## §5. The lint-broken fixture (`tests/fixtures/corpora/lint_broken/`)

Mirrors `lint_clean/` but with seeded defects, one per lint code:

| Defect | File | Triggers |
|---|---|---|
| Empty body | `raw/engineering/empty.md` | L6 (zero-length) |
| Encoding error | `raw/engineering/cp1252_bom.md` (Latin-1 bytes) | L7 |
| Path with no context | `raw/orphan/unmatched.md` | L1 |
| Dim mismatch | post-build mutation of `vectors/wiki/embedding_model.txt` | L9 |
| Partial embeddings | post-embed mutation of `vectors/wiki/meta.parquet` (drop a row) | L2 |
| Oversized chunk | a doc with 5000 dense tokens that the chunker fails to halve to ≤ 1100 | L4 |

Used by `test_kbm_lint_catches_*` tests in `10_tdd_acceptance.md §5`.

---

## §6. The bench-golden fixture (`tests/fixtures/corpora/bench_golden/`)

Used by `scripts/nightly_bench.py` (Lambda) AND by the integration test `test_query_returns_expected_top_3`.

### §6.1 Layout

```
bench_golden/
├── nightly_queries.jsonl                      # 10 queries with expected docids — see §6.2
└── (uses the same KB as lint_clean — no separate corpus)
```

### §6.2 `nightly_queries.jsonl` (verbatim)

One JSON object per line. **The full 10 queries:**

```jsonl
{"id":"q01","query":"kafka consumer lag debugging","expected_docids_top3":["abc123","def456"],"category":"exact_keyword","notes":"Should hit wiki/kafka-consumer-lag.md (curated synthesis)"}
{"id":"q02","query":"how do users log in","expected_docids_top3":["ghi789"],"category":"paraphrase","notes":"Vector semantic — wiki/authentication.md should win"}
{"id":"q03","query":"\"connection pool\" timeout","expected_docids_top3":["abc123"],"category":"quoted_phrase","notes":"FTS5 phrase query — runbooks/kafka.md mentions this exactly"}
{"id":"q04","query":"jwt bearer tokens RS256","expected_docids_top3":["ghi789","jkl012"],"category":"exact_keyword","notes":"Strong-signal candidate: api/auth.md likely top with big gap"}
{"id":"q05","query":"why did we choose BM25","expected_docids_top3":["jkl012"],"category":"intent","notes":"adr/001-bm25-choice.md — paraphrased intent"}
{"id":"q06","query":"runbook","expected_docids_top3":["abc123"],"category":"navigation","notes":"Single-word — should resolve via wiki/index.md context"}
{"id":"q07","query":"how to deploy authentication updates","expected_docids_top3":["ghi789"],"category":"cross_collection","notes":"Touches both wiki and raw; wiki should win"}
{"id":"q08","query":"what is the engineering README about","expected_docids_top3":["mno345"],"category":"meta","notes":"raw/engineering/README.md"}
{"id":"q09","query":"explain Goodhart law for OKRs","expected_docids_top3":[],"category":"no_match","notes":"Out-of-corpus — expect empty or low-confidence results"}
{"id":"q10","query":"intent: incident response\nlex: kafka lag pod restart\nvec: consumer group rebalance debug","expected_docids_top3":["abc123"],"category":"structured","notes":"Pre-expanded structured query path"}
```

The `expected_docids_top3` field allows for partial-credit scoring:
- 1.0: expected docid is at position 1
- 0.7: at position 2 or 3
- 0.0: not in top-3

Total possible score = 10.0. Nightly bench fails if score drops below 7.0 (alarm threshold per `12_performance_slo.md §3`).

---

## §7. Recorded OpenAI fixtures (`tests/fixtures/recorded_openai/`)

Each fixture is one JSON file. Naming: `<call_site>_<query_slug>.json`.

### §7.1 Expansion fixture shape

```json
{
  "call_site": "expand",
  "model": "gpt-4.1",
  "input_user_message_prefix": "kafka consumer lag",
  "parsed_object": {
    "lines": [
      {"type": "lex", "query": "kafka lag debug consumer"},
      {"type": "lex", "query": "consumer group offset behind"},
      {"type": "lex", "query": "kafka offsets backlog"},
      {"type": "vec", "query": "how to identify and resolve consumer group backlog in kafka"},
      {"type": "vec", "query": "diagnosing slow message processing in event streams"},
      {"type": "vec", "query": "consumer group rebalance triggered by pod restart"},
      {"type": "hyde", "query": "When Kafka consumers fall behind, check the lag metric in Datadog; threshold is 1000 messages; scale the group up if exceeded."}
    ]
  },
  "usage": {"prompt_tokens": 312, "completion_tokens": 178}
}
```

### §7.2 Rerank fixture shape

```json
{
  "call_site": "rerank",
  "model": "gpt-4.1",
  "input_user_message_prefix": "Query: kafka consumer lag",
  "parsed_object": {
    "scores": [9, 7, 8, 3, 6, 2, 5, 4, 1, 7, 6, 5, 4, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  },
  "usage": {"prompt_tokens": 12000, "completion_tokens": 80}
}
```

Note: rerank always returns exactly 40 scores even when fewer candidates are passed; the fixture aligns to test boundary behavior.

### §7.3 Generating fixtures (`make record-fixture`)

```python
# scripts/record_openai_fixture.py — invoked by `make record-fixture FIXTURE=expand_kafka_consumer_lag QUERY="kafka consumer lag"`
# Makes ONE real gpt-4.1 call, records the response, writes the JSON file.
# Run nightly + manually after prompt updates.
```

**Hard rule:** never commit a fixture generated by an LLM without checking it against `../doc_search_tool/24_audit_and_corrections.md §1` for shape correctness.

---

## §8. Recorded Bedrock fixtures (`tests/fixtures/recorded_bedrock/`)

Only one fixture needed since the mock_bedrock_embed fixture generates deterministic pseudo-vectors. Recorded fixture exists for "live shape verification" in nightly tests:

```json
{
  "call": "InvokeModel",
  "modelId": "amazon.titan-embed-text-v2:0",
  "request_body": {"inputText": "title: Kafka Consumer Lag Runbook | text: When consumers fall behind...", "dimensions": 1024, "normalize": true},
  "response_body": {"embedding": [0.0123, -0.0456, ...], "inputTextTokenCount": 142}
}
```

---

## §9. `docker-compose.yml` for integration tests

```yaml
# tests/integration/docker-compose.yml
version: "3.9"
services:
  localstack:
    image: localstack/localstack:3.8
    environment:
      - SERVICES=s3,secretsmanager,bedrock
      - DEBUG=0
      - PERSISTENCE=0
    ports:
      - "4566:4566"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    command: redis-server --maxmemory 100mb --maxmemory-policy allkeys-lru
```

`make test-integration` does:
```sh
docker compose -f tests/integration/docker-compose.yml up -d
sleep 10                                   # localstack init
pytest -m integration tests/integration
docker compose -f tests/integration/docker-compose.yml down
```

---

## §10. Hypothesis configuration

```python
# tests/conftest.py or pyproject.toml
from hypothesis import settings, Verbosity

settings.register_profile("ci",   max_examples=50,  deadline=2000)
settings.register_profile("dev",  max_examples=20,  deadline=1000)
settings.register_profile("nightly", max_examples=500, deadline=5000)

# CI defaults to "ci"; nightly EventBridge overrides via env var HYPOTHESIS_PROFILE=nightly.
```

---

## §11. Test data factories (`tests/factories.py`)

Used by unit tests to construct realistic Pydantic models without hand-coding every field.

```python
"""tests/factories.py — Factory-Boy-style factories for test data."""
from datetime import datetime
import hashlib
from kbm.types import Document, Chunk, SearchResult, RankedResult, ExpandedQuery


def make_document(
    body: str = "# Title\nbody content",
    collection: str = "wiki",
    path: str = "test.md",
    title: str | None = None,
) -> Document:
    hash_hex = hashlib.sha256(body.encode("utf-8")).hexdigest()
    return Document(
        docid=hash_hex[:6],
        hash=hash_hex,
        collection=collection,
        path=path,
        title=title or body.splitlines()[0].lstrip("#").strip() or "Untitled",
        body=body,
        modified_at=int(datetime(2026, 5, 20).timestamp()),
    )


def make_chunk(text: str = "chunk content", pos: int = 0, n_tokens: int = 25) -> Chunk:
    return Chunk(text=text, pos=pos, end_pos=pos + len(text), n_tokens=n_tokens)


def make_search_result(
    file: str = "qmd://wiki/test.md", score: float = 0.8, title: str = "Test",
) -> SearchResult:
    return SearchResult(docid=file.split("/")[-1][:6], file=file, title=title, score=score)


def make_ranked_result(
    file: str = "qmd://wiki/test.md", rrf_score: float = 0.1, top_rank: int = 0,
) -> RankedResult:
    return RankedResult(
        docid=file.split("/")[-1][:6], file=file, title="T", rrf_score=rrf_score, top_rank=top_rank,
    )


def make_expanded_query(type_: str = "lex", query: str = "test") -> ExpandedQuery:
    return ExpandedQuery(type=type_, query=query)
```

---

## §12. Cross-references

| Fixture | Used by tests in |
|---|---|
| `gold_kb_dir` + `s3_bucket` + `gold_kb_in_s3` | `10_*.md §5` (build pipeline), §6.5 (retrieval E2E), §7 (MCP) |
| `mock_openai` + `mock_bedrock_embed` | `10_*.md §6.1-§6.5` (retrieval), §7 (MCP) |
| `redis_client` | `10_*.md §6.4` (cache) |
| `recorded_openai/` fixtures | live-shape verification (§7 generation) |
| `factories.py` | every unit test that constructs models |

---

## §13. Definition of Done — fixtures shipment

Phase 1 PR includes:
- [ ] `tests/conftest.py` (§2) committed
- [ ] `tests/integration/conftest.py` (§3) committed
- [ ] `tests/factories.py` (§11) committed
- [ ] `tests/integration/docker-compose.yml` (§9) committed
- [ ] `tests/fixtures/corpora/lint_clean/` populated with 7 source docs + `manifest.yaml`
- [ ] `tests/fixtures/golden_chunks/sample_doc.md` + `expected_chunks_for_sample.json` committed
- [ ] `tests/fixtures/corpora/bench_golden/nightly_queries.jsonl` (§6.2) committed
- [ ] `tests/fixtures/recorded_openai/*.json` for at least the 10 nightly queries committed
- [ ] `scripts/regenerate_demo_data.py` works against a freshly-cloned repo

Phase 1.5 PR (after chunker is green) adds:
- [ ] `tests/fixtures/corpora/lint_broken/` (§5) — used by L1-L9 negative tests
- [ ] `tests/fixtures/corpora/lint_clean/expected_outputs/*` — committed snapshot of a known-good build

Once these fixtures exist, every other test specified in `10_*.md` is unblocked.
