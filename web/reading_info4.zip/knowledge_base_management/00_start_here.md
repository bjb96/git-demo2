# 00 — Start Here (Junior Coding Agent Playbook — `knowledge_base_management`)

> **You are about to build a Python sub-package that delivers TWO halves of one product**: (1) a **local build pipeline** that turns a folder of source files into S3-uploadable knowledge-base artifacts, and (2) a **server-side tool package** that the main `target_product_bundle` chatbot agent calls via MCP to do parallel hybrid search over that knowledge base on AWS ECS.
>
> **This bundle is the contract**. Every architectural decision is committed to one of the files below. Your job is **not to design**. Your job is **to read what's already decided, translate it to code via TDD, and prove it passes the acceptance gates**.
>
> **Time to read this file: 25-30 minutes.** Read it fully before opening any other file. The bundle has CI scripts that will reject your PR if you drift.

---

## §1. The contract this file establishes

By reading this file, you accept:

| Rule | Why |
|---|---|
| **Every code change starts with a failing test** | TDD — see [10_tdd_acceptance.md](10_tdd_acceptance.md). CI rejects PRs without an accompanying test edit. |
| **Every PR scope is one phase from §4** | Cross-phase PRs are unreviewable. |
| **Algorithm constants are NEVER re-tuned without an ADR** | The chunker (`05_chunker_spec.md`) and retrieval pipeline (`06_retrieval_pipeline_spec.md`) are verbatim ports of doc_search's measured-good constants. Tuning them without measuring against the bench fixture (UAT case 7) is a delivery-blocker. |
| **You write Python — never JavaScript/TypeScript** | doc_search is in TypeScript. This bundle ports it to Python. Do not import `node-llama-cpp`. Do not run `npm`. Do not install `qmd`. |
| **When you're unsure, you STOP and ask** | See §9. Cost of asking: ~5 min. Cost of inventing: hours of rework + drift. |

---

## §2. What you are building (one paragraph)

A Python package `knowledge_base_management` (`kbm` for short) with two halves under one repo:

**Half A — `kbm.build` (local CLI, runs on developer's laptop):**
takes a folder tree of `.md` / `.txt` source files organized into collections (one of which is a curated `wiki/` collection per the existing [CLAUDE.md](claude.md), plus one or more `raw/` collections), walks it, hashes content for deduplication, chunks via doc_search's smart chunker (900 tokens / 15% overlap / 12-tier break-point scoring / code-fence-aware / AST-aware for code), embeds each chunk via AWS Bedrock Titan-Embed-Text-v2, builds **one SQLite FTS5 file per collection** (BM25) and **one FAISS index per collection** (cosine), runs 9 lint checks, and outputs a deterministic S3-uploadable folder. The product owner runs `kbm upload` once they're satisfied with lint output.

**Half B — `kbm.search` + `kbm.mcp` (server, runs on AWS ECS):**
boots, pulls KB artifacts from S3 to local disk cache, exposes 5 MCP tools (`query`, `get`, `multi_get`, `status`, `ls`) plus REST shortcut routes via FastAPI. The hybrid retrieval pipeline ports doc_search's signature quartet verbatim: optional LLM query expansion via gpt-4.1 → parallel BM25 + cosine retrieval across collections via `asyncio.gather` → Reciprocal Rank Fusion (k=60, original-query weight 2.0, top-rank bonus +0.05/+0.02) → top-40 candidates → gpt-4.1 cross-encoder rerank (one batch call, all 40 docs in one prompt) → position-aware blend (75/60/40 by RRF rank) → snippet extract → context attach. Strong-signal bypass at score≥0.85 + gap≥0.15 skips expansion entirely on obvious hits.

**The main `target_product_bundle` chatbot agent then consumes these tools via tool-calling.** Wiring is specified in [08_main_app_integration.md](08_main_app_integration.md).

---

## §3. Bundle inventory (one-screen mental map)

| # | File | Role | Read priority |
|---|---|---|---|
| **Existing (do NOT modify)** | | | |
| — | [`claude.md`](claude.md) | Runtime instructions for the Claude agent that maintains the wiki — describes the Karpathy wiki workflow (ingest, page format, citation rules, lint, question-answering) | Read once for context |
| — | [`SKILL.md`](SKILL.md) | The agent skill describing how to USE the deployed `qmd`-equivalent tools from a chatbot session | Read once for context |
| **This contractual bundle** | | | |
| 00 | `00_start_here.md` (this file) | Playbook — read first | **Required** |
| 01 | [`01_overall_process_map.html`](01_overall_process_map.html) | Build-half + serve-half at a glance | Required (orientation) |
| 02 | [`02_repo_scaffold.md`](02_repo_scaffold.md) | Directory tree + every verbatim infra file (Dockerfile, Makefile, CI/CD, pyproject.toml) | **Required — Phase 0** |
| 03 | [`03_data_contracts.md`](03_data_contracts.md) | Every Pydantic model, S3 layout schema, FAISS `meta.parquet` columns, `catalog.parquet` columns, `manifest.yaml` shape, `build_info.json` shape | **Required — Phase 1** |
| 04 | [`04_mcp_tool_contract.md`](04_mcp_tool_contract.md) | 5 MCP tools (query, get, multi_get, status, ls) with full input/output Pydantic schemas, status codes, error envelopes, and the 5 CLI commands | **Required — Phase 3** |
| 05 | [`05_chunker_spec.md`](05_chunker_spec.md) | ⭐⭐ Verbatim port spec of doc_search's smart chunker | **Required — Phase 1** |
| 06 | [`06_retrieval_pipeline_spec.md`](06_retrieval_pipeline_spec.md) | ⭐⭐ Verbatim port of the retrieval quartet (RRF + top-rank bonus + position blend + strong-signal bypass) | **Required — Phase 4** |
| 07 | [`07_build_pipeline_spec.md`](07_build_pipeline_spec.md) | The `kbm build / embed / lint / plan-upload / upload` CLI commands — what each one walks, hashes, writes | **Required — Phase 2** |
| 08 | [`08_main_app_integration.md`](08_main_app_integration.md) | How `kbm` tools are exposed to the main `target_product_bundle` agent: which file in `src/mp_tools/`, which skill file under `src/skills/`, which prompt addition under `src/prompts/library.py` | **Required — Phase 6** |
| 09 | [`09_python_demo.py`](09_python_demo.py) | Runnable single-file reference (adapted from doc_search_tool's demo); passes a 15-check self-test | Reference (skim during Phase 1, run during Phase 4) |
| 10 | [`10_tdd_acceptance.md`](10_tdd_acceptance.md) | Given/When/Then per artifact + mutation policy + coverage gate | **Required — Phase 1 onwards** |
| 11 | [`11_test_fixtures.md`](11_test_fixtures.md) | conftest, factories, LocalStack S3, mock Bedrock + mock OpenAI, golden fixtures for the bench harness | **Required — Phase 1 onwards** |
| 12 | [`12_performance_slo.md`](12_performance_slo.md) | Latency / cost / cache-hit-rate targets + alarm thresholds | Required — Phase 5 |
| 13 | [`13_risk_register.md`](13_risk_register.md) | 12 KB-specific risks + Day-1 mitigations | Required — Phase 2 |
| 14 | [`14_adr_catalog.md`](14_adr_catalog.md) | 12 locked decisions + rationale (FAISS over sqlite-vec, gpt-4.1 over local rerank, etc.) | Required — Phase 0 (Phase-0 disagreement resolution) |
| 15 | [`15_ops_runbook.md`](15_ops_runbook.md) | Rebuild, re-upload, cache invalidate, rollback procedures | Required — Phase 7 |
| 16 | [`16_user_uat_script.md`](16_user_uat_script.md) | Product-owner-runs acceptance test; **the contractual "delivered" signal** | Required — final delivery |
| **External references** | | | |
| ↗ | [`../../doc_search_tool/24_audit_and_corrections.md`](../../doc_search_tool/24_audit_and_corrections.md) | The 44 verified source claims from doc_search audit; **THE ground truth** when this bundle and doc_search disagree | Required — every time you implement an algorithm |
| ↗ | [`../../doc_search_tool/00_manual.md`](../../doc_search_tool/00_manual.md) | doc_search 12-zone architecture handbook | Reference (consult when you need to understand WHY) |
| ↗ | [`../../doc_search_tool/20_llm_payload_evidence.md`](../../doc_search_tool/20_llm_payload_evidence.md) | Verbatim prompts, GBNF grammar, GEPA best_prompt to port | Required — Phase 4 (when you wire gpt-4.1 expansion + rerank) |

---

## §4. Build phase sequence — the actual work

You ship in **8 phases** (Phase 0 through Phase 7), each a focused 1-3 day chunk. Phases are sequential because each builds on the previous's invariants.

### Phase 0 — Setup the sub-repo (~1 day) — tag `kbm-v0.0.1-infra`

**Goal**: `git init` (if this is a fresh sub-repo) + paste all infra files; `make bootstrap` succeeds; `make ci` runs cleanly on an empty `src/kbm/`.

| Field | Contents |
|---|---|
| **Read first** | `02_repo_scaffold.md` (cover to cover) + `00_start_here.md` (this file) §8 hard constraints + `14_adr_catalog.md` (skim — open this when you disagree with anything in `02_*.md §1`) |
| **Files you create** | `.gitignore`, `pyproject.toml`, `requirements.in`, `requirements.txt`, `requirements-dev.in`, `requirements-dev.txt`, `Dockerfile`, `Makefile`, `.pre-commit-config.yaml`, `.github/workflows/ci.yml`, `.github/workflows/cd.yml`, `.github/pull_request_template.md`, `pytest.ini`, root `conftest.py`, `src/kbm/__init__.py`, `tests/__init__.py`, `README.md` — all from `02_*.md §3-§16` verbatim |
| **Verify with** | `make bootstrap && make ci` (must pass on empty `src/kbm/`) |
| **DoD** | (1) `make ci` passes locally on empty `src/`; (2) `pre-commit run --all-files` clean; (3) CI green on PR |

### Phase 1 — Foundation: data contracts + chunker (~2-3 days) — tag `kbm-v0.0.2-foundation`

**Goal**: Every Pydantic model imports cleanly; smart chunker passes its 8 chunker tests; Gate11Validator-equivalent (`Lint9Validator`) compiles.

| Field | Contents |
|---|---|
| **Read first** | `03_data_contracts.md` cover-to-cover + `05_chunker_spec.md` cover-to-cover + `10_tdd_acceptance.md §3` (chunker tests) + `11_test_fixtures.md §2` (conftest) |
| **Files you create** | `src/kbm/types.py` (all Pydantic models from `03_*.md`), `src/kbm/constants.py` (chunker constants from `05_*.md §1`), `src/kbm/build/chunker.py`, `src/kbm/build/ast_chunker.py`, `src/kbm/build/manifest.py`, `src/kbm/shared/docid.py`, `src/kbm/shared/paths.py`, `src/kbm/build/lint.py` (`Lint9Validator`), plus matching `tests/unit/test_chunker.py`, `tests/unit/test_manifest.py`, `tests/unit/test_lint.py` |
| **Reference continuously** | `03_*.md`, `05_*.md`, `../../doc_search_tool/24_audit_and_corrections.md §1` rows 1-10 (the verified chunker constants) |
| **Test against** | `10_*.md §3` (per-chunker Given/When/Then) |
| **Verify with** | `make ci` + `scripts/check_chunker_constants.py` (asserts the 12 BREAK_PATTERNS + 6 chunk constants are byte-equal to doc_search) + `scripts/check_8_pydantic_schemas.py` |
| **DoD** | (1) all 8 chunker tests pass against the golden chunk fixtures in `tests/fixtures/golden_chunks/`; (2) `Lint9Validator().run_all()` returns expected results on the 3 lint-fixture cases; (3) coverage ≥ 90% on `chunker.py` |

### Phase 2 — Build half: walker + embed + index (~3-4 days) — tag `kbm-v0.0.3-build`

**Goal**: `kbm build && kbm embed && kbm lint` on a 100-doc test fixture produces a complete S3-uploadable folder; lint exits 0 on the clean fixture and exits 1 on the broken fixture.

| Field | Contents |
|---|---|
| **Read first** | `07_build_pipeline_spec.md` cover-to-cover + `13_risk_register.md` (skim — note R-KB-3, R-KB-7) |
| **Files you create** | `src/kbm/build/walker.py`, `src/kbm/build/embedder.py` (Bedrock client), `src/kbm/build/fts5_builder.py`, `src/kbm/build/faiss_builder.py`, `src/kbm/build/uploader.py` (S3 sync), `src/kbm/build/cli.py` (the `kbm` Click CLI), plus `tests/integration/test_build_pipeline.py` + golden-file expected outputs |
| **Reference continuously** | `07_*.md`, `06_data_contracts.md §3-§5` (S3 layout), `../../doc_search_tool/21_q1_kb_build_pipeline.md` (Q1 reference) |
| **Test against** | `10_*.md §4` (build-pipeline tests) |
| **Verify with** | `make ci` + integration test `test_build_pipeline_end_to_end` (runs against LocalStack S3) |
| **DoD** | (1) given the 100-doc test corpus + `manifest.yaml`, `kbm build && kbm embed && kbm lint` produces the canonical S3 folder shape; (2) re-running with no source changes is a no-op (idempotent); (3) `kbm plan-upload --to s3://localstack-bucket/` shows the expected diff |

### Phase 3 — Server tools: MCP layer (~2-3 days) — tag `kbm-v0.0.4-mcp`

**Goal**: 5 MCP tools registered on FastAPI; `/health` + `/ready` respond; `POST /mcp` accepts JSON-RPC. Search still returns stubbed results — Phase 4 wires the real pipeline.

| Field | Contents |
|---|---|
| **Read first** | `04_mcp_tool_contract.md` cover-to-cover |
| **Files you create** | `src/kbm/mcp/server.py` (FastAPI app), `src/kbm/mcp/tools.py` (4 MCP tool descriptors + verbatim descriptions from doc_search `mcp/server.ts:241-535`), `src/kbm/mcp/auth.py` (bearer-token middleware), `src/kbm/mcp/health.py`, `src/kbm/mcp/instructions.py` (port of `mcp/server.ts:108-165` `buildInstructions`), plus `tests/integration/test_mcp_endpoints.py` |
| **Reference continuously** | `04_*.md`, `../../doc_search_tool/22_q2_search_tools_pipeline.md §8` (MCP tool descriptions) |
| **Test against** | `10_*.md §5` (per-route integration tests) |
| **Verify with** | `make test-integration` + `scripts/check_mcp_tool_descriptions_unchanged.py` (byte-equal with doc_search) |
| **DoD** | (1) `GET /health` returns `{"status":"ok","uptime":<sec>}`; (2) `GET /ready` returns 200 only if S3 + Redis + Bedrock probes succeed; (3) all 4 MCP tools accept the documented input shape and reject malformed input with the documented error envelope |

### Phase 4 — Search half: hybrid retrieval pipeline (~3-4 days) — tag `kbm-v0.0.5-search`

**Goal**: All 10 retrieval-pipeline steps from `06_retrieval_pipeline_spec.md` are implemented; cross-collection query passes end-to-end against the LocalStack fixture KB.

| Field | Contents |
|---|---|
| **Read first** | `06_retrieval_pipeline_spec.md` cover-to-cover + `../../doc_search_tool/20_llm_payload_evidence.md` (verbatim prompts + GBNF replacement schema) + `../../doc_search_tool/24_audit_and_corrections.md §1` rows 5-11, 17-25 |
| **Files you create** | `src/kbm/search/store.py` (KBStore — holds FTS5 + FAISS handles per collection), `src/kbm/search/s3.py` (S3 reader with local-disk cache + ETag refresh), `src/kbm/search/fts.py`, `src/kbm/search/vec.py`, `src/kbm/search/rrf.py`, `src/kbm/search/blend.py`, `src/kbm/search/expand.py` (gpt-4.1 + Pydantic structured output), `src/kbm/search/rerank.py` (gpt-4.1 batch call), `src/kbm/search/snippet.py`, `src/kbm/search/query.py` (the orchestrator), `src/kbm/search/cache.py` (Redis), `src/kbm/search/get.py`, `src/kbm/search/multi_get.py`, `src/kbm/search/status.py`, `src/kbm/search/ls.py`. Plus matching unit tests + 1 integration test that exercises the full query path. |
| **Reference continuously** | `06_*.md`, `04_mcp_tool_contract.md`, `09_python_demo.py` (run `python 09_python_demo.py --selftest` to confirm understanding before coding each piece) |
| **Test against** | `10_*.md §6` (retrieval pipeline tests) — note the 6 "verbatim port" assertions: RRF k=60, original-weight 2.0, top-rank bonus +0.05/+0.02, position-blend 75/60/40, strong-signal 0.85+0.15, candidate-limit 40 |
| **Verify with** | `make ci` + `scripts/check_retrieval_constants.py` (asserts the 6 verbatim-port constants are byte-equal) + `make mutate` ≥ 90% survival on `rrf.py` + `blend.py` |
| **DoD** | (1) given the LocalStack fixture KB (2 collections, 50 docs total), `POST /mcp tools/call query` returns valid `QueryToolOutput` with non-empty results; (2) the 10 nightly-bench golden queries return their `expected_in_top_3` doc IDs; (3) `--explain` traces match the RRF math doc_search produces on the same input |

### Phase 5 — Observability + IaC (~1-2 days) — tag `kbm-v0.0.6-obs`

**Goal**: 8 CloudWatch metrics emit; CDK synthesizes the ECS stack; nightly bench Lambda is scheduled.

| Field | Contents |
|---|---|
| **Read first** | `12_performance_slo.md` cover-to-cover + `15_ops_runbook.md §3` (CloudWatch dashboard spec) |
| **Files you create** | `src/kbm/obs/metrics.py` (the 8 counters from `12_*.md §2`), `src/kbm/obs/breakers.py` (circuit breakers around Bedrock + OpenAI), `cdk/app.py`, `cdk/stack.py`, `scripts/nightly_bench.py` (EventBridge-triggered Lambda) |
| **Verify with** | `cdk synth` succeeds; metric integration test emits to LocalStack CloudWatch |
| **DoD** | (1) `cdk synth` outputs the expected resource list; (2) breaker unit tests pass; (3) metrics emit on first integration test run |

### Phase 6 — Main-app integration (~1-2 days) — tag `kbm-v0.0.7-integration`

**Goal**: `target_product_bundle`'s main agent can call `kbm` tools through its existing tool-calling layer. The 3 integration tests pass.

| Field | Contents |
|---|---|
| **Read first** | `08_main_app_integration.md` cover-to-cover |
| **Files you create** | NEW: `target_product_bundle/src/mp_tools/kbm.py` (thin wrapper exposing `query`, `get`, `multi_get`, `status`, `ls` to the orchestrator), NEW skill at `target_product_bundle/src/skills/kbm-search/SKILL.md`, addition to `target_product_bundle/src/prompts/library.py` (one new `KBM_TOOL_DESCRIPTION` constant). Plus integration tests `target_product_bundle/tests/integration/test_kbm_integration.py` |
| **Test against** | `08_*.md §4` (integration tests) |
| **Verify with** | `make ci` in BOTH `kbm/` AND `target_product_bundle/` (because this phase touches both) |
| **DoD** | (1) main agent can invoke `kbm.query()` via tool-calling and receive valid results; (2) skill file passes the existing `scripts/check_skills.py` drift-check in the main bundle; (3) main bundle's existing tests still pass |

### Phase 7 — UAT + deploy (~1 day) — tag `kbm-v0.1.0`

**Goal**: Product owner runs the 8-case UAT script ([16_user_uat_script.md](16_user_uat_script.md)) against deployed `dev` env. All cases pass. Deploy to `prod`.

| Field | Contents |
|---|---|
| **Read first** | `16_user_uat_script.md` + `15_ops_runbook.md §4` (deploy procedure) |
| **Actions** | (1) push image to ECR; (2) run `make cdk-deploy ENV=dev`; (3) seed `s3://kb-dev` with the canonical UAT corpus; (4) hand product owner the UAT script; (5) collect sign-off |
| **DoD** | (1) all 8 UAT cases pass; (2) sign-off block in `16_*.md §9` signed; (3) `make cdk-deploy ENV=prod` succeeds; (4) `/health` returns 200 from prod ALB |

---

## §5. The TDD inner loop every PR follows

```
1. RED       : Write a failing test that encodes the acceptance criterion (10_*.md).
2. GREEN     : Write the minimum code that passes.
3. REFACTOR  : Clean up, keeping tests green.
4. SCOPE     : Confirm only files in the PR's stated phase changed.
5. COMPLETE  : Confirm no TODO / stub / mock-in-prod left behind.
6. REVIEW    : Code review.
7. REFINE    : Apply review fixes, re-running 4-5.
8. TEST      : `make ci`.
9. DEBUG     : If anything fails, root-cause the code (NEVER weaken the test).
10. RECONCILE: Verify every original acceptance criterion is MET (not PARTIAL).
```

**Hard rule**: a junior agent who edits code without writing a failing test FIRST has broken the rule. The PR template has a checkbox; reviewer rejects PRs without it.

---

## §6. Cross-file consistency rules (the drift hazards)

These 6 cross-file invariants are CI-enforced. Violations block your PR.

| # | Invariant | Files involved | CI script |
|---|---|---|---|
| 1 | The 6 chunker constants (`CHUNK_SIZE_TOKENS=900`, `CHUNK_OVERLAP_TOKENS=135`, `CHUNK_WINDOW_TOKENS=200`, plus char-conversions) are identical across `05_chunker_spec.md`, `src/kbm/constants.py`, `09_python_demo.py` SECTION A | `05`, `src/`, `09` | `scripts/check_chunker_constants.py` |
| 2 | The 12 BREAK_PATTERNS entries (regex + score + tag) are identical across `05_chunker_spec.md §2`, `src/kbm/build/chunker.py`, `09_python_demo.py` | `05`, `src/`, `09` | `scripts/check_break_patterns.py` |
| 3 | The 6 retrieval constants (RRF k=60, original 2.0x, top-rank +0.05/+0.02, position-blend 75/60/40, strong-signal 0.85+0.15, candidate-limit 40) are identical across `06_retrieval_pipeline_spec.md`, `src/kbm/search/*.py`, `09_python_demo.py` | `06`, `src/`, `09` | `scripts/check_retrieval_constants.py` |
| 4 | Every MCP tool description in `src/kbm/mcp/tools.py` is byte-equal to the doc_search source it ports (`mcp/server.ts:241-535`) | `04`, `src/`, `../../doc_search_tool/22_q2_search_tools_pipeline.md §8` | `scripts/check_mcp_tool_descriptions_unchanged.py` |
| 5 | Every Pydantic model declared in `src/kbm/types.py` matches the schema in `03_data_contracts.md` (field names, types, defaults, validation rules) — auto-generated JSON-schema must match | `03`, `src/kbm/types.py`, `docs/schemas/*.json` | `scripts/check_schemas_unchanged.py` |
| 6 | The S3 layout (every path in `s3://kb-{env}/...`) is identical across `03_data_contracts.md §3`, `src/kbm/build/uploader.py`, `src/kbm/search/s3.py` | `03`, `src/` | `scripts/check_s3_layout.py` |

When in doubt, run `scripts/check_*.py` manually before opening a PR.

---

## §7. Hard constraints (NEVER violate)

These come from the main `target_product_bundle/CLAUDE.md`, [14_adr_catalog.md](14_adr_catalog.md), and the audit findings:

| # | Rule | Why |
|---|---|---|
| 1 | **NEVER modify anything in `raw/` folders** | Source documents are immutable (per [claude.md](claude.md) line 91). Build pipeline reads, never writes. |
| 2 | **NEVER hard-code secrets** (OpenAI API key, AWS creds, Bedrock model IDs) | Use `pydantic-settings` reading from env / Secrets Manager / SSM Parameter Store. |
| 3 | **NEVER bypass the verbatim-port assertions** for chunker + retrieval constants | They are measured-good. Use [14_adr_catalog.md](14_adr_catalog.md) ADR-process if you need to change them. |
| 4 | **NEVER run `kbm build` or `kbm embed` on the main app's source files automatically** | These are user-initiated operations only. The main agent must NOT call them. |
| 5 | **NEVER write to S3 from the server-side `kbm.search` half** | The server is read-only. Writes happen during local `kbm upload` only. |
| 6 | **NEVER install `node-llama-cpp`, `qmd`, `bun`, or run `npm install`** | doc_search is the reference; this is the Python port. If you find yourself reaching for the npm package, you are off-track — open an issue. |
| 7 | **NEVER use Python `print()` in production code** | Use `structlog` (configured in `src/kbm/logger.py`). `print()` corrupts MCP stdio JSON-RPC framing. |
| 8 | **NEVER concatenate user input into SQL** | Use SQLite `?`-parameterized queries always. The FTS5 query builder in `src/kbm/search/fts.py` has its own sanitizer per `06_*.md §5`. |
| 9 | **NEVER let the `wiki/` collection rebuild trigger a destructive overwrite of `raw/` chunks** | They are different collections with different S3 prefixes. `kbm embed` per collection is the only path that touches vectors. |
| 10 | **NEVER skip the lint pass before `kbm upload`** | `kbm upload` refuses to run if `build_info.json` has `lint_passed: false`. Adding a `--force` flag is forbidden by ADR-007. |

---

## §8. The "stop and ask" rules

When you encounter any of these, **stop coding and open an issue with the question**:

| Situation | Why ask | Where to put the question |
|---|---|---|
| The contract is ambiguous (one paragraph in `03_*.md` contradicts another) | The bundle is internally inconsistent; ANYTHING you choose is wrong | GitHub issue tagged `contract-clarification` |
| You'd need to invent a constant not specified in `03_*.md` / `05_*.md` / `06_*.md` | Constants are measured-good. Inventing risks drift. | Issue tagged `decision-needed` |
| A test in `10_*.md` seems wrong (Given/When/Then doesn't match the spec) | Either spec or test is wrong; figure out which before changing code | Issue tagged `test-spec-mismatch` |
| You need a new dependency not in `02_*.md §3` (`pyproject.toml`) | Bundle locks the dep list. Adding requires an ADR. | Issue tagged `new-dep-proposal` |
| The doc_search source (referenced in `../../doc_search_tool/`) disagrees with this bundle | Some claim drifted. Look in `../../doc_search_tool/24_audit_and_corrections.md §1` first. | Issue tagged `doc-search-drift` |
| You're implementing an algorithm and the bundle's pseudocode doesn't match `../../doc_search_tool/24_audit_and_corrections.md §1`'s verified row | Verified row wins. File a PR fixing the bundle BEFORE the code. | Issue tagged `algo-drift` |
| The wiki workflow (in [claude.md](claude.md)) conflicts with the build pipeline behavior | The wiki is curated by Claude at runtime; the build pipeline is run by the developer. They use the same files but write at different times. | Issue tagged `wiki-vs-build-conflict` |

**Cost of asking: ~5-10 minutes (open issue + wait for clarification + resume).**
**Cost of guessing wrong: hours of rework + drifted code + PR rejected.**

---

## §9. The Definition of Done (DoD) checklist — print for every PR

Tick every box before requesting review:

- [ ] **TDD inner loop completed**: failing test pushed in commit BEFORE implementation commit
- [ ] **Only files in the stated phase changed** (per §4 above)
- [ ] **No `TODO` / `FIXME` / `XXX` / stub / mock left in production code**
- [ ] **Every public function has a docstring** with Given/When/Then format for tests, single-purpose for prod code
- [ ] **Coverage on changed lines ≥ 90%** (per `10_*.md §1`)
- [ ] **Mutation testing**: if you touched a security-critical or signature-algorithm file (chunker, retrieval, RRF, blend, ast_allowlist), `make mutate` survival ≥ 90%
- [ ] **`make ci` passes locally**
- [ ] **All cross-file consistency scripts pass** (per §6)
- [ ] **Pre-commit hooks clean** (`pre-commit run --all-files`)
- [ ] **Phase tag created** (`git tag kbm-v0.x.y-<phase>` after merge)
- [ ] **PR description references the phase** (`Phase 2 — Build half: walker + embed`)
- [ ] **If a constant changed**: ADR added in `14_*.md` AND `scripts/check_*_constants.py` updated AND the bundle file (`05_*.md` etc.) updated in the same PR

---

## §10. Two-half architecture at a glance

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                  HALF A — Local build (developer's laptop)                  │
│                                                                              │
│   raw/             wiki/          (collections defined in manifest.yaml)    │
│     │                │                                                       │
│     ▼                ▼                                                       │
│  ┌──────────────────────────┐                                                │
│  │ kbm build                │  walk + hash + content-addressable write       │
│  │ kbm embed                │  smart-chunk + Bedrock-embed + dual-index      │
│  │ kbm lint                 │  9 lint checks → build_info.json               │
│  │ kbm plan-upload          │  diff vs current S3                            │
│  │ kbm upload               │  aws s3 sync with ETag verification            │
│  └──────────────────────────┘                                                │
│                │                                                              │
│                ▼                                                              │
│   s3://kb-{env}/                                                             │
│      manifest.yaml                                                            │
│      catalog.parquet                                                          │
│      content/{hash[:2]}/{hash}.md                                             │
│      fts/{collection}.sqlite                                                  │
│      vectors/{collection}/index.faiss + meta.parquet + embedding_model.txt   │
│      contexts.json                                                            │
│      build_info.json                                                          │
└─────────────────────────────────────────────────────────────────────────────┘

                              ↓ (developer copies to S3)

┌─────────────────────────────────────────────────────────────────────────────┐
│             HALF B — Server tools (AWS ECS, called by chatbot agent)        │
│                                                                              │
│  Chatbot agent (target_product_bundle) ─── tool-call ───┐                   │
│                                                          ▼                   │
│  POST /mcp tools/call name=query/get/multi_get/status/ls                    │
│                            │                                                 │
│                            ▼                                                 │
│  ┌──────────────────────────────────────────────────────────────────┐       │
│  │ kbm.mcp.server (FastAPI on ECS)                                  │       │
│  │   ├── query → kbm.search.query (hybrid pipeline)                 │       │
│  │   │            ├── strong-signal bypass check                    │       │
│  │   │            ├── gpt-4.1 expansion (cache via Redis)           │       │
│  │   │            ├── asyncio.gather over collections × variants    │       │
│  │   │            │     ├── BM25 (per-collection SQLite FTS5)       │       │
│  │   │            │     └── FAISS cosine (per-collection)           │       │
│  │   │            ├── RRF fusion (k=60, 2x original, top-rank bonus)│       │
│  │   │            ├── top-40 candidates                             │       │
│  │   │            ├── gpt-4.1 batch rerank (1 call for all 40)      │       │
│  │   │            ├── position-aware blend (75/60/40)               │       │
│  │   │            ├── snippet extract                                │       │
│  │   │            └── context attach                                 │       │
│  │   ├── get → kbm.search.get (docid / virtual-path / fuzzy)        │       │
│  │   ├── multi_get → kbm.search.multi_get (asyncio.gather fetch)    │       │
│  │   ├── status → kbm.search.status (catalog stats)                 │       │
│  │   └── ls → kbm.search.ls (DuckDB scan over catalog.parquet)      │       │
│  └──────────────────────────────────────────────────────────────────┘       │
│           │                                                                  │
│           ▼ reads from                                                       │
│   local-disk cache (TTL via ETag) ←─ s3://kb-{env}/                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

Full zoomable version: [01_overall_process_map.html](01_overall_process_map.html).

---

## §11. The relationship to the existing CLAUDE.md and SKILL.md

These two files in this folder **already exist** and serve different purposes:

| File | Audience | Role | Modifiable by you? |
|---|---|---|---|
| [`claude.md`](claude.md) | The Claude agent THAT MAINTAINS THE WIKI at runtime (the human asks "ingest this PDF" and Claude follows the workflow) | Runtime curation instructions for the wiki — describes the ingest workflow, page format, citation rules, lint pass | NO — these are the instructions the wiki-Claude reads. They define the wiki's authoring contract. |
| [`SKILL.md`](SKILL.md) | The chatbot agent in `target_product_bundle` that USES the deployed `kbm` tools | Tells the chatbot how to search/query — three search modes, structured-query DSL, retrieval workflow | NO — these are the chatbot-facing instructions. They drive how the agent invokes `query` / `get` / `multi_get` |
| `00_start_here.md` ... `16_*` (everything else this bundle adds) | **You, the junior coding agent BUILDING the tools** | Design + build contract | YES — these are yours to read, follow, and update via ADR if needed |

**The three-file relationship:**

```
claude.md  ─── tells Claude how to CURATE the wiki         ┐
                                                            │ runtime
SKILL.md   ─── tells the chatbot how to USE the tools      ┘

00-16/     ─── tells the junior agent how to BUILD the tools  (build-time, you)
```

Your job is to ship the tools. The chatbot then uses `SKILL.md` to use them. The wiki-Claude uses `claude.md` to maintain the wiki content that `kbm build` then indexes.

---

## §12. Glossary (5 terms you'll see repeatedly)

| Term | Meaning |
|---|---|
| **doc_search** | The TypeScript reference product (`qmd-main/`) whose architecture is being ported. **You are NOT using its npm package**; you are porting its algorithms to Python. The verified ground-truth claims are at `../../doc_search_tool/24_audit_and_corrections.md §1`. |
| **`kbm`** | Short name of this Python package (`knowledge_base_management`). Also the CLI entry-point name (`kbm build`, `kbm query`, etc.). |
| **target_product_bundle** | The main chatbot product's design bundle, located at `target_product_bundle/00_start_here.md` etc. (one level up from this folder). The chatbot consumes `kbm` tools through tool-calling. |
| **Signature algorithm** | An algorithm that doc_search proved measurably better than common alternatives. There are two — smart chunking (`05_*.md`) and the retrieval quartet (`06_*.md`). These are ported **verbatim**. Tuning requires an ADR and re-running the bench fixture in `16_user_uat_script.md` case 7. |
| **Verbatim port** | Byte-equal port of a constant, prompt, or algorithm. CI scripts enforce byte-equality with the source-of-truth file. Changing a verbatim-port value without updating the source bundle file in the same PR fails CI. |

---

## §13. What "done" looks like

You are done when:

1. All 8 phases (Phase 0 through Phase 7) are tagged
2. The 8-case UAT in [16_user_uat_script.md](16_user_uat_script.md) is signed off by the product owner
3. `cdk deploy ENV=prod` succeeds and `/health` returns 200 from the prod ALB
4. The main `target_product_bundle` agent successfully invokes `kbm.query()` end-to-end against a real query
5. The nightly bench Lambda from [12_performance_slo.md](12_performance_slo.md) runs green for 7 consecutive days

That's the contract. Open `02_repo_scaffold.md` to start Phase 0.
