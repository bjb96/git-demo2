# 13 — Risk Register (12 named risks + Day-1 mitigations)

> **Purpose** — every named risk to `kbm` delivery + the mitigation the bundle either (a) implements as a Day-1 control or (b) leaves as an open issue for v2. **Phase 2 reader: mitigate the 4 Day-1 risks BEFORE shipping; don't defer.**
>
> **Severity:** P0 (delivery-blocker) · P1 (must mitigate before prod traffic) · P2 (alarm in prod; manual response) · P3 (informational)

---

## §1. Risk inventory

| # | ID | Risk | Severity | Mitigation file | Day-1? |
|---|---|---|---|---|---|
| 1 | R-KB-1 | Dim mismatch between build-time and serve-time embedding model silently corrupts results | P0 | HC-3 in `00_*.md §7`; `embedding_model.txt` boot-time check (`03_*.md §3.10`) | YES |
| 2 | R-KB-2 | Chunker non-determinism produces different chunks across rebuilds, invalidating ALL embeddings | P0 | HC-2 in `00_*.md §7`; `scripts/check_chunker_byte_identical.py` (`05_*.md §7`) | YES |
| 3 | R-KB-3 | `kbm upload` writes a partially-uploaded KB to S3; ECS containers serve a broken mix | P0 | HC-5: upload refuses if `lint_passed != True`; atomic ETag verification (`07_*.md §6.3`) | YES |
| 4 | R-KB-4 | OpenAI API outage blocks all queries (no graceful degradation) | P1 | Circuit breaker around OpenAI client (`src/kbm/obs/breakers.py`); fall back to RRF-only when rerank fails (`06_*.md §7`); fall back to `[{lex:q},{vec:q}]` when expansion fails (§3.3) | YES |
| 5 | R-KB-5 | Bedrock API outage blocks indexing (`kbm embed`) | P2 | Retry policy 4 attempts × exponential backoff per `03_*.md §7`; `kbm embed` is restartable (idempotent per chunk) | YES |
| 6 | R-KB-6 | Stale wiki content drifts from raw sources; agent cites outdated info | P2 | Lint check L1 (missing context) + nightly bench detects regression on golden queries (`12_*.md §8`); wiki/log.md changelog provides audit trail | NO (operational) |
| 7 | R-KB-7 | Redis cache stores poisoned expansion that pollutes future queries | P2 | Cache key is content-hashed (input-derived); no per-tenant cross-contamination by construction (`03_*.md §6.1`); manual cache flush via `kbm-admin flush-cache` runbook step | NO (incident-only) |
| 8 | R-KB-8 | gpt-4.1 hallucinates docids in expansion output | P3 | Anti-hallucination filter `has_query_term` per `06_*.md §3.3` rejects expansions with zero query-token overlap | YES |
| 9 | R-KB-9 | FAISS index too large to fit in 2GB ECS container RAM | P2 | Per `03_*.md §3.8`, IndexHNSWFlat above 100k docs; mmap reads avoid full load. Alarm at ECS memory > 80% (`12_*.md §3`) | YES (sizing decision) |
| 10 | R-KB-10 | A single tenant uploads a malicious doc with a prompt-injection payload that the agent treats as instructions | P1 | doc_search's `extractSnippet` highlights query terms only; agent's system prompt should mark KB content as untrusted (handled in main bundle's prompt library, NOT here). kbm-side: snippet output is plain markdown with `**bold**` highlighting; agent's task is to detect injection. | NO (main-bundle concern) |
| 11 | R-KB-11 | Concurrent rebuild while ECS is reading mid-flight serves a half-updated index | P1 | Versioned S3 keys (`s3://kb-{env}/{version}/...`) + ECS reads version pinned in env var `KBM_KB_VERSION`. Deploy = rebuild → upload to new version → bump env var via SSM → ECS restart | YES (deferred to v2; v1 uses re-deploy with brief downtime) |
| 12 | R-KB-12 | OpenAI bearer-token leak / rotation requires app restart | P1 | Token loaded via Secrets Manager at runtime (NOT baked into image); rotation rotates the secret + triggers ECS service rolling restart (`15_*.md §5`) | YES |

---

## §2. Day-1 mitigations (mandatory before Phase 6)

These 5 mitigations MUST be in place before the main `target_product_bundle` agent points at the kbm-search ALB. **R-KB-1, R-KB-2, R-KB-3, R-KB-4, R-KB-9.**

### R-KB-1 — Dim mismatch detector
- Implementation: `_verify_embedding_model` in `src/kbm/search/store.py` (per `03_*.md §3.10`)
- Test: `test_dim_mismatch_raises_on_boot` (per `10_*.md §4`)
- Fails fast: container refuses to serve queries if any collection's `embedding_model.txt` disagrees with runtime settings

### R-KB-2 — Chunker determinism check
- Implementation: `scripts/check_chunker_byte_identical.py` runs in CI on every PR
- Test: `test_chunk_deterministic_3_runs` (per `10_*.md §3` test 11) + property `test_chunker_deterministic_property`
- Fails CI: if 3 consecutive runs on the same input produce different chunks

### R-KB-3 — Lint-blocks-upload
- Implementation: `kbm upload` reads `build_info.lint_passed` BEFORE any S3 write (per `07_*.md §6.2`)
- Test: `test_kbm_upload_refuses_lint_failed` (per `10_*.md §5` test 10)
- Fails fast: exit 1 with HC-5 message; nothing uploaded

### R-KB-4 — Circuit breakers + graceful degradation
- Implementation: `src/kbm/obs/breakers.py` 3-state breaker around `openai` + `boto3.bedrock-runtime` clients
- Test: `test_expand_fallback_when_openai_500` + `test_rerank_skipped_when_openai_500`
- Behavior: expansion failure → use `[{lex:q},{vec:q}]`. Rerank failure → skip rerank step (RRF rank order preserved). Embed failure (query-time) → fail the query (no fallback possible without an embedding).

### R-KB-9 — FAISS sizing fence
- Implementation: `select_faiss_index_type` per vector count (`03_*.md §3.8`)
- Pre-deploy check: ops runs `kbm size-estimate --manifest manifest.yaml` (Phase 5 deliverable) which reports estimated index size in MB and warns if > 1.5GB
- Alarm: CloudWatch `ECSServiceMemoryUtilization > 80%` triggers SEV-3

---

## §3. Open risks (P2/P3) — accepted for v1, plan for v2

| # | Risk | v1 status | v2 plan |
|---|---|---|---|
| R-KB-6 | Stale wiki drift | Manual via nightly bench + `claude.md` lint workflow | v2: automated "wiki dirty" alarm — detect that raw/ has new docs that don't have matching wiki coverage |
| R-KB-7 | Cache poisoning | Manual flush via runbook | v2: per-tenant cache namespaces + signed cache values |
| R-KB-11 | Concurrent rebuild | Brief downtime via deploy | v2: versioned S3 prefixes + atomic version-flip via SSM |
| R-KB-10 | Prompt injection in KB content | Main bundle responsibility | n/a — orthogonal to kbm |

---

## §4. Risk-to-implementation map

When implementing a phase, cross-reference here to ensure no Day-1 mitigation is forgotten:

| Phase | Read this section of 13_*.md |
|---|---|
| Phase 1 (Foundation + chunker) | R-KB-2 (chunker determinism) — write the drift-check stub now |
| Phase 2 (Build half) | R-KB-3 (lint-blocks-upload) — wire HC-5 into uploader |
| Phase 3 (MCP layer) | R-KB-12 (token rotation) — auth middleware reads from Secrets Manager, not env var directly |
| Phase 4 (Search half) | R-KB-1 (dim mismatch); R-KB-4 (circuit breakers, graceful degradation); R-KB-8 (hallucination filter) |
| Phase 5 (Obs + IaC) | R-KB-9 (FAISS sizing); R-KB-11 (versioned uploads — even if deferred, the file path scheme is set) |
| Phase 6 (Integration) | R-KB-10 (KB content as untrusted — coordinate with main bundle's prompt library) |
| Phase 7 (Deploy) | All P0+P1 mitigations verified via UAT (`16_user_uat_script.md` case 7) |

---

## §5. Incident classification

When something breaks in prod, ops uses this to severity-tag:

| Severity | Examples | Response |
|---|---|---|
| SEV-1 | `/health` returning 500; all queries error; ALB targets all unhealthy | Wake up on-call immediately; runbook OPS-01 |
| SEV-2 | p95 > 5s for > 15 min; recall@3 nightly bench < 5 for 2 nights; query availability < 99% over 24h | Notify on-call within 1h; OPS-02 |
| SEV-3 | Single alarm tripping (cost, cache hit, single P95 spike); informational | Investigate during business hours; OPS-04+ |
| SEV-4 | Lint warning rate up; informational | Note in weekly review |

See `15_ops_runbook.md` for the playbooks (OPS-01 through OPS-08).
