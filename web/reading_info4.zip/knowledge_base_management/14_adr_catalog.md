# 14 — ADR Catalog (12 locked architectural decisions)

> **Purpose** — the "why" answer for every decision the junior agent might be tempted to second-guess. Each ADR documents: context, decision, rationale, alternatives considered, consequences. **Disagree first → ADR → THEN code.**
>
> **Format**: standard ADR (Architecture Decision Record). Status values: `accepted`, `superseded`, `deprecated`.

---

## ADR-001 — Python 3.12 + standard toolchain (FastAPI/uvicorn/pytest/ruff/mypy/pip-tools/CDK)

**Status:** accepted (2026-04-15)
**Context:** Need a stack that's (a) Bedrock+OpenAI SDK compatible, (b) familiar to junior agents, (c) deployable on ECS without unusual tooling.
**Decision:** Python 3.12 (pinned), FastAPI + uvicorn, pytest 8.x, ruff (replaces flake8+isort+pyupgrade), mypy strict, pip-tools for lockfiles, CDK v2 (Python) for IaC.
**Alternatives considered:**
- Node.js (matches doc_search's TS but adds a new ecosystem for the team — rejected).
- Go (no good FAISS bindings; no AWS Bedrock SDK parity — rejected).
- Poetry (more complex lockfile semantics than pip-tools; rejected for junior friendliness).
**Consequences:** Locked deps + pinned Python = ECS image is reproducible. Junior agents who try `pyproject.toml [project] requires-python="^3.12"` instead of `>=3.12,<3.13` will fail `make ci`'s pin-check.

---

## ADR-002 — Bearer-token auth (single shared secret) for v1

**Status:** accepted (2026-04-15) — likely superseded by SigV4 in v2
**Context:** kbm-search runs on a private ALB inside the VPC. Calls come from the main `target_product_bundle` ECS task only (no end-user traffic).
**Decision:** Single bearer token via `Authorization: Bearer <KBM_BEARER_TOKEN>`. Token stored in Secrets Manager (`kbm/bearer-token`); rotated every 90 days via manual procedure (`15_*.md §5`).
**Alternatives considered:**
- IAM SigV4: more secure, but cross-account complexity for the main bundle. Defer to v2.
- mTLS: massive ops overhead for this scale. Rejected.
- No auth (private ALB only): violates defense-in-depth. Rejected.
**Consequences:** Token rotation requires a 5-minute coordinated deploy (main bundle + kbm). `kbm.mcp.auth.bearer_auth_middleware` uses `hmac.compare_digest` to defeat timing attacks. Tests use a fixed `test-token` value.

---

## ADR-003 — 90% line coverage gate + mutmut on signature files

**Status:** accepted
**Context:** Main bundle uses 85% coverage. kbm's surface is smaller and algorithm-heavier (chunker + RRF + blend); the same bug class will affect proportionally more of the system.
**Decision:** 90% coverage on changed lines. Mutation testing (`mutmut`) on `chunker.py`, `ast_chunker.py`, `rrf.py`, `blend.py`, `query.py` with ≥ 90% survival rate.
**Alternatives considered:**
- 95% coverage: punitive; junior agents struggle with exception-path coverage on third-party clients.
- No mutation testing: fast tests stay green even when wrong code passes them. Rejected per the lessons from doc_search's bench fixtures.
**Consequences:** PRs that touch a signature file MUST run `make mutate`. Adds ~5 min to PR cycle but catches 80% of the "tautological test" class.

---

## ADR-004 — SQLite FTS5 (NOT `bm25s`) for BM25

**Status:** accepted (2026-04-20)
**Context:** doc_search uses SQLite FTS5 with column weights (filepath=1.5, title=4.0, body=1.0). The Python equivalent `bm25s` is faster + lighter but does NOT natively support per-column weights.
**Decision:** Use stdlib `sqlite3` + FTS5 virtual tables. One SQLite file per collection.
**Alternatives considered:**
- `bm25s` package: ~500× faster than `rank_bm25`. **Rejected** because compensating for missing column weights via 3 parallel indexes is more complex than just keeping FTS5.
- OpenSearch BM25 (managed service): overkill for this scale; adds an external dep; rejected.
- `rank_bm25`: pure-Python but slow. Rejected.
**Consequences:** Per-collection `.sqlite` files ship to S3 as immutable artifacts. Container boot pulls them to local disk. FTS5 lib comes with Python — zero dep cost. Builders pay a small write-time cost (~5s for 7 docs); query-time cost is FTS5-fast.

---

## ADR-005 — FAISS (`faiss-cpu`) for vector search

**Status:** accepted (2026-04-20)
**Context:** doc_search uses sqlite-vec (the same SQLite virtual-table extension model as FTS5). Python's sqlite-vec is available but requires the `sqlite_vec` PyPI package + boot-time `db.load_extension()`.
**Decision:** FAISS (`faiss-cpu`) for cosine search. Per-collection `index.faiss` file + `meta.parquet` for row-id → hash_seq lookup.
**Alternatives considered:**
- sqlite-vec (Python port): matches doc_search exactly. **Rejected** because: (a) per-container `db.load_extension()` adds boot-time complexity; (b) FAISS is industry-standard with better tooling for index type selection (HNSW vs IVF-PQ at scale); (c) the 2-step query workaround for vec0-JOIN-hang doesn't translate cleanly to Python.
- pgvector + RDS: adds a managed DB just for vectors. Rejected on cost.
- Pinecone / Weaviate / Qdrant managed: vendor lock-in; rejected at this scale.
**Consequences:** Index type chosen by vector count (Flat <100K, HNSW <10M, IVFPQ ≥10M). Vectors must be L2-normalized before insert (then `IndexFlatIP` == cosine).

---

## ADR-006 — Bedrock Titan-Embed-Text-v2 (1024-dim) for embeddings

**Status:** accepted (2026-04-22)
**Context:** doc_search uses `embeddinggemma-300M` (768-dim) via node-llama-cpp locally. ECS has no GPU; CPU-side sentence-transformers adds cold-start cost.
**Decision:** Bedrock Titan-Embed-Text-v2 (1024-dim, $0.02/1M input tokens, normalize=true).
**Alternatives considered:**
- Cohere `embed-english-v3` via Bedrock: similar cost, slightly higher MTEB. Tie-breaker = AWS-native (Titan).
- OpenAI `text-embedding-3-large` (3072-dim): cross-cloud egress + 3× index size. Rejected.
- sentence-transformers `all-MiniLM-L12-v2` locally: free per-token but adds 80MB to the container + CPU embed latency.
**Consequences:** Hard-pinned at `amazon.titan-embed-text-v2:0`. Dim is 1024. Switching models = rebuild + re-upload all FAISS indexes (no migration path). The `embedding_model.txt` sidecar (HC-3) prevents silent dim mismatch.

---

## ADR-007 — gpt-4.1 (via OpenAI SDK with structured outputs) for query expansion + rerank

**Status:** accepted (2026-04-25)
**Context:** doc_search uses (a) Qwen3-1.7B fine-tuned + GBNF grammar for query expansion, (b) Qwen3-Reranker-0.6B cross-encoder for rerank. Both run via node-llama-cpp on a local GPU. ECS has no GPU; even if SageMaker hosted these models, per-token cost would be similar to gpt-4.1.
**Decision:** Use gpt-4.1 for BOTH expansion (Pydantic structured-output replaces GBNF) AND rerank (1M context window fits 40-doc batch in one call).
**Alternatives considered:**
- Cohere Rerank-v3.5 via Bedrock: ~50× cheaper but slightly lower quality on long-tail queries. Acceptable for v2 cost optimization. Document as Phase-7 toggle.
- Local Qwen3 models on SageMaker: 10× more expensive ECS task definition (GPU); rejected.
- BGE-Reranker-Large locally: same GPU problem; rejected.
**Consequences:** OpenAI key in Secrets Manager. Cost ceiling per `12_*.md §6`. Structured outputs (`response_format=ExpansionResult` / `RerankBatchResult`) replace the GBNF + chat-template-token-management complexity of doc_search's TS code. Verbatim port of doc_search's GEPA `best_prompt.txt` as system prompt (per `06_*.md §3.1`).

---

## ADR-008 — ElastiCache Redis (allkeys-LRU, 24h TTL) for LLM result cache

**Status:** accepted (2026-04-26)
**Context:** doc_search uses `llm_cache` SQLite table with probabilistic 1% eviction at 1000-row cap. That scales fine for single-user laptops; ECS at 50 concurrent users needs a shared cache.
**Decision:** ElastiCache Redis (`cache.t4g.small`) with `maxmemory-policy=allkeys-lru` and 24h TTL on every write. Cache keys = SHA-256(url + sorted-JSON body) (verbatim from doc_search store.ts:2024-2029).
**Alternatives considered:**
- DynamoDB: TTL works but per-call latency adds 10-20ms; rejected.
- In-process LRU per container: defeats the point (each container has its own cache).
- Skip caching: each query pays full gpt-4.1 cost; estimated 4× cost increase.
**Consequences:** Redis is ~$25/month. Cache hit-rate target ≥ 60% (expansion) / ≥ 50% (rerank). Failures degrade gracefully (`RETRY_POLICIES[CacheError] = {"max_attempts": 1}` — skip cache, run full pipeline).

---

## ADR-009 — One Docker image, one ECS service, CDK v2 (Python) for IaC

**Status:** accepted
**Context:** Need a deployment shape that matches main bundle's existing ECS+ALB pattern.
**Decision:** Single Docker image (`kbm-search:vX.Y.Z`), single ECS service in main bundle's existing cluster, dedicated ALB target group. CDK stack lives in `kbm/cdk/` and imports IDs from main bundle's CDK outputs (cluster ID, VPC ID).
**Alternatives considered:**
- Two services (build CLI as a Lambda + search as ECS): build CLI is developer-laptop-only; rejected.
- Shared image with main bundle: image bloat; conflicting dep versions. Rejected.
**Consequences:** kbm's CDK + main bundle's CDK are deployed separately, with documented dependency ordering (`15_*.md §5`).

---

## ADR-010 — Parquet (Polars) for catalog + meta; not SQLite documents table

**Status:** accepted
**Context:** doc_search uses a SQLite `documents` table (single file, joinable). For Python on ECS reading from S3, Parquet is more natural (columnar, DuckDB scannable, no SQLite WAL contention).
**Decision:** `catalog.parquet` for the document inventory. `meta.parquet` for FAISS row-id ↔ chunk mapping. SQLite is used ONLY for the FTS5 virtual table (one file per collection).
**Alternatives considered:**
- Single SQLite per collection containing both FTS5 + documents table: matches doc_search but adds the cross-platform-sqlite cost (need to LOCK or use WAL).
- JSON Lines: human-readable but slow scan over large KBs.
**Consequences:** DuckDB scans `catalog.parquet` for the `ls` tool in sub-50ms even at 100k docs. Polars writes are atomic.

---

## ADR-011 — Tree-sitter for AST chunking (6 languages)

**Status:** accepted
**Context:** doc_search ports `ast.ts` using web-tree-sitter (WASM). Python has native `tree-sitter` + per-language grammars on PyPI.
**Decision:** Use the native Python `tree-sitter` package + `tree-sitter-{python,typescript,go,rust}` PyPI packages. Use the same 6-language scope as doc_search (TS, JS, Py, Go, Rust, TSX).
**Alternatives considered:**
- `ast` (stdlib, Python-only): doesn't cover TS/JS/Go/Rust.
- Skip AST entirely (regex-only): degrades code retrieval quality.
**Consequences:** PyPI grammar packages may fail to install on some platforms (graceful fallback per `05_*.md §6.4` — log warning, fall back to regex). Grammars add ~30MB to wheel size; acceptable.

---

## ADR-012 — Typer (NOT Click) for CLI

**Status:** accepted
**Context:** Need a CLI framework with Pydantic-friendly types and good help output.
**Decision:** Typer 0.12+.
**Alternatives considered:**
- Click: ubiquitous but Pydantic integration is awkward.
- argparse: stdlib but verbose for our 5-command surface.
**Consequences:** Junior agents use `typer.Argument` + `typer.Option` decorators. Help output via `--help` is automatic.

---

## ADR-013 — Wiki collection is queried FIRST; raw is fallback (wiki-first architecture)

**Status:** accepted (2026-05-15) — THE central architectural choice
**Context:** The bundle's downstream consumer is a chatbot agent that needs to retrieve from a KB. We have TWO kinds of content: curated wiki pages (synthesized by Claude per `claude.md`) and raw source documents (immutable inputs). Naively querying both as one collection buries the curated answers under raw chunks.
**Decision:**
1. Manifest must declare ≥ 1 collection with `kind="wiki"` (HC-1 via Pydantic validator in `03_*.md §2.1`).
2. Wiki collection(s) have `include_by_default=true`; raw collection(s) default to `include_by_default=false`.
3. Agent's `kbm_query()` defaults to wiki-only.
4. Skill `kbm-search` (per `08_*.md §4`) instructs the agent: query wiki first; fall back to all collections only when wiki returns 0 or top score < 0.5.
5. wiki/log.md is `ignore`d (per `gold_kb/manifest.yaml` example) so the changelog doesn't pollute search.
**Alternatives considered:**
- Treat wiki + raw as one collection: rejected — destroys the compounding flywheel.
- Query both in parallel and let rerank decide: rejected — the wiki's curation effort is wasted when ranked against raw chunks 10× more numerous.
- Wiki-only (drop raw): rejected — raw catches the long tail.
**Consequences:** The wiki collection MUST be curated by Claude per `claude.md`. The agent's retrieval workflow has a documented if/else (wiki → raw fallback). Latency: wiki-only query is ~30% faster (single collection); fallback to raw adds 1 round-trip but only fires on cache miss for novel queries.

---

## ADR-014 — Strong-signal bypass fires only on single-collection / unfiltered queries

**Status:** accepted (2026-05-18) — port discrepancy from doc_search documented in `06_*.md §2`
**Context:** doc_search's `hybridQuery` runs ONE `searchFTS` for the bypass probe; its signature only takes a SINGLE optional `collection` (per `store.ts:4298`). When the agent queries multiple collections, doc_search's `structuredSearch` is used — and it has NO bypass at all.
**Decision:** kbm's bypass mirrors doc_search exactly: fires only when `len(collections) <= 1` (i.e. single collection OR no filter). Multi-collection queries skip the bypass.
**Alternatives considered:**
- Cross-collection parallel probe with global top-2: an enhancement my earlier draft proposed. Rejected because it changes semantics (one collection's strong signal can mask another's relevant doc).
**Consequences:** When the agent queries `collections=["wiki"]` (the default per ADR-013), bypass fires normally. When it falls back to `collections=["wiki", "raw"]`, bypass is skipped — the full pipeline runs, which is the right behavior for ambiguous cross-collection queries.

---

## §15. ADR template for new decisions

```markdown
## ADR-NN — <decision title>

**Status:** proposed | accepted | superseded by ADR-XX | deprecated
**Context:** <the problem; why this decision needed making>
**Decision:** <what we chose>
**Rationale:** <why>
**Alternatives considered:**
- A: <pros/cons>
- B: <pros/cons>
**Consequences:** <what changes; what's now harder; what's now easier>
```

To propose a new ADR: open an issue tagged `adr-proposal` with this template filled in. Resolution = merged PR adding the ADR to this file + any code that depends on it.
