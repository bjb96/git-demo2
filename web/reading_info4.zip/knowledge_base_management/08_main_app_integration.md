# 08 — Main-App Integration (how `kbm` wires into `target_product_bundle`)

> **Purpose** — the contract for Phase 6. Specifies exactly what gets added to `target_product_bundle/` (the main chatbot) so its agent can call `kbm` tools through its existing tool-calling layer. **No new patterns invented**; we slot `kbm` into the existing `mp_tools` + `skills` + `prompts` triad the main bundle already uses.
>
> **Files this PR touches:** `target_product_bundle/src/mp_tools/kbm.py` (NEW), `target_product_bundle/src/skills/kbm-search/SKILL.md` (NEW), one new constant in `target_product_bundle/src/prompts/library.py`, one integration test under `target_product_bundle/tests/integration/test_kbm_integration.py`.

---

## §1. The integration shape (mental model)

```
[Chatbot agent in target_product_bundle]
            │ tool-call request
            ▼
target_product_bundle/src/mp_tools/kbm.py        ← NEW thin wrapper (5 functions)
            │ HTTP request (signed)
            ▼
kbm.mcp.server (running on kbm's ECS service)    ← Phase 3+4 from this bundle
            │ reads from
            ▼
s3://kb-{env}/                                    ← uploaded via Phase 2
```

The main agent never imports `kbm.search.*` directly. It calls `kbm.query(...)` etc. on its own `mp_tools` namespace, which under the hood does HTTP to the `kbm.mcp.server` ECS service.

**Why HTTP rather than in-process import?** ADR-026: the two services have different scaling profiles (the chatbot has higher TPS, FAISS RAM resident in memory). Decoupling lets them scale independently and lets `kbm` be reused by future products without coupling release trains.

---

## §2. The 5 new functions in `target_product_bundle/src/mp_tools/kbm.py`

```python
"""src/mp_tools/kbm.py — thin HTTP client for the kbm.mcp.server service.

This module is added in Phase 6 per knowledge_base_management/08_main_app_integration.md.
The chatbot agent invokes these as ordinary mp_tools — its tool-calling layer
(see target_product_bundle/19_orchestrator.md) dispatches them just like any
other mp_tools.* function.
"""
from __future__ import annotations

import httpx
from pydantic import BaseModel

from src.settings import get_settings
from src.exceptions import AppError, ToolTimeoutError, ToolUnavailableError


_TIMEOUT = httpx.Timeout(connect=5.0, read=30.0, write=10.0, pool=5.0)


def _client() -> httpx.AsyncClient:
    """Returns an httpx client configured with the bearer token + KBM service URL."""
    s = get_settings()
    return httpx.AsyncClient(
        base_url=s.kbm_service_url,                       # NEW env var, see §5
        timeout=_TIMEOUT,
        headers={"Authorization": f"Bearer {s.kbm_bearer_token.get_secret_value()}"},
    )


# ── The 5 tool functions ──────────────────────────────────────────────────

async def kbm_query(
    *,
    query: str | None = None,
    searches: list[dict] | None = None,
    intent: str | None = None,
    collections: list[str] | None = None,
    limit: int = 10,
    candidate_limit: int = 40,
    min_score: float = 0.0,
    rerank: bool = True,
    explain: bool = False,
) -> dict:
    """Mirror of kbm/04_mcp_tool_contract.md §3 — see for full schema."""
    body = {k: v for k, v in {
        "query": query, "searches": searches, "intent": intent,
        "collections": collections, "limit": limit, "candidate_limit": candidate_limit,
        "min_score": min_score, "rerank": rerank, "explain": explain,
    }.items() if v is not None}

    async with _client() as c:
        r = await c.post("/query", json=body)
    return _check(r, "kbm_query")


async def kbm_get(
    *,
    file: str,
    from_line: int | None = None,
    max_lines: int | None = None,
    line_numbers: bool = False,
) -> dict:
    body = {"file": file, "line_numbers": line_numbers}
    if from_line is not None: body["from_line"] = from_line
    if max_lines is not None: body["max_lines"] = max_lines
    async with _client() as c:
        r = await c.post("/get", json=body)
    return _check(r, "kbm_get")


async def kbm_multi_get(
    *,
    pattern: str,
    max_bytes: int = 10240,
    max_lines: int | None = None,
    line_numbers: bool = False,
) -> dict:
    body = {"pattern": pattern, "max_bytes": max_bytes, "line_numbers": line_numbers}
    if max_lines is not None: body["max_lines"] = max_lines
    async with _client() as c:
        r = await c.post("/multi_get", json=body)
    return _check(r, "kbm_multi_get")


async def kbm_status() -> dict:
    async with _client() as c:
        r = await c.post("/status", json={})
    return _check(r, "kbm_status")


async def kbm_ls(*, path: str | None = None, recursive: bool = False) -> dict:
    body = {"recursive": recursive}
    if path is not None: body["path"] = path
    async with _client() as c:
        r = await c.post("/ls", json=body)
    return _check(r, "kbm_ls")


# ── Internal: response checker ─────────────────────────────────────────────

def _check(response: httpx.Response, tool_name: str) -> dict:
    """Map kbm HTTP responses to AppError if not 200, otherwise return body."""
    if 200 <= response.status_code < 300:
        return response.json()
    if response.status_code == 401:
        raise AppError("kbm_auth_error", "kbm rejected bearer token", http_status=503)
    if response.status_code == 502:
        # kbm itself failed downstream (Bedrock / OpenAI / Redis)
        raise ToolUnavailableError(tool_name, response.json().get("error", {}).get("message", ""))
    if response.status_code == 504:
        raise ToolTimeoutError(tool_name)
    # 400 / 404 etc. — surface to the orchestrator as a tool-error so the agent can recover
    raise AppError(
        f"kbm_{response.status_code}",
        response.json().get("error", {}).get("message", "kbm tool failed"),
        http_status=502,
    )
```

### 2.1 Why HTTP and not gRPC / in-process?

- **HTTP**: matches the existing `mp_tools.io_http` pattern in `target_product_bundle/src/mp_tools/io_http.py`; reuses the bearer-token auth pattern; debuggable via curl.
- **In-process**: requires shipping FAISS + 1024-dim vectors into the chatbot's container memory; doubles memory footprint and prevents `kbm` from scaling independently.
- **gRPC**: extra dependency; no win at our scale.

See ADR-026.

---

## §3. New SKILL.md at `target_product_bundle/src/skills/kbm-search/SKILL.md`

Frontmatter + body. **Must pass the main bundle's existing `scripts/check_skills.py` drift-check** — every `tools_used:` reference must resolve to an mp_tools function declared in §2.

```markdown
---
name: kbm-search
description: Search the knowledge base via kbm.* tools. Use when the user asks a question that may be answered by indexed wiki pages or raw source documents. Prefer wiki collection first; fall back to raw.
license: Proprietary
compatibility: Requires kbm.mcp.server reachable at KBM_SERVICE_URL.
metadata:
  author: target-bundle
  version: "0.1.0"
allowed-tools: kbm_query, kbm_get, kbm_multi_get, kbm_status, kbm_ls
tools_used: [kbm_query, kbm_get, kbm_multi_get, kbm_status, kbm_ls]
---

# kbm-search — Hybrid BM25 + FAISS knowledge-base search

When the user asks something the chatbot's own model knowledge can't answer well, search the curated knowledge base via `kbm_query`. The KB has two collection types:

1. **`wiki`** — Claude-curated pages with citations and wiki-links. **Search this first** for any conceptual question. Results here are higher signal than raw chunks.
2. **`raw`** — immutable source documents (PDFs converted to markdown, podcast transcripts, etc.). **Search this only if `wiki` doesn't have the answer** OR the user explicitly asks for primary sources.

## Workflow (the 4-step protocol)

1. **Discover** — call `kbm_status` at session start to learn which collections exist + their context strings. Cache this for the session.
2. **Search** — call `kbm_query` with `collections=["wiki"]` first. If results below `min_score=0.4`, retry with `collections=["wiki", "raw"]`.
3. **Retrieve** — for any result you intend to cite, call `kbm_get` with the result's `file` field to read the FULL page (snippets in `query` results are not enough to ground a precise answer).
4. **Answer** — cite each claim by quoting `file` (the qmd:// URI) and `docid` (the 6-char hash). If the answer is good and the user is satisfied, the human can ask Claude (the wiki maintainer) to file it back to the wiki for next time.

## Search modes (use `searches:` for explicit control)

| Mode | When |
|---|---|
| Simple `query: "..."` | Default. gpt-4.1 auto-expands. |
| Structured `searches: [...]` | When you know lex vs vec is the right call (rare; trust the default). |

The structured-search DSL is documented in `target_product_bundle/knowledge_base_management/SKILL.md` (the qmd skill). Don't duplicate it here.

## Pitfalls

- **Do not stop at snippets.** Snippets are 500 chars; for any factual citation, `kbm_get` the full page.
- **Do not overuse `raw`.** Wiki pages are higher-signal and faster (they're typically smaller); search raw only when wiki misses.
- **Do not mutate.** The chatbot has no permission to upload or modify the KB. That's done locally by the developer + the wiki-maintaining Claude session.
- **Cite, don't paraphrase as if it's your own knowledge.** Every fact from kbm gets a citation.
- **Respect rate limits.** If `kbm_query` returns 429, back off 2s and retry once. If still 429, surface the limit to the user — don't loop.
- **multi_get for synthesis.** When the answer spans 3+ documents, use `kbm_multi_get` instead of N sequential `kbm_get` calls — it's 5× faster.

## Example session

```
USER: how do I debug Kafka consumer lag?

ASSISTANT (internal):
  kbm_query(query="kafka consumer lag debugging", collections=["wiki"], limit=5)
  → result #1 score=0.87 file="qmd://wiki/runbooks/kafka-lag.md"

  kbm_get(file="qmd://wiki/runbooks/kafka-lag.md")
  → full body of the runbook page

ASSISTANT (to user):
  "Per the on-call runbook at qmd://wiki/runbooks/kafka-lag.md (#a1b2c3):
   When consumers fall behind, check the lag metric in Datadog. The threshold is
   1000 messages. If exceeded, scale up the consumer group via
   `kubectl scale deployment kafka-consumer --replicas=...`. Full procedure in
   the linked page."
```
```

### 3.1 Drift check `tools_used:` validity

The frontmatter `tools_used: [kbm_query, ...]` MUST list names that resolve to functions in `target_product_bundle/src/mp_tools/kbm.py`. The main bundle's `scripts/check_skills.py` already enforces this — no new check needed.

---

## §4. One new prompt-library constant

`target_product_bundle/src/prompts/library.py` already has `*_SYSTEM` constants per agent. Add:

```python
# Appended at the end of src/prompts/library.py — Phase 6 addition
KBM_TOOL_PROMPT_ADDITION: str = """
You have access to a hybrid knowledge-base search via the kbm tools:

- kbm_query(query, collections?, intent?, limit?) — search both wiki and raw collections
- kbm_get(file) — fetch a single document by docid (#abc123) or qmd:// URI
- kbm_multi_get(pattern, max_bytes?) — batch fetch by glob / comma list / docid list
- kbm_status() — see what's in the KB
- kbm_ls(path?) — list collections / subfolders

Default protocol:
1. Search wiki first (collections=["wiki"]). It contains curated, cited pages.
2. If wiki has no answer (min_score < 0.4), retry with raw added.
3. For any answer you'll cite, kbm_get the full page (snippets are not enough).
4. Always cite by qmd:// path + #docid.
""".strip()
```

The orchestrator (`target_product_bundle/src/orchestrator/planner.py`) appends this to every system prompt when the `kbm-search` skill is active.

**This is the ONLY change to `src/prompts/library.py` — do not edit existing constants.**

---

## §5. New env vars (added to `target_product_bundle/src/settings.py`)

```python
# Added in Phase 6 — kbm service connection
from pydantic import HttpUrl, SecretStr
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # ... existing fields ...

    kbm_service_url: HttpUrl = "http://localhost:8080"        # dev default
    kbm_bearer_token: SecretStr                                # required; from SSM kbm/bearer-token
```

And `.env.example` in the main bundle gains:

```dotenv
# === KBM service (Phase 6 integration) ===
KBM_SERVICE_URL=http://localhost:8080                     # ECS: https://kbm.{env}.example.com
KBM_BEARER_TOKEN=dev-only-change-me                       # prod: SSM kbm/bearer-token
```

---

## §6. Integration tests (added to `target_product_bundle/tests/integration/test_kbm_integration.py`)

```python
"""tests/integration/test_kbm_integration.py — Phase 6 integration tests.

Spin up the kbm.mcp.server in a subprocess against the LocalStack fixture KB,
then exercise the chatbot's tool-calling layer to verify it can reach all 5 tools.
"""
import asyncio
import pytest
from src.mp_tools.kbm import kbm_query, kbm_get, kbm_multi_get, kbm_status, kbm_ls


@pytest.mark.integration
async def test_kbm_query_round_trip(kbm_test_server):
    """
    Given: kbm.mcp.server is running with the LocalStack fixture KB seeded
    When:  the chatbot's mp_tools.kbm.kbm_query is called with a known-good query
    Then:  the response includes the expected file (from the bench-golden fixture)
       And the bearer-token auth header was attached
    """
    result = await kbm_query(query="kafka consumer lag", collections=["wiki"], limit=3)
    files = [r["file"] for r in result["results"]]
    assert "qmd://wiki/runbooks/kafka.md" in files


@pytest.mark.integration
async def test_kbm_get_round_trip(kbm_test_server):
    """Given valid docid → Then full body returned with context prepended."""
    result = await kbm_get(file="qmd://wiki/runbooks/kafka.md")
    assert "<!-- Context: " in result["body"][:500]


@pytest.mark.integration
async def test_kbm_multi_get_parallel(kbm_test_server):
    """Given comma-list of 3 docids → Then result has 3 docs and total wall-time < 1s."""
    import time
    t0 = time.perf_counter()
    result = await kbm_multi_get(pattern="#a1b2c3,#d4e5f6,#789012")
    elapsed = time.perf_counter() - t0
    assert len(result["docs"]) == 3
    assert elapsed < 1.0  # asyncio.gather working


@pytest.mark.integration
async def test_kbm_status_returns_collections(kbm_test_server):
    result = await kbm_status()
    assert "wiki" in [c["name"] for c in result["collections"]]


@pytest.mark.integration
async def test_kbm_ls_lists_collections(kbm_test_server):
    result = await kbm_ls()
    assert any(e["kind"] == "collection" and e["name"] == "wiki" for e in result["entries"])
```

---

## §7. CI pipeline update

`target_product_bundle/.github/workflows/ci.yml` gains:

```yaml
      - name: Start kbm server for integration tests
        run: |
          # Pull pre-built kbm image (from previous kbm CI run)
          docker pull ${{ secrets.ECR_KBM_DEV }}:latest
          docker run -d --name kbm \
            -p 8080:8080 \
            -e KBM_S3_BUCKET=kb-test \
            -e KBM_S3_ENDPOINT_URL=http://localhost:4566 \
            -e KBM_REDIS_URL=redis://localhost:6379/0 \
            -e KBM_OPENAI_API_KEY=sk-test-mock \
            -e KBM_BEARER_TOKEN=ci-test-token \
            ${{ secrets.ECR_KBM_DEV }}:latest
          # Seed fixture KB to LocalStack
          aws --endpoint-url=http://localhost:4566 s3 sync tests/fixtures/kbm_test_kb/ s3://kb-test/

      - name: Integration tests (includes kbm round-trip)
        env:
          KBM_SERVICE_URL: http://localhost:8080
          KBM_BEARER_TOKEN: ci-test-token
        run: pytest tests/integration -m integration
```

---

## §8. Boundary contract (what `target_product_bundle` MUST NOT do)

| Rule | Why |
|---|---|
| **NEVER call `kbm_query` with `rerank=False` from production code** | The reranker is what makes hybrid search work — disabling it ships lower quality. Only acceptable in offline batch tools. |
| **NEVER pass user input directly as `intent`** | `intent` is meant to be agent-curated disambiguation; passing the user's raw query as intent leaks the original query into expansion + rerank and biases scoring. The chatbot should populate `intent` from internal session state (current topic / current persona). |
| **NEVER modify or upload to S3 from `target_product_bundle`** | The chatbot is read-only against the KB. Wiki maintenance is the wiki-Claude session (see `knowledge_base_management/claude.md`). |
| **NEVER cache `kbm_query` results in the chatbot's own cache** | `kbm` has its own Redis cache (24h TTL); doubling up creates stale-data risk. |
| **NEVER fall back to in-process `import kbm.search`** | Decoupling is a hard architectural rule per ADR-026. |

---

## §9. Definition of Done — Phase 6

Tag `kbm-v0.0.7-integration` when:

- [ ] `target_product_bundle/src/mp_tools/kbm.py` exists with the 5 functions from §2
- [ ] `target_product_bundle/src/skills/kbm-search/SKILL.md` exists per §3 and passes `scripts/check_skills.py`
- [ ] `target_product_bundle/src/prompts/library.py` has `KBM_TOOL_PROMPT_ADDITION` exactly as in §4 (CI byte-equality check via `scripts/check_prompts_unchanged.py` in the main bundle)
- [ ] New env vars in `target_product_bundle/src/settings.py` per §5
- [ ] 5 integration tests pass against a real running `kbm.mcp.server` (LocalStack KB)
- [ ] Main bundle's `make ci` still passes
- [ ] Both bundles bumped to compatible versions and tagged together (`kbm-v0.0.7-integration` + `target-bundle-vX.Y.Z`)

→ Phase 7 (UAT + deploy) is in [16_user_uat_script.md](16_user_uat_script.md).
