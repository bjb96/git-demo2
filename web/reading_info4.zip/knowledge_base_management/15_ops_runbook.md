# 15 — Ops Runbook (8 incident playbooks + deploy + rebuild procedures)

> **Purpose** — the on-call's go-to file once kbm-search is in prod. Each playbook: detection signal → diagnosis → mitigation → rollback. Plus the 4 standard ops procedures (deploy, rotate secrets, rebuild KB, version flip).
>
> **Audience** — on-call engineer holding the pager. Junior agent reads this once during Phase 7 to understand what they're shipping.

---

## §0. Cheat sheet (top of the runbook — bookmark this section)

| Symptom | Likely runbook |
|---|---|
| `/health` 500 | OPS-01 |
| p95 latency > 3s | OPS-02 |
| ALB target unhealthy | OPS-03 |
| Cache hit < 50% | OPS-04 |
| Cost > $20/day | OPS-05 |
| Nightly bench recall < 6.0 | OPS-06 |
| ECS task OOM-killed | OPS-07 |
| OpenAI / Bedrock outage | OPS-08 |

**Key dashboards:** `cloudwatch://dashboards/kbm-overview` + `cloudwatch://dashboards/kbm-cost`.
**Error-budget tracker:** team spreadsheet at `<internal-wiki-link>` (per `12_*.md §9`).

---

## §1. Standard ops procedures

### §1.1 Deploy new kbm-search version

1. CI green on `main` → manual `git tag kbm-vX.Y.Z` triggers `cd.yml`
2. Watch deploy in ECS console; rolling restart (one task at a time)
3. New tasks come up; `/health` returns 200; ALB drains old tasks
4. Verify: `curl -H "Authorization: Bearer $TOKEN" https://kbm.internal/health`
5. Run smoke: `make load-test SCENARIO=smoke ENV=prod` from a bastion box
6. If smoke fails: roll back via `aws ecs update-service --cluster ... --service kbm-search --task-definition <previous-rev>`

### §1.2 Rotate `KBM_BEARER_TOKEN`

1. Generate new token: `openssl rand -hex 32`
2. Update Secrets Manager: `aws secretsmanager update-secret --secret-id kbm/bearer-token --secret-string "$NEW_TOKEN"`
3. **Update main bundle's secret simultaneously** (it stores the SAME token to call kbm-search): `aws secretsmanager update-secret --secret-id my-product/kbm-token --secret-string "$NEW_TOKEN"`
4. Trigger rolling restart of BOTH services: kbm-search + main app
5. Verify: a request through main → kbm round-trip returns 200
6. After 5 min of green: tokens are rotated. Old token is gone.

### §1.3 Rebuild + re-upload KB (developer-driven; ops verifies)

1. Developer runs locally: `kbm build --manifest manifest.yaml --output ./kb-prod/`
2. Developer runs: `kbm embed --output ./kb-prod/`
3. Developer runs: `kbm lint --output ./kb-prod/` — verify exit 0
4. Developer runs: `kbm plan-upload --output ./kb-prod/ --to s3://kb-prod/` — review diff
5. Developer runs: `kbm upload --output ./kb-prod/ --to s3://kb-prod/`
6. Ops: trigger ECS rolling restart so containers pull new S3 artifacts: `aws ecs update-service --cluster kbm --service kbm-search --force-new-deployment`
7. Ops: verify `/status` returns updated `last_updated` timestamp
8. Ops: run nightly bench manually: `aws lambda invoke --function-name kbm-nightly-bench /tmp/bench-result.json`

### §1.4 Version flip (v2 feature — deferred for v1; documented for future)

When versioned S3 prefixes ship (per R-KB-11): rebuild writes to `s3://kb-prod/{new-version}/`; SSM param `/my-product/kbm-kb-version` flips; ECS reads via env var; no downtime.

---

## §2. OPS-01 — `/health` returning 500

**Detection:** ALB target group reports unhealthy targets; CloudWatch alarm `kbm-health-unhealthy` fires.

**Diagnosis:**
1. `aws ecs describe-services --cluster kbm --service kbm-search` — running count vs desired count
2. CloudWatch logs `/aws/ecs/kbm-search/<task-id>` — last 50 lines for the failing task
3. If logs show `ImportError` or `ModuleNotFoundError`: image build is broken
4. If logs show `boto3.exceptions`: AWS creds / VPC / Bedrock access misconfigured
5. If logs show `ConnectionRefusedError` on Redis: ElastiCache cluster down or security group blocking
6. If logs show `RuntimeError: KBM_BEARER_TOKEN empty`: Secrets Manager read failed

**Mitigation:**
- (a) If image broken: roll back to previous task definition (procedure §1.1 step 6).
- (b) If creds: fix IAM task role in CDK; redeploy.
- (c) If Redis: verify cluster status; bounce ElastiCache subnet group if needed.
- (d) If secret read fails: verify task role has `secretsmanager:GetSecretValue` on `kbm/bearer-token`.

**Rollback:** previous task definition is always available; rollback is `update-service --task-definition <previous-rev>`.

---

## §3. OPS-02 — p95 latency > 3s

**Detection:** CloudWatch alarm `kbm-query-latency-p95-high`.

**Diagnosis:**
1. Dashboard `kbm-overview` — check per-step latency breakdown (`§4` in `12_*.md`)
2. Most likely culprits in order:
   - gpt-4.1 rerank latency spike (cache hit rate dropped, or OpenAI's batch latency varies)
   - FAISS cold (mmap pages not yet in memory — typically only after container restart)
   - S3 throttling (rare; happens only on cold pulls of large indexes)
3. Check `kbm.query.cache_hit_rate` — if < 30%, recent traffic is all novel queries
4. Check `kbm.rerank.tokens_in` — sudden 2× spike suggests `candidate_limit` was raised inadvertently

**Mitigation:**
- (a) If gpt-4.1 slow: increase OpenAI rate-limit reservation; or temporarily disable rerank (set env var `KBM_DEFAULT_RERANK=false`) — quality drop but latency wins.
- (b) If FAISS cold: warm up by issuing 10 known queries; or pin container's `vm.swappiness=0`.
- (c) If S3 throttled: enable Transfer Acceleration; or migrate hot indexes to ECS EFS volume.

**Rollback:** N/A (no code change needed for latency mitigation).

---

## §4. OPS-03 — ALB target unhealthy

**Detection:** ALB target group health checks failing; CloudWatch + SNS notify on-call.

**Diagnosis:**
- Health check path is `/health` (not `/ready`). If `/health` is 500, jump to OPS-01.
- If `/health` is 200 but target unhealthy: ALB-side issue (security group, listener rule, port mismatch).
- Verify ECS task is actually listening on port 8181: `aws ecs describe-tasks --tasks <task-arn>` and inspect `networkInterfaces`.

**Mitigation:** rebuild CDK stack; check `tg.healthcheck` settings; ensure `--port 8181` in Dockerfile CMD.

---

## §5. OPS-04 — Cache hit rate < 50%

**Detection:** alarm `kbm-cache-hit-low` (rolling 1h average).

**Diagnosis:**
- Sudden drop: probable cause is a Redis flush (manual or by another tenant — confirm Redis cluster shared with main app)
- Gradual drop: traffic mix changed; users querying novel topics. This is normal; if sustained for > 7 days, raise the SLO target.
- ElastiCache `cache.t4g.small` has ~1.5GB memory; if maxmemory hit, allkeys-lru evicts aggressively. Check `Evictions` metric — if > 1000/min, upsize.

**Mitigation:**
- (a) Upsize Redis to `cache.t4g.medium` (one CDK line change + `cdk deploy`)
- (b) Increase TTL from 24h to 48h (constant `CACHE_TTL_SECONDS` in `src/kbm/constants.py`)
- (c) Add a warm-up Lambda that runs canonical queries every hour

---

## §6. OPS-05 — Cost > $20/day

**Detection:** AWS Cost Anomaly Detection + CloudWatch metric `kbm.rerank.cost_usd_per_query > $0.01` triggers SNS.

**Diagnosis:**
1. Top suspect: a runaway loop in the main bundle's agent that's calling `kbm_query` thousands of times per session
2. Check `kbm.query.cache_hit_rate` — if 0% on a metric that was previously 60%, cache is broken (Redis outage?)
3. Check `kbm.embed.tokens` — if a rebuild was triggered, this could be one-time spike (normal)
4. Audit OpenAI usage dashboard for the org → which API key is spiking

**Mitigation:**
- (a) If runaway agent: emergency rate-limit at the ALB (AWS WAF rule). Coordinate with main bundle team to deploy a `mp_tools.kbm.kbm_query` rate-limiter at the call site (token bucket — 100/min per session).
- (b) If cache broken: restore Redis; flush + reseed.
- (c) Lower `candidate_limit` from 40 to 20 if rerank cost dominates (constant in `06_*.md §5` — ADR-007a).

---

## §7. OPS-06 — Nightly bench recall@3 < 6.0/10

**Detection:** Lambda `kbm-nightly-bench` publishes recall to `kbm.nightly.recall_at_3`; alarm fires on 2 consecutive nights < 6.0.

**Diagnosis:**
1. Open last 2 nights' Lambda invocation logs — which queries failed?
2. Cross-check: does the failing query have a known answer in the current KB? `kbm_get` the expected docid — does the doc exist?
3. Common causes:
   - KB was rebuilt; expected docids changed (the bench fixture is stale)
   - Chunker constants changed (signature regression — should have been caught by mutmut)
   - Embedding model dim mismatch (R-KB-1 — should have been caught at boot)
   - Wiki has been edited and the gold-truth top-3 needs an update

**Mitigation:**
- (a) If bench fixture is stale: regenerate via `scripts/regenerate_demo_data.py`; commit + run nightly again
- (b) If chunker regression: revert the offending PR; rebuild + re-upload KB
- (c) If wiki was legitimately edited: open a PR updating `expected_docids_top3` in `nightly_queries.jsonl`

---

## §8. OPS-07 — ECS task OOM-killed

**Detection:** ECS reports "Essential container exited"; CloudWatch event triggers SNS.

**Diagnosis:**
- KB is bigger than expected — FAISS index didn't fit in the 2GB task memory
- Run `kbm size-estimate --manifest manifest.yaml` against the deployed KB; report should be < 1.5GB

**Mitigation:**
- (a) Resize ECS task to 4GB memory (one CDK line; re-deploy)
- (b) Switch FAISS index type from HNSWFlat to IVFPQ for the offending collection (one constant in `03_*.md §3.8`)
- (c) Add `KBM_LOCAL_CACHE_TTL_SEC=600` to evict stale on-disk shards faster (frees disk for memory)

---

## §9. OPS-08 — OpenAI or Bedrock outage

**Detection:** alarm `kbm-error-rate-high` fires; CloudWatch logs show `OpenAIError` or `bedrock-runtime.ClientError`.

**Diagnosis:**
1. Status page check: status.openai.com / status.aws.amazon.com
2. Circuit breaker state: in `kbm.obs.breakers`, check the breaker's open/closed/half-open state
3. If breaker is OPEN: the kbm service is automatically degrading (expansion skipped; rerank skipped; queries return RRF-only results)

**Mitigation:**
- (a) Notify main bundle team that response quality is degraded — they may want to disable kbm calls until recovery
- (b) If OpenAI is the only failure: kbm can run rerank-disabled + expansion-disabled; main bundle's agent gets slightly lower quality but responses still come back. Verify by `curl POST /query rerank=false`.
- (c) If Bedrock embed fails on a query: that query fails (no fallback possible — embedding is required for vector search). BM25-only queries still work via `searches=[{type:"lex",query:"..."}]` (which the agent can be instructed to fall back to).

**Recovery:**
- Auto: circuit breaker transitions to half-open after 30s; one successful call closes it.
- Manual: ops can force-close via `curl POST /admin/breaker/close` (Phase 7 endpoint; requires admin token).

---

## §10. Standing dashboards

`docs/dashboards/kbm-overview.json` (CDK creates from this):

| Panel | Metric | Aggregation | Threshold lines |
|---|---|---|---|
| Query latency (1h) | `kbm.query.latency_ms` | p50, p95, p99 | 800ms, 2000ms, 4000ms |
| Cache hit rate (24h) | `kbm.query.cache_hit_rate` | avg by `cache_layer` | 60% (expand), 50% (rerank) |
| Strong-signal bypass rate (24h) | `kbm.query.strong_signal_bypass_rate` | avg | — (informational) |
| Error rate (1h) | `kbm.search.error_count` / total requests | rate | 5% |
| ECS memory util | `ECSServiceMemoryUtilization` | avg | 80% |
| Token spend (24h) | `kbm.rerank.tokens_*` + `kbm.embed.tokens` | sum × pricing | $0.01/query |
| Nightly bench (7d) | `kbm.nightly.recall_at_3` | min, avg | 7.0, 6.0 |

`docs/dashboards/kbm-cost.json`:

| Panel | Source |
|---|---|
| Per-day OpenAI cost | OpenAI API usage export → CloudWatch |
| Per-day Bedrock cost | AWS Cost Explorer filtered by service |
| Per-week total kbm cost | aggregated |
| Rerank vs expand cost ratio | derived from `kbm.rerank.tokens_*` and `kbm.expand.tokens` |

---

## §11. Logs Insights query catalog

Copy-paste-ready queries for CloudWatch Logs Insights:

```sql
-- 1. All 5xx responses in the last hour with their endpoints
fields @timestamp, @message, request.path, response.status
| filter response.status >= 500
| sort @timestamp desc
| limit 100

-- 2. Slow queries (latency > 2s) by collection
fields @timestamp, query.collections, latency_ms
| filter latency_ms > 2000
| stats count() by query.collections
| sort count desc

-- 3. Cache misses by cache_layer
fields @timestamp, cache_layer, cache_hit
| filter cache_hit = false
| stats count() by cache_layer

-- 4. Top 20 failing queries (5xx in last 24h)
fields @timestamp, query.text, error.class, error.message
| filter response.status >= 500
| sort @timestamp desc
| limit 20

-- 5. Error breakdown by KbmError subclass
fields error.class
| filter error.class != ""
| stats count() by error.class
```

---

## §12. Disaster recovery procedures

### DR-1 — Total S3 bucket loss

1. KB artifacts are reproducible from raw sources (which the developer's local machine has)
2. Developer re-runs `kbm build && kbm embed && kbm lint && kbm upload --to s3://kb-prod/`
3. ECS rolling restart pulls new artifacts
4. Time-to-recovery: ~30 min for 1k-doc KB; ~3h for 10k-doc KB

### DR-2 — ElastiCache cluster loss

1. Cache rebuild is automatic — first queries after restart hit the slow path, populate cache
2. Time-to-warm: depends on query traffic; ~6h to get to steady-state hit rate
3. Mitigation during warming: pre-warm with `scripts/cache_warmup.py` against the gold-bench queries

### DR-3 — ECS cluster loss (region failover)

1. Deferred to v2 — v1 is single-region (`us-east-1`)
2. v2 plan: cross-region replicate `s3://kb-prod/` to `us-west-2`; mirror ECS service; Route 53 health-check failover

---

## §13. Definition of Done — runbook shipment (Phase 7)

- [ ] All 8 OPS playbooks readable + actionable in < 5 min
- [ ] Dashboards JSON committed at `docs/dashboards/`
- [ ] Logs Insights queries in §11 verified against a deployed dev environment
- [ ] DR-1 procedure tested via game-day (delete dev bucket, restore from raw, verify queries work)
- [ ] On-call rotation tooling (PagerDuty / Opsgenie) configured to read from these CloudWatch alarms
