# 16 — User UAT Script (8 cases the product owner runs against deployed `dev` env)

> **Purpose** — the contractual "delivered" signal. **A junior agent does NOT mark v0.1.0 shipped until the product owner has signed the §9 block.** Pass/fail on each of 8 cases is mandatory; no partial credit.
>
> **Audience** — product owner. Junior agent runs the cases beforehand to verify they pass; product owner re-runs to confirm.
>
> **Time + cost budget**: ≤ 90 minutes wall-clock; ≤ $2 of OpenAI/Bedrock spend; runs against `s3://kb-dev/` (NOT prod).

---

## §0. Pre-UAT checklist (junior agent runs)

Before handing the UAT script to the product owner:

- [ ] `aws ecs describe-services --cluster kbm --service kbm-search` shows `runningCount: 2`
- [ ] `curl https://kbm-dev.internal/health` returns `{"status":"ok","uptime":<N>}`
- [ ] `curl -H "Authorization: Bearer <DEV_TOKEN>" -X POST https://kbm-dev.internal/status -d '{}'` returns a valid `StatusToolOutput` with both `wiki` and at least one `raw` collection
- [ ] `aws lambda invoke --function-name kbm-nightly-bench /tmp/r.json` returns `{recall@3: ≥ 7.0}`
- [ ] Gold KB has been uploaded: `aws s3 ls s3://kb-dev/manifest.yaml` exists
- [ ] Main bundle's `tests/integration/test_kbm_integration.py` passes against `kbm-dev.internal`

Once all checked: hand this file to the product owner.

---

## §1. Case 1 — "Search the wiki for the kafka runbook"

**Persona:** product owner sitting in the main bundle's chatbot UI; types a question.

**Action:** Ask the chatbot: *"Where's our kafka consumer lag runbook?"*

**Expected:**
- Agent calls `mp_tools.kbm.kbm_query(query="kafka consumer lag")` (verify by checking the agent's trace log)
- Top result has `file` starting with `qmd://wiki/`
- Top result's `score` ≥ 0.85
- Agent's final answer cites `qmd://wiki/kafka-consumer-lag.md` and quotes a passage from it

**Pass criteria:**
- [ ] Correct top result
- [ ] Citation in final answer
- [ ] Total wall-time < 3 seconds

**Fail handling:** check ALB latency dashboard; check `kbm-nightly-bench` for the matching golden query; if `expected_docids_top3` is stale → regenerate; if real regression → block ship.

---

## §2. Case 2 — "Fall back to raw when wiki is silent"

**Persona:** product owner asks about a topic intentionally NOT covered by the wiki.

**Action:** Ask: *"What's in our README file for the engineering folder?"*

**Expected:**
- Agent calls `kbm_query(query="engineering README")` (wiki-only by default)
- Result is empty OR top score < 0.5
- Agent then calls `kbm_query(query="engineering README", collections=["wiki","engineering_raw"])` (fallback per Skill 22)
- Top result is `qmd://engineering_raw/README.md`
- Agent's final answer cites the README

**Pass criteria:**
- [ ] Two query calls visible in trace (wiki first, then expanded)
- [ ] Final citation is the raw README
- [ ] Total wall-time < 5 seconds

**Fail handling:** if agent didn't follow the wiki-first → fallback workflow, the Skill 22 SKILL.md needs strengthening. See `08_main_app_integration.md §4`.

---

## §3. Case 3 — "Multi-get the top 3 results"

**Persona:** product owner asks the agent to gather background.

**Action:** Ask: *"Pull the full text of the kafka runbook AND the BM25 ADR so I can read them side-by-side."*

**Expected:**
- Agent calls `kbm_multi_get(pattern="qmd://wiki/kafka-consumer-lag.md, qmd://engineering_raw/adr/001-bm25-choice.md")`
- Response contains 2 docs (or 1 doc + 1 skipped-with-hint)
- Both bodies are returned in full
- Agent's final answer presents both texts

**Pass criteria:**
- [ ] Both documents in response
- [ ] No `skipped: true` entries unless a doc legitimately exceeds 10KB
- [ ] Total wall-time < 4 seconds

---

## §4. Case 4 — "List what's in a folder"

**Action:** Ask: *"What files are in the engineering runbooks folder?"*

**Expected:**
- Agent calls `kbm_ls(path="engineering_raw/runbooks")`
- Response has `entries` listing the files
- For the gold KB: should include `kafka.md`

**Pass criteria:**
- [ ] Correct entry list
- [ ] `kind` field is `"file"` for `kafka.md`
- [ ] Total wall-time < 1 second (DuckDB scan; should be fast)

---

## §5. Case 5 — "Status check on session start"

**Action:** Start a fresh chatbot session. Ask: *"What's available in the knowledge base?"*

**Expected:**
- Agent calls `kbm_status()` on session start (per Skill 22 default workflow)
- Agent's response lists both `wiki` and `engineering_raw` collections with their doc counts
- Capability gaps (if any) are mentioned

**Pass criteria:**
- [ ] Collection list correct
- [ ] Doc counts match `s3://kb-dev/build_info.json`
- [ ] Total wall-time < 1 second

---

## §6. Case 6 — "Hard query that requires expansion + rerank"

**Action:** Ask: *"How do users get authenticated in our system?"*

**Expected:**
- Agent calls `kbm_query` with no `intent` → triggers expansion (cache miss on first run)
- Result includes `qmd://wiki/authentication.md` at rank 1
- `--explain` trace (if asked for) shows: expansion produced lex/vec/hyde variants; RRF fused 6 ranked lists; gpt-4.1 rerank batched the top-40

**Pass criteria:**
- [ ] Top result is `authentication.md` (per gold KB)
- [ ] Strong-signal bypass DID NOT trigger (intent is implicit but no clear lex match — agent should let expansion run)
- [ ] Total wall-time 500ms-2000ms (cold path)

---

## §7. Case 7 — "Cache hit — second query is fast"

**Action:** Ask the same question as Case 6 again, immediately.

**Expected:**
- Same answer, much faster
- `kbm.query.cache_hit_rate` metric should show 100% on this query

**Pass criteria:**
- [ ] Total wall-time < 100ms
- [ ] Answer text identical to Case 6

**Why this case matters:** validates that Redis cache + Phase 4 implementation work end-to-end. If wall-time isn't < 100ms, the cache key is wrong OR Redis is unreachable.

---

## §8. Case 8 — "Edge case: not found, with similar suggestions"

**Action:** Ask: *"Show me the deployment runbook for our prod service."*

**Expected:**
- KB has NO matching doc (gold KB doesn't have deployment runbooks)
- Agent calls `kbm_query` — returns empty or very low-confidence
- Agent gracefully tells the user: *"I couldn't find a deployment runbook. The closest matches I see are: kafka.md, README.md, ..."*
- Or: agent calls `kbm_get(file="deployment-runbook.md")` → gets `DocumentNotFound` → presents the `similar` suggestions

**Pass criteria:**
- [ ] Agent does NOT hallucinate content
- [ ] Agent presents the similar-files list if any
- [ ] User gets a clear "not found" message

---

## §9. Sign-off block

Mark each box ON the actual deployed `dev` environment after running the above. **All 8 boxes must be ticked.**

```
□ Case 1 — wiki kafka runbook       PASS / FAIL
□ Case 2 — wiki-first → raw fallback PASS / FAIL
□ Case 3 — multi-get                 PASS / FAIL
□ Case 4 — ls folder listing         PASS / FAIL
□ Case 5 — status on session start   PASS / FAIL
□ Case 6 — expansion + rerank        PASS / FAIL
□ Case 7 — cache hit                 PASS / FAIL
□ Case 8 — not-found graceful        PASS / FAIL

Product owner name: ____________________
Date: __________________________________
Signature: ______________________________

Comments / surprises noted during UAT:
________________________________________
________________________________________

Deploy decision:  □ APPROVE prod deploy   □ BLOCK prod deploy (note reason above)
```

---

## §10. Post-UAT actions

If APPROVED:
1. Junior agent triggers `cd.yml` for `prod` env: `git tag kbm-v0.1.0`
2. Push tag; watch ECS prod deploy
3. Wait 5 min; smoke-test prod: `curl https://kbm.internal/health` returns 200
4. Notify main bundle team to flip `KBM_URL` SSM param to prod ALB
5. Wait 5 min; smoke-test main app's `mp_tools.kbm.kbm_query` against prod
6. Mark project DONE; archive issues; close epic

If BLOCKED:
1. Junior agent files an issue per failed case
2. Triage with product owner: what severity (P0 vs P1)?
3. Fix the failing case; repeat UAT from Case 1 (no partial UAT runs allowed)
4. Sign-off block can only be marked when ALL 8 are PASS

---

## §11. Why this UAT exists (the why-not-just-CI argument)

CI tests every function in isolation. CI integration tests verify the API contract.
**Neither catches:** the wiki-first behavior being subtly broken (the agent's prompt could be misinterpreting Skill 22); the chatbot UI presenting results unhelpfully; latency degradation visible to a human; "not found" feeling unhelpful even when technically correct.

These 8 cases simulate the actual user workflow end-to-end, against the actual deployed system, by the actual product owner. **It's the only test that matters at delivery time.**
