# 02 — Repository Scaffold (paste-ready infrastructure for `knowledge_base_management`)

> **Purpose** — every file a junior agent needs before touching `kbm` source. **Paste them in order; after the last one, `make bootstrap && make ci` should succeed on a clean machine.** No file in this document is for design discussion — they are committed decisions per [14_adr_catalog.md](14_adr_catalog.md).

---

## §1. Decisions locked before scaffolding (no junior-agent discretion)

| Decision | Value | Where the ADR lives |
|---|---|---|
| Language | Python **3.12** (pinned exactly, NOT `^3.12`) | ADR-001 |
| Web framework | FastAPI 0.115+ | ADR-002 |
| ASGI server | uvicorn[standard] 0.32+ | ADR-002 |
| Test framework | pytest 8.x + pytest-asyncio + pytest-cov | ADR-003 |
| Lint | ruff 0.7+ (replaces flake8 + isort + pyupgrade) | ADR-003 |
| Format | ruff format (black-compatible) | ADR-003 |
| Type checker | mypy 1.13+ in **strict** mode | ADR-003 |
| Dependency manager | `pip-tools` (`pip-compile`) — NOT Poetry | ADR-001 |
| Container base | `python:3.12-slim-bookworm` | ADR-009 |
| BM25 index | **SQLite FTS5** via stdlib `sqlite3` (NOT `bm25s`) | ADR-004 — supports column weights filepath=1.5/title=4.0/body=1.0 |
| Vector index | **FAISS** (`faiss-cpu`) | ADR-005 |
| Embedding model | **Bedrock Titan-Embed-Text-v2** (1024-dim) | ADR-006 |
| LLM expansion + rerank | **gpt-4.1 via OpenAI SDK** with `response_format` structured outputs | ADR-007 |
| Cache | ElastiCache Redis (`maxmemory-policy=allkeys-lru`, 24h TTL on writes) | ADR-008 |
| Catalog format | **Parquet** via Polars (NOT SQLite documents table) | ADR-010 |
| Auth (v1) | Bearer-token middleware via SSM `kbm/bearer-token` | ADR-011 |
| Logging | `structlog` 24.x with JSON renderer to STDERR | ADR-012 |
| IaC | AWS CDK v2 (Python) | ADR-009 |
| Coverage gate | **90% on changed lines** (10pp higher than main bundle's 85% — kbm is signature-algorithm-heavy) | ADR-013 |
| Commit style | Conventional Commits (`feat:`, `fix:`, `chore:`, `test:`) | ADR-014 |

If you disagree, **read the matching ADR first**, then if still disagree open an issue tagged `decision-needed`. Never silently diverge.

---

## §2. Directory tree (verbatim — `tree -L 4 --dirsfirst` output after bootstrap)

```
knowledge_base_management/
├── .github/
│   ├── workflows/
│   │   ├── ci.yml
│   │   └── cd.yml
│   ├── pull_request_template.md
│   └── CODEOWNERS
├── cdk/
│   ├── app.py
│   ├── stack.py
│   └── cdk.json
├── docs/
│   ├── schemas/                           # auto-generated JSON-schema dumps
│   └── design.md                          # links back to bundle files 00-16
├── scripts/
│   ├── check_chunker_constants.py
│   ├── check_break_patterns.py
│   ├── check_retrieval_constants.py
│   ├── check_mcp_tool_descriptions_unchanged.py
│   ├── check_schemas_unchanged.py
│   ├── check_s3_layout.py
│   ├── check_no_print_in_prod.py
│   ├── check_coverage_changed_lines.py
│   ├── dump_schemas.py
│   ├── regenerate_demo_data.py
│   └── nightly_bench.py
├── src/
│   └── kbm/
│       ├── __init__.py
│       ├── types.py                       # all Pydantic models (Phase 1)
│       ├── constants.py                   # chunker + retrieval constants (Phase 1)
│       ├── settings.py                    # pydantic-settings (Phase 0)
│       ├── logger.py                      # structlog setup (Phase 0)
│       ├── exceptions.py                  # exception hierarchy (Phase 1)
│       ├── shared/
│       │   ├── __init__.py
│       │   ├── docid.py                   # sha256 + 6-char prefix (Phase 1)
│       │   ├── paths.py                   # virtual-path qmd:// helpers (Phase 1)
│       │   └── token_count.py             # tiktoken wrapper (Phase 1)
│       ├── build/                         # Phase 1-2
│       │   ├── __init__.py
│       │   ├── chunker.py                 # ⭐⭐ smart chunker (Phase 1)
│       │   ├── ast_chunker.py             # tree-sitter merge (Phase 1)
│       │   ├── manifest.py                # YAML load/validate
│       │   ├── walker.py                  # walk + hash + write content-addressable
│       │   ├── embedder.py                # Bedrock Titan client
│       │   ├── fts5_builder.py            # per-collection SQLite FTS5
│       │   ├── faiss_builder.py           # per-collection FAISS index
│       │   ├── lint.py                    # Lint9Validator
│       │   ├── uploader.py                # aws s3 sync with ETag check
│       │   └── cli.py                     # Click CLI: kbm build/embed/lint/...
│       ├── search/                        # Phase 4
│       │   ├── __init__.py
│       │   ├── store.py                   # KBStore (holds FTS5 + FAISS handles)
│       │   ├── s3.py                      # S3 reader + local-disk cache
│       │   ├── fts.py                     # search_fts (BM25)
│       │   ├── vec.py                     # search_vec (FAISS cosine)
│       │   ├── rrf.py                     # ⭐⭐ Reciprocal Rank Fusion
│       │   ├── blend.py                   # ⭐⭐ position-aware blend
│       │   ├── expand.py                  # gpt-4.1 expansion
│       │   ├── rerank.py                  # gpt-4.1 batch rerank
│       │   ├── snippet.py                 # snippet extract + intent weight
│       │   ├── context.py                 # path-prefix context lookup
│       │   ├── cache.py                   # Redis SHA-256-keyed cache
│       │   ├── query.py                   # full pipeline orchestrator
│       │   ├── get.py
│       │   ├── multi_get.py
│       │   ├── status.py
│       │   └── ls.py
│       ├── mcp/                           # Phase 3
│       │   ├── __init__.py
│       │   ├── server.py                  # FastAPI app + routes
│       │   ├── tools.py                   # 4 MCP tool descriptors (verbatim)
│       │   ├── auth.py                    # bearer-token middleware
│       │   ├── health.py                  # GET /health + GET /ready
│       │   └── instructions.py            # buildInstructions port
│       └── obs/                           # Phase 5
│           ├── __init__.py
│           ├── metrics.py                 # 8 CloudWatch counters
│           └── breakers.py                # circuit breakers
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── unit/
│   │   ├── test_chunker.py
│   │   ├── test_manifest.py
│   │   ├── test_lint.py
│   │   ├── test_rrf.py
│   │   ├── test_blend.py
│   │   ├── test_fts.py
│   │   ├── test_vec.py
│   │   ├── test_expand.py
│   │   ├── test_rerank.py
│   │   ├── test_snippet.py
│   │   ├── test_docid.py
│   │   └── test_paths.py
│   ├── integration/
│   │   ├── test_build_pipeline.py
│   │   ├── test_mcp_endpoints.py
│   │   └── test_query_pipeline.py
│   ├── e2e/
│   │   └── test_full_kb_lifecycle.py
│   └── fixtures/
│       ├── corpora/
│       │   ├── lint_clean/
│       │   ├── lint_broken/
│       │   └── bench_golden/
│       ├── golden_chunks/
│       ├── recorded_openai/
│       └── recorded_bedrock/
├── .dockerignore
├── .env.example
├── .gitignore
├── .pre-commit-config.yaml
├── Dockerfile
├── Makefile
├── pyproject.toml
├── pytest.ini
├── README.md
├── conftest.py
├── requirements.in
├── requirements.txt
├── requirements-dev.in
└── requirements-dev.txt
```

---

## §3. `.gitignore` — verbatim

```gitignore
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
*.egg-info/
.installed.cfg
*.egg
.eggs/
dist/
build/
.venv/
venv/
env/

# Test & coverage
.pytest_cache/
.coverage
coverage.xml
htmlcov/
.mutmut-cache
.mypy_cache/
.ruff_cache/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Local data & secrets
.env
*.local.yaml
*.local.json
local_kb/
local_cache/

# CDK
cdk.out/
cdk.context.json

# Auto-generated
docs/schemas/*.json
```

---

## §4. `.dockerignore` — verbatim

```dockerignore
.git
.github
.venv
.env
.env.local
.pytest_cache
.mypy_cache
.ruff_cache
__pycache__
*.pyc
tests/
docs/
cdk/
scripts/regenerate_demo_data.py
scripts/nightly_bench.py
local_kb/
local_cache/
cdk.out/
README.md
*.md
```

---

## §5. `.env.example` — verbatim

```dotenv
# === Environment ===
KBM_ENV=local                                    # local | dev | staging | prod
KBM_LOG_LEVEL=INFO                               # DEBUG | INFO | WARN | ERROR

# === AWS ===
AWS_REGION=us-east-1
KBM_S3_BUCKET=kb-local                           # local: LocalStack; dev/prod: real S3
KBM_S3_ENDPOINT_URL=http://localhost:4566        # LocalStack only — unset in dev/prod

# === Bedrock (embeddings) ===
KBM_EMBED_MODEL_ID=amazon.titan-embed-text-v2:0
KBM_EMBED_DIM=1024

# === OpenAI (expansion + rerank) ===
KBM_OPENAI_API_KEY=sk-...                        # prod reads from SSM kbm/openai-api-key
KBM_EXPAND_MODEL=gpt-4.1
KBM_RERANK_MODEL=gpt-4.1

# === Redis ===
KBM_REDIS_URL=redis://localhost:6379/0
KBM_CACHE_TTL_SECONDS=86400                      # 24h

# === Auth ===
KBM_BEARER_TOKEN=dev-only-change-me              # prod reads from SSM kbm/bearer-token

# === Chunker (DO NOT CHANGE without ADR — see 05_chunker_spec.md) ===
KBM_CHUNK_SIZE_TOKENS=900
KBM_CHUNK_OVERLAP_TOKENS=135
KBM_CHUNK_WINDOW_TOKENS=200

# === Retrieval (DO NOT CHANGE without ADR — see 06_retrieval_pipeline_spec.md) ===
KBM_RRF_K=60
KBM_RERANK_CANDIDATE_LIMIT=40
KBM_STRONG_SIGNAL_MIN_SCORE=0.85
KBM_STRONG_SIGNAL_MIN_GAP=0.15
KBM_ORIGINAL_QUERY_WEIGHT=2.0

# === Local cache ===
KBM_LOCAL_CACHE_DIR=/var/cache/kbm               # ECS; ./local_cache on laptop
KBM_LOCAL_CACHE_TTL_SECONDS=3600                 # 1h ETag refresh cadence

# === API ===
KBM_API_HOST=0.0.0.0
KBM_API_PORT=8080
```

---

## §6. `pyproject.toml` — verbatim

```toml
[build-system]
requires = ["setuptools>=68", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "knowledge-base-management"
version = "0.0.1"
description = "Hybrid BM25+FAISS knowledge base management toolbox for AWS ECS"
requires-python = "==3.12.*"
readme = "README.md"
license = { text = "Proprietary" }
authors = [{ name = "Yi Li" }]
dynamic = ["dependencies", "optional-dependencies"]

[project.scripts]
kbm = "kbm.build.cli:main"
kbm-server = "kbm.mcp.server:run"

[tool.setuptools.packages.find]
where = ["src"]

[tool.setuptools.package-data]
kbm = ["py.typed"]

# === Ruff ===
[tool.ruff]
target-version = "py312"
line-length = 120
src = ["src", "tests"]

[tool.ruff.lint]
select = ["E", "W", "F", "I", "B", "C4", "UP", "N", "ASYNC", "S", "T20", "RET", "SIM", "RUF"]
ignore = ["S101", "S311"]

[tool.ruff.lint.per-file-ignores]
"tests/**/*.py" = ["S101", "S105", "S106", "T201"]
"src/kbm/build/cli.py" = ["T201"]

[tool.ruff.format]
quote-style = "double"
indent-style = "space"
line-ending = "lf"

# === Mypy ===
[tool.mypy]
python_version = "3.12"
strict = true
warn_unreachable = true
disallow_any_generics = true
no_implicit_reexport = true
plugins = ["pydantic.mypy"]

[[tool.mypy.overrides]]
module = "faiss.*"
ignore_missing_imports = true

[[tool.mypy.overrides]]
module = "tree_sitter.*"
ignore_missing_imports = true

# === Pytest ===
[tool.pytest.ini_options]
minversion = "8.0"
testpaths = ["tests"]
addopts = [
  "--strict-markers",
  "--strict-config",
  "-ra",
  "--cov=src/kbm",
  "--cov-report=term-missing:skip-covered",
  "--cov-report=xml",
  "--cov-fail-under=85",
]
asyncio_mode = "auto"
markers = [
  "unit: fast pure-Python unit tests",
  "integration: requires LocalStack S3 + mock OpenAI",
  "e2e: end-to-end against full kbm pipeline",
  "live_openai: hits real OpenAI API — nightly only",
  "live_bedrock: hits real Bedrock API — nightly only",
]

# === Coverage ===
[tool.coverage.run]
source = ["src/kbm"]
branch = true
omit = ["src/kbm/__init__.py", "src/kbm/build/cli.py"]

[tool.coverage.report]
exclude_lines = [
  "pragma: no cover",
  "raise NotImplementedError",
  "if __name__ == .__main__.:",
  "if TYPE_CHECKING:",
]
```

---

## §7. `requirements.in` — verbatim

```pip
# Web
fastapi==0.115.0
uvicorn[standard]==0.32.0

# Settings + logging
pydantic==2.8.0
pydantic-settings==2.5.0
structlog==24.4.0

# CLI
click==8.1.7

# Data
polars==1.5.0
duckdb==1.0.0
pyarrow==17.0.0
pyyaml==6.0.2

# Hybrid search
faiss-cpu==1.8.0
# sqlite3 is stdlib — no install needed

# Embeddings + LLM
boto3==1.35.0
openai==1.50.0
tiktoken==0.7.0

# AST chunking
tree-sitter==0.23.0
tree-sitter-python==0.23.0
tree-sitter-typescript==0.23.0
tree-sitter-go==0.23.0
tree-sitter-rust==0.24.0

# Cache + glob
redis==5.0.8
pathspec==0.12.0

# AWS
aws-cdk-lib==2.155.0
constructs==10.3.0
```

---

## §8. `requirements-dev.in` — verbatim

```pip
-r requirements.in

# Test
pytest==8.3.0
pytest-asyncio==0.24.0
pytest-cov==5.0.0

# Lint + type
ruff==0.7.0
mypy==1.13.0
pydantic[mypy]
types-pyyaml==6.0.12.20240808
types-redis==4.6.0.20240903
boto3-stubs[s3,bedrock-runtime,ssm]==1.35.0

# LocalStack
localstack-client==2.7.0
testcontainers==4.8.0

# Mutation
mutmut==2.4.5

# Pre-commit
pre-commit==4.0.0
```

---

## §9. `Dockerfile` — verbatim

```dockerfile
# syntax=docker/dockerfile:1.7
FROM python:3.12-slim-bookworm AS base

ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    PIP_NO_CACHE_DIR=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1

RUN apt-get update && apt-get install -y --no-install-recommends \
      ca-certificates \
      curl \
      build-essential \
      libgomp1 \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

FROM base AS builder
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM base AS runtime
RUN groupadd -r kbm --gid 1000 \
    && useradd -r -g kbm -u 1000 -d /app -s /bin/false kbm \
    && mkdir -p /var/cache/kbm \
    && chown -R kbm:kbm /app /var/cache/kbm

COPY --from=builder /usr/local/lib/python3.12/site-packages /usr/local/lib/python3.12/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin

COPY --chown=kbm:kbm src/ /app/src/
COPY --chown=kbm:kbm pyproject.toml /app/

USER kbm

HEALTHCHECK --interval=30s --timeout=5s --start-period=60s --retries=3 \
  CMD curl -fsS http://localhost:8080/health || exit 1

EXPOSE 8080

CMD ["uvicorn", "kbm.mcp.server:app", "--host", "0.0.0.0", "--port", "8080", "--workers", "1"]
```

---

## §10. `Makefile` — verbatim

```makefile
.PHONY: bootstrap clean lint format type-check test test-unit test-integration test-e2e mutate ci check-drift build run-server run-cli cdk-synth cdk-deploy schemas regenerate-demo

bootstrap:
	python -m venv .venv
	. .venv/bin/activate && pip install --upgrade pip pip-tools
	. .venv/bin/activate && pip-compile requirements.in -o requirements.txt
	. .venv/bin/activate && pip-compile requirements-dev.in -o requirements-dev.txt
	. .venv/bin/activate && pip install -r requirements-dev.txt
	. .venv/bin/activate && pip install -e .
	. .venv/bin/activate && pre-commit install
	@echo "Bootstrap complete. Activate with: source .venv/bin/activate"

clean:
	rm -rf .venv .pytest_cache .mypy_cache .ruff_cache .mutmut-cache .coverage coverage.xml htmlcov dist build *.egg-info cdk.out

lint:
	ruff check src tests
	ruff format --check src tests

format:
	ruff format src tests
	ruff check --fix src tests

type-check:
	mypy src

test-unit:
	pytest tests/unit -m unit

test-integration:
	pytest tests/integration -m integration

test-e2e:
	pytest tests/e2e -m e2e

test: test-unit test-integration

mutate:
	mutmut run --paths-to-mutate=src/kbm/build/chunker.py,src/kbm/search/rrf.py,src/kbm/search/blend.py,src/kbm/search/query.py
	mutmut results

check-drift:
	python scripts/check_chunker_constants.py
	python scripts/check_break_patterns.py
	python scripts/check_retrieval_constants.py
	python scripts/check_mcp_tool_descriptions_unchanged.py
	python scripts/check_schemas_unchanged.py
	python scripts/check_s3_layout.py
	python scripts/check_no_print_in_prod.py

ci: lint type-check check-drift test
	@echo "CI passed."

schemas:
	python scripts/dump_schemas.py
	@git diff --exit-code docs/schemas/ || (echo "Schemas changed — commit the diff." && exit 1)

regenerate-demo:
	python scripts/regenerate_demo_data.py

build:
	docker build -t kbm:local .

run-server:
	uvicorn kbm.mcp.server:app --host 0.0.0.0 --port 8080 --reload

run-cli:
	python -m kbm.build.cli $(ARGS)

cdk-synth:
	cd cdk && cdk synth

cdk-deploy:
	cd cdk && cdk deploy --require-approval never KbmStack-$(ENV)

cdk-diff:
	cd cdk && cdk diff KbmStack-$(ENV)
```

---

## §11. `.pre-commit-config.yaml` — verbatim

```yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.7.0
    hooks:
      - id: ruff
        args: [--fix]
      - id: ruff-format

  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v5.0.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
      - id: check-added-large-files
        args: ['--maxkb=500']
      - id: check-merge-conflict
      - id: detect-private-key
      - id: no-commit-to-branch
        args: ['--branch', 'main']

  - repo: local
    hooks:
      - id: check-no-print
        name: No print() in production code
        entry: python scripts/check_no_print_in_prod.py
        language: system
        files: ^src/
        pass_filenames: false
```

---

## §12. `.github/workflows/ci.yml` — verbatim

```yaml
name: CI

on:
  pull_request:
    branches: [main]
  push:
    branches: [main]

jobs:
  ci:
    runs-on: ubuntu-22.04
    timeout-minutes: 20
    services:
      redis:
        image: redis:7-alpine
        ports: [6379:6379]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - name: Install pip-tools
        run: pip install pip-tools
      - name: Verify requirements are up-to-date
        run: |
          pip-compile requirements.in -o requirements.txt --quiet
          pip-compile requirements-dev.in -o requirements-dev.txt --quiet
          git diff --exit-code requirements*.txt || (echo "requirements*.txt out of date" && exit 1)
      - name: Install deps
        run: pip install -r requirements-dev.txt && pip install -e .
      - name: Lint
        run: |
          ruff check src tests
          ruff format --check src tests
      - name: Type check
        run: mypy src
      - name: Drift checks
        run: make check-drift
      - name: Start LocalStack
        run: |
          docker run -d --name localstack -p 4566:4566 \
            -e SERVICES=s3,ssm,secretsmanager,cloudwatch \
            localstack/localstack:3.7
          for i in {1..30}; do
            curl -fsS http://localhost:4566/_localstack/health && break
            sleep 2
          done
      - name: Unit + integration tests
        env:
          KBM_S3_BUCKET: kb-test
          KBM_S3_ENDPOINT_URL: http://localhost:4566
          KBM_REDIS_URL: redis://localhost:6379/0
          KBM_OPENAI_API_KEY: sk-test-mock
        run: pytest tests/unit tests/integration --cov-fail-under=85
      - name: Coverage check on changed lines
        run: python scripts/check_coverage_changed_lines.py --min 90
      - name: Upload coverage
        uses: codecov/codecov-action@v4
        if: always()
        with: { file: ./coverage.xml }
```

---

## §13. `.github/workflows/cd.yml` — verbatim

```yaml
name: CD

on:
  push:
    branches: [main]
    tags: ['kbm-v*']

permissions:
  id-token: write
  contents: read

jobs:
  deploy-dev:
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-22.04
    timeout-minutes: 30
    environment: dev
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_DEPLOY_ROLE_DEV }}
          aws-region: us-east-1
      - uses: aws-actions/amazon-ecr-login@v2
      - name: Build + push image
        run: |
          docker build -t $ECR_REPO:$GITHUB_SHA .
          docker push $ECR_REPO:$GITHUB_SHA
        env: { ECR_REPO: "${{ secrets.ECR_REPO_DEV }}" }
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - name: CDK deploy
        run: |
          pip install -r requirements-dev.txt
          cd cdk && cdk deploy --require-approval never KbmStack-dev
        env: { IMAGE_TAG: "${{ github.sha }}" }
      - name: Smoke test /health
        run: |
          for i in {1..30}; do
            STATUS=$(curl -s -o /dev/null -w "%{http_code}" $ALB_DNS/health)
            if [ "$STATUS" = "200" ]; then exit 0; fi
            sleep 5
          done
          echo "/health did not return 200 within 150s"; exit 1
        env: { ALB_DNS: "${{ secrets.ALB_DNS_DEV }}" }

  deploy-prod:
    if: startsWith(github.ref, 'refs/tags/kbm-v')
    needs: deploy-dev
    runs-on: ubuntu-22.04
    timeout-minutes: 30
    environment: prod
    steps:
      - run: echo "Same shape as deploy-dev; swap *_DEV → *_PROD"
```

---

## §14. `.github/pull_request_template.md` — verbatim

```markdown
## Summary

(1-2 sentences. What changed and why.)

## Phase

- [ ] Phase 0 — Setup
- [ ] Phase 1 — Foundation (data contracts + chunker)
- [ ] Phase 2 — Build half
- [ ] Phase 3 — MCP layer
- [ ] Phase 4 — Search half
- [ ] Phase 5 — Observability + IaC
- [ ] Phase 6 — Main-app integration
- [ ] Phase 7 — UAT + deploy

## TDD evidence

- [ ] **Failing test in a commit BEFORE implementation commit** — link the commit: ______
- [ ] All new Pytest functions have Given/When/Then docstrings
- [ ] Coverage on changed lines ≥ 90%
- [ ] If touched signature algorithm: mutation survival ≥ 90% (`make mutate`)

## Drift check

- [ ] `make check-drift` passes locally
- [ ] If a constant changed: ADR added to `14_adr_catalog.md` in this PR AND bundle file (05/06/etc.) updated in the same PR

## Verbatim-port assertions (Phase 1 / Phase 4)

- [ ] Chunker constants byte-equal: `CHUNK_SIZE_TOKENS=900`, `CHUNK_OVERLAP_TOKENS=135`, `CHUNK_WINDOW_TOKENS=200`
- [ ] `BREAK_PATTERNS` table = 12 entries verbatim
- [ ] Retrieval constants byte-equal: `RRF_K=60`, `RERANK_CANDIDATE_LIMIT=40`, `STRONG_SIGNAL_MIN_SCORE=0.85`, `STRONG_SIGNAL_MIN_GAP=0.15`, `ORIGINAL_QUERY_WEIGHT=2.0`
- [ ] Top-rank bonus: `+0.05` rank-0, `+0.02` rank ≤ 2
- [ ] Position-blend: `0.75` (1-3), `0.60` (4-10), `0.40` (11+)

## Acceptance criteria

(Paste the rows from `10_tdd_acceptance.md` this PR satisfies.)

## Test plan

- [ ] Local: `make ci`
- [ ] If build half: `kbm build && kbm embed && kbm lint` on `tests/fixtures/corpora/lint_clean/`
- [ ] If MCP layer: `curl -X POST localhost:8080/mcp -d '...'` returns expected
- [ ] If search half: golden bench query returns expected `expected_in_top_3`
```

---

## §15. `.github/CODEOWNERS` — verbatim

```
*                                       @kbm-maintainers
/05_chunker_spec.md                     @kbm-architects
/06_retrieval_pipeline_spec.md          @kbm-architects
/14_adr_catalog.md                      @kbm-architects
/08_main_app_integration.md             @kbm-maintainers @target-bundle-maintainers
```

---

## §16. `README.md` — verbatim

```markdown
# knowledge_base_management (kbm)

Hybrid BM25 + FAISS knowledge-base toolbox for the `target_product_bundle` chatbot.
Ports doc_search's signature retrieval algorithms (smart chunking, RRF with top-rank
bonus, position-aware blend, strong-signal bypass) from TypeScript to Python on AWS ECS.

## Quick start

\```bash
make bootstrap
source .venv/bin/activate

kbm build --manifest manifest.yaml --output ./local_kb
kbm embed --manifest manifest.yaml --output ./local_kb
kbm lint --output ./local_kb                       # exits 1 on errors
kbm plan-upload --output ./local_kb --to s3://kb-dev/
kbm upload --output ./local_kb --to s3://kb-dev/

docker compose -f docker-compose.local.yml up -d   # LocalStack + Redis
make run-server                                    # uvicorn on :8080

make test
\```

## Documentation

Start with [`00_start_here.md`](00_start_here.md) — the junior agent playbook.

The 17-file contractual bundle (00-16) is the design source of truth, backed by a
verified deep-dive of the doc_search reference product at [`../../doc_search_tool/`]
and an audit-and-corrections trail at [`../../doc_search_tool/24_audit_and_corrections.md`].
```

---

## §17. `pytest.ini` — verbatim

```ini
# Empty by design — config lives in pyproject.toml [tool.pytest.ini_options]
# This file exists only so pytest discovery picks up the package as a project root.
```

---

## §18. Root `conftest.py` — verbatim

```python
"""Root conftest — minimal. Real fixtures live in tests/conftest.py.

This file only ensures `src/` is importable from any test file.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))
```

---

## §19. `src/kbm/__init__.py` — verbatim

```python
"""knowledge_base_management — hybrid BM25 + FAISS KB toolbox."""

__version__ = "0.0.1"
```

---

## §20. `src/kbm/settings.py` (Phase 0) — verbatim

```python
"""Settings — single source of env-var truth.

Every env-var the package reads is declared here. Tuning-locked constants
(chunker + retrieval) live in src/kbm/constants.py, NOT in env vars.
"""

from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="KBM_",
        case_sensitive=False,
        extra="forbid",
    )

    env: Literal["local", "dev", "staging", "prod"] = "local"
    log_level: Literal["DEBUG", "INFO", "WARN", "ERROR"] = "INFO"

    aws_region: str = "us-east-1"
    s3_bucket: str = "kb-local"
    s3_endpoint_url: str | None = None

    embed_model_id: str = "amazon.titan-embed-text-v2:0"
    embed_dim: int = 1024

    openai_api_key: SecretStr = Field(default_factory=lambda: SecretStr(""))
    expand_model: str = "gpt-4.1"
    rerank_model: str = "gpt-4.1"

    redis_url: str = "redis://localhost:6379/0"
    cache_ttl_seconds: int = 86400

    bearer_token: SecretStr = Field(default_factory=lambda: SecretStr("dev-only"))

    api_host: str = "0.0.0.0"
    api_port: int = 8080

    local_cache_dir: str = "/var/cache/kbm"
    local_cache_ttl_seconds: int = 3600


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
```

---

## §21. `src/kbm/logger.py` (Phase 0) — verbatim

```python
"""Structured logger — JSON to STDERR (NOT stdout).

The MCP stdio transport requires stdout for JSON-RPC framing. Logging to stdout
corrupts the frame. ECS collects from both streams equally.
"""

import logging
import sys

import structlog

from kbm.settings import get_settings


def setup_logging() -> None:
    s = get_settings()
    level = getattr(logging, s.log_level)
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    return structlog.get_logger(name)
```

---

## §22. `scripts/check_no_print_in_prod.py` — verbatim

```python
"""CI guard: no `print()` calls in src/ (use structlog). Exits 1 if any found.

Exempted: src/kbm/build/cli.py — Click's echo replaces print but raw print() is OK
because the CLI is meant to be human-driven.
"""

import re
import sys
from pathlib import Path

EXEMPT = {"src/kbm/build/cli.py"}
pat = re.compile(r"^\s*print\(", re.MULTILINE)

violations: list[str] = []
for path in Path("src").rglob("*.py"):
    if str(path).replace("\\", "/") in EXEMPT:
        continue
    text = path.read_text(encoding="utf-8")
    for m in pat.finditer(text):
        line_no = text[: m.start()].count("\n") + 1
        violations.append(f"{path}:{line_no}: print() in production code")

if violations:
    print("\n".join(violations), file=sys.stderr)
    sys.exit(1)
```

---

## §23. Bootstrap verification

After pasting all files above, run:

```bash
make bootstrap
make ci
```

Expected output (on empty `src/kbm/` except for what §19-§21 add):

```
ruff check src tests              # passes
ruff format --check src tests     # passes
mypy src                          # passes
make check-drift                  # all 7 scripts pass (no source yet, so no drift to find)
pytest tests/unit tests/integration  # 0 tests collected, no errors
```

If any step fails, the issue is in this scaffold — open an issue tagged `scaffold-bug` and DO NOT proceed to Phase 1.

**Phase 0 Definition of Done:** above output achieved on a clean machine + PR opened + reviewer-approved + tagged `kbm-v0.0.1-infra` on `main`.

→ Continue to [`03_data_contracts.md`](03_data_contracts.md) for Phase 1.
