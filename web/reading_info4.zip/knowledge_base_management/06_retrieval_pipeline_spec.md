# 06 — Retrieval Pipeline Spec (signature ⭐⭐ — verbatim port)

> **Purpose** — byte-level contract for `src/kbm/search/{fts.py, vec.py, rrf.py, blend.py, expand.py, rerank.py, snippet.py, query.py}`. Every constant in this file is verified against `../doc_search_tool/24_audit_and_corrections.md §1` rows 5-12, 17-25. **Verbatim port: do not invent.**
>
> **Why ⭐⭐**: this is the hybrid pipeline that makes BM25 + FAISS + gpt-4.1 deliver more than the sum of its parts. Failure modes are subtle — RRF k=60 + top-rank bonus + position-blend + strong-signal bypass are mutually-tuned. Change one without changing the others and quality silently degrades.

---

## §1. The 10-step pipeline (the master picture)

```
Input: QueryToolInput (query OR searches[], intent?, collections?, limit, rerank?)
  │
  ▼
[Step 0]  Default collections   ── if input.collections is None: use store.default_collection_names()
  │
  ▼
[Step 1]  Strong-signal bypass  ── ONE searchFTS call against the (one) collection (or whole corpus)
  │                                if top.score ≥ 0.85 AND (top − next) ≥ 0.15 AND intent is None
  │                                AND len(collections) ≤ 1 → SKIP STEPS 2-3, go to Step 6
  ▼ (no strong signal)
[Step 2]  Query expansion       ── gpt-4.1 + Pydantic structured output → list[ExpandedQuery]
  │                                cache check first (Redis SHA-256 key)
  │                                always prepend [{type:"lex",query:opts.query},{type:"vec",query:opts.query}]
  ▼
[Step 3]  Parallel retrieval    ── asyncio.gather over (collection × sub_query)
  │                                lex   → search_fts(coll, q, limit=20)
  │                                vec   → search_vec(coll, q, limit=20)
  │                                hyde  → search_vec(coll, q, limit=20)  # vec over hypothetical answer
  │                                Output: list[list[SearchResult]] (N_collections × M_subqueries lists)
  ▼
[Step 4]  RRF fusion            ── k=60; weights: original-query lists 2.0, expansions 1.0
  │                                top-rank bonus: +0.05 (rank 0), +0.02 (rank 1 or 2)
  │                                Output: list[RankedResult] sorted by rrf_score desc
  ▼
[Step 5]  Candidate cap         ── keep top 40 (RERANK_CANDIDATE_LIMIT)
  │
  ▼
[Step 6]  Best chunk per cand   ── for each candidate: chunk_document_async + intent-weighted pick
  │                                Output: list[(file, best_chunk_text)]
  ▼
[Step 7]  Rerank (optional)     ── if input.rerank=True and len(candidates) > 1:
  │                                  gpt-4.1 ONE batch call, all 40 (q,chunk) pairs
  │                                  cache content-keyed (SHA-256 of query+chunk_text)
  │                                  Output: list[float] aligned with candidates
  │                                else: skip (rerank_scores = [None] * N)
  ▼
[Step 8]  Position-aware blend  ── for rrf_rank (1-indexed):
  │                                  rrf_weight = 0.75 (1-3) | 0.60 (4-10) | 0.40 (11+)
  │                                  blended = rrf_weight * (1/rrf_rank) + (1-rrf_weight) * rerank_score
  │                                  Re-sort by blended_score desc
  ▼
[Step 9]  Snippet + context     ── extract_snippet (intent-weighted) + get_context_for_file
  │
  ▼
Output: QueryToolOutput with results, total_candidates, bypass_reason, latency_ms
```

---

## §2. Strong-signal bypass (Step 1) — the port discrepancy

**Verbatim from doc_search `store.ts:4298-4305`:**

```python
# src/kbm/search/query.py
async def _check_strong_signal_bypass(
    store: KBStore,
    query: str,
    intent: str | None,
    collections: list[str],
) -> list[SearchResult] | None:
    """Returns the FTS results if strong signal triggers, else None.

    HC-7 + ADR-014: doc_search's hybridQuery runs ONE searchFTS against a single
    optional collection (store.ts:4298). For kbm we keep that behavior: bypass
    only fires when len(collections) <= 1.

    For multi-collection queries (len > 1), we DO NOT run a parallel cross-
    collection probe. The decision is documented in ADR-014; the alternative
    (parallel probe + global top-2) was rejected because it would change the
    quality semantics of bypass (one collection's strong signal can mask another's
    relevant doc).
    """
    if intent is not None:
        return None
    if len(collections) > 1:
        return None
    coll = collections[0] if collections else None
    initial = await asyncio.to_thread(store.search_fts, coll, query, 10)
    if len(initial) < 2:
        return None
    top, second = initial[0].score, initial[1].score
    if top >= STRONG_SIGNAL_MIN_SCORE and (top - second) >= STRONG_SIGNAL_MIN_GAP:
        return initial
    return None
```

**Constants (HC-1):**

```python
# src/kbm/constants.py
STRONG_SIGNAL_MIN_SCORE = 0.85    # 24_audit §1 row 5
STRONG_SIGNAL_MIN_GAP   = 0.15    # 24_audit §1 row 5
```

---

## §3. Query expansion (Step 2)

### §3.1 gpt-4.1 prompt (verbatim — port of GEPA best_prompt + the `/no_think` Qwen3 prompt)

The Python ECS port **uses gpt-4.1 with the verbatim GEPA prompt** (per `../doc_search_tool/20_llm_payload_evidence.md §3.6`). Do NOT replicate the `/no_think` Qwen3 idiom — gpt-4.1 doesn't have a thinking mode to suppress.

```python
# src/kbm/search/expand.py
EXPAND_SYSTEM_PROMPT = """\
You are an assistant that expands a given search query into lexical (lex), vector (vec), and HYDE expansions for improved search retrieval.

## Input Format
You will receive input in this exact format:
```
## Inputs
### query
[the search query]
```

## Output Format
Respond ONLY with this exact format, nothing else:
```
## Generated Outputs
### expansion
lex: [short keyword phrase 1]
lex: [short keyword phrase 2]
lex: [short keyword phrase 3]
vec: [medium phrasal expansion 1]
vec: [medium phrasal expansion 2]
vec: [medium phrasal expansion 3]
hyde: [concise hypothetical document snippet, SINGLE LINE, under 150 characters total]
```

## Generation Rules
- **Exactly 3 lex lines**: Short (2-5 words), keyword-like expansions. MUST include core query terms or direct synonyms/variants (e.g., for "web mail", include "webmail"). Focus on key entities, actions, or concepts.
- **Exactly 3 vec lines**: Medium-length (4-8 words) natural language phrases capturing query intent, aspects, or related searches.
- **Exactly 1 hyde line**: A single, fluent sentence acting as a hypothetical relevant document passage. Keep STRICTLY under 150 characters (aim for 100-140). Be descriptive but concise—no lists, no examples unless essential.
- Strategy: Break down the query into synonyms (lex), semantic rephrasings (vec), and a compact informative summary (hyde) to cover lexical, embedding, and dense retrieval signals.
- Match query intent precisely; expand to related high-relevance terms without hallucinating unrelated content.
"""
```

**Drift-checker:** `scripts/check_prompts_unchanged.py` asserts byte-equality between this constant and the file `../doc_search_tool/finetune/experiments/gepa/best_prompt.txt`.

### §3.2 Structured-output Pydantic schema (replaces GBNF)

```python
# src/kbm/search/expand.py
from pydantic import BaseModel, Field
from typing import Literal


class ExpandedLine(BaseModel):
    type: Literal["lex", "vec", "hyde"]
    query: str = Field(min_length=1, max_length=200)


class ExpansionResult(BaseModel):
    lines: list[ExpandedLine] = Field(min_length=1, max_length=10)
```

### §3.3 OpenAI call shape

```python
async def expand_query(
    client: AsyncOpenAI,
    cache: Cache,
    query: str,
    intent: str | None = None,
    model: str = "gpt-4.1",
) -> list[ExpandedQuery]:
    """Returns 1-7 expanded queries. Falls back to [{lex:q},{vec:q}] on failure.

    Caches result via SHA-256(url + sorted-JSON body) for 24h.
    """
    cache_key_str = cache_key("expandQuery", {"query": query, "model": model, **({"intent": intent} if intent else {})})
    if (cached := await cache.get(f"kbm:{settings.env}:expand:{cache_key_str}")) is not None:
        return [ExpandedQuery(**d) for d in json.loads(cached)]

    user_msg = f"## Inputs\n### query\n{query}\n"
    if intent:
        user_msg += f"### intent\n{intent}\n"

    try:
        resp = await client.beta.chat.completions.parse(
            model=model,
            messages=[
                {"role": "system", "content": EXPAND_SYSTEM_PROMPT},
                {"role": "user",   "content": user_msg},
            ],
            response_format=ExpansionResult,
            temperature=EXPAND_TEMPERATURE,
            max_tokens=EXPAND_MAX_TOKENS,
        )
        result = resp.choices[0].message.parsed
        assert result is not None
        # Anti-hallucination filter — port of llm.ts:1342-1346 hasQueryTerm
        query_tokens = set(re.findall(r'\w+', query.lower()))
        kept: list[ExpandedQuery] = []
        for line in result.lines:
            line_tokens = set(re.findall(r'\w+', line.query.lower()))
            if not query_tokens or (query_tokens & line_tokens):
                kept.append(ExpandedQuery(type=line.type, query=line.query))
        if not kept:
            # Fallback chain — port of llm.ts:1362-1366
            kept = [
                ExpandedQuery(type="hyde", query=f"Information about {query}"),
                ExpandedQuery(type="lex",  query=query),
                ExpandedQuery(type="vec",  query=query),
            ]
        await cache.set(
            f"kbm:{settings.env}:expand:{cache_key_str}",
            json.dumps([e.model_dump() for e in kept]),
            ex=CACHE_TTL_SECONDS,
        )
        return kept
    except Exception as e:
        logger.warning("expand_query_failed", error=str(e), query=query[:100])
        # On any failure — port of llm.ts:1371-1373
        return [
            ExpandedQuery(type="lex", query=query),
            ExpandedQuery(type="vec", query=query),
        ]
```

**Generation params (HC-1):**

```python
EXPAND_TEMPERATURE     = 0.7    # 24_audit §1 row 22
EXPAND_TOP_P           = 0.8
EXPAND_MAX_TOKENS      = 600
EXPAND_PRESENCE_PENALTY = 0.5
# NOTE: gpt-4.1 with response_format=Pydantic ignores top_k/repeat_penalty;
# those Qwen3-specific params (llm.ts:1330-1335) are TS-only and do not carry over.
```

---

## §4. Parallel retrieval (Step 3)

```python
# src/kbm/search/query.py
async def _parallel_retrieve(
    store: KBStore,
    sub_queries: list[ExpandedQuery],
    collections: list[str],
) -> tuple[list[list[SearchResult]], list[RankedListMeta]]:
    """Run BM25/cosine for every (collection, sub_query) pair in parallel.

    Returns:
      (ranked_lists, list_meta)
    where list_meta[i] tracks (collection, sub_query, is_original) for weight assignment.

    HC-7: asyncio.gather is unconditional — Bedrock embed + SQLite FTS5 are stateless,
    no concurrent-embed-hang constraint (which was a node-llama-cpp issue).
    """
    tasks: list[asyncio.Task] = []
    meta: list[RankedListMeta] = []
    for coll in collections:
        for sq_idx, sq in enumerate(sub_queries):
            is_original = sq_idx < 2  # first two are always the original as lex+vec (Step 2)
            if sq.type == "lex":
                tasks.append(asyncio.to_thread(store.search_fts, coll, sq.query, 20))
            else:  # vec or hyde
                tasks.append(asyncio.create_task(store.search_vec(coll, sq.query, 20)))
            meta.append(RankedListMeta(collection=coll, sub_query=sq, is_original=is_original))
    ranked_lists = await asyncio.gather(*tasks, return_exceptions=False)
    return list(ranked_lists), meta
```

**`RankedListMeta` Pydantic model (lives in `src/kbm/types.py`):**

```python
class RankedListMeta(BaseModel):
    collection: str
    sub_query: ExpandedQuery
    is_original: bool                                    # gets weight 2.0 in RRF
```

---

## §5. RRF fusion (Step 4) — the most-tested function

### §5.1 Constants (HC-1)

```python
RRF_K                  = 60       # 24_audit §1 row 7 — store.ts:3598
TOP_RANK_BONUS_R0      = 0.05     # 24_audit §1 row 8 — store.ts:3617
TOP_RANK_BONUS_R1_R2   = 0.02     # 24_audit §1 row 8 — store.ts:3619
ORIGINAL_QUERY_WEIGHT  = 2.0      # 24_audit §1 row 9 — store.ts:4256
EXPANSION_QUERY_WEIGHT = 1.0      # 24_audit §1 row 9
```

### §5.2 Function signature + body

```python
# src/kbm/search/rrf.py
def reciprocal_rank_fusion(
    ranked_lists: list[list[SearchResult]],
    list_meta: list[RankedListMeta],
    k: int = RRF_K,
) -> list[RankedResult]:
    """Verbatim port of doc_search store.ts:3583-3626.

    Formula:
      contribution(doc, list_i) = weight_i / (k + rank_i + 1)
      rrf_score(doc) = Σ contribution(doc, list_i) over all lists doc appears in

    Top-rank bonus (added AFTER summing contributions):
      top_rank == 0       → += 0.05
      0 < top_rank <= 2   → += 0.02
      top_rank > 2        → no bonus

    Where top_rank(doc) = min(rank_i) across all lists.

    Per-doc dedup is on `result.file` (virtual path). Two results with the same
    `file` but different `docid` are still treated as one.
    """
    assert len(ranked_lists) == len(list_meta), "ranked_lists and list_meta length mismatch"
    seen: dict[str, RankedResult] = {}

    for list_idx, (results, meta) in enumerate(zip(ranked_lists, list_meta)):
        weight = ORIGINAL_QUERY_WEIGHT if meta.is_original else EXPANSION_QUERY_WEIGHT
        for rank, r in enumerate(results):
            contribution = weight / (k + rank + 1)
            entry = seen.get(r.file)
            if entry is None:
                entry = RankedResult(
                    docid=r.docid, file=r.file, title=r.title,
                    rrf_score=0.0, contributing_lists=[], top_rank=rank,
                )
                seen[r.file] = entry
            entry.rrf_score += contribution
            entry.contributing_lists.append(list_idx)
            if rank < entry.top_rank:
                entry.top_rank = rank

    # Top-rank bonus — port of store.ts:3614-3621
    for entry in seen.values():
        if entry.top_rank == 0:
            entry.rrf_score += TOP_RANK_BONUS_R0
        elif entry.top_rank <= 2:
            entry.rrf_score += TOP_RANK_BONUS_R1_R2

    return sorted(seen.values(), key=lambda r: r.rrf_score, reverse=True)
```

**`RankedResult` Pydantic model:**

```python
class RankedResult(BaseModel):
    docid: str
    file: str
    title: str
    rrf_score: float
    contributing_lists: list[int] = Field(default_factory=list)
    top_rank: int                                        # min rank across contributing lists
```

### §5.3 RRF math reference (cheat-sheet for code review)

For RRF with k=60, two lists, doc D at rank 0 in both:
- contribution per list = 1.0 / (60 + 0 + 1) = 0.01639
- two lists, weight 1.0 each → total contributions = 0.03279
- top-rank bonus +0.05 → final rrf_score = 0.08279

For the same doc at rank 5 in both lists:
- contribution per list = 1.0 / (60 + 5 + 1) = 0.01515
- two lists → 0.03030
- no bonus (rank > 2) → final = 0.03030

Doc must score higher overall to win — RRF rewards being a top-3 in any list more than being mid-pack in many lists.

---

## §6. Candidate cap + best-chunk-per-candidate (Steps 5-6)

```python
RERANK_CANDIDATE_LIMIT = 40    # 24_audit §1 row 6 — store.ts:318
```

```python
# src/kbm/search/query.py
def _pick_best_chunk_per_candidate(
    store: KBStore,
    candidates: list[RankedResult],
    query: str,
    intent: str | None,
) -> list[tuple[str, str]]:
    """For each candidate (one per file), pick the best-matching chunk from its
    body to send to the reranker. Returns [(file, chunk_text), ...] in candidate order.

    'Best chunk' = the chunk that maximizes intent-weighted token overlap with query.

    Port of doc_search store.ts:4407-4425.
    """
    query_tokens = set(re.findall(r'\w+', query.lower()))
    intent_tokens = set(re.findall(r'\w+', intent.lower())) if intent else set()
    out: list[tuple[str, str]] = []
    for cand in candidates[:RERANK_CANDIDATE_LIMIT]:
        chunks = store.fetch_chunks_for_doc(cand.docid)   # reads chunks/{hash[:2]}/{hash}_chunks.parquet
        best_score = -1.0
        best_text = chunks[0].text if chunks else ""
        for ch in chunks:
            ch_tokens = set(re.findall(r'\w+', ch.text.lower()))
            q_overlap = len(query_tokens & ch_tokens) / max(1, len(query_tokens))
            i_overlap = len(intent_tokens & ch_tokens) / max(1, len(intent_tokens)) if intent_tokens else 0.0
            score = q_overlap + INTENT_WEIGHT_CHUNK * i_overlap
            if score > best_score:
                best_score = score
                best_text = ch.text
        out.append((cand.file, best_text))
    return out
```

**Constants (HC-1):**

```python
INTENT_WEIGHT_CHUNK   = 0.5   # 24_audit §1 row 12 — store.ts:4051
INTENT_WEIGHT_SNIPPET = 0.3   # 24_audit §1 row 12 — store.ts:4048
```

---

## §7. Rerank (Step 7) — gpt-4.1 batched

```python
# src/kbm/search/rerank.py
class RerankBatchResult(BaseModel):
    """gpt-4.1 returns one score per (query, chunk) pair. We constrain output."""
    scores: list[int] = Field(min_length=1, max_length=40)   # 0..10 per doc


RERANK_SYSTEM_PROMPT = """\
You are a precise relevance reranker. For EACH document below, rate how well it answers the query on a 0-10 integer scale:
- 0 = totally irrelevant
- 5 = somewhat related
- 10 = perfect match

Output ONE integer score per document, in the same order as input. Use the JSON schema strictly.
"""


async def rerank_batch(
    client: AsyncOpenAI,
    cache: Cache,
    query: str,
    docs: list[tuple[str, str]],                          # (file, chunk_text)
    intent: str | None = None,
    model: str = "gpt-4.1",
) -> list[float | None]:
    """Returns one float in [0,1] per doc; None for cache failures.

    HC-1: model='gpt-4.1' AND temperature=0 (deterministic).
    HC-7: ALL docs in ONE API call (gpt-4.1 has 1M context).

    Per-doc cache: SHA-256(rerank, {query, model, chunk_text}). On cache hit, the
    doc is skipped in the batch request; cached score returned directly.
    Verbatim port of doc_search store.ts:3534-3577 + llm.ts:1385-1478.
    """
    rerank_query = (f"{intent}\n" if intent else "") + query
    # Cache check per-doc
    cached_scores: dict[int, float] = {}
    uncached_indices: list[int] = []
    uncached_docs: list[tuple[str, str]] = []
    for i, (file, text) in enumerate(docs):
        ckey = f"kbm:{settings.env}:rerank:{cache_key('rerank', {'query': rerank_query, 'model': model, 'chunk': text})}"
        if (raw := await cache.get(ckey)) is not None:
            cached_scores[i] = float(raw)
        else:
            uncached_indices.append(i)
            uncached_docs.append((file, text))

    fresh_scores_by_idx: dict[int, float] = {}
    if uncached_docs:
        numbered = "\n\n".join(f"[{i+1}] {text[:2000]}" for i, (_, text) in enumerate(uncached_docs))
        user_msg = f"Query: {rerank_query}\n\nDocuments:\n{numbered}\n\nOutput integer scores in input order."
        try:
            resp = await client.beta.chat.completions.parse(
                model=model,
                messages=[
                    {"role": "system", "content": RERANK_SYSTEM_PROMPT},
                    {"role": "user",   "content": user_msg},
                ],
                response_format=RerankBatchResult,
                temperature=RERANK_TEMPERATURE,           # 0.0
                max_tokens=RERANK_MAX_TOKENS,
            )
            result = resp.choices[0].message.parsed
            assert result is not None and len(result.scores) == len(uncached_docs)
            for local_i, score in enumerate(result.scores):
                global_i = uncached_indices[local_i]
                normalized = score / 10.0
                fresh_scores_by_idx[global_i] = normalized
                # cache write
                ckey = f"kbm:{settings.env}:rerank:{cache_key('rerank', {'query': rerank_query, 'model': model, 'chunk': uncached_docs[local_i][1]})}"
                await cache.set(ckey, str(normalized), ex=CACHE_TTL_SECONDS)
        except Exception as e:
            logger.warning("rerank_failed", error=str(e))
            for i in uncached_indices:
                fresh_scores_by_idx[i] = None  # caller falls back to RRF-only

    # Stitch cached + fresh into one list aligned with input
    return [
        cached_scores.get(i, fresh_scores_by_idx.get(i, None))
        for i in range(len(docs))
    ]


RERANK_TEMPERATURE = 0.0    # deterministic — unlike expansion's 0.7
RERANK_MAX_TOKENS  = 200
```

---

## §8. Position-aware blend (Step 8)

### §8.1 Constants (HC-1)

```python
BLEND_RRF_RANK_1_3   = 0.75    # 24_audit §1 row 10 — store.ts:4501
BLEND_RRF_RANK_4_10  = 0.60    # 24_audit §1 row 10 — store.ts:4502
BLEND_RRF_RANK_11_UP = 0.40    # 24_audit §1 row 10 — store.ts:4503
```

### §8.2 Function (verbatim port of `store.ts:4498-4505`)

```python
# src/kbm/search/blend.py
def position_aware_blend(
    candidates: list[RankedResult],
    rerank_scores: list[float | None],
) -> list[tuple[RankedResult, float]]:
    """For each candidate at 1-indexed rrf_rank position, blend RRF + rerank.

    Per store.ts:4498-4505:
      rrf_rank ∈ [1, 3]  → blended = 0.75 * (1/rrf_rank) + 0.25 * rerank
      rrf_rank ∈ [4, 10] → blended = 0.60 * (1/rrf_rank) + 0.40 * rerank
      rrf_rank ∈ [11,∞)  → blended = 0.40 * (1/rrf_rank) + 0.60 * rerank

    If rerank_score is None (rerank disabled or failed): return RRF rrf_score unchanged.

    Returns list sorted by blended_score desc.
    """
    assert len(candidates) == len(rerank_scores)
    out: list[tuple[RankedResult, float]] = []
    for i, (cand, rs) in enumerate(zip(candidates, rerank_scores)):
        rrf_rank = i + 1                                  # 1-indexed
        if rs is None:
            out.append((cand, cand.rrf_score))
            continue
        if rrf_rank <= 3:
            rrf_weight = BLEND_RRF_RANK_1_3
        elif rrf_rank <= 10:
            rrf_weight = BLEND_RRF_RANK_4_10
        else:
            rrf_weight = BLEND_RRF_RANK_11_UP
        rrf_component = 1.0 / rrf_rank
        blended = rrf_weight * rrf_component + (1.0 - rrf_weight) * rs
        out.append((cand, blended))
    out.sort(key=lambda x: x[1], reverse=True)
    return out
```

### §8.3 Worked example (verify by running `tests/unit/test_blend.py`)

Three candidates after RRF: `A` (rrf_rank 1), `B` (rrf_rank 5), `C` (rrf_rank 15). Rerank says `A=0.6, B=0.9, C=0.95`.

| Candidate | rrf_rank | rrf_component (1/r) | rrf_weight | rerank | blended | new rank |
|---|---|---|---|---|---|---|
| A | 1 | 1.000 | 0.75 | 0.60 | 0.75*1.0 + 0.25*0.60 = **0.900** | 1 |
| B | 5 | 0.200 | 0.60 | 0.90 | 0.60*0.20 + 0.40*0.90 = **0.480** | 3 |
| C | 15 | 0.067 | 0.40 | 0.95 | 0.40*0.067 + 0.60*0.95 = **0.597** | 2 |

A stays #1 (the top-3 protection), C jumps from rrf_rank 15 to position 2 (the bottom-trust-rerank rule). B (mid-pack) gets the balanced treatment.

---

## §9. Snippet extract (Step 9)

```python
# src/kbm/search/snippet.py
def extract_snippet(
    body: str,
    query: str,
    intent: str | None = None,
    max_length: int = 500,
    context_lines: int = 2,
) -> tuple[str, int]:
    """Port of doc_search store.ts:4085.

    Find best-matching line window in body, return ~max_length chars with
    query terms highlighted via **bold** markup. Returns (snippet_text, start_line).

    Intent terms boost the line score by INTENT_WEIGHT_SNIPPET = 0.3 (per store.ts:4048).
    """
    query_tokens = set(re.findall(r'\w+', query.lower()))
    intent_tokens = set(re.findall(r'\w+', intent.lower())) if intent else set()
    lines = body.splitlines()
    if not lines:
        return ("", 1)
    best_line, best_score = 0, -1.0
    for i, line in enumerate(lines):
        line_tokens = set(re.findall(r'\w+', line.lower()))
        q_overlap = len(query_tokens & line_tokens) / max(1, len(query_tokens))
        i_overlap = len(intent_tokens & line_tokens) / max(1, len(intent_tokens)) if intent_tokens else 0.0
        score = q_overlap + INTENT_WEIGHT_SNIPPET * i_overlap
        if score > best_score:
            best_score, best_line = score, i
    start = max(0, best_line - context_lines)
    end = min(len(lines), best_line + context_lines + 1)
    snippet = "\n".join(lines[start:end])
    if len(snippet) > max_length:
        snippet = snippet[:max_length] + "..."
    # Highlight query terms
    for term in query_tokens:
        snippet = re.sub(rf'\b({re.escape(term)})\b', r'**\1**', snippet, flags=re.IGNORECASE)
    return (snippet, best_line + 1)                       # 1-indexed line number for the agent
```

---

## §10. The `query_tool` orchestrator (Step 0 → Step 9)

```python
# src/kbm/search/query.py
async def query_tool(
    store: KBStore,
    cache: Cache,
    openai_client: AsyncOpenAI,
    opts: QueryToolInput,
) -> QueryToolOutput:
    """Master pipeline. Port of doc_search hybridQuery (store.ts:4272-4553)."""
    t0 = time.perf_counter()
    debug = {"bypass_reason": None}

    # Step 0
    collections = opts.collections or await store.default_collections()

    # Step 1 — Strong-signal bypass
    if opts.query:
        bypass = await _check_strong_signal_bypass(store, opts.query, opts.intent, collections)
        if bypass is not None:
            debug["bypass_reason"] = "strong_signal_bypass"
            return await _finalize_via_blend(
                store, cache, openai_client, opts, bypass, t0, debug,
            )

    # Step 2 — Expansion (or use pre-expanded `searches`)
    if opts.query:
        expanded = await expand_query(openai_client, cache, opts.query, opts.intent)
        sub_queries = [
            ExpandedQuery(type="lex", query=opts.query),
            ExpandedQuery(type="vec", query=opts.query),
            *expanded,
        ]
    else:
        sub_queries = list(opts.searches)

    # Step 3 — Parallel retrieval
    ranked_lists, list_meta = await _parallel_retrieve(store, sub_queries, collections)

    # Step 4 — RRF
    fused = reciprocal_rank_fusion(ranked_lists, list_meta, k=RRF_K)

    # Step 5 — Candidate cap
    candidates = fused[:opts.candidate_limit]

    # Steps 6-9 in helper
    return await _finalize_pipeline(store, cache, openai_client, opts, candidates, t0, debug)


async def _finalize_pipeline(
    store: KBStore, cache: Cache, client: AsyncOpenAI,
    opts: QueryToolInput, candidates: list[RankedResult], t0: float, debug: dict,
) -> QueryToolOutput:
    # Step 6 — best chunk per candidate
    query_for_rerank = opts.query or (opts.searches[0].query if opts.searches else "")
    chunks = _pick_best_chunk_per_candidate(store, candidates, query_for_rerank, opts.intent)

    # Step 7 — rerank
    if opts.rerank and len(candidates) > 1:
        rerank_scores = await rerank_batch(client, cache, query_for_rerank, chunks, opts.intent)
    else:
        rerank_scores = [None] * len(candidates)

    # Step 8 — position-aware blend
    blended = position_aware_blend(candidates, rerank_scores)

    # Step 9 — snippet + context
    results: list[SearchResultItem] = []
    for cand, score in blended[:opts.limit]:
        if score < opts.min_score:
            continue
        body = await store.fetch_body(cand.docid)
        snippet, line = extract_snippet(body, query_for_rerank, opts.intent)
        ctx = await store.get_context_for_file(cand.file)
        results.append(SearchResultItem(
            docid=cand.docid, file=cand.file, title=cand.title,
            score=round(score, 4), context=ctx, line=line, snippet=snippet,
        ))

    return QueryToolOutput(
        results=results,
        total_candidates=len(candidates),
        bypass_reason=debug.get("bypass_reason"),
        latency_ms=int((time.perf_counter() - t0) * 1000),
    )
```

---

## §11. Search backends (`search_fts` + `search_vec`)

### §11.1 `search_fts` (BM25 via SQLite FTS5)

Port of doc_search `store.ts:3177-3246`.

```python
# src/kbm/search/fts.py
def search_fts(db: sqlite3.Connection, query: str, limit: int = 20, collection: str | None = None) -> list[SearchResult]:
    """Returns top-K BM25 matches with NORMALIZED scores in [0,1].

    BM25 column weights: filepath=1.5, title=4.0, body=1.0 (24_audit §1 row 11).
    Score normalization: |bm25| / (1 + |bm25|) (24_audit §1 row 26).
    """
    fts_query = build_fts5_query(query)                  # see §11.2
    fts_limit = limit * 10 if collection else limit       # overfetch when filtering (store.ts:3191)
    cursor = db.execute(
        SQL_FTS5_SEARCH,                                  # see 03_data_contracts.md §3.7
        (FTS_WEIGHT_FILEPATH, FTS_WEIGHT_TITLE, FTS_WEIGHT_BODY, fts_query, fts_limit),
    )
    rows = cursor.fetchall()
    results: list[SearchResult] = []
    for filepath, title, raw_bm25 in rows:
        # Collection filter applied post-fetch when filtering on caller side
        score = abs(raw_bm25) / (1.0 + abs(raw_bm25))
        coll, _, path = filepath.partition("/")
        results.append(SearchResult(
            docid=...,                                    # looked up via catalog
            file=f"qmd://{coll}/{path}",
            title=title,
            score=score,
        ))
    return results[:limit]
```

### §11.2 `build_fts5_query` — sanitization

Verbatim port of `store.ts:3061-3151`. Handles quoted phrases, `-` negation, hyphenated tokens (split to phrase), CJK char-segmenting, prefix-match for plain terms. **CI script `scripts/check_fts5_query_builder.py` enforces byte-equality with the doc_search reference.**

### §11.3 `search_vec` (FAISS cosine)

```python
# src/kbm/search/vec.py
async def search_vec(
    faiss_index: faiss.Index,
    meta: pl.DataFrame,
    catalog: pl.DataFrame,
    query: str,
    limit: int = 20,
    collection: str | None = None,
) -> list[SearchResult]:
    """Embed query via Bedrock-Titan, search FAISS, join to catalog.

    Returns top-K with cosine similarity normalized to [0,1].
    Per-doc dedup: keep max similarity per file.
    """
    query_vec = await bedrock_embed_async(query)         # 1024-dim normalized
    distances, row_ids = await asyncio.to_thread(
        faiss_index.search,
        np.array([query_vec], dtype=np.float32),
        limit * 3,                                        # overfetch for dedup
    )
    valid = [(d, r) for d, r in zip(distances[0], row_ids[0]) if r >= 0]
    if not valid:
        return []
    hash_seqs = [meta[r, "hash_seq"] for d, r in valid]
    hashes = [hs.rsplit("_", 1)[0] for hs in hash_seqs]
    docs = catalog.filter(pl.col("hash").is_in(hashes))
    if collection:
        docs = docs.filter(pl.col("collection") == collection)
    # Dedup by file, keep max score
    seen: dict[str, SearchResult] = {}
    for d, r in valid:
        hs = meta[r, "hash_seq"]
        h = hs.rsplit("_", 1)[0]
        match = docs.filter(pl.col("hash") == h)
        if len(match) == 0:
            continue
        doc = match.row(0, named=True)
        sim = 1.0 - d                                     # cosine sim = 1 - distance (store.ts:3331)
        file_key = f"qmd://{doc['collection']}/{doc['path']}"
        existing = seen.get(file_key)
        if existing is None or sim > existing.score:
            seen[file_key] = SearchResult(
                docid=doc["docid"], file=file_key, title=doc["title"], score=sim,
            )
    return sorted(seen.values(), key=lambda r: r.score, reverse=True)[:limit]
```

---

## §12. Tests (cross-reference to `10_tdd_acceptance.md`)

| Function | Test file | Tests count | Mutation target |
|---|---|---|---|
| `reciprocal_rank_fusion` | `test_rrf.py` | 6 (per `10_*.md §6.1`) | ≥ 90% |
| `position_aware_blend` | `test_blend.py` | 5 (per `10_*.md §6.2`) | ≥ 90% |
| `_check_strong_signal_bypass` | `test_query.py` | 5 (per `10_*.md §6.3`) | ≥ 90% |
| `expand_query` | `test_expand.py` | 4 (cache hit / cache miss / fallback / hallucination filter) | n/a (LLM mock) |
| `rerank_batch` | `test_rerank.py` | 4 (cache hit / cache miss / failure-fallback / batched-shape) | n/a |
| `extract_snippet` | `test_snippet.py` | 3 (best line / context window / highlight) | ≥ 80% |
| `search_fts` | `test_fts.py` | 4 (single-coll / collection-filter / sanitize / score normalize) | ≥ 80% |
| `search_vec` | `test_vec.py` | 3 (top-k / dedup-by-file / collection-filter) | ≥ 80% |
| `query_tool` E2E | `test_query_pipeline.py` (integration) | 6 (per `10_*.md §6.5`) | n/a |

---

## §13. Drift-checkers (CI-enforced)

| Script | Asserts |
|---|---|
| `scripts/check_retrieval_constants.py` | The 7 constants in §5.1 + §8.1 + §6 == values in `src/kbm/constants.py` == values in `24_audit §1` rows 5-12 |
| `scripts/check_prompts_unchanged.py` | `EXPAND_SYSTEM_PROMPT` byte-equal to `../doc_search_tool/finetune/experiments/gepa/best_prompt.txt`; `RERANK_SYSTEM_PROMPT` byte-equal to §7 above |
| `scripts/check_pipeline_step_order.py` | Parses `query_tool` AST; asserts Step 0-9 functions are called in the documented order |
| `scripts/check_no_magic_numbers_in_retrieval.py` | greps `src/kbm/search/` for literal numbers; only allowed literals are `0, 1, -1, 0.0, 1.0` |

---

## §14. Definition of Done — Phase 4 retrieval shipment

Tag `kbm-v0.0.5-search`:

- [ ] §3-§9 implemented in matching files
- [ ] §5.1 + §6 + §8.1 constants in `src/kbm/constants.py`
- [ ] All 31 tests across §12 green
- [ ] `make mutate` survival ≥ 90% on `rrf.py`, `blend.py`, `query.py`
- [ ] §13 drift-checkers all green
- [ ] gold-KB E2E test (`test_query_returns_expected_top_3`) passes
- [ ] Strong-signal bypass single-collection behavior verified (HC-7)
- [ ] Coverage on changed lines ≥ 95% (signature files)

Open **[07_build_pipeline_spec.md](07_build_pipeline_spec.md)** to see the build-half spec (which produces the indexes this pipeline reads).
