# 05 — Chunker Spec (signature ⭐⭐ — verbatim port)

> **Purpose** — this file is the byte-level contract for `src/kbm/build/chunker.py` and `src/kbm/build/ast_chunker.py`. **Every number in this file is verified against `../doc_search_tool/24_audit_and_corrections.md §1` rows 1-4.** Junior agent: do not invent. Do not "improve." Port the math verbatim. CI script `scripts/check_chunker_constants.py` enforces byte-equality between this file and `src/kbm/constants.py`.
>
> **Why ⭐⭐ signature**: the chunker is the most easily-broken algorithmic port. A wrong constant here silently degrades retrieval quality everywhere downstream. The 200-line first PR you ship is this chunker + tests.

---

## §1. Constants (must match `src/kbm/constants.py` byte-for-byte)

| Constant | Value | doc_search source | Audit §1 row |
|---|---|---|---|
| `CHUNK_SIZE_TOKENS` | 900 | `store.ts:55` | row 2 |
| `CHUNK_OVERLAP_TOKENS` | 135 (= floor(900 × 0.15)) | `store.ts:56` | row 2 |
| `CHUNK_SIZE_CHARS` | 3600 (= 900 × 4 char-per-token) | `store.ts:58` | row 2 |
| `CHUNK_OVERLAP_CHARS` | 540 | `store.ts:59` | row 2 |
| `CHUNK_WINDOW_TOKENS` | 200 | `store.ts:61` | row 2 |
| `CHUNK_WINDOW_CHARS` | 800 | `store.ts:62` | row 2 |
| `DECAY_FACTOR` | 0.7 | `store.ts:217` | row 3 |
| `LINT_L4_OVERSIZED_TOKENS` | 1100 | n/a (kbm-specific lint threshold) | n/a |

---

## §2. The 12-tier BREAK_PATTERNS table (verbatim)

Port of doc_search `store.ts:100-113`. **Order in the list matters for scoring** — higher-score patterns must come earlier so `scanBreakPoints` keeps the higher score when patterns overlap at the same position.

```python
# src/kbm/build/chunker.py
import re

# BREAK_PATTERNS = [(compiled_regex, score, type_tag), ...]
# DO NOT REORDER. DO NOT CHANGE A NUMBER WITHOUT UPDATING 05_*.md §2 IN THE SAME PR.
BREAK_PATTERNS: list[tuple[re.Pattern, int, str]] = [
    (re.compile(r"\n#{1}(?!#)"),                   100, "h1"),
    (re.compile(r"\n#{2}(?!#)"),                    90, "h2"),
    (re.compile(r"\n#{3}(?!#)"),                    80, "h3"),
    (re.compile(r"\n#{4}(?!#)"),                    70, "h4"),
    (re.compile(r"\n#{5}(?!#)"),                    60, "h5"),
    (re.compile(r"\n#{6}(?!#)"),                    50, "h6"),
    (re.compile(r"\n```"),                          80, "codeblock"),
    (re.compile(r"\n(?:---|\*\*\*|___)\s*\n"),      60, "hr"),
    (re.compile(r"\n\n+"),                          20, "blank"),
    (re.compile(r"\n[-*]\s"),                        5, "list"),
    (re.compile(r"\n\d+\.\s"),                       5, "numlist"),
    (re.compile(r"\n"),                              1, "newline"),
]
```

**Drift-check** (`scripts/check_break_patterns.py`): parses this file's §2 block and asserts `BREAK_PATTERNS` in `chunker.py` is element-wise identical (regex pattern + score + tag). Any divergence fails CI.

---

## §3. The 6 functions to implement

All in `src/kbm/build/chunker.py`. **Signature, return type, and behavior are all fixed.** The junior agent writes the bodies, not the signatures.

### §3.1 `scan_break_points(text: str) -> list[BreakPoint]`

```python
class BreakPoint(BaseModel):
    """One potential cut point. Per-position dedup: keep highest score."""
    pos: int                                # char position (start of match in text)
    score: int                              # 1..100
    type: str                               # e.g. "h1", "blank", "newline"


def scan_break_points(text: str) -> list[BreakPoint]:
    """Walk all 12 patterns. For each position, keep the highest-scoring tag.
    Return sorted by pos ascending.

    Port of doc_search store.ts:120-141.
    """
    ...
```

**Behavior contract:**
- Iterates `BREAK_PATTERNS` in order.
- For each regex, finds all `re.finditer` matches.
- Uses a `dict[int, BreakPoint]` keyed by `pos`. If a position already has a `BreakPoint`, the new one replaces it ONLY if new score > existing score.
- Returns `sorted(seen.values(), key=lambda b: b.pos)`.

**Edge cases:**
- Empty `text` → returns `[]`.
- Single character → returns `[]` (no patterns match a single char).
- Text with no markdown structure → returns one `BreakPoint(pos=N, score=1, type="newline")` per `\n`.

### §3.2 `find_code_fences(text: str) -> list[CodeFenceRegion]`

```python
class CodeFenceRegion(BaseModel):
    start: int       # position of opening \n```
    end: int         # position of closing \n``` + 4 (inclusive of the closing marker)


def find_code_fences(text: str) -> list[CodeFenceRegion]:
    """Pair triple-backtick markers. Port of doc_search store.ts:147-169.

    If an unclosed fence remains at end-of-text, treat it as extending to len(text).
    """
    ...
```

**Behavior contract:**
- Uses `re.finditer(r"\n```", text)`.
- Pairs matches 1-2, 3-4, 5-6, etc. Pair (k, k+1) becomes `CodeFenceRegion(start=match_k.start(), end=match_{k+1}.start() + 4)`.
- An odd number of matches → the last unpaired marker yields a region `(start, len(text))`.
- Zero matches → returns `[]`.

### §3.3 `is_inside_code_fence(pos: int, fences: list[CodeFenceRegion]) -> bool`

```python
def is_inside_code_fence(pos: int, fences: list[CodeFenceRegion]) -> bool:
    """Strict-inside (open interval): True iff f.start < pos < f.end for any fence.

    Port of doc_search store.ts:174-176.

    Boundary positions (pos == f.start or pos == f.end) are NOT considered inside.
    """
    return any(f.start < pos < f.end for f in fences)
```

### §3.4 `find_best_cutoff(break_points, target_char_pos, window_chars=CHUNK_WINDOW_CHARS, decay_factor=DECAY_FACTOR, code_fences=None) -> int`

The signature algorithm. **Port verbatim of `store.ts:191-227`.**

```python
def find_best_cutoff(
    break_points: list[BreakPoint],
    target_char_pos: int,
    window_chars: int = CHUNK_WINDOW_CHARS,                # 800
    decay_factor: float = DECAY_FACTOR,                    # 0.7
    code_fences: list[CodeFenceRegion] | None = None,
) -> int:
    """Pick the highest-scoring break point in [target - window, target], with
    squared-distance decay. Break points inside code fences are rejected.

    Math (verbatim from doc_search store.ts:217):
      normalized_dist = (target - bp.pos) / window_chars
      multiplier      = 1.0 - (normalized_dist ** 2) * decay_factor
      effective_score = bp.score * multiplier

    Pick argmax(effective_score) over candidates. If no candidate is in the
    window, return target_char_pos (the caller chunks at the hard cap).
    """
    code_fences = code_fences or []
    window_start = target_char_pos - window_chars
    best_score: float = -1.0
    best_pos: int = target_char_pos
    for bp in break_points:
        if bp.pos < window_start:
            continue
        if bp.pos > target_char_pos:
            break                                          # break_points are sorted by pos
        if is_inside_code_fence(bp.pos, code_fences):
            continue
        normalized_dist = (target_char_pos - bp.pos) / window_chars
        multiplier = 1.0 - (normalized_dist ** 2) * decay_factor
        effective_score = bp.score * multiplier
        if effective_score > best_score:
            best_score = effective_score
            best_pos = bp.pos
    return best_pos
```

**Decay table (must match the docstring comment, verified against `store.ts:212-215`):**

| Distance back from target | (d/w)² | multiplier | H1 effective (score=100) | Blank effective (score=20) |
|---|---|---|---|---|
| 0 (at target) | 0.000 | 1.000 | 100.00 | 20.00 |
| 200 (25% back) | 0.063 | 0.956 | 95.60 | 19.13 |
| 400 (50% back) | 0.250 | 0.825 | 82.50 | 16.50 |
| 600 (75% back) | 0.563 | 0.606 | 60.60 | 12.12 |
| 800 (window edge) | 1.000 | 0.300 | 30.00 | 6.00 |

**Critical invariant: an H1 at the window edge (effective 30) still beats a blank line at the target (effective 20).** This is the one fact every junior agent must protect. Test `test_h1_at_edge_beats_blank_at_target` (in `10_*.md §3`) enforces it.

### §3.5 `merge_break_points(a: list[BreakPoint], b: list[BreakPoint]) -> list[BreakPoint]`

```python
def merge_break_points(a: list[BreakPoint], b: list[BreakPoint]) -> list[BreakPoint]:
    """Union two break-point lists. Per-position dedup: keep the higher score.
    Used by chunk_document_async() to merge regex break points with AST break
    points when chunk_strategy='auto'.

    Port of doc_search store.ts:239-254.
    """
    seen: dict[int, BreakPoint] = {}
    for src in (a, b):
        for bp in src:
            existing = seen.get(bp.pos)
            if existing is None or bp.score > existing.score:
                seen[bp.pos] = bp
    return sorted(seen.values(), key=lambda b: b.pos)
```

### §3.6 `chunk_document_with_break_points(content, break_points, code_fences, max_chars=CHUNK_SIZE_CHARS, overlap_chars=CHUNK_OVERLAP_CHARS, window_chars=CHUNK_WINDOW_CHARS) -> list[Chunk]`

The core chunker kernel. **Port verbatim of `store.ts:260-310`.**

```python
def chunk_document_with_break_points(
    content: str,
    break_points: list[BreakPoint],
    code_fences: list[CodeFenceRegion],
    max_chars: int = CHUNK_SIZE_CHARS,                     # 3600
    overlap_chars: int = CHUNK_OVERLAP_CHARS,              # 540
    window_chars: int = CHUNK_WINDOW_CHARS,                # 800
) -> list[Chunk]:
    """Greedy left-to-right chunker. Per chunk:
      1. target_end_pos = min(char_pos + max_chars, len(content))
      2. end_pos = find_best_cutoff(break_points, target_end_pos, window, decay, code_fences)
      3. If find_best_cutoff returns a value <= current char_pos (window empty
         AND no break point inside) OR > target_end_pos: snap to target_end_pos.
      4. Emit Chunk(text=content[char_pos:end_pos], pos=char_pos, end_pos=end_pos)
      5. char_pos = end_pos - overlap_chars
      6. Guard: if next char_pos <= last_chunk.pos, advance char_pos to end_pos
         (no infinite-loop).

    Returns: [] if content == "". Returns [Chunk(content, 0, len(content))]
    if len(content) <= max_chars.
    """
    if not content:
        return []
    if len(content) <= max_chars:
        return [Chunk(text=content, pos=0, end_pos=len(content))]

    chunks: list[Chunk] = []
    char_pos = 0
    while char_pos < len(content):
        target_end_pos = min(char_pos + max_chars, len(content))
        end_pos = target_end_pos
        if end_pos < len(content):
            best = find_best_cutoff(break_points, target_end_pos, window_chars, DECAY_FACTOR, code_fences)
            if char_pos < best <= target_end_pos:
                end_pos = best
        if end_pos <= char_pos:
            end_pos = min(char_pos + max_chars, len(content))
        chunks.append(Chunk(text=content[char_pos:end_pos], pos=char_pos, end_pos=end_pos))
        if end_pos >= len(content):
            break
        char_pos = end_pos - overlap_chars
        if chunks and char_pos <= chunks[-1].pos:
            char_pos = end_pos
    return chunks
```

---

## §4. The high-level entry point (`chunk_document`)

```python
def chunk_document(
    content: str,
    filepath: str = "",
    chunk_strategy: Literal["regex", "auto"] = "regex",
) -> list[Chunk]:
    """High-level chunker. Used by walker.py + by query.py for runtime best-chunk-per-doc.

    Steps:
      1. Compute regex break points via scan_break_points.
      2. Compute code fences via find_code_fences.
      3. If chunk_strategy == 'auto' AND filepath endswith one of {.ts, .tsx, .js, .jsx,
         .py, .go, .rs}: compute AST break points via ast_chunker.get_ast_break_points,
         then merge with regex break points.
      4. Run chunk_document_with_break_points.
      5. Run token-verify pass via token_count.verify_chunks (see §5).

    Return: list[Chunk] (each with .text, .pos, .end_pos, .n_tokens).
    """
    break_points = scan_break_points(content)
    code_fences = find_code_fences(content)
    if chunk_strategy == "auto" and _is_code_file(filepath):
        ast_bps = get_ast_break_points(content, filepath)
        if ast_bps:
            break_points = merge_break_points(break_points, ast_bps)
    chunks = chunk_document_with_break_points(content, break_points, code_fences)
    return verify_chunks_by_token_count(chunks)
```

`_is_code_file` is a simple suffix check; lives in `src/kbm/build/chunker.py`.

---

## §5. Token verification (`verify_chunks_by_token_count`)

```python
# src/kbm/build/chunker.py
from kbm.shared.token_count import count_tokens

def verify_chunks_by_token_count(chunks: list[Chunk]) -> list[Chunk]:
    """Fill chunk.n_tokens; recursively halve any chunk over CHUNK_SIZE_TOKENS.

    Char-based chunker uses 4 chars/token as approximation. Real tokenizer
    (tiktoken cl100k_base) may produce more tokens on dense English text.
    Per-chunk verify:
      - count tokens
      - if n_tokens <= CHUNK_SIZE_TOKENS: set n_tokens and continue
      - else: split text at midpoint (char-based), recurse on both halves,
        replace the offending chunk with the two new chunks (preserving pos/end_pos)
      - HARD LIMIT: max recursion depth = 4. If still over after 4 halves,
        truncate via tokenizer (re-encode, slice to CHUNK_SIZE_TOKENS, decode).

    Port of doc_search store.ts:2412-2500.
    """
    ...
```

**Why recursive halving rather than smart re-chunking:** dense English text in long paragraphs has higher tokens-per-char than markdown. The 4-chars/token approximation occasionally overshoots. Halving and re-checking is cheap; re-running the full chunker would re-evaluate break points and could thrash. Per `store.ts:2412-2500`, depth 4 is sufficient for >99.9% of real input.

---

## §6. AST chunking (`src/kbm/build/ast_chunker.py`)

Port of doc_search `ast.ts`.

### §6.1 Supported languages + grammar mapping

```python
SUPPORTED_LANGUAGES: dict[str, str] = {
    ".ts":  "typescript",
    ".tsx": "tsx",
    ".js":  "javascript",
    ".jsx": "tsx",
    ".mts": "typescript",
    ".cts": "typescript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".py":  "python",
    ".go":  "go",
    ".rs":  "rust",
}
```

### §6.2 AST score map (verbatim from `ast.ts:158-172`)

```python
AST_SCORE_MAP: dict[str, int] = {
    "class":      100,
    "iface":      100,
    "struct":     100,
    "trait":      100,
    "impl":       100,
    "mod":        100,
    "export":      90,
    "func":        90,
    "method":      90,
    "decorated":   90,
    "type":        80,
    "enum":        80,
    "import":      60,
}
```

### §6.3 Tree-sitter S-expression queries per language (verbatim from `ast.ts:94-151`)

Verbatim — copy each query into `LANGUAGE_QUERIES: dict[str, str]`. **All six queries are listed in `ast.ts:94-151`; the junior agent copies them character-for-character.**

### §6.4 `get_ast_break_points(content: str, filepath: str) -> list[BreakPoint]`

```python
def get_ast_break_points(content: str, filepath: str) -> list[BreakPoint]:
    """Parse content via tree-sitter, return BreakPoint at every node's start_byte.

    Returns [] if:
      - filepath's suffix is not in SUPPORTED_LANGUAGES, OR
      - the grammar failed to load (log one warning per language; return [])

    Port of doc_search ast.ts:274-323.

    Per-position dedup: at each byte position, keep the highest-scoring capture
    (handles export_statement wrapping class_declaration).
    """
    ...
```

**Graceful fallback (per `ast.ts:241-245`):** if the grammar fails to load (e.g. missing `tree-sitter-python` install), log `[chunker] AST grammar unavailable for {language}: {error}` ONCE per language (track via `_failed_languages: set[str]` at module scope) and return `[]`. The regex-only path still works.

---

## §7. Determinism + reproducibility (HC-2)

**Hard requirement:** `chunk_document(body, filepath)` must produce **byte-identical output** across N consecutive runs on the same input. This is enforced by `scripts/check_chunker_byte_identical.py`:

```python
# scripts/check_chunker_byte_identical.py
"""Run chunk_document on the gold fixture 3 times; assert byte-identical output."""
from kbm.build.chunker import chunk_document

with open("tests/fixtures/golden_chunks/sample_doc.md") as f:
    body = f.read()

runs = [chunk_document(body) for _ in range(3)]
assert runs[0] == runs[1] == runs[2], "Chunker is non-deterministic"
```

**Sources of non-determinism the junior agent might accidentally introduce:**

| Source | Mitigation |
|---|---|
| `set` iteration order | Use `dict` or sorted list everywhere. `BREAK_PATTERNS` is a list, not a set. |
| `re.MULTILINE` flag inconsistency | The 12 patterns use `\n` explicitly; do not add `re.MULTILINE`. |
| Tokenizer state | `tiktoken` is deterministic given the same encoding name. Always use `"cl100k_base"`. |
| AST node visitation order | Tree-sitter is deterministic; do not multi-thread the query walk. |
| Float precision in `find_best_cutoff` | All multipliers are computed in IEEE 754 64-bit — Python's default. Do not cast to `numpy.float32`. |

---

## §8. Tests (mapped to `10_tdd_acceptance.md §3`)

The chunker has **18 mandatory tests**. CI rejects the PR if any are missing. Full Given/When/Then in `10_tdd_acceptance.md §3`.

| # | Test name | Behavior verified |
|---|---|---|
| 1 | `test_chunk_short_doc_no_split` | Content ≤ max_chars → 1 chunk |
| 2 | `test_chunk_long_doc_h1_split` | Long doc with H1s splits at H1 boundaries |
| 3 | `test_chunk_code_fence_protected` | Break points inside `\n```...\n```` regions are rejected |
| 4 | `test_chunk_code_fence_unclosed` | Unclosed fence extends to len(content) |
| 5 | `test_decay_h1_at_edge_beats_blank_at_target` | H1 score=100 at 800 back: effective 30 > blank score=20 at 0: effective 20 |
| 6 | `test_decay_math_table_exact` | Exact-equality check on the 5 rows of the §3.4 decay table |
| 7 | `test_scan_break_points_per_position_dedup` | Same position with two patterns → highest score wins |
| 8 | `test_scan_break_points_returns_sorted` | Returned list strictly ascending by pos |
| 9 | `test_find_code_fences_pairs` | 4 markers → 2 regions; 5 markers → 3 regions (last unclosed) |
| 10 | `test_overlap_no_infinite_loop` | Tiny doc + huge overlap → loop guard advances correctly |
| 11 | `test_chunk_deterministic_3_runs` | Three runs produce byte-identical chunks (HC-2) |
| 12 | `test_chunk_empty_input` | `chunk_document("")` returns `[]` |
| 13 | `test_merge_break_points_keeps_higher_score` | Per-position dedup across two lists |
| 14 | `test_ast_chunker_python_class` | `.py` file with `class Foo:` produces a `BreakPoint(score=100, type="ast:class")` |
| 15 | `test_ast_chunker_grammar_missing_falls_back` | Force tree-sitter to fail; returns `[]` |
| 16 | `test_ast_merge_with_regex` | `--chunk-strategy auto` produces strictly more break points than `regex` on a `.py` file with H1s |
| 17 | `test_verify_chunks_recursive_halving` | A 2000-token-dense chunk recursively halves until all parts ≤ 900 tokens |
| 18 | `test_verify_chunks_truncation_last_resort` | A 4000-token-dense chunk hits depth limit and is tokenizer-truncated |

**Mutation testing target (HC-3 + ADR-003): mutmut survival ≥ 90% on `chunker.py`.**

---

## §9. Property-based tests (hypothesis)

In addition to the 18 unit tests above, ship 3 property-based tests:

```python
# tests/unit/test_chunker_properties.py
import hypothesis.strategies as st
from hypothesis import given, settings


@given(st.text(min_size=0, max_size=5000))
def test_chunker_does_not_lose_chars(body: str):
    """Joined chunks (with overlap removed) cover the entire input."""
    chunks = chunk_document(body)
    if not body:
        assert chunks == []
        return
    # Property: every char in body appears in at least one chunk
    rebuilt = "".join(c.text for c in chunks)
    assert set(body) <= set(rebuilt), "Chunker dropped characters"


@given(st.text(min_size=0, max_size=5000))
def test_chunker_chunks_within_size_bound(body: str):
    """No chunk exceeds CHUNK_SIZE_CHARS by more than 10% (recursive-halving cap)."""
    for c in chunk_document(body):
        assert len(c.text) <= int(CHUNK_SIZE_CHARS * 1.1)


@settings(max_examples=20)
@given(st.text(min_size=200, max_size=5000))
def test_chunker_deterministic_property(body: str):
    """Two runs on same input produce identical output."""
    assert chunk_document(body) == chunk_document(body)
```

---

## §10. The "first PR" recipe (Phase 1 unblocker)

Your first PR ships:
1. `src/kbm/build/chunker.py` — implements §3.1-§3.6 + §4 + §5 (no AST yet).
2. `src/kbm/constants.py` — the 7 chunker constants from §1.
3. `src/kbm/types.py` — `BreakPoint`, `CodeFenceRegion`, `Chunk` Pydantic models (already specified in `03_data_contracts.md`).
4. `tests/unit/test_chunker.py` — tests 1-13 from §8.
5. `tests/unit/test_chunker_properties.py` — 3 properties from §9.
6. `tests/fixtures/golden_chunks/sample_doc.md` + `expected_chunks_for_sample.json` (snapshot test).
7. `scripts/check_chunker_constants.py` + `scripts/check_break_patterns.py` + `scripts/check_chunker_byte_identical.py` (no longer stubs).

**Do NOT include in first PR:** `ast_chunker.py`, AST tests (14-16), `verify_chunks_by_token_count` (17-18). Those ship in PR #2.

**Why split:** the regex chunker is the foundation. AST + token-verify add ~150 LOC and depend on tree-sitter + tiktoken; if the regex chunker is wrong, building on top doubles your debug surface. Get §3 perfect, ship it, then add §5 + §6.

---

## §11. ECS+S3 port — the only divergences from doc_search

doc_search's chunker has two TypeScript-only artifacts that **do NOT** carry over to Python:

1. **`tree-sitter` is loaded via WASM in TS** (`ast.ts:200-205`). In Python, use the native `tree-sitter` + `tree-sitter-{lang}` PyPI packages. The S-expression queries are identical.
2. **doc_search uses `node-llama-cpp`'s internal tokenizer for `verify_chunks_by_token_count`** (`llm.ts:1069-1094`). In Python, use `tiktoken` with `cl100k_base` encoding (matches gpt-4 family). Per token-count differences run on the order of ±5% — within the 22% over-budget tolerance (LINT_L4 = 1100 / 900 = 1.22). **If you find a real-world chunk that the tokenizer over-counts beyond 1100, that's a bug in `verify_chunks_by_token_count`'s halving depth, not the constant.**

---

## §12. The drift-checker scripts (`scripts/check_*.py`)

| Script | What it asserts | Fails when |
|---|---|---|
| `check_chunker_constants.py` | The 7 constants in §1 == values in `src/kbm/constants.py` | Someone edits `constants.py` without updating this file |
| `check_break_patterns.py` | The 12 patterns in §2 == `BREAK_PATTERNS` in `chunker.py` | Someone reorders the list, edits a regex, or changes a score |
| `check_chunker_byte_identical.py` | `chunk_document(body)` on the gold fixture is byte-identical across 3 runs | Someone introduces non-determinism |

All three exit non-zero on drift. CI runs all three on every PR.

---

## §13. Definition of Done — Phase 1 chunker shipment

PR #1 (regex chunker):
- [ ] §3.1-§3.6 implemented in `src/kbm/build/chunker.py`
- [ ] §1 constants in `src/kbm/constants.py`
- [ ] `BreakPoint`, `CodeFenceRegion`, `Chunk` Pydantic models in `src/kbm/types.py`
- [ ] Tests 1-13 from §8 + 3 properties from §9 all green
- [ ] `scripts/check_chunker_constants.py` + `check_break_patterns.py` + `check_chunker_byte_identical.py` all green
- [ ] `mutmut run --paths-to-mutate=src/kbm/build/chunker.py` survival ≥ 90%
- [ ] Coverage on changed lines ≥ 95% (chunker is pure functions — high bar)

PR #2 (AST + token-verify):
- [ ] §5 `verify_chunks_by_token_count` implemented + tests 17-18
- [ ] §6 AST chunker in `src/kbm/build/ast_chunker.py` + tests 14-16
- [ ] All 6 tree-sitter grammars install cleanly via `pip install -r requirements.txt`
- [ ] Graceful fallback on grammar load failure tested

After both PRs: tagged `kbm-v0.0.2-foundation` (covers `03_data_contracts.md` + `05_chunker_spec.md`).

Open **[10_tdd_acceptance.md](10_tdd_acceptance.md)** next to see the Given/When/Then for every test mentioned above.
