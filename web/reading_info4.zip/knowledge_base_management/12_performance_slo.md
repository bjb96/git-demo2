# 12 — Performance SLOs (single source of truth for every alarm threshold)

> **Purpose** — every numeric threshold the kbm-search service alarms on lives in this file. CDK reads these values via the `scripts/slo_export.py` script; magic numbers in `cdk/stack.py` are CI-rejected.
>
> **Audience** — Phase 5 (Observability + IaC) reader. Also referenced by the nightly bench Lambda and the on-call runbook.

---

## §1. SLI/SLO summary (what we measure + targets)

| SLI | SLO | Window | Action if breached |
|---|---|---|---|
| **Query availability** | 99.5% of `/query` requests return 2xx | rolling 28-day | SEV-2 page; bandwidth runbook OPS-01 |
| **Query latency p50** | < 800ms (no rerank) / < 1s (rerank) | rolling 7-day | SEV-3 if > 1.5× target; OPS-02 |
| **Query latency p95** | < 2s (no rerank) / < 3s (rerank) | rolling 7-day | SEV-3 if > 1.5×; OPS-02 |
| **Query latency p99** | < 4s | rolling 7-day | SEV-3 if > 6s; OPS-02 |
| **`/health` availability** | 100% (excluding deploys) | rolling 24-hour | SEV-1 — ALB removes task; OPS-03 |
| **Cache hit rate (expand)** | ≥ 60% | rolling 7-day | informational; tune cache TTL if < 50% (OPS-04) |
| **Cache hit rate (rerank)** | ≥ 50% | rolling 7-day | informational; tune TTL or LRU policy (OPS-04) |
| **gpt-4.1 cost / query (median)** | ≤ $0.005 | rolling 7-day | SEV-3 if > $0.01; tune `candidate_limit` (OPS-05) |
| **Bedrock embed cost / build** | ≤ $1 per 10k docs | per-build | informational; alarm if > $5; OPS-05 |
| **Nightly bench recall@3** | ≥ 7.0/10 | nightly | SEV-2 if < 6.0 for 2 consecutive nights; OPS-06 |
| **Nightly bench latency p95** | < 3s | nightly | SEV-3 if > 5s; OPS-02 |
| **Build wall-time** | < 60s for KBs up to 1k docs; < 10min for 10k docs | per-build | informational |

---

## §2. CloudWatch metrics (the 8 emitters in `src/kbm/obs/metrics.py`)

Verbatim from `03_data_contracts.md §6.2`:

| Metric | Unit | Dimensions | Emitted by |
|---|---|---|---|
| `kbm.query.latency_ms` | Milliseconds | env, collection_count_bucket | `query.py` (every `query_tool` call) |
| `kbm.query.cache_hit_rate` | Percent | env, cache_layer={expand,rerank} | `cache.py` |
| `kbm.query.strong_signal_bypass_rate` | Percent | env | `query.py` |
| `kbm.rerank.tokens_in` | Count | env | `rerank.py` |
| `kbm.rerank.tokens_out` | Count | env | `rerank.py` |
| `kbm.embed.tokens` | Count | env, mode={build,query} | `embedder.py` + `vec.py` |
| `kbm.build.wall_time_sec` | Seconds | env, collection | `build/cli.py` |
| `kbm.search.error_count` | Count | env, error_class | every `KbmError` catch site |

**Drift-checker** `scripts/check_metric_names.py` asserts every metric name string in `src/kbm/obs/metrics.py` is one of the 8 constants in `src/kbm/constants.py CW_METRIC_*`.

---

## §3. CloudWatch alarm definitions (consumed by `cdk/stack.py`)

The 9 alarms below are configured in CDK. **`cdk/stack.py` reads thresholds via `from src.kbm.constants import *` — no magic numbers in CDK.** `scripts/check_ci_alarms_use_slo_file.py` enforces this.

```python
# src/kbm/constants.py — alarm thresholds (referenced by CDK)
ALARM_QUERY_AVAILABILITY_MIN_PCT  = 99.5
ALARM_QUERY_LATENCY_P95_MS        = 2_000
ALARM_QUERY_LATENCY_P99_MS        = 4_000
ALARM_HEALTH_UNHEALTHY_5MIN       = 1        # threshold = 1 unhealthy check in 5 min
ALARM_CACHE_HIT_RATE_MIN_PCT      = 50.0     # informational alarm at 50%; SLO target is 60%
ALARM_RERANK_COST_PER_QUERY_USD   = 0.01
ALARM_NIGHTLY_BENCH_RECALL_MIN    = 6.0      # /10 — fires on 2 consecutive nights
ALARM_BUILD_COST_USD              = 5.0
ALARM_ERROR_RATE_MAX              = 0.05     # 5% of requests
```

| Alarm name | Threshold | Period | Datapoints |
|---|---|---|---|
| `kbm-query-availability-low` | < 99.5% of 5xx responses | 5min | 3 consecutive |
| `kbm-query-latency-p95-high` | > 2000ms | 5min | 3 consecutive |
| `kbm-query-latency-p99-high` | > 4000ms | 5min | 3 consecutive |
| `kbm-health-unhealthy` | any unhealthy ALB target | 1min | 1 |
| `kbm-cache-hit-low` | < 50% on expand cache | 1h | 1 |
| `kbm-rerank-cost-high` | > $0.01 / query (90th-percentile cost) | 1h | 1 |
| `kbm-nightly-bench-recall-low` | recall@3 < 6.0/10 | daily | 2 consecutive |
| `kbm-build-cost-high` | > $5 per build | per-build event | 1 |
| `kbm-error-rate-high` | error_count / total_requests > 5% | 5min | 3 |

---

## §4. Latency budget per pipeline step (p50 / p95)

Used to diagnose where latency violations come from. Numbers are TARGETS, not measured ground truth.

| Step | p50 target | p95 target | What causes overage |
|---|---|---|---|
| Receive request + Pydantic validate | < 5ms | < 10ms | malformed JSON; rate-limiting |
| Strong-signal bypass FTS probe (single coll) | < 30ms | < 80ms | cold SQLite cache; large collection |
| gpt-4.1 expansion (cache miss) | < 250ms | < 500ms | OpenAI API latency; tokenizer cold path |
| Expansion cache hit | < 5ms | < 10ms | Redis latency |
| Parallel retrieval (FTS + FAISS × N collections × M variants) | < 100ms | < 250ms | FAISS cold (mmap not yet paged); FTS5 query slow |
| RRF fusion + candidate cap | < 5ms | < 10ms | Python loop overhead |
| Best-chunk-per-candidate | < 30ms | < 80ms | parquet I/O on cold container |
| gpt-4.1 rerank batched (40 docs, cache miss) | < 400ms | < 1200ms | OpenAI batch latency varies |
| Rerank cache hit (all 40 cached) | < 5ms | < 10ms | Redis latency |
| Position-aware blend | < 1ms | < 2ms | pure Python sort |
| Snippet extract + context attach | < 30ms | < 80ms | regex on large bodies |
| JSON serialize + send | < 5ms | < 10ms | Pydantic serialization |
| **TOTAL cold (cache miss path)** | **~800ms** | **~2200ms** | |
| **TOTAL cache hit** | **~50ms** | **~120ms** | |

These numbers come from `../doc_search_tool/22_q2_search_tools_pipeline.md §9` (Q2 latency table). **They are engineering targets, NOT measured against a real deployment.** Once the kbm-search service has 1 week of CloudWatch data, revisit and pin to actuals.

---

## §5. Locust scenarios (for `make load-test`)

Three scenarios in `tests/load/locustfile.py` (Phase 5 deliverable):

| Scenario | RPS target | Mix | Pass condition |
|---|---|---|---|
| **smoke** | 1 RPS for 60s | 50% query, 30% get, 20% multi_get | 0 errors; p95 < 2s |
| **steady** | 10 RPS for 5min | same mix | < 0.5% error rate; p95 < 3s |
| **burst** | 50 RPS for 30s, then back to 1 RPS | same mix | autoscaling kicks in within 60s; recovery to baseline within 90s |

`make load-test SCENARIO=smoke` runs the smoke. CI runs smoke nightly. Burst is manual-only (cost).

---

## §6. Cost ceiling (per environment per month)

Target (for "moderate" usage = 10k queries/day, 1 full rebuild/week):

| Cost item | Monthly $ |
|---|---|
| Bedrock Titan-Embed-Text-v2 (build) | $4 (4 rebuilds × 12.5M tokens × $0.02/1M) |
| Bedrock Titan-Embed-Text-v2 (query embeddings) | $0.30 (300k queries × 50 tokens × $0.02/1M) |
| gpt-4.1 expansion (cache miss rate ~30%) | $45 |
| gpt-4.1 rerank batched | $150 |
| ECS Fargate (2× 1vCPU + 2GB, 24/7) | $60 |
| ALB | $20 |
| ElastiCache Redis (`cache.t4g.small`) | $25 |
| S3 storage (~1GB) | $0.02 |
| S3 requests | $0.01 |
| CloudWatch logs + metrics | $15 |
| **Total** | **~$320/month** |

**Cost-down levers (if budget pressure):**
- Drop gpt-4.1 rerank → Cohere Rerank-v3.5 via Bedrock: -$140
- Aggressive caching (24h → 7d TTL where safe): -$30
- Scale-to-zero ECS off-hours (if user pattern is business-hours only): -$30

**Cost-up triggers (alarm if breached):**
- Any single day > $20: SEV-3 (probable runaway loop or cache invalidation bug)
- Rolling 7-day > $100: SEV-3 (sustained anomaly)

---

## §7. Error budget policy

99.5% availability over 28 days = ~3.4 hours of unavailability budget per month.

| Budget remaining | Response |
|---|---|
| ≥ 50% | Normal operations; feature work continues |
| 25-50% | Yellow: prioritize reliability work; new feature PRs require staff-eng review |
| 10-25% | Orange: stop new features; only bug fixes + reliability work |
| < 10% | Red: emergency change-freeze; all non-incident work paused |

---

## §8. Nightly bench (SLO-driven nightly Lambda)

`scripts/nightly_bench.py` runs as an EventBridge-triggered Lambda at 03:00 UTC.

1. Pull bench fixture from `s3://kb-{env}/bench/nightly_queries.jsonl` (per `11_*.md §6`)
2. For each of 10 queries: call `POST /query` against the deployed `kbm-search` ALB
3. Score each result against `expected_docids_top3` (per `11_*.md §6.2`)
4. Aggregate score (max 10.0)
5. Publish to CloudWatch metric `kbm.nightly.recall_at_3`
6. If score < ALARM_NIGHTLY_BENCH_RECALL_MIN (6.0): emit SNS to ops topic

Per-environment: dev bench runs nightly; prod bench runs daily at 04:00 UTC.

---

## §9. Definition of Done — SLO file

- [ ] All 9 alarms in §3 wired in `cdk/stack.py` via constants from `src/kbm/constants.py`
- [ ] `scripts/check_ci_alarms_use_slo_file.py` enforces no magic numbers in CDK
- [ ] CloudWatch dashboard JSON committed at `docs/dashboards/kbm.json` (mirrors the SLI/SLO table in §1)
- [ ] Nightly bench Lambda deployed and emits to `kbm.nightly.recall_at_3`
- [ ] Error-budget tracking spreadsheet linked in `15_ops_runbook.md §0`
- [ ] After 1 week of prod data: revisit §4 targets and pin to measured values
