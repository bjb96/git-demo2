# 03 — Data Contracts (every Pydantic model, every constant, every artifact shape)

> **Purpose** — every data shape `kbm` produces, reads, or exchanges is specified here. Pydantic models, enums, exception hierarchy, on-disk artifact layout, S3 layout, Redis layout, CloudWatch metric names. **Junior agent rule: no model is defined elsewhere. If you find yourself needing a new model, open an issue first.**
>
> **Audience** — junior coding agent at the start of Phase 1.
>
> **Where these live in code:** every model in this file lives in `src/kbm/types.py`. Every constant in this file lives in `src/kbm/constants.py`. Every exception lives in `src/kbm/exceptions.py`. No scattered model files.

---

## §1. The four-bucket structure

The contracts split into 4 buckets:

| Bucket | Lives in | Read by | Written by |
|---|---|---|---|
| **A — Build-input models** | `manifest.yaml` (on disk) → `kbm/types.py` | Build half + Search half (manifest is shipped to S3) | Developer (hand-edited) |
| **B — Build-output artifacts** | `s3://kb-{env}/...` (parquet + sqlite + faiss + .md blobs) | Search half (read-only) | Build half |
| **C — Runtime request/response models** | `kbm/types.py` (in-memory only) | MCP server + tool callers | MCP server |
| **D — Cache + metric shapes** | Redis + CloudWatch (in-memory / managed) | Both halves | Both halves |

The §-numbered subsections below follow this order.

---

## §2. BUCKET A — Build-input models (`manifest.yaml` + Pydantic validators)

### §2.1 `Manifest` (Pydantic; validates `manifest.yaml`)

```python
# src/kbm/types.py
from typing import Literal, Annotated
from pydantic import BaseModel, Field, field_validator
from datetime import datetime


class BuildInfo(BaseModel):
    """Locked at build start; copied verbatim into the output."""
    kbm_version: str                                                      # set from setuptools-scm or pyproject version
    embedding_model_id: Literal["amazon.titan-embed-text-v2:0"]           # ADR-006 — change requires ADR
    embedding_dim: Literal[1024]                                          # MUST match embedding_model_id
    rerank_model: Literal["gpt-4.1"]                                      # ADR-007
    expand_model: Literal["gpt-4.1"]                                      # ADR-007
    chunk_size_tokens: Literal[900]                                       # see 05_chunker_spec.md §1
    chunk_overlap_tokens: Literal[135]                                    # 15% of 900
    chunk_window_tokens: Literal[200]


class CollectionSpec(BaseModel):
    """One indexable collection."""
    kind: Literal["wiki", "raw"]                                          # ADR-013 — wiki is primary, raw is fallback
    path: str = Field(min_length=1, description="Relative path on local disk OR s3:// URI")
    pattern: str = Field(default="**/*.md", description="Glob; supports {md,mdx,txt}")
    ignore: list[str] = Field(default_factory=list)
    context: dict[str, str] = Field(default_factory=dict, description="Path-prefix → context string")
    include_by_default: bool = True                                       # if False: only queried when -c is passed
    chunk_strategy: Literal["regex", "auto"] = "regex"                    # "auto" = AST-aware for code


class Manifest(BaseModel):
    """The on-disk manifest.yaml. Frozen — re-deploying requires a new build."""
    build_info: BuildInfo
    global_context: str | None = None                                     # prepended to every result's context
    collections: dict[str, CollectionSpec] = Field(min_length=1)          # name → spec

    @field_validator("collections")
    @classmethod
    def _at_least_one_wiki(cls, v: dict[str, CollectionSpec]) -> dict[str, CollectionSpec]:
        """ADR-013: a well-formed KB has ≥1 'wiki' collection.

        Reason: the wiki/raw architecture requires the curated layer to exist
        even if it's initially empty. Empty wiki is OK; missing wiki is not.
        """
        if not any(c.kind == "wiki" for c in v.values()):
            raise ValueError("Manifest must declare at least one collection with kind='wiki'")
        return v
```

**Canonical `manifest.yaml` example (committed at `tests/fixtures/gold_kb/manifest.yaml`):**

```yaml
build_info:
  kbm_version: "0.1.0"
  embedding_model_id: "amazon.titan-embed-text-v2:0"
  embedding_dim: 1024
  rerank_model: "gpt-4.1"
  expand_model: "gpt-4.1"
  chunk_size_tokens: 900
  chunk_overlap_tokens: 135
  chunk_window_tokens: 200

global_context: |
  This knowledge base supports the my-product internal AI agent.
  Always cite documents by docid or qmd://collection/path.

collections:
  wiki:
    kind: "wiki"
    path: "./wiki"
    pattern: "**/*.md"
    context:
      "/":      "Curated, interlinked wiki pages. Cite these by default."
      "/index": "Table of contents — scan first."
    include_by_default: true
    chunk_strategy: "regex"

  engineering_raw:
    kind: "raw"
    path: "./raw/engineering"
    pattern: "**/*.{md,mdx}"
    ignore: ["**/drafts/**", "**/*.test.md"]
    context:
      "/":         "Engineering wiki — runbooks, ADRs, API references."
      "/runbooks": "On-call runbooks."
      "/adr":      "Architecture Decision Records."
    include_by_default: false                                             # only queried when wiki returns 0
    chunk_strategy: "regex"
```

---

## §3. BUCKET B — Build-output artifacts (S3 layout — single source of truth)

The output of `kbm build && kbm embed && kbm lint` is **byte-identical across consecutive runs** (HC-2). The product owner runs `aws s3 sync ./kb-dev/ s3://kb-dev/` (or `kbm upload`).

### §3.1 S3 layout

```
s3://kb-{env}/                                          {env} ∈ {dev, staging, prod}
├── manifest.yaml                                       Bucket A §2.1 verbatim
├── build_info.json                                     §3.2 below
├── catalog.parquet                                     §3.3 below
├── contexts.json                                       §3.4 below — snapshot of context maps for fast load
├── content/
│   └── {hash[0:2]}/{hash}.md                           §3.5 below — content-addressable blobs (256 shards)
├── chunks/
│   └── {hash[0:2]}/{hash}_chunks.parquet               §3.6 below — per-document chunks
├── fts/
│   └── {collection}.sqlite                             §3.7 below — per-collection FTS5
└── vectors/
    └── {collection}/
        ├── index.faiss                                 §3.8 below — FAISS index (mmap-able)
        ├── meta.parquet                                §3.9 below — row_id → hash_seq metadata
        └── embedding_model.txt                         §3.10 below — dim safety check (HC-3)
```

**S3 path drift-check**: `scripts/check_s3_layout.py` parses this section and asserts that `src/kbm/build/uploader.py` + `src/kbm/search/s3.py` reference these paths verbatim. **Adding a new path requires editing this file first.**

### §3.2 `build_info.json`

```python
class BuildResult(BaseModel):
    """Written to s3://kb-{env}/build_info.json at the end of `kbm build && kbm embed && kbm lint`."""
    kbm_version: str
    built_at: datetime
    manifest_sha256: str                                                  # hex digest of manifest.yaml bytes
    raw_input_count: int                                                  # total files walked across collections
    docs_indexed: int                                                     # written to catalog.parquet
    chunks_emitted: int                                                   # sum across all hashes
    embeddings_emitted: int                                               # == chunks_emitted on success
    lint_passed: bool                                                     # HC-5 — upload refuses if False
    lint_errors: list["LintFinding"]                                      # see §3.11
    lint_warnings: list["LintFinding"]
    collections: dict[str, "CollectionBuildStats"]                        # name → §3.12

    model_config = {"json_schema_extra": {"example": {
        "kbm_version": "0.1.0",
        "manifest_sha256": "abc123...",
        "docs_indexed": 142,
        "lint_passed": True,
    }}}


class LintFinding(BaseModel):
    code: Literal["L1", "L2", "L3", "L4", "L5", "L6", "L7", "L8", "L9"]   # see §3.11
    severity: Literal["error", "warn", "info"]
    where: str                                                            # qmd://collection/path OR chunk id
    message: str


class CollectionBuildStats(BaseModel):
    doc_count: int
    chunk_count: int
    vector_count: int
    total_bytes: int                                                      # sum of body lengths
    last_modified: datetime
```

### §3.3 `catalog.parquet` (Polars/DuckDB-readable; one row per active document)

| Column | Type | Description |
|---|---|---|
| `docid` | str (6 chars) | First 6 hex chars of SHA-256 — see §5.2 |
| `hash` | str (64 chars) | Full SHA-256 hex of UTF-8 body |
| `collection` | str | Collection name from manifest |
| `path` | str | Path RELATIVE to collection root, forward-slash normalized |
| `title` | str | First H1 in body, else filename without extension |
| `body_len` | uint32 | UTF-8 byte length of body |
| `chunk_count` | uint16 | Number of chunks this doc produced |
| `modified_at` | int64 | Unix epoch seconds (UTC) |
| `kind` | str | `"wiki"` or `"raw"` — copied from collection's CollectionSpec.kind |

**Polars schema (verbatim, in `src/kbm/types.py`):**

```python
import polars as pl

CATALOG_SCHEMA: pl.Schema = pl.Schema({
    "docid":       pl.Utf8,
    "hash":        pl.Utf8,
    "collection":  pl.Utf8,
    "path":        pl.Utf8,
    "title":       pl.Utf8,
    "body_len":    pl.UInt32,
    "chunk_count": pl.UInt16,
    "modified_at": pl.Int64,
    "kind":        pl.Utf8,
})
```

### §3.4 `contexts.json`

```python
class ContextSnapshot(BaseModel):
    """Snapshot of all context maps from manifest.yaml, flattened for fast load on container boot."""
    global_context: str | None
    per_collection: dict[str, dict[str, str]]                             # collection → path-prefix → context string
```

### §3.5 `content/{hash[0:2]}/{hash}.md`

Raw UTF-8 markdown body. Stored under 256 shard prefixes (`00`..`ff`) for S3 prefix throughput. **Content-addressable: writing the same body twice is a no-op.**

### §3.6 `chunks/{hash[0:2]}/{hash}_chunks.parquet`

One parquet file per source hash, columnar for fast hash-lookup. **All chunks of one doc fit in one file.**

| Column | Type | Description |
|---|---|---|
| `hash` | str (64) | redundant w/ filename, included for joinability |
| `seq` | uint16 | 0-indexed chunk order within doc |
| `pos` | uint32 | char offset of chunk start in body |
| `end_pos` | uint32 | char offset of chunk end (exclusive) |
| `text` | str | the chunk content |
| `n_tokens` | uint16 | token count via `tiktoken cl100k_base` |

```python
CHUNKS_SCHEMA: pl.Schema = pl.Schema({
    "hash":     pl.Utf8,
    "seq":      pl.UInt16,
    "pos":      pl.UInt32,
    "end_pos":  pl.UInt32,
    "text":     pl.Utf8,
    "n_tokens": pl.UInt16,
})
```

### §3.7 `fts/{collection}.sqlite`

A single SQLite database per collection, containing exactly one virtual table.

**Schema (verbatim — `src/kbm/build/fts5_builder.py` must `CREATE` this exact shape):**

```sql
CREATE VIRTUAL TABLE documents_fts USING fts5(
    filepath, title, body,
    tokenize='porter unicode61'
);
-- After INSERT: INSERT INTO documents_fts(documents_fts) VALUES('optimize');
```

**BM25 column weights applied at search time** (in `src/kbm/search/fts.py`):

```python
# Verbatim port of doc_search store.ts:3195 — see 24_audit_and_corrections.md §1 row 11
FTS_WEIGHT_FILEPATH = 1.5
FTS_WEIGHT_TITLE    = 4.0
FTS_WEIGHT_BODY     = 1.0

# Query SQL — verbatim shape from doc_search store.ts:3193-3200
SQL_FTS5_SEARCH = """
WITH fts_matches AS (
    SELECT rowid, bm25(documents_fts, ?, ?, ?) AS bm25_score
    FROM documents_fts WHERE documents_fts MATCH ?
    ORDER BY bm25_score ASC LIMIT ?
)
SELECT filepath, title, bm25_score
FROM fts_matches
ORDER BY bm25_score ASC
"""
```

`filepath` is `collection/path` (no `qmd://` prefix in the stored value — added at result-construction time).

### §3.8 `vectors/{collection}/index.faiss`

FAISS binary file. **Index type chosen by total vector count** (from `BuildResult.collections[name].vector_count`):

```python
# Verbatim from 21_q1_kb_build_pipeline.md §2 Stage 4b
def select_faiss_index_type(n_vectors: int, dim: int = 1024) -> "faiss.Index":
    if n_vectors < 100_000:
        return faiss.IndexFlatIP(dim)                                     # exact cosine on normalized vectors
    elif n_vectors < 10_000_000:
        idx = faiss.IndexHNSWFlat(dim, 32, faiss.METRIC_INNER_PRODUCT)
        idx.hnsw.efConstruction = 200
        idx.hnsw.efSearch = 64
        return idx
    else:
        quantizer = faiss.IndexFlatIP(dim)
        nlist = int(n_vectors ** 0.5)
        return faiss.IndexIVFPQ(quantizer, dim, nlist, 16, 8)
```

**Vector normalization (HC-6):** every vector must be L2-normalized BEFORE `index.add()`. Then `IndexFlatIP` (inner product) is exactly cosine similarity.

### §3.9 `vectors/{collection}/meta.parquet`

| Column | Type | Description |
|---|---|---|
| `row_id` | uint32 | FAISS row index (0..N-1 in insertion order) |
| `hash_seq` | str | Composite key `{hash}_{seq}` |
| `hash` | str (64) | for catalog join |
| `seq` | uint16 | chunk seq within doc |
| `pos` | uint32 | char offset in body (for snippet extraction) |
| `text_preview` | str | first 200 chars of chunk — for debug only, never used in retrieval |

```python
META_SCHEMA: pl.Schema = pl.Schema({
    "row_id":       pl.UInt32,
    "hash_seq":     pl.Utf8,
    "hash":         pl.Utf8,
    "seq":          pl.UInt16,
    "pos":          pl.UInt32,
    "text_preview": pl.Utf8,
})
```

### §3.10 `vectors/{collection}/embedding_model.txt` (HC-3 safety)

Two-line text file:

```
amazon.titan-embed-text-v2:0
1024
```

Boot-time check in `src/kbm/search/store.py`:

```python
def _verify_embedding_model(coll_dir: Path) -> None:
    """HC-3: refuse to serve if the deployed model doesn't match the build-time model."""
    txt = (coll_dir / "embedding_model.txt").read_text().strip().splitlines()
    if len(txt) != 2:
        raise DimMismatchError(f"Malformed embedding_model.txt in {coll_dir}")
    declared_model, declared_dim = txt[0], int(txt[1])
    if declared_model != settings.embed_model_id:
        raise DimMismatchError(
            f"Collection {coll_dir.name} was built with {declared_model}, "
            f"but search service is configured with {settings.embed_model_id}. "
            f"Rebuild + re-upload before serving queries."
        )
    if declared_dim != settings.embed_dim:
        raise DimMismatchError(
            f"Dim mismatch: built={declared_dim}, runtime={settings.embed_dim}"
        )
```

### §3.11 `Lint9Validator` — the 9 lint checks (HC-5)

```python
class LintFinding(BaseModel):
    code: Literal["L1", "L2", "L3", "L4", "L5", "L6", "L7", "L8", "L9"]
    severity: Literal["error", "warn", "info"]
    where: str
    message: str
```

| Code | Severity | Check | Detection |
|---|---|---|---|
| `L1` | warn | Missing context | Document at path with no matching prefix in `CollectionSpec.context` |
| `L2` | error | Partial embeddings | Doc's `chunk_count` in catalog ≠ row count in `meta.parquet` for that hash |
| `L3` | info | Duplicate hashes across collections | Same hash appears in ≥ 2 collections (informational; CA storage handles dedup) |
| `L4` | warn | Oversized chunks | Any chunk with `n_tokens > 1100` (target 900 + 22% tolerance) |
| `L5` | info | Undersized chunks | Any chunk with `n_tokens < 100` (often == small docs; informational) |
| `L6` | error | Zero-length doc | Doc with `body_len == 0` |
| `L7` | error | UTF-8 decode failure | Source file that failed `bytes.decode("utf-8")` during walk |
| `L8` | warn | AST grammar load failure | Code file where tree-sitter grammar failed; fell back to regex |
| `L9` | error | Embedding-model mismatch | `vectors/{c}/embedding_model.txt` doesn't match `BuildInfo.embedding_model_id` |

`scripts/check_8_pydantic_schemas.py` asserts these 9 codes are defined exactly once each.

### §3.12 `CollectionBuildStats`

See §3.2.

---

## §4. BUCKET C — Runtime request/response models

### §4.1 `ExpandedQuery` — the typed-subquery DSL

Verbatim from doc_search `store.ts:328-334`:

```python
class ExpandedQuery(BaseModel):
    """One typed sub-query in the lex/vec/hyde DSL."""
    type: Literal["lex", "vec", "hyde"]
    query: str = Field(min_length=1, max_length=500)
```

### §4.2 `QueryToolInput` — MCP `query` tool input

Mirrors doc_search `mcp/server.ts:301-317`:

```python
class QueryToolInput(BaseModel):
    """Input to POST /mcp tools/call name=query."""
    query: str | None = Field(default=None, description="Plain NL query — auto-expanded via gpt-4.1")
    searches: list[ExpandedQuery] | None = Field(
        default=None, min_length=1, max_length=10,
        description="Pre-expanded typed sub-queries — skip auto-expansion"
    )
    intent: str | None = Field(default=None, max_length=500)
    collections: list[str] | None = None                                  # None = default-include set
    limit: int = Field(default=10, ge=1, le=100)
    candidate_limit: int = Field(default=40, ge=1, le=100)                # see 06_*.md §5
    min_score: float = Field(default=0.0, ge=0.0, le=1.0)
    rerank: bool = True
    explain: bool = False                                                 # adds RRF + blend traces

    @field_validator("searches")
    @classmethod
    def _query_or_searches(cls, v, info):
        """Exactly one of {query, searches} must be present."""
        if v is None and info.data.get("query") is None:
            raise ValueError("Must provide either 'query' or 'searches'")
        if v is not None and info.data.get("query") is not None:
            raise ValueError("Provide only one of 'query' or 'searches' (not both)")
        return v
```

### §4.3 `SearchResultItem` — one row in `QueryToolOutput.results`

```python
class SearchResultItem(BaseModel):
    """Mirror of doc_search MCP query result (mcp/server.ts:39-47)."""
    docid: str                                                            # 6-char SHA-256 prefix
    file: str                                                             # virtual path: qmd://collection/path
    title: str
    score: float = Field(ge=0.0, le=1.0)                                  # final blended score
    context: str | None = None                                            # path-prefix context attached
    line: int = Field(ge=1)                                               # snippet start line (1-indexed)
    snippet: str                                                          # ~500 chars with terms highlighted
    explain: "HybridQueryExplain | None" = None                           # only if input.explain=True
```

### §4.4 `HybridQueryExplain` — `--explain` traces

```python
class RankedListTrace(BaseModel):
    list_idx: int
    collection: str
    sub_query: ExpandedQuery
    rank: int                                                             # 0-indexed; the rank this doc had in this list
    backend_score: float                                                  # BM25-normalized or cosine sim

class HybridQueryExplain(BaseModel):
    rrf_rank: int                                                         # 1-indexed final rank pre-blend
    rrf_score: float                                                      # sum of weighted contributions + bonus
    top_rank_bonus: float                                                 # 0.0, 0.02, or 0.05
    contributing_lists: list[RankedListTrace]
    rerank_score: float | None                                            # gpt-4.1 score [0,1]; None if rerank=False
    blend_weight: float                                                   # 0.75, 0.60, or 0.40
    blended_score: float
```

### §4.5 `QueryToolOutput`

```python
class QueryToolOutput(BaseModel):
    results: list[SearchResultItem]
    total_candidates: int                                                 # before rerank
    bypass_reason: Literal["strong_signal_bypass"] | None = None
    latency_ms: int
```

### §4.6 `GetToolInput` / `GetToolOutput`

```python
class GetToolInput(BaseModel):
    file: str = Field(min_length=1)                                       # docid "#abc123" | qmd://coll/path | path:line
    from_line: int | None = Field(default=None, ge=1)
    max_lines: int | None = Field(default=None, ge=1, le=10_000)
    line_numbers: bool = False


class GetToolOutput(BaseModel):
    docid: str
    file: str
    title: str
    context: str | None = None
    body: str                                                             # may be sliced + line-numbered


class DocumentNotFound(BaseModel):
    """Returned when get() can't resolve the requested file."""
    error: Literal["not_found"]
    query: str                                                            # what the caller asked for
    similar: list[str] = Field(default_factory=list, max_length=5)        # fuzzy-match suggestions
```

### §4.7 `MultiGetToolInput` / `MultiGetToolOutput`

```python
class MultiGetToolInput(BaseModel):
    pattern: str                                                          # glob "**/*.md" | comma "a.md,b.md" | docid list
    max_bytes: int = Field(default=10_240, ge=1, le=1_000_000)            # default 10KB — verbatim from doc_search store.ts:49
    max_lines: int | None = Field(default=None, ge=1, le=10_000)
    line_numbers: bool = False


class MultiGetDoc(BaseModel):
    docid: str
    file: str
    title: str
    context: str | None = None
    body: str
    skipped: bool = False


class MultiGetSkip(BaseModel):
    docid: str
    file: str
    skipped: Literal[True] = True
    reason: str                                                           # e.g. "File too large (15.2KB > 10KB). Use 'get' with #abc123"


class MultiGetToolOutput(BaseModel):
    docs: list[MultiGetDoc | MultiGetSkip]
    errors: list[str] = Field(default_factory=list)
```

### §4.8 `StatusToolOutput` (MCP `status` has no input)

```python
class CollectionInfo(BaseModel):
    name: str
    kind: Literal["wiki", "raw"]
    path: str                                                             # the manifest declared path
    pattern: str
    doc_count: int
    last_updated: datetime | None
    context: str                                                          # the "/" prefix context (top-level summary)


class StatusToolOutput(BaseModel):
    total_documents: int
    has_vector_index: bool                                                # True iff every collection has a non-empty index.faiss
    collections: list[CollectionInfo]
    kbm_version: str
    last_updated: datetime | None
    capability_gaps: list[str] = Field(default_factory=list)              # e.g. ["No vector embeddings yet for 'raw'"]
```

### §4.9 `LsToolInput` / `LsToolOutput`

```python
class LsToolInput(BaseModel):
    path: str | None = None                                               # None → list collections; "coll" → list immediate children; "coll/sub" → list children of sub
    recursive: bool = False


class LsEntry(BaseModel):
    name: str                                                             # last segment
    kind: Literal["collection", "folder", "file"]
    doc_count: int                                                        # for folder/collection: descendants; for file: 1
    last_modified: datetime | None = None
    context: str | None = None


class LsToolOutput(BaseModel):
    entries: list[LsEntry]
```

---

## §5. Shared helpers (every other module imports these)

### §5.1 `Chunk` (in-memory, NOT serialized to S3 as-is)

```python
class Chunk(BaseModel):
    """One chunk of a document. Lives in memory during build + during query rerank-prep."""
    text: str
    pos: int                                                              # char start in original body
    end_pos: int                                                          # char end (exclusive)
    n_tokens: int | None = None                                           # filled after tiktoken count
```

### §5.2 `Document` (in-memory walker output, NOT serialized)

```python
class Document(BaseModel):
    """Walker output. NOT persisted directly; the catalog.parquet row is derived from this."""
    docid: str = Field(min_length=6, max_length=6)
    hash: str = Field(min_length=64, max_length=64)
    collection: str
    path: str                                                             # forward-slash normalized RELATIVE path
    title: str
    body: str
    modified_at: int                                                      # unix seconds
```

### §5.3 6-char docid (`src/kbm/shared/docid.py`)

```python
# Verbatim port of doc_search store.ts:1811-1813
def get_docid(hash_hex: str) -> str:
    """First 6 hex chars of SHA-256. Collisions resolved by first-match-wins LIKE 'abc123%'."""
    if len(hash_hex) < 6:
        raise ValueError(f"hash_hex too short: {len(hash_hex)}")
    return hash_hex[:6]


def normalize_docid(s: str) -> str:
    """Strip surrounding quotes/whitespace + leading '#'. Lowercase."""
    s = s.strip().strip('"').strip("'")
    if s.startswith("#"):
        s = s[1:]
    return s.lower()


def is_docid(s: str) -> bool:
    """True iff normalize_docid(s) is 6-64 hex chars."""
    normalized = normalize_docid(s)
    return 6 <= len(normalized) <= 64 and all(c in "0123456789abcdef" for c in normalized)
```

### §5.4 Virtual paths (`src/kbm/shared/paths.py`)

```python
import re

VIRTUAL_PATH_RE = re.compile(r'^qmd://([^/]+)/?(.*)$')

def parse_virtual_path(s: str) -> tuple[str, str] | None:
    """Returns (collection, path) or None. Port of doc_search store.ts:613-628."""
    m = VIRTUAL_PATH_RE.match(s)
    if not m:
        return None
    return m.group(1), m.group(2)


def build_virtual_path(collection: str, path: str) -> str:
    """Returns 'qmd://collection/path'. Port of doc_search store.ts:633-636."""
    return f"qmd://{collection}/{path}"


def is_virtual_path(s: str) -> bool:
    return s.startswith("qmd://")
```

---

## §6. BUCKET D — Cache + metric shapes

### §6.1 Redis layout (`src/kbm/search/cache.py`)

| Key pattern | TTL | Value | Set by | Read by |
|---|---|---|---|---|
| `kbm:{env}:expand:{sha256(query,model,intent)}` | 86_400 (24h) | JSON-encoded `list[ExpandedQuery]` | `kbm.search.expand` | `kbm.search.expand` |
| `kbm:{env}:rerank:{sha256(query,model,chunk_text)}` | 86_400 (24h) | float as `str` (e.g. `"0.873"`) | `kbm.search.rerank` | `kbm.search.rerank` |
| `kbm:{env}:bypass_rate` | n/a | Redis INCR counter | `kbm.search.query` on bypass hit | CloudWatch metric extractor |

**Cache key construction (verbatim port of doc_search `store.ts:2024-2029`):**

```python
import hashlib, json

def cache_key(url: str, body: dict) -> str:
    h = hashlib.sha256()
    h.update(url.encode("utf-8"))
    h.update(json.dumps(body, sort_keys=True).encode("utf-8"))             # sort_keys for determinism
    return h.hexdigest()
```

Full key construction examples:

```python
# Expansion cache key
expand_key = f"kbm:{settings.env}:expand:{cache_key('expandQuery', {'query': q, 'model': m, 'intent': intent_or_none})}"

# Rerank cache key (content-keyed — moves with chunk across path renames)
rerank_key = f"kbm:{settings.env}:rerank:{cache_key('rerank', {'query': rerank_q, 'model': m, 'chunk': chunk_text})}"
```

### §6.2 CloudWatch metrics (`src/kbm/obs/metrics.py`)

The 8 metric names emitted by `kbm.search`:

| Metric name | Unit | Cardinality | Aggregation in CloudWatch |
|---|---|---|---|
| `kbm.query.latency_ms` | Milliseconds | dims=`env, collection_count_bucket` | p50, p95, p99 |
| `kbm.query.cache_hit_rate` | Percent | dims=`env, cache_layer={expand,rerank}` | Average |
| `kbm.query.strong_signal_bypass_rate` | Percent | dims=`env` | Average |
| `kbm.rerank.tokens_in` | Count | dims=`env` | Sum |
| `kbm.rerank.tokens_out` | Count | dims=`env` | Sum |
| `kbm.embed.tokens` | Count | dims=`env, mode={build,query}` | Sum |
| `kbm.build.wall_time_sec` | Seconds | dims=`env, collection` | Sum, Average |
| `kbm.search.error_count` | Count | dims=`env, error_class` | Sum |

**Hard rule (HC-1 + drift script):** every metric name appears verbatim in `src/kbm/constants.py` as a string constant:

```python
# src/kbm/constants.py
CW_METRIC_QUERY_LATENCY     = "kbm.query.latency_ms"
CW_METRIC_CACHE_HIT_RATE    = "kbm.query.cache_hit_rate"
CW_METRIC_BYPASS_RATE       = "kbm.query.strong_signal_bypass_rate"
CW_METRIC_RERANK_TOKENS_IN  = "kbm.rerank.tokens_in"
CW_METRIC_RERANK_TOKENS_OUT = "kbm.rerank.tokens_out"
CW_METRIC_EMBED_TOKENS      = "kbm.embed.tokens"
CW_METRIC_BUILD_WALL_TIME   = "kbm.build.wall_time_sec"
CW_METRIC_ERROR_COUNT       = "kbm.search.error_count"
```

`scripts/check_metric_names.py` asserts every metric name in `src/kbm/obs/metrics.py` references one of these constants.

---

## §7. Exception hierarchy (`src/kbm/exceptions.py`)

```python
class KbmError(Exception):
    """Base for all kbm-raised errors. Never raise bare Exception."""


# Build-side
class ManifestValidationError(KbmError):
    """manifest.yaml failed Pydantic validation."""


class WalkError(KbmError):
    """Filesystem walk failed (permission denied, broken symlink, etc.)."""


class ChunkerError(KbmError):
    """Smart chunker produced invalid output (e.g. chunk with text==''."""


class EmbedderError(KbmError):
    """Bedrock embed call failed after retries."""


class FaissBuildError(KbmError):
    """faiss-cpu raised; e.g. dim mismatch, NaN vector."""


class LintFailedError(KbmError):
    """Lint pass found ≥1 error (severity='error'). Uploader refuses (HC-5)."""


class UploadError(KbmError):
    """aws s3 sync failed mid-way OR ETag verification failed."""


# Search-side
class DimMismatchError(KbmError):
    """vectors/{c}/embedding_model.txt doesn't match runtime config. (HC-3)"""


class CollectionNotLoadedError(KbmError):
    """Tried to query a collection whose artifacts haven't been pulled from S3 yet."""


class CacheError(KbmError):
    """Redis call failed; should degrade gracefully (search pipeline runs without cache)."""


class ExpandError(KbmError):
    """gpt-4.1 expansion failed; fall back to [{lex:q},{vec:q}]."""


class RerankError(KbmError):
    """gpt-4.1 rerank failed; skip rerank step, return RRF results directly."""


class AuthError(KbmError):
    """Bearer-token middleware rejected the request."""
```

**Retry policy (verbatim — `src/kbm/constants.py`):**

```python
RETRY_POLICIES: dict[type[KbmError], dict] = {
    EmbedderError: {"max_attempts": 4, "backoff_seconds": [1, 2, 4, 8]},
    ExpandError:   {"max_attempts": 2, "backoff_seconds": [1, 2]},
    RerankError:   {"max_attempts": 2, "backoff_seconds": [1, 2]},
    UploadError:   {"max_attempts": 3, "backoff_seconds": [2, 5, 15]},
    CacheError:    {"max_attempts": 1, "backoff_seconds": []},  # graceful degradation
}
```

---

## §8. Enums (`src/kbm/types.py`)

```python
from enum import StrEnum


class CollectionKind(StrEnum):
    WIKI = "wiki"
    RAW = "raw"


class SubQueryType(StrEnum):
    LEX = "lex"
    VEC = "vec"
    HYDE = "hyde"


class LintCode(StrEnum):
    L1 = "L1"   # missing context
    L2 = "L2"   # partial embeddings
    L3 = "L3"   # duplicate hashes across collections
    L4 = "L4"   # oversized chunks
    L5 = "L5"   # undersized chunks
    L6 = "L6"   # zero-length doc
    L7 = "L7"   # UTF-8 decode failure
    L8 = "L8"   # AST grammar load failure
    L9 = "L9"   # embedding-model mismatch


class Severity(StrEnum):
    ERROR = "error"
    WARN = "warn"
    INFO = "info"


class ChunkStrategy(StrEnum):
    REGEX = "regex"
    AUTO = "auto"
```

`scripts/check_enum_completeness.py` asserts these enums are exhaustively covered in every `match` statement.

---

## §9. Constants summary (every numeric constant `kbm` uses)

All live in `src/kbm/constants.py`. **HC-1**: every constant references a row in `../doc_search_tool/24_audit_and_corrections.md §1`.

```python
# Chunking — see 05_chunker_spec.md §1 + 24_audit §1 rows 1-2
CHUNK_SIZE_TOKENS      = 900            # row 2
CHUNK_OVERLAP_TOKENS   = 135            # row 2 (15% of 900)
CHUNK_SIZE_CHARS       = 3600           # row 2 (4 chars/token)
CHUNK_OVERLAP_CHARS    = 540            # row 2
CHUNK_WINDOW_TOKENS    = 200            # row 2
CHUNK_WINDOW_CHARS     = 800            # row 2
DECAY_FACTOR           = 0.7            # row 3

# Retrieval — see 06_retrieval_pipeline_spec.md §3 + 24_audit §1 rows 5-10
STRONG_SIGNAL_MIN_SCORE = 0.85          # row 5
STRONG_SIGNAL_MIN_GAP   = 0.15          # row 5
RERANK_CANDIDATE_LIMIT  = 40            # row 6
RRF_K                   = 60            # row 7
TOP_RANK_BONUS_R0       = 0.05          # row 8 (rank 0)
TOP_RANK_BONUS_R1_R2    = 0.02          # row 8 (rank 1 or 2)
ORIGINAL_QUERY_WEIGHT   = 2.0           # row 9
EXPANSION_QUERY_WEIGHT  = 1.0           # row 9

# Position-aware blend — row 10
BLEND_RRF_RANK_1_3   = 0.75
BLEND_RRF_RANK_4_10  = 0.60
BLEND_RRF_RANK_11_UP = 0.40

# BM25 column weights — row 11
FTS_WEIGHT_FILEPATH = 1.5
FTS_WEIGHT_TITLE    = 4.0
FTS_WEIGHT_BODY     = 1.0

# Snippet intent weights — row 12
INTENT_WEIGHT_SNIPPET = 0.3
INTENT_WEIGHT_CHUNK   = 0.5

# Defaults — row 13
DEFAULT_MULTI_GET_MAX_BYTES = 10_240    # 10KB
DEFAULT_LIMIT               = 10

# FAISS HNSW — see 21_q1 §2 Stage 4b
FAISS_HNSW_M               = 32
FAISS_HNSW_EF_CONSTRUCTION = 200
FAISS_HNSW_EF_SEARCH       = 64

# Generation params — row 22
EXPAND_TEMPERATURE     = 0.7
EXPAND_TOP_K           = 20
EXPAND_TOP_P           = 0.8
EXPAND_MAX_TOKENS      = 600
EXPAND_PRESENCE_PENALTY = 0.5

# Rerank params
RERANK_MAX_TOKENS      = 200
RERANK_TEMPERATURE     = 0.0            # deterministic — different from expansion

# Cache TTL
CACHE_TTL_SECONDS = 86_400              # 24h

# Idle dispose (server) — see 24_audit §1 row 19
# We don't dispose because Bedrock is stateless; constant kept for parity
DEFAULT_INACTIVITY_TIMEOUT_MS = 5 * 60 * 1000

# Lint thresholds
LINT_L4_OVERSIZED_TOKENS  = 1_100       # 22% over chunk target
LINT_L5_UNDERSIZED_TOKENS = 100
```

**Drift-check (`scripts/check_constants_match_source.py`):** for every constant above, the script greps the named row in `24_audit §1` and asserts the value matches. Any divergence fails CI.

---

## §10. Settings (`src/kbm/settings.py`)

```python
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from typing import Literal


class Settings(BaseSettings):
    """SINGLE source of truth for env vars. Read from .env in dev, ENV vars in ECS."""

    model_config = SettingsConfigDict(env_file=".env", env_prefix="KBM_", extra="forbid")

    env: Literal["dev", "staging", "prod", "test"] = "dev"
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_format: Literal["json", "console"] = "json"

    # S3
    s3_bucket: str
    s3_region: str = "us-east-1"
    local_cache_root: str = "/var/cache/kbm"
    local_cache_ttl_sec: int = Field(default=3600, ge=60)

    # Bedrock
    bedrock_region: str = "us-east-1"
    embed_model_id: str = "amazon.titan-embed-text-v2:0"
    embed_dim: int = 1024

    # OpenAI
    expand_model: str = "gpt-4.1"
    rerank_model: str = "gpt-4.1"
    expand_max_tokens: int = 600
    rerank_max_tokens: int = 200

    # Redis
    redis_url: str = "redis://localhost:6379/0"
    cache_ttl_sec: int = 86_400

    # Server
    bearer_token: str = ""                                                # required in prod via Secrets Manager
    host: str = "0.0.0.0"
    port: int = 8181
    worker_count: int = 2


_settings: Settings | None = None

def get_settings() -> Settings:
    """Singleton accessor — settings are immutable after first access."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
```

---

## §11. Cross-references

- Every numeric constant: cross-check against [`../doc_search_tool/24_audit_and_corrections.md §1`](../doc_search_tool/24_audit_and_corrections.md)
- Every BREAK_PATTERN regex: see [05_chunker_spec.md §2](05_chunker_spec.md)
- Every MCP tool description: see [04_mcp_tool_contract.md](04_mcp_tool_contract.md) (verbatim)
- Every retry/timeout: see [12_performance_slo.md §4](12_performance_slo.md)
- Every CloudWatch alarm threshold: see [12_performance_slo.md §3](12_performance_slo.md)

---

## §12. Definition of Done — Phase 1

- [ ] `src/kbm/types.py` contains every Pydantic model in §2-§5, §6, §7, §8
- [ ] `src/kbm/constants.py` contains every constant in §9 — and ONLY those constants
- [ ] `src/kbm/exceptions.py` contains every exception class in §7
- [ ] `src/kbm/settings.py` matches §10 verbatim
- [ ] `src/kbm/shared/{docid,paths,token_count,hash}.py` match the helper specs in §5 + §6
- [ ] `scripts/check_constants_match_source.py` is no longer a stub — it grep-asserts every constant against `24_audit §1`
- [ ] `scripts/check_8_pydantic_schemas.py` exists and passes
- [ ] Every Pydantic model has at least one unit test in `tests/unit/test_<name>.py` per the Given/When/Then in `10_tdd_acceptance.md §2`
- [ ] `make schemas` regenerates `docs/schemas/*.json` and they're committed (drift-protected by `scripts/check_schemas_unchanged.py`)
- [ ] Coverage on changed lines ≥ 90%
- [ ] `make ci` green; PR merged; tagged `kbm-v0.0.2-foundation`

Open **[05_chunker_spec.md](05_chunker_spec.md)** next — the chunker is the most algorithmically dense file you'll port.
