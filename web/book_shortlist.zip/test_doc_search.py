"""Demo / smoke test — how to use src/book_shortlist on a 100k-book catalog.

What this shows
---------------
1. Build (once) and load a 100k-record catalog as JSON  -> test/catalog_100k.json
2. Call the developed module to get a top-10 shortlist for a loose query.
3. Both modes: rerank ON (best quality) and rerank OFF (fast lexical path).
4. How to swap in the production GPT-4o backend (used automatically if an
   OPENAI_API_KEY is present; otherwise the offline RuleBasedBackend runs so the
   demo works with no network).

Run:
    python test/test_doc_search.py
"""

from __future__ import annotations

import json
import os
import random
import sys
import time

# --- make the module under src/ importable, regardless of where we're run from -
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

from book_shortlist import (  # noqa: E402  (after sys.path tweak)
    OpenAIBackend,
    RuleBasedBackend,
    shortlist,
)

# render the "·" separators nicely on Windows consoles
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

CATALOG_PATH = os.path.join(HERE, "catalog_100k.json")
CATALOG_SIZE = 100_000


# --------------------------------------------------------------------------- #
# 1. Catalog generation — a synthetic library of 100k books.
#    Each record has 8 short structured attributes (stand-in for your 23).
#    A few "obvious winners" for the demo query are planted at the top.
# --------------------------------------------------------------------------- #
def build_sample_catalog(n: int = CATALOG_SIZE, seed: int = 42) -> list[dict]:
    rnd = random.Random(seed)
    cats = ["Fiction", "Non-fiction", "Science Fiction", "Romance", "Mystery",
            "Horror", "Fantasy", "Comedy"]
    countries = ["USA", "UK", "France", "Japan", "Germany", "Canada"]
    langs = ["English", "French", "Japanese", "German"]
    topics = ["space travel", "haunted house", "small-town romance", "war",
              "detective noir", "dragons", "coming of age", "office satire",
              "deep sea", "time travel"]
    adjectives = ["funny", "dark", "epic", "cozy", "thrilling", "absurd", "tender"]

    books: list[dict] = []
    for i in range(n):
        topic = rnd.choice(topics)
        adj = rnd.choice(adjectives)
        books.append({
            "id": i,
            "title": f"{adj.title()} {topic.title()} #{rnd.randint(1, 999)}",
            "author": f"Author {rnd.randint(1, 5000)}",
            "category": rnd.choice(cats),
            "subjects": topic,
            "country": rnd.choice(countries),
            "language": rnd.choice(langs),
            "year": rnd.randint(1950, 2025),
        })

    # plant a few unambiguous matches for "star trip funny story"
    planted = ["Hilarious Voyage to the Stars",
               "A Comic Spaceship Galaxy Adventure",
               "Funny Interstellar Expedition"]
    for j, title in enumerate(planted):
        books[j] = {"id": j, "title": title, "author": f"Author {j}",
                    "category": "Comedy", "subjects": "space travel comedy",
                    "country": "USA", "language": "English", "year": 2020 + j}
    return books


def load_or_build_catalog() -> list[dict]:
    if os.path.exists(CATALOG_PATH):
        with open(CATALOG_PATH, encoding="utf-8") as f:
            return json.load(f)
    print(f"Generating {CATALOG_SIZE:,}-book catalog -> {CATALOG_PATH} ...")
    t = time.perf_counter()
    books = build_sample_catalog()
    with open(CATALOG_PATH, "w", encoding="utf-8") as f:
        json.dump(books, f, ensure_ascii=False)
    size_mb = os.path.getsize(CATALOG_PATH) / 1e6
    print(f"  wrote {size_mb:.1f} MB in {(time.perf_counter() - t) * 1000:.0f} ms")
    return books


# --------------------------------------------------------------------------- #
# 2. Backend selection — production GPT-4o if a key is present, else offline.
# --------------------------------------------------------------------------- #
def pick_backend():
    if os.environ.get("OPENAI_API_KEY"):
        print("Backend: OpenAIBackend (gpt-4o) — production semantic quality.\n")
        return OpenAIBackend(model="gpt-4o")
    print("Backend: RuleBasedBackend (offline; no OPENAI_API_KEY found).")
    print("         Plumbing/scale demo — gpt-4o gives materially better ranking.\n")
    return RuleBasedBackend()


def _print(results: list[dict]) -> None:
    for i, r in enumerate(results, 1):
        print(f"  {i:2}. [{r['score']:.3f}] {r['title']}  —  {r['author']}")
        print(f"        why: {r['why']}")


# --------------------------------------------------------------------------- #
# 3. The actual usage — this is all a caller needs.
# --------------------------------------------------------------------------- #
def main() -> None:
    books = load_or_build_catalog()
    print(f"Catalog: {len(books):,} books loaded from {os.path.basename(CATALOG_PATH)}")

    backend = pick_backend()
    query = "get a star trip funny story for me"

    # --- best quality: GPT-4o (or offline stub) rerank ON --------------------
    t = time.perf_counter()
    top = shortlist(query, books, top_k=10, rerank=True, backend=backend)
    dt = (time.perf_counter() - t) * 1000
    print(f"Query: {query!r}")
    print(f"\n[rerank ON]  {len(top)} results in {dt:.0f} ms")
    _print(top)

    # --- fast path: lexical only, rerank OFF ---------------------------------
    t = time.perf_counter()
    fast = shortlist(query, books, top_k=10, rerank=False, backend=backend)
    dt = (time.perf_counter() - t) * 1000
    print(f"\n[rerank OFF] {len(fast)} results in {dt:.0f} ms (fast lexical path)")
    _print(fast)

    # --- minimal assertions so this doubles as a smoke test ------------------
    assert top and fast, "expected non-empty shortlists"
    assert all({"book_id", "title", "author", "score", "why"} <= set(r)
               for r in top), "unexpected result shape"
    print("\nOK — module produced shortlists end-to-end.")


if __name__ == "__main__":
    main()
