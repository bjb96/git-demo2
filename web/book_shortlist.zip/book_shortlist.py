"""book_shortlist — fast, no-embeddings semantic shortlist for a book catalog.

Problem
-------
A library API returns up to ~100k book records (each with ~23 short structured
attributes: title, author, year, country, language, category, ...). A user asks
a loose question like "get a star trip funny story for me". We must return the
top-10 most relevant books, very fast, using ONLY GPT-4o + BM25 — no dense
embeddings (no ada-002, no FAISS, no sentence-transformers).

Approach (see temp/doc_search_module_plan.md and the architecture diagram)
--------------------------------------------------------------------------
Semantics live in two GPT-4o "bookends"; the fast middle is purely lexical:

  1. understand   GPT-4o turns the loose query into {filters, lex variants,
                  hyde blurb, intent}.                       (1 call, cacheable)
  2. narrow       Apply structured filters over the 23 attributes:
                  100k -> a few hundred + a metadata-match boost. (fast, local)
  3. bm25         Rank each query variant with bm25s over the records'
                  concatenated text-ish attributes.              (fast, local)
  4. fuse         Reciprocal Rank Fusion (k=60, 2x original-query weight,
                  top-rank bonus) -> top-40 candidates.          (fast, local)
  5. rerank       GPT-4o scores the 40 candidates in one batched call, with
                  each candidate's BM25 score injected.      (1 call, cacheable)
  6. blend        Position-aware blend (75/60/40) + metadata boost -> top-10.

The records here hold only short structured attributes (no synopsis), so BM25
runs over the concatenated text-ish fields, structured matching carries real
weight, and the reranker sees the full record per candidate.

Public API
----------
    shortlist(query, books, top_k=10) -> list[dict]
    understand_query(query, books, backend) -> QueryPlan   # exported for reuse

The LLM boundary is abstracted behind `LLMBackend`. `OpenAIBackend` is the
production path; `RuleBasedBackend` is a deterministic offline fallback that
also powers the runnable self-test (`python -m book_shortlist`).
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Optional, Protocol

import bm25s

# --------------------------------------------------------------------------- #
# Tunables — ported verbatim from the doc_search hybrid pipeline.
# (deep_dives/doc_search_tool/16_document_retrieval.html, 22_q2_search_tools_pipeline.md)
# --------------------------------------------------------------------------- #
RRF_K = 60                      # store.ts:3598
ORIGINAL_QUERY_WEIGHT = 2.0     # store.ts:4255-4257
TOP_RANK_BONUS = {0: 0.05, 1: 0.02, 2: 0.02}   # store.ts:3614-3621
RERANK_CANDIDATE_LIMIT = 40     # store.ts:318
PER_VARIANT_DEPTH = 50          # how deep each BM25 list goes before fusion
METADATA_BOOST_WEIGHT = 0.15    # weight of structured match in the final blend
MIN_POOL_AFTER_NARROW = 200     # never narrow below this many candidates

_WORD_RE = re.compile(r"[A-Za-z0-9']+")


# --------------------------------------------------------------------------- #
# Data shapes
# --------------------------------------------------------------------------- #
@dataclass
class Filter:
    """A structured constraint over one attribute, produced by the LLM."""
    field: str
    value: str
    hard: bool = False          # hard -> may narrow the pool; soft -> boost only


@dataclass
class QueryPlan:
    """The typed plan GPT-4o derives from the loose query."""
    filters: list[Filter] = field(default_factory=list)
    lex_variants: list[str] = field(default_factory=list)   # synonym-expanded keywords
    hyde: str = ""                                           # hypothetical blurb
    intent: str = ""                                         # 1-line disambiguation


@dataclass
class FieldRoles:
    """Which record keys are text (BM25), categorical (filters), numeric, display.

    Auto-derived from a sample of records when not supplied. `text_weights` lets
    title/author/category-style fields count more in BM25 (doc_search weights
    title 4x); we emulate that by repeating a field's tokens `weight` times.
    """
    text_fields: list[str] = field(default_factory=list)
    categorical_fields: list[str] = field(default_factory=list)
    numeric_fields: list[str] = field(default_factory=list)
    id_field: Optional[str] = None
    title_field: Optional[str] = None
    author_field: Optional[str] = None
    text_weights: dict[str, int] = field(default_factory=dict)


# --------------------------------------------------------------------------- #
# LLM boundary
# --------------------------------------------------------------------------- #
class LLMBackend(Protocol):
    """The only two things the pipeline needs from an LLM."""

    def understand(self, query: str, schema_brief: str) -> dict:
        """Return {'filters':[{field,value,hard}], 'lex_variants':[...],
        'hyde': str, 'intent': str}."""
        ...

    def rerank(self, query: str, intent: str, candidates: list[dict]) -> dict:
        """Given candidates (each a record dict plus a '_bm25' score), return
        {'scores': [{'id': <id>, 'relevance': 0..1}, ...]}."""
        ...


class OpenAIBackend:
    """Production backend: GPT-4o via the OpenAI SDK, JSON-validated output."""

    def __init__(self, client: Any = None, model: str = "gpt-4o") -> None:
        if client is None:
            from openai import OpenAI  # lazy import — only when actually used
            client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        self.client = client
        self.model = model

    def _json(self, system: str, user: str) -> dict:
        resp = self.client.chat.completions.create(
            model=self.model,
            temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": system},
                      {"role": "user", "content": user}],
        )
        return json.loads(resp.choices[0].message.content)

    def understand(self, query: str, schema_brief: str) -> dict:
        system = (
            "You turn a loose natural-language book request into a precise search "
            "plan. The catalog records have ONLY short structured attributes (no "
            "synopsis). Return STRICT JSON with keys: "
            "filters (list of {field, value, hard}), lex_variants (3-5 keyword "
            "strings that expand synonyms/related terms so a keyword search can "
            "find the book), hyde (one short hypothetical blurb of an ideal match), "
            "intent (one line). Only use field names from the schema. Mark a filter "
            "hard=true only when the user clearly requires it (e.g. an explicit "
            "category/language); mark vibe/theme matches hard=false."
        )
        user = f"Catalog attributes:\n{schema_brief}\n\nUser request: {query!r}"
        return self._json(system, user)

    def rerank(self, query: str, intent: str, candidates: list[dict]) -> dict:
        system = (
            "You are a precise relevance judge for a book search. For each "
            "candidate, output a relevance score in [0,1] for how well it matches "
            "the user's request. Each candidate includes '_bm25', its keyword-match "
            "score — use it as a prior but rely on the attributes for the final "
            "judgment. Return STRICT JSON: {'scores':[{'id':..,'relevance':..}]}."
        )
        focus = f"{intent}\n{query}" if intent else query
        user = (f"Request: {focus!r}\n\nCandidates (JSON):\n"
                + json.dumps(candidates, ensure_ascii=False))
        return self._json(system, user)


class RuleBasedBackend:
    """Deterministic, offline backend. Powers the self-test and is a safe
    fallback when no API key is configured. It is intentionally simple: real
    semantic quality comes from OpenAIBackend, but the pipeline logic around it
    (narrow / bm25 / fuse / blend) is identical and fully exercised."""

    # a tiny "vibe" -> related-terms map, just enough to make the demo meaningful
    SYNONYMS = {
        "star": ["space", "galaxy", "interstellar", "spaceship", "cosmic"],
        "trip": ["voyage", "journey", "travel", "expedition"],
        "funny": ["comedy", "humor", "humorous", "comic", "satire"],
        "scary": ["horror", "thriller", "ghost", "haunted"],
        "love": ["romance", "romantic"],
        "detective": ["mystery", "crime", "noir"],
        "kids": ["children", "juvenile", "picture book"],
    }
    CATEGORY_HINTS = {"fiction", "nonfiction", "comedy", "science fiction",
                      "sci-fi", "romance", "mystery", "horror", "fantasy"}

    def understand(self, query: str, schema_brief: str) -> dict:
        words = [w.lower() for w in _WORD_RE.findall(query)
                 if w.lower() not in _STOPWORDS]
        expanded: list[str] = []
        for w in words:
            expanded.extend(self.SYNONYMS.get(w, []))
        lex_variants = [" ".join(words)]                      # the cleaned query
        if expanded:
            lex_variants.append(" ".join(dict.fromkeys(expanded)))
        filters = [Filter_to_dict(Filter(field="category", value=w, hard=False))
                   for w in words if w in self.CATEGORY_HINTS]
        hyde = " ".join(words + expanded)
        return {"filters": filters, "lex_variants": lex_variants,
                "hyde": hyde, "intent": " ".join(words)}

    def rerank(self, query: str, intent: str, candidates: list[dict]) -> dict:
        terms = set(w.lower() for w in _WORD_RE.findall(f"{intent} {query}"))
        for w in list(terms):
            terms.update(self.SYNONYMS.get(w, []))
        scores = []
        for c in candidates:
            blob = " ".join(str(v) for k, v in c.items()
                            if not k.startswith("_")).lower()
            hits = sum(1 for t in terms if t and t in blob)
            rel = min(1.0, hits / max(3, len(terms)))
            # nudge by the injected bm25 prior
            rel = 0.7 * rel + 0.3 * float(c.get("_bm25", 0.0))
            scores.append({"id": c.get("id"), "relevance": round(rel, 4)})
        return {"scores": scores}


def Filter_to_dict(f: Filter) -> dict:
    return {"field": f.field, "value": f.value, "hard": f.hard}


_STOPWORDS = {
    "a", "an", "the", "for", "me", "to", "of", "and", "or", "with", "get",
    "give", "find", "want", "some", "please", "story", "book", "books", "about",
    "my", "i", "need", "looking", "something",
}


# --------------------------------------------------------------------------- #
# Stage 0 — schema introspection
# --------------------------------------------------------------------------- #
def infer_field_roles(books: list[dict], sample: int = 200) -> FieldRoles:
    """Auto-derive field roles from a sample of records."""
    roles = FieldRoles()
    if not books:
        return roles
    keys: list[str] = []
    for b in books[:sample]:
        for k in b:
            if k not in keys:
                keys.append(k)

    cardinality: dict[str, set] = {k: set() for k in keys}
    is_num: dict[str, bool] = {k: True for k in keys}
    is_str: dict[str, bool] = {k: False for k in keys}
    for b in books[:sample]:
        for k in keys:
            v = b.get(k)
            if v is None:
                continue
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                cardinality[k].add(v)
            else:
                is_num[k] = False
                is_str[k] = True
                cardinality[k].add(str(v)[:64])

    for k in keys:
        kl = k.lower()
        if roles.id_field is None and kl in ("id", "book_id", "isbn", "uid"):
            roles.id_field = k
            continue
        if is_num[k]:
            roles.numeric_fields.append(k)
            continue
        if is_str[k]:
            roles.text_fields.append(k)
            # low-cardinality strings double as categorical filter targets
            if len(cardinality[k]) <= max(50, sample // 4):
                roles.categorical_fields.append(k)

    for k in roles.text_fields:
        kl = k.lower()
        if roles.title_field is None and "title" in kl:
            roles.title_field = k
        if roles.author_field is None and "author" in kl:
            roles.author_field = k
        if "title" in kl:
            roles.text_weights[k] = 3
        elif "author" in kl:
            roles.text_weights[k] = 2
        elif any(h in kl for h in ("category", "genre", "subject", "tag", "topic")):
            roles.text_weights[k] = 2
        else:
            roles.text_weights[k] = 1
    return roles


def _schema_brief(books: list[dict], roles: FieldRoles, max_values: int = 8) -> str:
    """A compact description of the catalog fields for the understand() prompt."""
    lines = []
    for k in roles.text_fields + roles.numeric_fields:
        vals = []
        for b in books[:500]:
            v = b.get(k)
            if v is not None and str(v) not in vals:
                vals.append(str(v))
            if len(vals) >= max_values:
                break
        kind = "number" if k in roles.numeric_fields else "text"
        lines.append(f"- {k} ({kind}): e.g. {', '.join(vals[:max_values])}")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# Stage 1 — query understanding
# --------------------------------------------------------------------------- #
def understand_query(query: str, books: list[dict], backend: LLMBackend,
                     roles: Optional[FieldRoles] = None,
                     cache: Optional["Cache"] = None) -> QueryPlan:
    roles = roles or infer_field_roles(books)
    brief = _schema_brief(books, roles)
    ck = _key("understand", query, brief)
    raw = cache.get(ck) if cache else None
    if raw is None:
        raw = backend.understand(query, brief)
        if cache:
            cache.set(ck, raw)
    filters = [Filter(f.get("field", ""), str(f.get("value", "")),
                      bool(f.get("hard", False)))
               for f in raw.get("filters", []) if f.get("value")]
    variants = [v for v in raw.get("lex_variants", []) if v and v.strip()]
    if query.strip() and query.strip() not in variants:
        variants.insert(0, query.strip())            # original always present
    return QueryPlan(filters=filters, lex_variants=variants,
                     hyde=raw.get("hyde", ""), intent=raw.get("intent", ""))


# --------------------------------------------------------------------------- #
# Stage 2 — structured narrowing + metadata boost
# --------------------------------------------------------------------------- #
def _norm(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s)).strip().lower()


def _resolve_field(name: str, roles: FieldRoles) -> Optional[str]:
    """Map an LLM-provided field name onto a real key (tolerant)."""
    cand = roles.text_fields + roles.numeric_fields
    nl = _norm(name)
    for k in cand:
        if _norm(k) == nl:
            return k
    for k in cand:
        if nl and (nl in _norm(k) or _norm(k) in nl):
            return k
    return None


def narrow(books: list[dict], plan: QueryPlan, roles: FieldRoles
           ) -> tuple[list[dict], list[float]]:
    """Return (pool, metadata_boost[]) aligned by index.

    Hard filters may shrink the pool (but never below MIN_POOL_AFTER_NARROW).
    All filters contribute an additive, normalized metadata boost.
    """
    resolved = [(f, _resolve_field(f.field, roles)) for f in plan.filters]
    resolved = [(f, k) for f, k in resolved if k]

    def matches(b: dict, f: Filter, k: str) -> bool:
        return _norm(f.value) in _norm(b.get(k, ""))

    # metadata boost for every record
    boosts: list[float] = []
    n_soft = sum(1 for f, _ in resolved if not f.hard) or 1
    for b in books:
        hits = sum(1 for f, k in resolved if not f.hard and matches(b, f, k))
        boosts.append(hits / n_soft)

    # try to narrow with hard filters, keep recall safe
    hard = [(f, k) for f, k in resolved if f.hard]
    if hard:
        kept_idx = [i for i, b in enumerate(books)
                    if all(matches(b, f, k) for f, k in hard)]
        if len(kept_idx) >= MIN_POOL_AFTER_NARROW or len(kept_idx) >= len(books):
            pool = [books[i] for i in kept_idx]
            pool_boost = [boosts[i] for i in kept_idx]
            return pool, pool_boost
    return books, boosts


# --------------------------------------------------------------------------- #
# Stage 3 — BM25 over concatenated text-ish attributes
# --------------------------------------------------------------------------- #
def _searchable_text(b: dict, roles: FieldRoles) -> str:
    parts: list[str] = []
    for k in roles.text_fields:
        v = b.get(k)
        if v is None:
            continue
        parts.extend([str(v)] * roles.text_weights.get(k, 1))   # weight = repeat
    return " ".join(parts)


def _build_index(corpus_texts: list[str]) -> bm25s.BM25:
    """Index the pool ONCE; all query variants retrieve against this."""
    retriever = bm25s.BM25()
    retriever.index(bm25s.tokenize(corpus_texts, stopwords="en",
                                   show_progress=False), show_progress=False)
    return retriever


def _bm25_rank(retriever: bm25s.BM25, n_docs: int, query: str, depth: int
               ) -> list[tuple[int, float]]:
    """Return [(doc_index, normalized_score)] for one query string."""
    q_tokens = bm25s.tokenize(query, stopwords="en", show_progress=False)
    k = min(depth, n_docs)
    if k < 1:
        return []
    try:
        idx, scores = retriever.retrieve(q_tokens, k=k, show_progress=False)
    except ValueError:
        # empty query (all stopwords) or no vocab overlap
        return []
    idx, scores = idx[0], scores[0]
    top = float(scores[0]) if len(scores) and scores[0] > 0 else 1.0
    return [(int(i), float(s) / top) for i, s in zip(idx, scores) if s > 0]


# --------------------------------------------------------------------------- #
# Stage 4 — Reciprocal Rank Fusion (verbatim from doc_search)
# --------------------------------------------------------------------------- #
def reciprocal_rank_fusion(ranked_lists: list[list[int]],
                           weights: list[float]) -> dict[int, float]:
    fused: dict[int, float] = {}
    for lst, w in zip(ranked_lists, weights):
        for rank, doc in enumerate(lst):
            fused[doc] = fused.get(doc, 0.0) + w / (RRF_K + rank + 1)
            if rank in TOP_RANK_BONUS:
                fused[doc] += TOP_RANK_BONUS[rank]
    return fused


# --------------------------------------------------------------------------- #
# Stage 6 — position-aware blend.
#
# doc_search uses 75/60/40 (RRF share) because it had a DENSE-VECTOR leg carrying
# semantics, so BM25 rank was trustworthy. We dropped that leg: with thin records,
# BM25 only catches literal word overlap, so the GPT-4o reranker is the only true
# semantic signal. We therefore shift trust toward the reranker (50/40/30 RRF
# share). This is a deliberate, documented deviation driven by the no-embeddings
# constraint. Tune RRF_SHARE back up if BM25 quality is high on your catalog.
# --------------------------------------------------------------------------- #
RRF_SHARE = {"top3": 0.50, "top10": 0.40, "rest": 0.30}


def _blend_weight(rrf_rank: int) -> float:
    if rrf_rank <= 3:
        return RRF_SHARE["top3"]
    if rrf_rank <= 10:
        return RRF_SHARE["top10"]
    return RRF_SHARE["rest"]


# --------------------------------------------------------------------------- #
# Tiny pluggable cache (in-process default; swap for Redis on ECS)
# --------------------------------------------------------------------------- #
class Cache(Protocol):
    def get(self, key: str) -> Optional[dict]: ...
    def set(self, key: str, value: dict) -> None: ...


class DictCache(dict):
    def get(self, key: str) -> Optional[dict]:   # type: ignore[override]
        return dict.get(self, key)

    def set(self, key: str, value: dict) -> None:
        self[key] = value


def _key(*parts: str) -> str:
    return hashlib.sha1("\x00".join(parts).encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------- #
# Orchestrator
# --------------------------------------------------------------------------- #
def shortlist(query: str, books: list[dict], top_k: int = 10, *,
              rerank: bool = True, backend: Optional[LLMBackend] = None,
              roles: Optional[FieldRoles] = None,
              cache: Optional[Cache] = None,
              explain: bool = False) -> list[dict]:
    """Return the top-`top_k` most relevant books for a loose query.

    Parameters
    ----------
    query    : the loose natural-language request.
    books    : list of record dicts (up to ~100k), each ~23 short attributes.
    rerank   : GPT-4o rerank on (best quality, ~1s) or off (lexical, ~100ms).
    backend  : LLM backend; defaults to OpenAIBackend (needs OPENAI_API_KEY).
    explain  : attach per-result scoring trace.
    """
    t0 = time.perf_counter()
    if not books:
        return []
    backend = backend or OpenAIBackend()
    roles = roles or infer_field_roles(books)
    cache = cache if cache is not None else DictCache()

    # 1 — understand
    plan = understand_query(query, books, backend, roles, cache)

    # 2 — narrow
    pool, boosts = narrow(books, plan, roles)
    corpus = [_searchable_text(b, roles) for b in pool]

    # 3 — BM25 per variant (+ hyde). Index the pool ONCE, then retrieve per variant.
    variants = list(dict.fromkeys(plan.lex_variants + ([plan.hyde] if plan.hyde else [])))
    retriever = _build_index(corpus)
    ranked_lists: list[list[int]] = []
    weights: list[float] = []
    best_bm25: dict[int, float] = {}
    for vi, v in enumerate(variants):
        ranked = _bm25_rank(retriever, len(corpus), v, PER_VARIANT_DEPTH)
        if not ranked:
            continue
        ranked_lists.append([i for i, _ in ranked])
        weights.append(ORIGINAL_QUERY_WEIGHT if vi == 0 else 1.0)
        for i, s in ranked:
            best_bm25[i] = max(best_bm25.get(i, 0.0), s)

    # Fallback: if nothing matched lexically, rank purely by metadata boost
    if not ranked_lists:
        order = sorted(range(len(pool)), key=lambda i: boosts[i], reverse=True)
        return _format(order[:top_k], pool, roles,
                       {i: boosts[i] for i in order}, {}, boosts, explain, t0)

    # 4 — fuse -> top candidates
    fused = reciprocal_rank_fusion(ranked_lists, weights)
    candidates = sorted(fused, key=fused.get, reverse=True)[:RERANK_CANDIDATE_LIMIT]

    # 5 — rerank (optional), with BM25 score injected per candidate
    rerank_scores: dict[int, float] = {}
    if rerank and len(candidates) > 1:
        payload = []
        for i in candidates:
            rec = {k: pool[i].get(k) for k in roles.text_fields + roles.numeric_fields}
            rec["id"] = _record_id(pool[i], i, roles)
            rec["_bm25"] = round(best_bm25.get(i, 0.0), 4)
            payload.append(rec)
        rk = _key("rerank", plan.intent, query, json.dumps(payload, sort_keys=True))
        raw = cache.get(rk)
        if raw is None:
            raw = backend.rerank(query, plan.intent, payload)
            cache.set(rk, raw)
        id_to_idx = {_record_id(pool[i], i, roles): i for i in candidates}
        for s in raw.get("scores", []):
            i = id_to_idx.get(s.get("id"))
            if i is not None:
                rerank_scores[i] = float(s.get("relevance", 0.0))

    # 6 — position-aware blend + metadata boost
    final: dict[int, float] = {}
    for rrf_rank, i in enumerate(sorted(candidates, key=fused.get, reverse=True), 1):
        rrf_component = 1.0 / rrf_rank
        if i in rerank_scores:
            w = _blend_weight(rrf_rank)
            base = w * rrf_component + (1.0 - w) * rerank_scores[i]
        else:
            base = rrf_component
        final[i] = base + METADATA_BOOST_WEIGHT * boosts[i]

    order = sorted(final, key=final.get, reverse=True)[:top_k]
    return _format(order, pool, roles, final, rerank_scores, boosts, explain, t0)


def _record_id(b: dict, idx: int, roles: FieldRoles) -> Any:
    return b.get(roles.id_field) if roles.id_field else idx


def _format(order, pool, roles, final, rerank_scores, boosts, explain, t0):
    out = []
    for i in order:
        rec = pool[i]
        row = {
            "book_id": _record_id(rec, i, roles),
            "title": rec.get(roles.title_field) if roles.title_field else None,
            "author": rec.get(roles.author_field) if roles.author_field else None,
            "score": round(float(final.get(i, 0.0)), 4),
            "why": _why(rec, roles, rerank_scores.get(i), boosts[i]),
        }
        if explain:
            row["explain"] = {"final": final.get(i), "rerank": rerank_scores.get(i),
                              "metadata_boost": boosts[i]}
        out.append(row)
    if explain and out:
        out[0].setdefault("explain", {})["latency_ms"] = int((time.perf_counter() - t0) * 1000)
    return out


def _why(rec: dict, roles: FieldRoles, rerank_s: Optional[float], boost: float) -> str:
    bits = []
    if roles.title_field and rec.get(roles.title_field):
        bits.append(str(rec[roles.title_field]))
    for k in roles.categorical_fields[:3]:
        if rec.get(k):
            bits.append(f"{k}={rec[k]}")
    tag = []
    if rerank_s is not None:
        tag.append(f"rerank={rerank_s:.2f}")
    if boost:
        tag.append(f"meta={boost:.2f}")
    return " · ".join(bits) + (f"  ({', '.join(tag)})" if tag else "")


# --------------------------------------------------------------------------- #
# Self-test — runs fully offline with the rule-based backend.
#   python -m book_shortlist        (from src/)  or   python src/book_shortlist.py
# --------------------------------------------------------------------------- #
def _synthetic_catalog(n: int = 100_000) -> list[dict]:
    import random
    rnd = random.Random(42)
    cats = ["Fiction", "Non-fiction", "Science Fiction", "Romance", "Mystery",
            "Horror", "Fantasy", "Comedy"]
    countries = ["USA", "UK", "France", "Japan", "Germany", "Canada"]
    langs = ["English", "French", "Japanese", "German"]
    topics = ["space travel", "haunted house", "small-town romance", "war",
              "detective noir", "dragons", "coming of age", "office satire",
              "deep sea", "time travel"]
    adjectives = ["funny", "dark", "epic", "cozy", "thrilling", "absurd", "tender"]
    books = []
    for i in range(n):
        topic = rnd.choice(topics)
        adj = rnd.choice(adjectives)
        books.append({
            "id": i,
            "title": f"{adj.title()} {topic.title()} #{rnd.randint(1, 999)}",
            "author": f"Author {rnd.randint(1, 5000)}",
            "category": rnd.choice(cats),
            "subjects": topic,
            "country": rnd.choice(countries),
            "language": rnd.choice(langs),
            "year": rnd.randint(1950, 2025),
        })
    # plant a few obvious winners for "star trip funny story"
    for j, t in enumerate(["Hilarious Voyage to the Stars",
                           "A Comic Spaceship Galaxy Adventure",
                           "Funny Interstellar Expedition"]):
        books[j] = {"id": j, "title": t, "author": f"Author {j}",
                    "category": "Comedy", "subjects": "space travel comedy",
                    "country": "USA", "language": "English", "year": 2020 + j}
    return books


def _selftest() -> None:
    print("Building synthetic 100k catalog ...")
    t = time.perf_counter()
    books = _synthetic_catalog(100_000)
    print(f"  built in {(time.perf_counter()-t)*1000:.0f} ms")

    backend = RuleBasedBackend()
    query = "get a star trip funny story for me"

    t = time.perf_counter()
    results = shortlist(query, books, top_k=10, backend=backend, explain=True)
    dt = (time.perf_counter() - t) * 1000

    print(f"\nQuery: {query!r}\nLatency: {dt:.0f} ms (offline rule-based backend)\n")
    assert results, "expected a non-empty shortlist"
    for r in results:
        print(f"  {r['score']:.3f}  {r['title']}  [{r['why']}]")

    titles = " ".join(r["title"].lower() for r in results[:5])
    assert any(w in titles for w in ("star", "space", "galaxy", "interstellar",
                                     "voyage", "spaceship")), \
        "expected space-themed books near the top"
    assert all(set(r) >= {"book_id", "title", "author", "score", "why"}
               for r in results), "result shape check"
    print("\nOK — self-test passed.")


if __name__ == "__main__":
    _selftest()
