# my-product — Quick Start

> Companion to [00_manual.md](00_manual.md) (the comprehensive handbook), [01_process_map.html](01_process_map.html) (the visual nav hub), and [05_python_demo.py](05_python_demo.py) (the runnable real-technology demo).
>
> Use this file as: the **function/class index** (Ctrl-F here), **common modifications recipe**, **debugging cheat sheet**, and **plain-English glossary**.

---

## 1. Run the demo in 60 seconds

The demo uses real my-product class signatures, constants, and patterns. It runs without an API key — the self-test exercises 12 subsystems end-to-end.

```powershell
cd temp/deep_dives/my-product_tool_calling
python 05_python_demo.py --selftest
```

You should see:

```
[1] StepContract for text_analyzer step
    requires_documents=True requires_datasets=False expected_output_files_must_be_empty=True
[2] validate_inputs_exist on a step missing required dataset
    ok=False issues=1 first_severity=escalate
[3] route_feedback ESCALATE_TO_PLANNER
[4] Agent catalog version=r10-v1 agents=[gateway_arbitrator, dataset_profiler, representation_builder,
    text_analyzer, general_knowledge_researcher, code_generator, code_executor, qc_verifier, synthesizer]
[5] 8 schemas
[6] validate_sandbox_imports violations=['Blocked import: subprocess']
[7] validate_sandbox_imports on legitimate code violations=[]
[8] FunctionRegistry register + search SQLite+FTS5 succeeds
[9] compute_chunk_size chunk_size=47680 chars, overlap=2384, max_chunks=50, chunk_output_tokens=1907
[10] compute_csv_budget csv_token_budget=300000, csv_max_rows=6000
[11] execute_plan_demo run_id=run-ce78f1 status=ok steps=2
[12] _bm25_retrieve top2 pareto correctly ranked first

[OK] my-product demo self-test passed.
```

If you see this, every signature subsystem of my-product is correctly mirrored — including: StepContract dataclass, 11 validation gates, route_feedback decision logic, 9-agent catalog, 8 JSON schemas, sandbox AST scan with allowlist/blocklist, function_registry SQLite+FTS5, model-aware chunking, plan execution with run_id, and BM25 retrieval.

---

## 2. The 10 function groups (zones)

| Zone | Color | Deep-dive | What's distinctive about my-product's approach |
|---|---|---|---|
| 🟢 TOOL | green | [02](02_tool_registry.html) · [03](03_llm_call_flow.html) · [04](04_architecture.html) · [06](06_process_map_demo.html) | **Agent catalog (9 agents, 4 planner-visible)**, 8 JSON schemas, `COT_IN_SCHEMA_ENABLED=True`, 4 LLM call entry points, `LLM_MAX_CONTINUATIONS=3` |
| 🔵 CTX | cyan | [09](09_context_management.html) | Static planner-input builder + CoT strip from agent results + 4 query modes |
| 🟠 ART | orange | [08](08_artifact_management.html) ⭐ | **4 catalogs** (dataset/document/code/visual) with caps 100/100/20/100, `run_id`-tagged S3-style paths, plan persistence |
| 🟣 EXEC | purple | [10](10_code_execution.html) | `sandbox_exec` subprocess + AST static check + ~80-package allowlist + ~30-package blocklist |
| 🟡 SKILL | yellow | [11](11_skill_management.html) | **`StepContract` dataclass (50 fields)** + 8 JSON schemas + `reasoning_steps` CoT injection |
| 💙 MEMORY | indigo | [12](12_memory_management.html) ⭐ | **`function_registry` (SQLite + FTS5)** cross-session code library + `running_catalog` + Redis 20h catalog cache |
| 🔴 PERM | red | [13](13_permission_approval.html) ⭐ | **11 deterministic validation gates (NO LLM)** + `route_feedback` + `merge_results` |
| 🔵 SUB-AGENT | deep blue | [14](14_subagent_delegation.html) ⭐ | **9 agents + 4 query modes** (shallow/deep_plan/deep_execute/deep_auto) + **2-tier retry** (`LOCAL_RETRY_MAX=2` + `GLOBAL_RETRY_MAX=1`) |
| 🟢 COMPACT | teal | [15](15_compaction_summarization.html) | Upstream chunking BEFORE LLM with 17 constants + `LLM_MAX_CONTINUATIONS=3` + `LLM_MODEL_CONTEXT_WINDOWS` registry |
| 🟤 TEXT | brown | [16](16_document_retrieval.html) | Auto-profilers (`dataset_profiler` + `representation_builder`) + BM25 retrieval + chunked `text_analyzer` |
| ⚫ SURFACE *(Phase 3 gap-fill)* | gray | [17](17_surface.html) | 21 FastAPI routes + 2 SSE channels (`/progress/stream` + `/sse/jobs/{job_id}`) + single static HTML UI + fake-S3/fake-Redis (3-tier TTL). **No channels, voice, image-gen, CLI, native apps, or Dockerfile.** |
| ⚪ OBSERVABILITY *(Phase 3 gap-fill)* | light-gray | [18](18_observability.html) | 4-tier retry (LOCAL=2 / GLOBAL=1 / JSON-repair=2 / HTTP=4) + LLM continuation=3 + pipeline trace (`_ptrace` in-memory) + LLM payload ring buffer (deque maxlen=100) + sliding-window per-IP rate limit (FIFO cap 100k IPs) + slowapi limiter + Semaphore(20)/Semaphore(20) + schema strict-mode startup gate (fail-closed) + CoT scrubber + CSV sanitization + CSP/bleach/iframe-sandbox + per-run artifact manifest. **NO OTel/Prometheus, NO eval harness, NO A/B, NO $/cost rollup, NO `/health` endpoint (ECS-blocker), NO audit log, NO circuit breaker, NO typed error taxonomy.** |
| 🟢 ADAPT_LEARN *(Phase 3 gap-fill, ⭐ USER'S #1 ICP)* | green | [19](19_adapt_learn.html) | **HEADLINE: 0/10 today, multiple dead-letter signals**. `quality_score_0_to_1` 1 producer/0 readers; `usage_count` + `increment_usage()` ZERO callers in `reasoning_multiagent_demo.py` (dead code in live schema); `execution_state.runs[]` capped to 10 entries; no `/feedback` endpoint. **But `function_registry.py` SQLite+FTS5 is the BEST scaffolding of the 3 products** — 5-step fix (~200 LOC) moves 0/10 → 4-5/10. Phase 5 INVENT opportunity: explicit per-step user-acceptance signal (no competitor has this). |

⭐ = my-product's strongest position relative to product-A and product-B.

---

## 3. Function & class index — Ctrl-F here

All locations point to real my-product source in `custom_dashboard/reference_project/simple_reasoning_model/`.

### TOOL zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `build_agent_catalog()` | Constructs 9-agent catalog with 10 fields per entry | `reasoning_multiagent_demo.py:462` | SECTION D |
| `read_agent_catalog_cached()` | Returns catalog, Redis 20h global TTL | `reasoning_multiagent_demo.py:1039` | SECTION D |
| `_format_agent_catalog_for_planner(catalog)` | Catalog → markdown block in planner prompt | `reasoning_multiagent_demo.py:792` | (referenced) |
| `_build_planning_guidance_block(query, mode)` | Mode-specific planner guidance (shallow/deep_plan/deep_execute/deep_auto) | `reasoning_multiagent_demo.py:4123` | (referenced) |
| `_strip_cot_from_result(result)` | Removes `reasoning_steps` before catalog write | `reasoning_multiagent_demo.py:3855` | (referenced) |
| `_llm_call_planner(...)` | LLM call entry point #1 — planner | `reasoning_multiagent_demo.py:3864-3890` | SECTION D |
| `_llm_call_agent(...)` | LLM call entry point #2 — agent | `reasoning_multiagent_demo.py:3864-3890` | SECTION D |
| `_llm_call_simple(...)` | LLM call entry point #3 — simple/utility | `reasoning_multiagent_demo.py:3864-3890` | (referenced) |
| `_llm_call_finalize(...)` | LLM call entry point #4 — final response | `reasoning_multiagent_demo.py:3864-3890` | (referenced) |
| `ALLOWED_AGENT_IDS` (frozenset, 9) | All 9 valid agent IDs | `config.py:48` | SECTION D |
| `PLANNER_AGENT_IDS` (frozenset, 4) | Only 4 are planner-visible | `config.py:61` | SECTION D |
| `AGENT_CATALOG_VERSION = "r10-v1"` | Catalog version pin (validation fingerprint) | `config.py:620` | SECTION D |
| `AGENT_CATALOG_FINGERPRINT_LEN = 12` | SHA256 hex chars for catalog fingerprint | `config.py:749` | (referenced) |
| `COT_IN_SCHEMA_ENABLED = True` | Toggle for CoT-in-schema injection | `config.py:580` | SECTION C |
| `LLM_MAX_CONTINUATIONS = 3` | Auto-continue on `finish_reason='length'` | `config.py:243` | (referenced) |
| `LLM_MODEL_CONTEXT_WINDOWS` | Model → context-window dict | `config.py` (search) | SECTION H |
| `SCHEMA_PLAN` | Strict plan envelope JSON schema | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |
| `SCHEMA_TEXT_ANALYZER` | Text analyzer output schema | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |
| `SCHEMA_KNOWLEDGE` | general_knowledge_researcher output schema | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |
| `SCHEMA_CODE_GENERATOR` | Code generator output schema | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |
| `SCHEMA_CODE_EXECUTOR` | Code executor output schema | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |
| `SCHEMA_QC_VERIFIER` | QC verifier output schema | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |
| `SCHEMA_SYNTHESIZER` | Synthesizer output schema | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |
| `SCHEMA_PROFILER` | Profiler output schema | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |

### CTX zone

| Identifier | What it does | Where |
|---|---|---|
| `_format_agent_catalog_for_planner(catalog)` | Catalog → "ALLOWED_AGENTS" block | `reasoning_multiagent_demo.py:792` |
| `_build_planning_guidance_block(query, mode)` | Per-mode planner guidance | `reasoning_multiagent_demo.py:4123` |
| `_strip_cot_from_result(result)` | Remove reasoning_steps before merge | `reasoning_multiagent_demo.py:3855` |
| 4 query modes (`shallow`, `deep_plan`, `deep_execute`, `deep_auto`) | Top-level mode switch via `gateway_arbitrator` | `reasoning_multiagent_demo.py` |
| Agent-catalog fingerprint | SHA256 hex 12 chars (validation pin) | `config.py:749` |

### ART zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `MAX_DATASET_CATALOG_ENTRIES = 100` | Dataset catalog cap | `config.py:99` | SECTION I |
| `MAX_DOCUMENT_CATALOG_ENTRIES = 100` | Document catalog cap | `config.py:100` | SECTION I |
| `MAX_CODE_CATALOG_ENTRIES = 20` | Code catalog cap | `config.py:99` | SECTION I |
| `MAX_VISUAL_CATALOG_ENTRIES = 100` | Visual catalog cap | `config.py:101` | SECTION I |
| `dataset_path(run_id, name)` | S3-style key for dataset | `reasoning_multiagent_demo.py:1944-2052` | SECTION I |
| `document_path(run_id, name)` | S3-style key for document | `reasoning_multiagent_demo.py:1944-2052` | SECTION I |
| `code_path(run_id, name)` | S3-style key for code | `reasoning_multiagent_demo.py:1944-2052` | SECTION I |
| `visual_path(run_id, name)` | S3-style key for visual | `reasoning_multiagent_demo.py:1944-2052` | SECTION I |
| `plan_path(run_id)` | Plan JSON persistence path | `reasoning_multiagent_demo.py:1944-2052` | SECTION I |
| `save_plan(plan, run_id)` | Write validated plan to disk | `reasoning_multiagent_demo.py` (search) | SECTION G |
| `running_catalog` (dict) | Per-execution catalog state | `reasoning_multiagent_demo.py:7263` | SECTION G |
| `run_id` (`run-<hex>`) | 6-char hex prefix | `reasoning_multiagent_demo.py:7280` | SECTION G |
| `MAX_CATALOG_LOCKS = 500` | Bounded distributed lock count | `config.py:611` | (referenced) |
| `MAX_CATALOG_VERSIONS_PER_FILE = 10` | Per-artifact version cap | `config.py:612` | (referenced) |
| `CATALOG_SUPERSEDED_PRUNE_ON_WRITE = True` | Auto-prune old versions | `config.py:613` | (referenced) |
| `CATALOG_ID_LEN = 8` | UUID hex chars for artifact context IDs | `config.py:748` | (referenced) |

### EXEC zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `validate_sandbox_imports(code)` | AST static scan; rejects non-allowlisted imports | `reasoning_multiagent_demo.py:140` | SECTION E |
| `SANDBOX_ALLOWED_IMPORTS` (frozenset, ~80) | Pandas, numpy, scipy, sklearn, ... | `reasoning_multiagent_demo.py` (search) | SECTION E |
| `SANDBOX_BLOCKED_IMPORTS` (frozenset, ~30) | subprocess, os, sys, socket, ... | `reasoning_multiagent_demo.py` (search) | SECTION E |
| `sandbox_exec(code, ...)` | subprocess runner with output limits | `reasoning_multiagent_demo.py` (search) | (referenced) |
| `CATALOG_EXEC_STDOUT_MAX_CHARS = 2000` | stdout truncation | `config.py:364` | (referenced) |
| `CATALOG_EXEC_ERROR_MAX_CHARS = 1000` | stderr/error truncation | `config.py:363` | (referenced) |
| `MAX_CODE_SIZE_BYTES = 65_536` | Hard cap on generated code | `config.py:799` | (referenced) |
| `MAX_CODE_QUALITY_RETRIES = 2` | Pre-execution code-quality retries | `config.py:232` | (referenced) |

### SKILL zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `Severity` (enum) | info / warning / error / escalate | `common.py:26` | SECTION A |
| `ValidationIssue` (dataclass) | severity, gate, message, field, details | `common.py:33` | SECTION A |
| `ValidationResult` (dataclass) | ok, issues, metadata | `common.py:46` | SECTION A |
| `StepContract` (dataclass, 50 fields) | Per-step typed contract | `common.py:70-115` | SECTION A |
| `build_contract(step) -> StepContract` | Plan-step → contract converter | `common.py:126` | SECTION A |
| `COT_IN_SCHEMA_ENABLED = True` | `reasoning_steps` injection toggle | `config.py:580` | SECTION C |
| 8 JSON schemas (`SCHEMA_*`) | Output shape per agent | `reasoning_multiagent_demo.py:1073-1303` | SECTION C |

### MEMORY zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `function_registry.py` (whole module) | SQLite + FTS5 code library | `function_registry.py` (339 lines) | SECTION F |
| `register_function(name, code, ...)` | Insert into registry + FTS5 index | `function_registry.py` | SECTION F |
| `search_functions(query, limit)` | FTS5 query, BM25 ranked | `function_registry.py` | SECTION F |
| `get_function(name)` | Lookup by name | `function_registry.py` | SECTION F |
| `update_function(name, ...)` | Update + reindex | `function_registry.py` | (referenced) |
| `delete_function(name)` | Remove from registry | `function_registry.py` | (referenced) |
| `list_functions(...)` | Enumerate with filters | `function_registry.py` | (referenced) |
| `FUNCTION_REGISTRY_SEARCH_LIMIT = 10` | FTS5 default limit | `config.py:74` | (referenced) |
| `_umod_` prefix | User-uploaded module name prefix (collision-safe) | `function_registry.py` | SECTION F |
| `running_catalog` (per-execution dict) | Working memory; lifetime = `execute_plan` scope | `reasoning_multiagent_demo.py:7263` | SECTION G |
| `read_agent_catalog_cached()` | Redis 20h TTL global catalog cache | `reasoning_multiagent_demo.py:1039` | SECTION D |

### PERM zone (11 deterministic gates — NO LLM in any gate)

| Identifier | What it checks | Where (real) | Where (demo) |
|---|---|---|---|
| `validate_inputs_exist(...)` | All required inputs present in catalog | `common.py:187` | SECTION B |
| `validate_instruction_exists(...)` | Agent has clear instructions | `common.py:253` | SECTION B (stub) |
| `validate_evidence_quality(...)` | Evidence rows meet min quality bar | `common.py:353` | SECTION B (stub) |
| `validate_output_types(...)` | Output types match declarations | `common.py:406` | SECTION B (stub) |
| `validate_output_deliverables(...)` | Required deliverables present | `common.py:434` | SECTION B (stub) |
| `validate_catalog_registration(...)` | Outputs registered in correct catalog | `common.py:475` | SECTION B |
| `validate_llm_output_nonempty(...)` | No empty required fields | `common.py:513` | SECTION B (stub) |
| `validate_plan_step_contracts(...)` | Every plan step validates against StepContract | `common.py:536` | SECTION B |
| `validate_plan_deliverable_consistency(...)` | Plan promises match plan steps | `common.py:684` | SECTION B (stub) |
| `validate_code_compliance(...)` | Code passes AST + size + allowlist | `common.py:746` | SECTION B |
| `validate_schema_compatibility(...)` | LLM JSON matches agent schema | `common.py:793` | SECTION B |
| `route_feedback(result, contract)` | retry_local / escalate_to_planner / accept | `common.py:840` | SECTION B |
| `merge_results(*results)` | AND-compose multiple ValidationResults (severity max wins) | `common.py:863` | SECTION B |

### SUB-AGENT zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `execute_plan(plan, ...)` | Top-level orchestrator | `reasoning_multiagent_demo.py:7263` | SECTION G |
| `gateway_arbitrator` agent | Mode selection (shallow / deep_plan / deep_execute / deep_auto) | `reasoning_multiagent_demo.py` (search) | (referenced) |
| `dataset_profiler_profile(dataset_path, ...)` | Auto-runs on dataset upload | `reasoning_multiagent_demo.py:2913` | (referenced) |
| `representation_builder_profile(dataset_id, ...)` | Auto-runs after profiler | `reasoning_multiagent_demo.py:3233` | (referenced) |
| `text_analyzer(document_ids, query, ...)` | Planner-visible; chunked doc analysis | `reasoning_multiagent_demo.py:6014` | (referenced) |
| `general_knowledge_researcher` | Planner-visible; LLM-only (no retrieval) | `reasoning_multiagent_demo.py` (search) | (referenced) |
| `code_generator` | Planner-visible; emits Python | `reasoning_multiagent_demo.py` (search) | (referenced) |
| `code_executor` | Planner-visible; runs sandboxed code | `reasoning_multiagent_demo.py` (search) | (referenced) |
| `qc_verifier` | Auto-runs after every code_executor | `reasoning_multiagent_demo.py` (search) | (referenced) |
| `synthesizer` | Auto-runs at end; produces final answer | `reasoning_multiagent_demo.py` (search) | (referenced) |
| `LOCAL_RETRY_MAX = 2` | Per-agent retry before escalating (Tier 1) | `config.py:230` | SECTION G |
| `GLOBAL_RETRY_MAX = 1` | Planner re-eval (Tier 2) | `config.py:231` | SECTION G |
| `route_feedback` | The decision router (see PERM zone) | `common.py:840` | SECTION B |

### COMPACT zone (17 chunking constants)

| Identifier | What it does | Where | Where (demo) |
|---|---|---|---|
| `CHUNK_SIZE_DEFAULT_CHARS = 47_680` | Default chunk size | `config.py:30-50` | SECTION H |
| `CHUNK_OVERLAP_RATIO = 0.05` | Overlap fraction | `config.py:30-50` | SECTION H |
| `CHUNK_OVERLAP_MAX_CHARS = 4_768` | Overlap cap | `config.py:30-50` | SECTION H |
| `MAX_CHUNKS_PER_AGENT = 50` | Per-agent chunk cap | `config.py:30-50` | SECTION H |
| `MAX_CHUNK_PROCESS_LIMIT = 8` | Concurrent chunk LLM semaphore | `config.py:383` | (referenced) |
| `CHUNK_OUTPUT_TOKEN_BUDGET_PCT = 0.04` | Output budget % per chunk | `config.py:30-50` | SECTION H |
| `CHUNK_BUDGET_DOC_PCT = 0.60` | Document input budget % | `config.py:30-50` | SECTION H |
| `CHUNK_BUDGET_CSV_PCT = 0.30` | CSV input budget % | `config.py:30-50` | SECTION H |
| `CSV_TOKEN_BUDGET_DEFAULT = 300_000` | CSV token cap default | `config.py:30-50` | SECTION H |
| `CSV_MAX_ROWS_DEFAULT = 6_000` | CSV row cap default | `config.py:30-50` | SECTION H |
| `compute_chunk_size(model_name)` | Derives chunk math from model context window | `reasoning_multiagent_demo.py:3051-3086` | SECTION H |
| `compute_csv_budget(model_name)` | Derives CSV math from model context window | `reasoning_multiagent_demo.py` (search) | SECTION H |
| `LLM_MAX_CONTINUATIONS = 3` | Auto-continue on length-finish | `config.py:243` | (referenced) |
| `LLM_MODEL_CONTEXT_WINDOWS` (dict) | Model → context-window mapping | `config.py` (search) | SECTION H |

### TEXT zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `dataset_profiler_profile(dataset_path, ...)` | Auto-runs on dataset upload | `reasoning_multiagent_demo.py:2913` | (referenced) |
| `representation_builder_profile(dataset_id, ...)` | Auto-runs after profiler | `reasoning_multiagent_demo.py:3233` | (referenced) |
| `text_analyzer(document_ids, query, ...)` | Planner-visible; chunked doc analysis | `reasoning_multiagent_demo.py:6014` | (referenced) |
| `_bm25_retrieve(query, candidates, top_k)` | Pure-Python BM25 ranking | `reasoning_multiagent_demo.py:1819` | SECTION H |
| `PROFILER_DISPLAY_COLS_LIMIT = 30` | Profiler output width cap | `config.py:606` | (referenced) |
| `FOLDER_PREVIEW_SCAN_LIMIT = 500` | Folder preview scan cap | `config.py:770` | (referenced) |

### SURFACE zone *(Phase 3 gap-fill)*

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `app = FastAPI(title="...", lifespan=_app_lifespan)` | Main FastAPI app | `reasoning_multiagent_demo.py:9792` | SECTION K |
| 21 routes table | Full surface | `reasoning_multiagent_demo.py:9914-11737` | SECTION K |
| `GET /demo_web` → `FileResponse(static/demo.html)` | UI entry | `:9920-9923` | SECTION K |
| `POST /upload` (multipart batch, MAX_FILES=20, MAX_BYTES=200MB) | Batch upload | `:9925-9973` + `config.py:603, 114` | SECTION K |
| `POST /chat_legacy` (synchronous, 4 modes) | Legacy chat path | `:9975-10040` | SECTION K |
| `POST /chat` (async job bridge, returns `job_id` 202) | New chat path | `:11374-11478` | SECTION K |
| `GET /chat_jobs/{job_id}` (poll 60/min) + `DELETE` (cancel 30/min) | Job lifecycle | `:11481-11552` | SECTION K |
| `POST /sse_ticket/{job_id}` (TTL 30s, 10/min) | SSE ticket | `:11558-11623` + `SSE_TICKET_TTL_SEC` | SECTION K |
| `GET /sse/jobs/{job_id}` (SSE, safety timeout 600s) | Async-job SSE | `:11626-11683` + `ASYNC_SSE_SAFETY_TIMEOUT_SEC=600 (config.py:792)` | SECTION K |
| `GET /progress/stream` (SSE per-agent narration) | Progress SSE | `:10183-10205` | SECTION K |
| `GET /artifacts/{result_key:path}` (CSP-sandboxed HTML serve) | Artifact serve | `:11686-11737` | (referenced) |
| `GET /download` (traversal-guarded) | Artifact download | `:10146-10181` | (referenced) |
| `GET /state` (catalogs + plan + execution state) | State dump | `:10107-10144` | (referenced) |
| Body-size middleware (411/413 for 4 mutation paths) | Body cap | `:9827-9847` | (referenced) |
| Sliding-window per-IP rate-limit middleware | Rate limit | `:9849-9910` | (referenced) |
| `LOCAL_STORAGE_ROOT = _local_s3/` | Fake-S3 root | `:113` | (referenced) |
| `LOCAL_REDIS_ROOT = _local_redis/` (3 tiers: 10min/2hr/20hr) | Fake-Redis root | `:114` | (referenced) |
| `ensure_local_redis_layout()` | Boot-time fake-Redis dir layout | `:2362` | (referenced) |
| `redis_get_tier()` / `redis_set_tier()` (file IO) | Fake-Redis API | `:2411-2426` | (referenced) |
| `SANDBOX_BLOCKED_IMPORTS` blocks `boto3, botocore, awscli` | Sandbox isolation | `config.py:188` | (referenced) |
| `# AWS_REFRACTOR` markers | ECS-readiness flags | `:1584, 2050, 2055, 10418` | — |
| `# R8-1: Memory limit for Linux/ECS` | Sandbox ECS hint | `:5210` | — |
| uvicorn entry (`host=127.0.0.1, port=5000, workers=1`) | Server launch | `:11740-11747` | SECTION K |
| `static/demo.html` (vanilla JS, 2,489 lines) | The UI | `static/demo.html:1-2489` | (referenced) |
| `addUserMsg/addAgentThinking/addProgressLine/finalizeAgentMsg` | Front-end render | `static/demo.html:808, 821, 837, 850` | (referenced) |

### OBSERVABILITY zone *(Phase 3 gap-fill)*

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `LOCAL_RETRY_MAX = 2` / `GLOBAL_RETRY_MAX = 1` | Tier 1 + Tier 2 retry | `config.py:230, 231` | SECTION L |
| `LLM_JSON_REPAIR_ATTEMPTS = 2` | Tier 3 JSON-repair on `JSONDecodeError` | `config.py:565` | SECTION L |
| `LLM_HTTP_RETRIES = 4` / `LLM_BACKOFF_MAX_SEC = 30` / `LLM_RETRY_AFTER_MAX_SEC = 60` | Tier 4 HTTP retry constants | `config.py:562, 563, 564` | SECTION L |
| `LLM_MAX_CONTINUATIONS = 3` | Continuation on `finish_reason=length` | `config.py:1067` | SECTION L |
| `_track_llm_call(agent, call_type, attempt, prompt_tokens, completion_tokens, finish_reason, ...)` | Per-call token capture | `reasoning_multiagent_demo.py:1345` | SECTION L |
| `_compute_llm_stats()` → `{total_llm_calls, truncation_events, repair_events, total_prompt_tokens, total_completion_tokens, by_agent}` | Per-request stats aggregator | `:1363-1391` | SECTION L |
| `_llm_call_log.clear()` (per-request reset) | Stats dropped per-request — not persisted | `:10017` | SECTION L |
| `_ptrace(session_id, task_id, phase, event, agent_id, step_id, **detail)` | Structured trace event | `:1718-1750` | SECTION L |
| `_PIPELINE_TRACE_STORE` (`Dict[str, List]` in-memory) | Pipeline trace store | `:1651` | (referenced) |
| `_LLM_PAYLOAD_LOG = deque(maxlen=100)` | LLM payload ring buffer | `:1321` | SECTION L |
| `_dump_llm_payloads(filepath)` | Forensic dump | `:1330` | (referenced) |
| Per-step `wall_time_ms` | Per-step timing (time.time, NOT perf_counter) | `:7447, 7624, 7847, 8156, 8478` | (referenced) |
| Sliding-window per-IP rate limit middleware | Folder routes; FIFO eviction at `FOLDER_RATE_BUCKET_MAX_SIZE=100_000` | `:9849-9910` | SECTION L |
| `FOLDER_RATE_LIMIT_WRITE = "5/minute"` / `FOLDER_RATE_LIMIT_READ = "30/minute"` | Folder route limits | `config.py:773-774` + `:9812-9813` | (referenced) |
| `_aj_limiter = _SlowAPILimiter(key_func=_aj_get_rate_limit_key)` | slowapi Async-Job limiter | `:10964-10965` | (referenced) |
| `@_aj_limiter.limit("60/minute" / "30/minute" / "10/minute")` | Per-route Async-Job limits | `:11484, 11518, 11557` | (referenced) |
| `_aj_get_rate_limit_key()` (XFF walk + `TRUSTED_PROXY_CIDR`) | Trusted-proxy rate-limit key | `:10922-10957` | (referenced) |
| `_GATEWAY_SEMAPHORE = Semaphore(20)` / `_LLM_SEMAPHORE = Semaphore(20)` / `_slot_manager = TieredSlotManager(7)` | Concurrency primitives | `:9720-9724` | SECTION L |
| Body-size middleware (`Content-Length` 411/413) | Pre-check at `/folder/*` + `/directories/config` | `:9827-9847` | (referenced) |
| Schema strict-mode startup gate (7 schemas, FATAL on fail) | Fail-closed posture | `:9747-9763` | SECTION L |
| `_strip_cot_from_result(result, agent_label)` | Removes `reasoning_steps` from agent output | `:3855-3861` | SECTION L |
| `COT_IN_SCHEMA_ENABLED = True` (toggle) | CoT injection master switch | `config.py:580` | (referenced) |
| `LLM_INTERNAL_REASONING_DIRECTIVE` (when CoT off) | Anti-CoT directive | `config.py:570-576` | (referenced) |
| `_sanitize_col_names()` + cell truncation 200 chars | CSV sanitization | `:2909-2999` | (referenced) |
| `MAX_FIELD_LENGTH = 200` / `MAX_FILES_PER_REQUEST = 20` / `MAX_QUERY_CHARS = 10000` | Upload + query caps | `:9930-9937` + `config.py:601` | (referenced) |
| CSP on `/artifacts/` (`default-src none; frame-ancestors self`) | Strict CSP | `:11731-11735` | (referenced) |
| `_aj_sanitize_html_output()` (bleach + `_AJ_ALLOWED_TAGS`) | HTML sanitization + iframe sandbox | `:10750, 10821-10833` | (referenced) |
| `application/octet-stream` force-download on `/download` | XSS prevention | `:10180-10181` | (referenced) |
| `validate_sandbox_imports(code)` AST check (PERM-zone) | Sandbox import allowlist | `:140, 197, 2666, 5183` | (referenced) |
| Lifespan startup gate (`_app_lifespan` FATAL on schema fail) | Boot-time check | `:9706-9764` | (referenced) |
| `_write_manifest()` (`mfst-{run_id}.json`) | Per-run artifact manifest | `:2292-2323` | SECTION L |
| `manifest_index.json` (global append) | Global run index | `:2288, 2318-2321` | (referenced) |
| `save_plan()` / `load_latest_plan()` | Plan persistence | `:5145-5163` | (referenced) |
| `task_meta.json` (`latest_plan_id`, `updated_at`) | Task meta | `:2333-2335` | (referenced) |
| SSE progress stream `/progress/stream` | Live observability surface | `:10183-10205` | (referenced) |
| `_push_progress(session_id, task_id, agent_id, step_id, phase, message)` | Progress producer | `:1539-1549` | (referenced) |
| `_narrate_planner_input/output` / `_narrate_agent_input/output` | Narration helpers | `:1555, 1559, 1566, 1580` | (referenced) |
| `PROGRESS_SSE_TIMEOUT_SEC = 60` | SSE idle ping | `config.py:1459` | (referenced) |
| `qc_verifier` quality check (deterministic, NOT LLM-judged) | Runtime quality gate; `quality_score_0_to_1 = 1.0 if passed else max(0.3, 1.0 - 0.15 * len(issues))` | `:6323-6389` | (referenced) |
| **NO LLM-response cache / NO Anthropic cache_control / NO chunking cache** | Gaps | — | — |
| **NO OTel / Prometheus / Datadog / Honeycomb** | Telemetry gap | — | — |
| **NO eval harness / golden set / LLM judge / rouge / bleu** | Eval gap | — | — |
| **NO A/B framework** | Only static config bool flags | — | — |
| **NO pricing table / $ cost rollup** | Cost gap | — | — |
| **NO `/health` or `/healthz` or `/ready`** | ECS-blocker | — | — |
| **NO centralized audit log** | SIEM-incompatible | — | — |
| **NO provider circuit breaker** | Only retry+backoff | — | — |
| **NO typed error taxonomy** | Only bare `RuntimeError` | — | — |

---

## 4. Common modifications — recipe per task

| What you want to change | Which zone | Where | Recipe |
|---|---|---|---|
| Add a new agent | TOOL + SKILL | `build_agent_catalog` + new JSON schema | (1) Add entry in `build_agent_catalog` with 10 fields; (2) Add `SCHEMA_<AGENT>` constant; (3) Add agent function; (4) Add agent_id to `ALLOWED_AGENT_IDS`; (5) Optionally add to `PLANNER_AGENT_IDS` if planner-visible |
| Add a new validation gate | PERM | `common.py` after line 793 | (1) Define `def validate_<rule>(contract, catalog, result) -> ValidationResult`; (2) Wire into call site that builds full validation chain |
| Change retry budgets | SUB-AGENT | `config.py:230-231` | Edit `LOCAL_RETRY_MAX` (per-agent) or `GLOBAL_RETRY_MAX` (planner re-eval) |
| Change a catalog cap | ART | `config.py:99-102` | Edit one of `MAX_{DATASET,DOCUMENT,CODE,VISUAL}_CATALOG_ENTRIES` |
| Add a new package to sandbox allowlist | EXEC | search `SANDBOX_ALLOWED_IMPORTS` | Add module name string to frozenset |
| Block a new package from sandbox | EXEC | search `SANDBOX_BLOCKED_IMPORTS` | Add module name string to frozenset; AST gate auto-rejects |
| Change chunk size for a new model | COMPACT | `config.py:30-50` + `LLM_MODEL_CONTEXT_WINDOWS` | Add model→context-window entry; `compute_chunk_size` re-derives automatically |
| Disable CoT-in-schema | TOOL + SKILL | `config.py:580` | Set `COT_IN_SCHEMA_ENABLED = False` |
| Change agent-catalog cache TTL | MEMORY | search `read_agent_catalog_cached` | Edit hardcoded 20h constant |
| Add a new query mode | SUB-AGENT + CTX | `gateway_arbitrator` switch + `_build_planning_guidance_block` | Add new mode string + per-mode guidance block |
| Tune profiler output width | TEXT | `config.py:606` | Edit `PROFILER_DISPLAY_COLS_LIMIT = 30` |
| Cap LLM continuation count | TOOL + COMPACT | `config.py:243` | Edit `LLM_MAX_CONTINUATIONS = 3` |
| Add a deterministic safety rule (e.g., "code cannot import requests") | EXEC + PERM | `SANDBOX_BLOCKED_IMPORTS` + new gate | Add to blocklist; gate `validate_code_compliance` already covers this |
| Persist a new artifact type (e.g., audio) | ART | Add namespace + path helper + cap | (1) `audio_path(run_id, name)`; (2) `MAX_AUDIO_CATALOG_ENTRIES = 100`; (3) `running_catalog["audio_*"]` shape |
| Bump agent-catalog version | TOOL | `config.py:620` | Set `AGENT_CATALOG_VERSION = "r10-v2"`; cached plans auto-invalidate |
| Add a new package to function_registry | MEMORY | `function_registry.register_function(...)` | One API call; FTS5 reindex automatic |

---

## 5. Debugging cheat sheet — symptom → which zone

| Symptom | Likely zone | First thing to check |
|---|---|---|
| Planner emits an unknown agent_id | TOOL | `AGENT_CATALOG_VERSION` mismatch; `ALLOWED_AGENT_IDS` doesn't include it |
| Gate `validate_schema_compatibility` trips often | TOOL + SKILL | JSON schema drift vs LLM response — check `SCHEMA_*` field names match agent code |
| `validate_inputs_exist` trips on every step | ART | Catalog write succeeded but ID format differs — check `CATALOG_ID_LEN = 8` |
| Code executor blocks `pandas` (or similar legit lib) | EXEC | `SANDBOX_ALLOWED_IMPORTS` missing that package |
| Code executor allows `subprocess` (or similar dangerous lib) | EXEC | `SANDBOX_BLOCKED_IMPORTS` missing; check `validate_sandbox_imports` still runs |
| Same plan re-emitted on global retry | SUB-AGENT | `escalate_to_planner` not feeding back the gate failure reason — check `route_feedback` payload |
| Chunked summary missing middle chunks | COMPACT | `MAX_CHUNKS_PER_AGENT = 50` hit; raise cap or pre-filter via BM25 |
| LLM truncates mid-JSON | COMPACT | Continuation kicked in but JSON re-assembly broken — check `LLM_MAX_CONTINUATIONS` log |
| `running_catalog` blows past 100 dataset entries | ART | `dataset_profiler` firing more than once per artifact — dedup by sha256 |
| Plan persistence fails | ART | `plan_path(run_id)` returns invalid S3 key — check `run_id` format `run-<hex>` |
| Two users see each other's catalog | MEMORY | Redis catalog cache key missing tenant prefix — add `tenant_id` to key |
| QC verifier passes obviously-wrong output | PERM | `validate_evidence_quality` thresholds too loose; tighten |
| Agent called with stale catalog | CTX | Catalog fingerprint mismatch — invalidate cache on every catalog write |
| function_registry returns no results for new code | MEMORY | FTS5 index not committed; check `commit()` after `INSERT INTO functions_fts` |
| Sandbox subprocess hangs | EXEC | No timeout set; `sandbox_exec` should wrap in `subprocess.run(..., timeout=...)` |
| Plan re-runs from scratch after ECS task recycle | ART | `save_plan` not running; check `plan_path(run_id)` writes to durable storage (S3, not container fs) |
| `_strip_cot_from_result` not removing reasoning_steps | CTX | `COT_IN_SCHEMA_ENABLED` toggled off but strip-step still expects it; symmetric flag check needed |
| BM25 ranking returns irrelevant top-k | TEXT | Query tokenizer mismatch vs index tokenizer; check `_bm25_retrieve` candidate preprocessing |
| Auto-profiler runs again on cached dataset | ART + TEXT | Dataset identity by name not sha256; bump to content hash |

---

## 6. Glossary — Terms in plain English

> Plain-English definition + everyday analogy + concrete project example. Search by Ctrl-F.

### **Agent catalog**
- **Plain English:** The list of every agent my-product knows about, with what each takes as input and produces as output.
- **Like:** A team roster — name, role, what they need to start, what they deliver.
- **In this project:** `build_agent_catalog()` at `reasoning_multiagent_demo.py:462`. 9 agents, each with 10 metadata fields. Cached in Redis with 20h TTL.

### **ALLOWED_AGENT_IDS vs PLANNER_AGENT_IDS**
- **Plain English:** All 9 agents exist, but only 4 are visible to the LLM-planner. The other 5 run automatically at well-defined moments.
- **Like:** "The kitchen has 9 staff, but the customer only sees 4 in the open kitchen — the others (dishwasher, prep cook, etc.) run in the back."
- **In this project:** `ALLOWED_AGENT_IDS` (9 strings, `config.py:48`); `PLANNER_AGENT_IDS` (4 strings, `config.py:61`).

### **Auto-orchestrated agent**
- **Plain English:** An agent the orchestrator triggers automatically — the planner doesn't need to ask for it.
- **Like:** The smoke detector that runs whether you remember to check it or not.
- **In this project:** `gateway_arbitrator` (entry), `dataset_profiler` (on upload), `representation_builder` (after profile), `qc_verifier` (after every code_executor), `synthesizer` (at end).

### **9 named agents**
- **Plain English:** The complete set of pre-built "workers" in my-product.
- **In this project:** `gateway_arbitrator`, `dataset_profiler`, `representation_builder`, `text_analyzer`, `general_knowledge_researcher`, `code_generator`, `code_executor`, `qc_verifier`, `synthesizer`.

### **4 query modes**
- **Plain English:** Four ways the user can interact: instant (shallow), plan-only (deep_plan), full execution (deep_execute), or "let the gateway decide" (deep_auto).
- **Like:** Restaurant menu — quick snack / chef's plan / multi-course meal / "surprise me."
- **In this project:** Switch in `gateway_arbitrator`; each mode picks a different `_build_planning_guidance_block` branch.

### **SCHEMA_PLAN**
- **Plain English:** The exact shape every plan must take — steps, agent_ids, sequencing.
- **Like:** A standardized work-order form everyone fills out the same way.
- **In this project:** JSON schema constant at `reasoning_multiagent_demo.py:1073-1303`. Any planner output that doesn't validate is rejected before execution.

### **StepContract**
- **Plain English:** The 50-field contract that defines what a plan step needs and what it must produce.
- **Like:** A construction contract — specs, deliverables, deadlines, acceptance criteria.
- **In this project:** Python dataclass at `common.py:70-115`. Built from a plan step dict via `build_contract(step)`.

### **Validation gate**
- **Plain English:** A pure-Python check that returns "pass" or "fail" — no LLM involved.
- **Like:** A metal detector at airport security — deterministic, fast, no judgment call.
- **In this project:** 11 gates in `common.py` at lines 187, 253, 353, 406, 434, 475, 513, 536, 684, 746, 793. Each returns a `ValidationResult` with `ok: bool` + `issues: List[ValidationIssue]`.

### **11 deterministic gates (NO LLM in any gate)**
- **Plain English:** Eleven safety/correctness checks that fire after every agent output. None of them use AI — they use Python code and Python rules.
- **Like:** A factory QC checklist — 11 items, each either pass or fail.
- **In this project:** `validate_inputs_exist`, `validate_instruction_exists`, `validate_evidence_quality`, `validate_output_types`, `validate_output_deliverables`, `validate_catalog_registration`, `validate_llm_output_nonempty`, `validate_plan_step_contracts`, `validate_plan_deliverable_consistency`, `validate_code_compliance`, `validate_schema_compatibility`.

### **Severity (info / warning / error / escalate)**
- **Plain English:** Four levels of how bad a validation failure is.
- **Like:** Traffic-light system but with four lights instead of three.
- **In this project:** `Severity` enum at `common.py:26`. `escalate` triggers planner re-evaluation; `error` triggers local retry.

### **route_feedback**
- **Plain English:** The function that decides what to do next after a gate fails: retry locally / escalate to planner / accept anyway.
- **Like:** The branch manager who decides "send back for rework" / "escalate to corporate" / "ship as-is."
- **In this project:** `common.py:840`. Inputs: `ValidationResult`, `StepContract`. Output: one of three decision tokens.

### **merge_results**
- **Plain English:** When multiple gates run on one step, combines their results — severity-max wins.
- **Like:** "If ANY of these checks fail, the worst failure wins."
- **In this project:** `common.py:863`. AND-composition with severity escalation.

### **2-tier retry**
- **Plain English:** When something fails, first try again with the same plan (Tier 1, up to 2 times). If that doesn't work, re-plan (Tier 2, up to 1 re-plan).
- **Like:** "Try the recipe again exactly. Still bad? Call a different chef to write a new recipe."
- **In this project:** `LOCAL_RETRY_MAX = 2` (`config.py:230`) + `GLOBAL_RETRY_MAX = 1` (`config.py:231`).

### **4 catalogs (dataset / document / code / visual)**
- **Plain English:** Four separately-namespaced filing cabinets for different types of artifacts.
- **Like:** A library with 4 floors — books / journals / DVDs / posters.
- **In this project:** Caps `100 / 100 / 20 / 100` (`config.py:99-102`). Path helpers map names → S3-style keys.

### **running_catalog**
- **Plain English:** The catalog that exists for one execution and dies when execution ends.
- **Like:** A meeting whiteboard — used during the meeting, wiped after.
- **In this project:** Local dict inside `execute_plan` (`reasoning_multiagent_demo.py:7263`). NOT persisted across runs — that's the function_registry's job.

### **run_id (`run-<hex>`)**
- **Plain English:** A unique 6-character ID for one execution.
- **Like:** An invoice number — every job gets one.
- **In this project:** Generated at `reasoning_multiagent_demo.py:7280`. Prefixed with `run-`; e.g. `run-ce78f1`.

### **path helper**
- **Plain English:** A function that converts a logical name (like "feedback") into the actual storage location.
- **Like:** A reservation system that maps "name on the list" → "table number 14."
- **In this project:** 10 helpers at `reasoning_multiagent_demo.py:1944-2052`. Each maps `(run_id, name)` → S3-style key.

### **Plan persistence**
- **Plain English:** Writing the validated plan to disk as JSON so the execution survives a server crash.
- **Like:** Saving the meeting agenda — if the projector dies you can keep going.
- **In this project:** `save_plan(plan, run_id)` writes to `plan_path(run_id)`. On ECS this becomes an S3 PUT.

### **sandbox_exec**
- **Plain English:** Runs LLM-generated code in a separate Python process with strict import rules.
- **Like:** Letting a contractor work in a single locked room with a curated tool kit.
- **In this project:** `subprocess.run(["python", "-c", code], ...)` + AST pre-check + ~80-package allowlist + ~30-package blocklist.

### **AST static check**
- **Plain English:** Parsing the code as a syntax tree and rejecting forbidden patterns BEFORE running it.
- **Like:** Looking over a recipe to flag dangerous ingredients before turning on the stove.
- **In this project:** `validate_sandbox_imports` at `reasoning_multiagent_demo.py:140`. Uses Python's `ast` module.

### **SANDBOX_ALLOWED_IMPORTS (~80 packages)**
- **Plain English:** The locked-down list of libraries the sandbox can import.
- **Like:** "From this kitchen you can use these 80 ingredients — nothing else."
- **In this project:** Frozenset including pandas, numpy, scipy, sklearn, matplotlib, plotly, openpyxl, statsmodels, pyarrow, networkx, sympy, ... (full list in source).

### **SANDBOX_BLOCKED_IMPORTS (~30 packages)**
- **Plain English:** Explicit deny list — even if not in the allowlist these are EXTRA forbidden.
- **Like:** "Even if it's a vegetable, no foxglove (it's poisonous)."
- **In this project:** subprocess, os, sys, socket, requests, pickle, ctypes, multiprocessing, threading, asyncio, signal, importlib, ...

### **function_registry (SQLite + FTS5)**
- **Plain English:** A persistent code library that survives forever and is searchable by free text.
- **Like:** A personal cookbook — every time you invent a good recipe, you write it down and you can find it later by ingredient or technique.
- **In this project:** `function_registry.py` (339 lines). Uses SQLite virtual table `USING fts5(...)` for full-text search.

### **FTS5**
- **Plain English:** SQLite's built-in full-text-search engine — like a private Google for SQL tables.
- **Like:** A book index where every word in every book is searchable.
- **In this project:** Powers `function_registry.search_functions`. Ranks results via BM25.

### **`_umod_` prefix**
- **Plain English:** A naming rule that says "if you upload Python yourself, your function names get this prefix so they can't pretend to be built-ins."
- **Like:** "All freelancer badges start with 'F-' so we can tell them from staff."
- **In this project:** Applied by `function_registry.register_function` when source is user-uploaded.

### **`reasoning_steps` (CoT-in-schema)**
- **Plain English:** Asking the LLM to emit its chain-of-thought as a list of strings INSIDE the JSON response, not as free-text prose around it.
- **Like:** Asking a student to "show your work" in a labeled section of the exam, not scribbled in the margins.
- **In this project:** Every of the 8 schemas injects `reasoning_steps: List[str]`. Toggle: `COT_IN_SCHEMA_ENABLED` (`config.py:580`).

### **4 LLM call entry points**
- **Plain English:** The four — and only four — places in code where my-product talks to the LLM.
- **Like:** Four doors in/out of the building; security is tight at each one.
- **In this project:** `_llm_call_planner`, `_llm_call_agent`, `_llm_call_simple`, `_llm_call_finalize` at `reasoning_multiagent_demo.py:3864-3890`. Continuation, retry, and error handling live here once instead of N times.

### **LLM_MAX_CONTINUATIONS = 3**
- **Plain English:** If the LLM cuts off mid-response, automatically ask it to keep going — up to 3 times.
- **Like:** "If the speaker runs out of time, give them 3 more time-extensions before cutting them off."
- **In this project:** `config.py:243`. Triggered on `finish_reason='length'`.

### **LLM_MODEL_CONTEXT_WINDOWS**
- **Plain English:** A dictionary mapping each model name to its context-window size, so chunking math adapts automatically when you swap models.
- **Like:** A shelving plan that resizes based on the size of the shelves.
- **In this project:** Dict in `config.py`. gpt-4.1 (1M), gpt-4o (128K), gpt-5 (400K), plus claude entries.

### **Upstream chunking (17 constants)**
- **Plain English:** Splitting big documents/CSVs into chunks BEFORE sending to the LLM, so the LLM never sees more than fits in its window.
- **Like:** Cutting a long roll of dough into manageable pieces before baking — vs trying to bake the whole roll and failing.
- **In this project:** 17 constants at `config.py:30-50`. `compute_chunk_size(model_name)` derives per-call chunk math from `LLM_MODEL_CONTEXT_WINDOWS`.

### **CHUNK_BUDGET_DOC_PCT (60%) / CHUNK_BUDGET_CSV_PCT (30%)**
- **Plain English:** Reserve 60% of the LLM's input window for document chunks; 30% for CSV evidence. (The remaining 10% is system + planner prompt.)
- **Like:** "Allocate 60% of the suitcase for clothes, 30% for shoes, 10% for everything else."
- **In this project:** Used by `compute_chunk_size` + `compute_csv_budget` to derive per-call budgets.

### **BM25 retrieval**
- **Plain English:** A classical scoring formula that ranks documents by how relevant they are to a query.
- **Like:** Google's "okapi BM25" — old-school but very good baseline.
- **In this project:** Pure-Python implementation at `reasoning_multiagent_demo.py:1819`. Used by `text_analyzer` to pre-select top-k chunks before LLM summarization.

### **Auto-profiler (`dataset_profiler` / `representation_builder`)**
- **Plain English:** Background agents that automatically run on every uploaded dataset to extract metadata (column types, candidate keys, sample rows, semantic representation).
- **Like:** A hotel concierge who automatically reads every guest's preferences from their reservation before they arrive.
- **In this project:** `dataset_profiler_profile` (`:2913`) + `representation_builder_profile` (`:3233`). NOT planner-visible.

### **CoT strip (`_strip_cot_from_result`)**
- **Plain English:** Before storing an agent's output in the catalog, remove the `reasoning_steps` field so the catalog stays compact.
- **Like:** Filing the meeting minutes but skipping the doodles in the margins.
- **In this project:** `reasoning_multiagent_demo.py:3855`. Called after each `_llm_call_agent`.

### **Agent-catalog cache (Redis 20h TTL)**
- **Plain English:** All running ECS containers share ONE compiled catalog from Redis, instead of each rebuilding it.
- **Like:** All employees consult one shared phone directory updated daily — not each employee's personal address book.
- **In this project:** `read_agent_catalog_cached` (`reasoning_multiagent_demo.py:1039`). 20h TTL chosen because catalog rarely changes between version bumps.

### **fake-S3 / fake-Redis**
- **Plain English:** Development-mode mock backends that simulate S3 and Redis using local files — let developers run the full stack offline.
- **Like:** Practicing surgery on a mannequin before doing it on a real patient.
- **In this project:** In `reasoning_multiagent_demo.py`. Production ECS swaps in real S3 + ElastiCache via config flags.

### **AGENT_CATALOG_VERSION ("r10-v1")**
- **Plain English:** A version pin on the catalog — any saved plan referring to a different version is rejected on resume.
- **Like:** A protocol version number — "v1 clients can't talk to v2 servers."
- **In this project:** `config.py:620`. Bumped when adding/removing agents.

### **CATALOG_ID_LEN (8)**
- **Plain English:** Every artifact gets an 8-character hex ID — short enough to log, long enough to avoid collisions.
- **Like:** Order numbers at a coffee shop — 6 digits is enough, 20 is overkill.
- **In this project:** `config.py:748`.

### **CATALOG_SUPERSEDED_PRUNE_ON_WRITE**
- **Plain English:** When a new version of an artifact is written, auto-delete any version beyond the cap.
- **Like:** Auto-emptying the recycling bin when it gets too full.
- **In this project:** `config.py:613` set to `True`. Cap is `MAX_CATALOG_VERSIONS_PER_FILE = 10`.

### **The four-entry-point LLM pattern**
- **Plain English:** Every LLM call goes through ONE of four functions — so retry, continuation, error handling, token tracking all live in 4 places instead of 40.
- **Like:** All international shipments through 4 ports — easier customs / easier monitoring.
- **In this project:** `_llm_call_planner`, `_llm_call_agent`, `_llm_call_simple`, `_llm_call_finalize`. Any new safeguard added once benefits every call site.

### **Browser-history monitoring (the explicit NON-feature)**
- **Plain English:** my-product does NOT watch your browser. The product is for data analysis, not general web research.
- **Like:** An accountant doesn't need to read your texts to do your taxes.
- **In this project:** Not implemented — by design. Do NOT add in v1.

---

## 7. The minimum mental model

If you remember three things about my-product:

1. **A 9-agent reasoning pipeline with 4 planner-visible agents** is the orchestration model. The planner doesn't see `gateway_arbitrator`, `dataset_profiler`, `representation_builder`, `qc_verifier`, or `synthesizer` — those run automatically. The planner only chooses among 4: `text_analyzer`, `general_knowledge_researcher`, `code_generator`, `code_executor`. This is **purposefully more constrained** than product-A's 60-skill operator-extensible model or product-B's `delegate_task` parallel-children primitive.

2. **11 deterministic validation gates in `common.py` (NO LLM in any gate)** is the safety model. Every agent output is checked against a `StepContract` and a JSON schema by pure Python. Outcomes route through `route_feedback`: retry locally up to 2 times (`LOCAL_RETRY_MAX`); if still failing, escalate to planner for re-plan up to 1 time (`GLOBAL_RETRY_MAX`). **This is the most distinguishing technology vs the other two products** — they validate via regex (product-B's HARDLINE/DANGEROUS) or via permissive prompting (product-A); my-product validates via typed-contract Python.

3. **4 named catalogs (dataset/document/code/visual) with `run_id`-tagged S3-style paths and plan persistence** is the artifact model. Every artifact goes into one of 4 catalogs with explicit per-run caps (100/100/20/100). The plan itself is persisted to disk as JSON via `save_plan(plan, run_id)` so a 20-minute deep_execute run survives ECS task recycling. **This is structurally cleaner than product-A's transcript-as-manifest** and **complementary to product-B's `FileStateRegistry` + shadow git** (which solves a different problem — general file editing).

Everything else in my-product is supporting infrastructure for these three: how the 4 LLM call entry points centralize retry/continuation logic, how the AST-checked sandbox runs LLM-generated code with an ~80-package allowlist, how the `function_registry` (SQLite+FTS5) preserves reusable code across sessions, how the upstream chunking system fits documents to the model context window, how the auto-profilers (`dataset_profiler` + `representation_builder`) enrich the catalog on every dataset upload, how the 2-tier retry handles transient and structural failures.

---

## 8. Cross-product comparison cheat sheet

For 3-way comparison sessions, the same identifier maps across products. Use this to answer "for zone X, what are the technology and method differences between the 3?" with code evidence.

| Zone | my-product | product-A | product-B |
|---|---|---|---|
| TOOL — register | `build_agent_catalog()` at `reasoning_multiagent_demo.py:462` | descriptor-contract module | `registry.register(...)` in `tools/registry.py` |
| TOOL — dispatch | `_llm_call_agent` at `:3864-3890` | predicate-driven dispatcher | `registry.dispatch(...)` |
| TOOL — schema | 8 JSON schemas `:1073-1303` (CoT in schema) | descriptor language | OpenAI function-spec JSON |
| CTX — composition | `_format_agent_catalog_for_planner` at `:792` | `ContextEngine` plugin chain | `@-reference` parser (6 types) |
| ART — persistence | 4 catalogs + path helpers `:1944-2052` + `save_plan` | transcript-as-manifest | `FileStateRegistry` + shadow git |
| ART — lineage | `run_id`-tagged S3 keys | session messages | `parent_session_id` chain |
| EXEC — isolation | subprocess + AST + ~80-pkg allowlist | Docker / SSH / subprocess | 7 sandboxes (PTC pattern) |
| EXEC — safety | `validate_sandbox_imports` at `:140` | Docker isolation | `SANDBOX_ALLOWED_TOOLS` frozenset |
| SKILL — definition | `StepContract` 50 fields + 8 schemas | 60 markdown skills | YAML frontmatter SKILL.md |
| SKILL — extensibility | code change only | markdown PR | markdown PR + curator daemon |
| MEMORY — code | `function_registry` SQLite+FTS5 (339 lines) | (none specific) | (none specific) |
| MEMORY — user | (none) | 4 plugins + dreaming | 8 plugins + always-on SQLite+FTS5 |
| MEMORY — sharing | Redis catalog cache 20h TTL | (varies) | per-tenant DynamoDB |
| PERM — output gates | 11 deterministic at `common.py:187-793` | 4 permission modes | NO output gates (uses smart approval LLM) |
| PERM — command gates | (none — gap) | deny+reason loopback | 12 HARDLINE + 47 DANGEROUS |
| SUB-AGENT — primitive | `execute_plan` orchestrator (NOT delegation) | 10+ sub-agent types | `delegate_task` parallel children |
| SUB-AGENT — retry | 2-tier (`LOCAL=2` + `GLOBAL=1`) | (varies) | `MAX_DEPTH=1`, `_DEFAULT_MAX_CONCURRENT_CHILDREN=3` |
| COMPACT — when | upstream (before LLM), not during session | live + batch | live (`ContextCompressor`) + batch (`TrajectoryCompressor`) |
| COMPACT — trick | `compute_chunk_size(model)` adapts to context window | 9-section structured summary | pre-summarize tool result to 1-liner |
| TEXT — profiling | `dataset_profiler` + `representation_builder` auto | (none) | (none) |
| TEXT — retrieval | BM25 pure-Python at `:1819` | ripgrep + extraction cache | ripgrep + 7 web backends + a11y-tree browser |
| TEXT — web | (none) | (none) | 7 web backends with lazy SDK |

---

*End of my-product quick start. Companion files: [00_manual.md](00_manual.md), [01_process_map.html](01_process_map.html), [05_python_demo.py](05_python_demo.py).*
