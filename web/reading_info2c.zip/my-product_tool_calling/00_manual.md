# my-product — Architecture Handbook

> **A maintenance manual for the 10 function groups that make my-product what it is.**
> Same shape as the product-A and product-B handbooks — pick a function group, get its key features, benefit, process map, terminology, method, code locator, **vs product-A / vs product-B gap**, and AWS ECS recipe in one consistent format. Side-by-side comparable.

---

## Anonymization & audience

- **Anonymization (HARD RULE):** Only `my-product`, `product-A`, `product-B` are used as labels. Real product names, brand names, marketplace names, or file names from the original source never appear in any artifact.
- **Audience:** A non-technical product owner who needs to understand each subsystem in plain English with everyday analogies, plus a junior-to-mid engineer who needs precise code locators to make changes.
- **Deployment target for my-product:** AWS ECS, 50 concurrent users on 2 containers. Every recommendation is translated to Python-on-ECS terms.

---

## 0. Audit status (read this first)

| Aspect | Status | Notes |
|---|---|---|
| Source verified against real my-product code | observed | All file:line references in this manual point to `custom_dashboard/reference_project/simple_reasoning_model/{reasoning_multiagent_demo.py, common.py, config.py, function_registry.py}` |
| Demo `05_python_demo.py` runs end-to-end without API key | observed | `python 05_python_demo.py --selftest` passes all 12 checks |
| 11 deterministic gates are LLM-free | observed | Every gate in `common.py` is pure-Python — verified by reading each function body |
| 8 JSON schemas exist and inject CoT | observed | `SCHEMA_*` constants L1073-1303; `_inject_cot_in_schema` L1058; `COT_IN_SCHEMA_ENABLED = True` config.py:580 |
| `StepContract` is a frozen dataclass with 50 fields | observed | `common.py:70-115` |
| 9 named agents + 4 PLANNER_AGENT_IDS | observed | `config.py:48` ALLOWED_AGENT_IDS = 9; `config.py:61` PLANNER_AGENT_IDS = 4 |
| 2-tier retry (`LOCAL_RETRY_MAX=2` + `GLOBAL_RETRY_MAX=1`) | observed | `config.py:230-231` verbatim |
| 4 catalogs (dataset / document / code / visual) | observed | running_catalog shape inside `execute_plan` L7263 |
| Sandbox AST pre-check + ~80-package allowlist | observed | `validate_sandbox_imports` reasoning_multiagent_demo.py:140 |
| `function_registry.py` SQLite+FTS5 cross-session code library | observed | `function_registry.py:1-339` |
| Chunking system (17 constants, upstream chunking before LLM) | observed | `config.py:30-50` |
| LLM continuation system (`LLM_MAX_CONTINUATIONS=3`) | observed | `config.py:243` |
| `LLM_MODEL_CONTEXT_WINDOWS` registry (3 entries) | observed | gpt-4.1 (1M) / gpt-4o (128K) / gpt-5 (400K) |
| Local fake-S3 + fake-Redis backends | observed | development mode in reasoning_multiagent_demo.py |
| **`@-reference` parser** | unknown | my-product does NOT have one — system prompt is hardcoded |
| **Permission gate** | unknown | my-product has NO HARDLINE/DANGEROUS pattern gate — ship-blocker for 50-user ECS |
| **Cross-session memory plugin** | unknown | my-product has function_registry only (code library), NOT free-text recall |

> Every claim below carries an `observed | inferred | unknown` tag in line with the evidence labeling rule.

---

## 1. How to use this handbook

Drop in at any function group (zone) and get the same eight things every time:

| Drop-in question | Where to look |
|---|---|
| "What does this zone DO?" | §3.X — Key features |
| "Why should I care?" | §3.X — Key benefit |
| "Show me the picture" | §3.X — Process map (links to the zoomable HTML) |
| "What are these weird words?" | §3.X — Key terminology (links to glossary in [07_quick_start.md](07_quick_start.md)) |
| "What technology / method drives it?" | §3.X — Key method |
| "Where in the code does it live?" | §3.X — Code locator |
| "Where is my-product stronger / weaker than product-A and product-B?" | §3.X — Strength/weakness analysis |
| "What should we build on AWS ECS?" | §3.X — AWS ECS recipe |

If you're new: read §2 (the big picture) and §3 (the master process map) first, then drop into any zone.

---

## 2. The big picture in one paragraph

my-product is an LLM-agent **multi-agent reasoning pipeline** (NOT a tool-calling loop). One file — `reasoning_multiagent_demo.py` (11,746 lines) — orchestrates 9 named agents (`gateway_arbitrator`, `dataset_profiler`, `representation_builder`, `text_analyzer`, `general_knowledge_researcher`, `code_generator`, `code_executor`, `qc_verifier`, `synthesizer`) through a strict **planner → executor** pipeline. The signature technologies are: (a) **plan-as-data** — `SCHEMA_PLAN` is a JSON schema and plans are saved to disk for re-execution across session interruptions; (b) **11 deterministic validation gates** in `common.py` (NO LLM in any gate) that check every step's output against a typed 50-field `StepContract` before claims are accepted; (c) **4 explicit catalogs** (dataset / document / code / visual) with hard caps (100/100/20/100) that provide cross-task persistent state; (d) a **2-tier retry** loop (`LOCAL_RETRY_MAX=2` per-agent + `GLOBAL_RETRY_MAX=1` planner re-evaluation) with targeted replanning; (e) a **sandbox** with AST pre-check + ~80-package allowlist + runtime preamble patches; (f) a **17-constant chunking system** that pre-chunks documents and CSVs BEFORE the LLM ever sees them; (g) an **LLM continuation system** (`LLM_MAX_CONTINUATIONS=3`) that stitches partial outputs into one final JSON; (h) a **SQLite+FTS5 function registry** (`function_registry.py`) for cross-session code reuse. **What my-product lacks vs product-A and product-B:** no permission gate, no @-reference context engine, no free-text cross-session memory, no skill system, no sub-agent primitive (delegation IS the executor's job), no LLM-driven compaction (chunking is upstream instead), no glob/grep document search (BM25 retrieval only), no browser. **Where my-product is uniquely best:** structured plan-validate-execute reasoning with deterministic gates — neither product-A nor product-B has anything equivalent.

---

## 3. The master process map (10 zones overview)

The full diagram is in **[01_process_map.html](01_process_map.html)** — zoomable, with every zone color-coded and yellow signature-callouts highlighting my-product's distinguishing technologies.

| Zone | Color | What it covers | Deep-dive |
|---|---|---|---|
| 🟢 **TOOL** | green | Agent catalog (9 agents, 4 planner-visible) + 4 LLM call entry points + 8 JSON schemas + CoT injection | [02](02_tool_registry.html) · [03](03_llm_call_flow.html) · [04](04_architecture.html) · [06](06_process_map_demo.html) |
| 🔵 **CTX** | cyan | Catalog evidence + planning guidance block + chat_history + `_strip_cot_from_result` | [09](09_context_management.html) |
| 🟠 **ART** | orange | 4 catalogs (dataset/document/code/visual) + plan persistence + run_id tagging + 10 path helpers | [08](08_artifact_management.html) |
| 🟣 **EXEC** | purple | Sandbox with AST pre-check + ~80-package allowlist + runtime preamble patches + stdout/stderr caps | [10](10_code_execution.html) |
| 🟡 **SKILL** | yellow | ⭐ **`StepContract` 50-field dataclass + 8 JSON schemas with CoT injection** (this is my-product's strongest position) | [11](11_skill_management.html) |
| 💙 **MEMORY** | indigo | 3-layer: SQLite+FTS5 function_registry (code) + running_catalog (per-execution) + 4 disk catalogs (cross-session via S3-style paths) | [12](12_memory_management.html) |
| 🔴 **PERM** | red | ⭐ **11 deterministic validation gates in `common.py` (NO LLM in any gate)** — my-product's signature technology | [13](13_permission_approval.html) |
| 🔵 **SUB-AGENT** | deep blue | ⭐ **Multi-agent orchestration via `execute_plan` + 4 query modes + 2-tier retry** — agents are the primary primitive, not a sub-agent escape hatch | [14](14_subagent_delegation.html) |
| 🟢 **COMPACT** | teal | ⭐ **Upstream chunking BEFORE LLM (17 constants)** — no LLM-driven mid-conversation compaction | [15](15_compaction_summarization.html) |
| 🟤 **TEXT** | brown | Auto-profilers (dataset/document) + BM25 retrieval + chunked extraction | [16](16_document_retrieval.html) |
| ⚫ **SURFACE** *(Phase 3 gap-fill)* | gray | 21 FastAPI routes + 2 SSE channels + single static HTML UI + local fake-S3/fake-Redis. **No channels, no voice, no image-gen, no CLI, no Dockerfile committed yet.** my-product's weakest zone vs both competitors. | [17](17_surface.html) |
| ⚪ **OBSERVABILITY** *(Phase 3 gap-fill)* | light-gray | 4-tier retry (LOCAL=2 / GLOBAL=1 / JSON-repair=2 / HTTP=4) + pipeline trace + LLM payload ring buffer (deque maxlen=100) + sliding-window per-IP rate limit (FIFO eviction at 100k IPs) + slowapi limiter + concurrency semaphores (20/20) + schema strict-mode startup gate (fail-closed) + per-run artifact manifest + CoT scrubber + CSV sanitization + CSP + bleach + iframe-sandbox. **NO OTel/Prometheus, NO eval harness, NO A/B, NO $/cost rollup, NO `/health` endpoint (ECS-blocker), NO audit log, NO circuit breaker, NO typed error taxonomy.** | [18](18_observability.html) |
| 🟢 **ADAPT_LEARN** *(Phase 3 gap-fill, USER'S #1 ICP)* | green | **HEADLINE FINDING — my-product has effectively ZERO closed-loop learning, AND multiple scaffolded-but-not-wired signals**: `quality_score_0_to_1` 1 producer / 0 readers; `usage_count` + `increment_usage()` have **ZERO callers** (dead code in live schema); `execution_state.runs[]` capped to 10 entries, only re-read for same-task next planner-memory; no `/feedback` endpoint. **`function_registry.py` SQLite+FTS5 is the only piece of cross-session learning infra** — closest scaffolding of the three products. **5-step fix (~200 LOC) moves 0/10 → 4-5/10 on ADAPT_LEARN ICP axis.** Phase 5 INVENT opportunity: explicit per-step user-acceptance signal (no competitor has this). | [19](19_adapt_learn.html) |

**Companion artifacts (always read alongside):**
- [05_python_demo.py](05_python_demo.py) — runnable Python demo with REAL my-product class signatures, constants, and patterns (run `python 05_python_demo.py --selftest`); passes 12 checks without an API key
- [07_quick_start.md](07_quick_start.md) — function/class index + common modifications + debugging cheat sheet + plain-English glossary (~50 terms)

---

## 4. The 11 function groups, drop-in style

Every zone below follows the uniform 8-part template. Zone 11 (SURFACE) was added in the Phase 3 gap-fill pass to cover user-facing surfaces (channels, multi-modality, native apps, voice, CLI, deployment) — the deep-dive bundle's original 10 zones did not cover this area.

---

### 4.1 🟢 Zone TOOL — Agent catalog & LLM call surface (observed)

**Key features**
- `build_agent_catalog()` at `reasoning_multiagent_demo.py:462` — assembles the master catalog of 9 agents with capabilities, allowed_outputs, gating rules; ~330 lines
- `read_agent_catalog_cached()` at `reasoning_multiagent_demo.py:1039` — Redis-backed global cache with **20-hour TTL** (one catalog version per deployment)
- **4 LLM call entry points** at `reasoning_multiagent_demo.py:3864-3890`:
  - `_chat_json_schema(...)` — strict JSON-schema-enforced call (the primary surface)
  - `_chat_completion_text(...)` — free-text fallback (used for planner narration, rare)
  - `_chat_with_continuation(...)` — multi-call stitching, up to `LLM_MAX_CONTINUATIONS=3`
  - `_chat_with_tools(...)` — function-calling style (legacy, not in main flow)
- **8 JSON schemas** at `reasoning_multiagent_demo.py:1073-1303`: `SCHEMA_PLAN`, `SCHEMA_DATASET_PROFILER`, `SCHEMA_REPRESENTATION_BUILDER`, `SCHEMA_TEXT_ANALYZER`, `SCHEMA_GENERAL_KNOWLEDGE_RESEARCHER`, `SCHEMA_CODE_GENERATOR`, `SCHEMA_CODE_EXECUTOR`, `SCHEMA_SYNTHESIZER`
- **CoT injection** — `_inject_cot_in_schema(schema)` at `reasoning_multiagent_demo.py:1058` adds a `reasoning_steps: List[str]` field to every output schema when `COT_IN_SCHEMA_ENABLED = True` (`config.py:580`). LLM reasoning is visible per-call, then stripped from the result before downstream consumption (see CTX zone for `_strip_cot_from_result`).
- **9 agent IDs** in `ALLOWED_AGENT_IDS` (`config.py:48`): `gateway_arbitrator`, `dataset_profiler`, `representation_builder`, `text_analyzer`, `general_knowledge_researcher`, `code_generator`, `code_executor`, `qc_verifier`, `synthesizer`
- **4 planner-visible IDs** in `PLANNER_AGENT_IDS` (`config.py:61`): `text_analyzer`, `general_knowledge_researcher`, `code_generator`, `code_executor` — only these are addressable by the planner's emitted steps; the other 5 are pre/post pipeline workers
- **3 model entries** in `LLM_MODEL_CONTEXT_WINDOWS`: gpt-4.1 (1M tokens), gpt-4o (128K), gpt-5 (400K)

**Key benefit** — schemas are the contract. The LLM cannot return an output that doesn't validate; the planner cannot reference an agent outside `PLANNER_AGENT_IDS`. The Redis-cached catalog is shared globally so 50 concurrent ECS users hit one fingerprint, not 50 catalog builds.

**Process map** — [02_tool_registry.html](02_tool_registry.html) + [03_llm_call_flow.html](03_llm_call_flow.html)

**Key terminology** — agent catalog, planner-visible agent, JSON schema, CoT injection, schema continuation, agent_catalog_version (all in [07_quick_start.md](07_quick_start.md))

**Key method/technology** — Static agent catalog (build-once, cache globally) + 8 strict JSON schemas + per-call CoT-in-schema injection + 4 LLM call entry points + 3-model context window registry

**Code locator**
| Concept | File:line |
|---|---|
| `build_agent_catalog()` | `reasoning_multiagent_demo.py:462` |
| `read_agent_catalog_cached()` | `reasoning_multiagent_demo.py:1039` |
| 4 LLM call entry points | `reasoning_multiagent_demo.py:3864-3890` |
| 8 JSON schemas | `reasoning_multiagent_demo.py:1073-1303` |
| `_inject_cot_in_schema()` | `reasoning_multiagent_demo.py:1058` |
| `ALLOWED_AGENT_IDS` / `PLANNER_AGENT_IDS` | `config.py:48, 61` |
| `LLM_MAX_CONTINUATIONS` | `config.py:243` |
| `COT_IN_SCHEMA_ENABLED` | `config.py:580` |
| `LLM_MODEL_CONTEXT_WINDOWS` | `config.py` (model registry section) |

**Strengths and gaps**
- vs **product-A** — product-A uses descriptor-contract + availability predicate language for tools; my-product uses JSON-schema-enforced calls for agent OUTPUTS (different problem). my-product's CoT-in-schema is unique.
- vs **product-B** — product-B has `ToolEntry.__slots__` with check_fn TTL + 9 provider adapters; my-product has 1 LLM provider, 9 agents (not tools). my-product's strength: schema contract enforced AT the LLM call.
- **my-product weakness** — no provider adapter layer (locked to one provider's response shape); no `check_fn` availability gating; no tool-call dispatch (because agents are the unit, not tools).

**AWS ECS recipe**
- Keep `build_agent_catalog()` build-once at container boot; ElastiCache for `read_agent_catalog_cached` (replace fake-Redis with real ElastiCache cluster)
- 20-hour TTL works for ECS — match it to your deployment cadence
- Use AWS Bedrock for `_chat_json_schema` (Claude/Titan models support response schemas)
- Cache LLM_MODEL_CONTEXT_WINDOWS as a YAML in `ssm:/my-product/context-windows` + AppConfig watch for hot-swap

**Related zones** — CTX (catalog evidence is part of planner prompt), SUB-AGENT (`PLANNER_AGENT_IDS` is the addressable set), SKILL (the 8 schemas ARE my-product's skill system).

---

### 4.2 🔵 Zone CTX — Catalog evidence + planning guidance + chat_history (observed)

**Key features**
- `_format_agent_catalog_for_planner()` at `reasoning_multiagent_demo.py:792` — turns the JSON catalog into a planner-readable text block (~9 lines per agent); only PLANNER_AGENT_IDS are surfaced; capabilities + allowed_outputs presented as bullets
- `_build_planning_guidance_block()` at `reasoning_multiagent_demo.py:4123` — emits hard rules ("never reference unknown agent_id", "deliverable types must match `allowed_outputs`", "every step needs a non-empty `instructions`"). This block is prepended to every planner LLM call.
- `_strip_cot_from_result()` at `reasoning_multiagent_demo.py:3855` — removes the `reasoning_steps` field from a validated agent output BEFORE the result is added to the running_catalog. Keeps CoT visible during the call (for debugging/log) but never re-injected into downstream steps.
- `chat_history` list — the prior user/assistant turns are passed straight into the gateway_arbitrator and planner LLM calls (no compaction, no @-reference expansion — see COMPACT zone for why this is OK in my-product's design)
- Per-call context budgets controlled by upstream chunking, NOT by post-LLM truncation
- **No @-reference parser** — my-product does NOT have product-B's `@file:`, `@folder:`, `@git:` shorthand. Users send file paths via a separate upload mechanism; the gateway_arbitrator triages them into the right pipeline branch.

**Key benefit** — planner prompts are deterministic and dependency-graph-readable. The CoT-strip step prevents the LLM's earlier reasoning from leaking into a later step's input (preventing self-reinforcement loops). The hardcoded planning guidance keeps the planner from inventing agent IDs.

**Process map** — [09_context_management.html](09_context_management.html)

**Key terminology** — catalog evidence, planning guidance block, reasoning_steps, CoT stripping, chat_history

**Key method/technology** — Deterministic prompt assembly (catalog evidence + planning guidance + chat_history) + per-call CoT strip + zero @-reference parsing

**Code locator**
| Concept | File:line |
|---|---|
| `_format_agent_catalog_for_planner()` | `reasoning_multiagent_demo.py:792` |
| `_build_planning_guidance_block()` | `reasoning_multiagent_demo.py:4123` |
| `_strip_cot_from_result()` | `reasoning_multiagent_demo.py:3855` |
| `chat_history` consumption | inside `gateway_arbitrator_route` and `planner_*` functions |

**Strengths and gaps**
- vs **product-A** — product-A has a `ContextEngine` plugin pipeline; my-product has hardcoded prompt assembly. product-A wins on flexibility, my-product wins on simplicity & determinism.
- vs **product-B** — product-B has `@-reference` parser with 6 types + dual budget; my-product has zero @-reference parser. **my-product weakness** — operators cannot inline files; uploads must go through the dataset/document/code pipeline.
- **my-product weakness** — no soft/hard budget on context; relies on upstream chunking to never exceed model window. If chunking misbehaves, the LLM call will fail rather than warn.

**AWS ECS recipe**
- Keep `_format_agent_catalog_for_planner` verbatim — ~9 lines per agent is well-tuned
- Add a SoftBudget warning if planning prompt exceeds 50% of model window (`LLM_MODEL_CONTEXT_WINDOWS` lookup × 0.5) — borrow product-B's threshold
- For ECS: cache assembled planner prompt by `(catalog_version, query_hash)` in Redis 5-min TTL — most concurrent queries share the same planner prompt

**Related zones** — TOOL (catalog evidence comes from `build_agent_catalog`), SUB-AGENT (`_build_planning_guidance_block` enforces `PLANNER_AGENT_IDS`), COMPACT (upstream chunking replaces post-LLM truncation).

---

### 4.3 🟠 Zone ART — 4 catalogs + plan persistence + run_id tagging (observed)

**Key features**
- **4 catalogs** with hard caps:
  - `datasets` (cap 100) — uploaded CSV/Parquet + derived intermediate tables
  - `documents` (cap 100) — uploaded PDF/DOCX/TXT + extracted text
  - `code` (cap 20) — generated Python snippets + stored function recipes (linked to `function_registry.py`)
  - `visuals` (cap 100) — PNG/SVG/HTML charts produced by `code_executor`
- `running_catalog` shape (inside `execute_plan` at `reasoning_multiagent_demo.py:7263`): dict of 4 lists, each list of dicts with `name`, `path`, `produced_by_step`, `tags`, `run_id`, `mtime`
- `run_id` generation at `reasoning_multiagent_demo.py:7280` — `f"run-{uuid4().hex[:6]}"` — tags every artifact produced during one `execute_plan` call so cross-run lineage is recoverable
- **10 path helpers** at `reasoning_multiagent_demo.py:1944-2052` — `datasets_dir`, `documents_dir`, `code_dir`, `visuals_dir`, `plans_dir`, `logs_dir`, `function_registry_db_path`, `temp_extract_dir`, `session_root`, `s3_prefix_for_session` — every helper composes a path under a session root and is the SINGLE source of truth for that path
- **Plan persistence** — `save_plan(plan, session_id)` writes the validated plan JSON to `plans_dir/plan_<ts>.json`; `load_plan(session_id)` re-hydrates a saved plan; this enables session resume after a container restart
- **Local fake-S3 + fake-Redis backends** for development — `S3Bucket(local_path)` and `FakeRedis` classes wrap the same boto3 / redis API surface so production code is unchanged

**Key benefit** — every artifact has lineage. `run_id` lets you ask "which visual was produced in the same run as this CSV?". Cap discipline prevents catalog runaway (100 documents = manageable; 10K documents = catalog scan blows). Plan persistence makes session interruption recoverable.

**Process map** — [08_artifact_management.html](08_artifact_management.html)

**Key terminology** — catalog, running_catalog, run_id, plans_dir, S3-style path layout, fake-S3 vs real S3, fake-Redis vs ElastiCache

**Key method/technology** — Disk-backed 4-catalog system + run_id-tagged JSON state + S3-prefixed paths + fake-backend dev-prod parity

**Code locator**
| Concept | File:line |
|---|---|
| 10 path helpers | `reasoning_multiagent_demo.py:1944-2052` |
| `running_catalog` shape | inside `execute_plan` `reasoning_multiagent_demo.py:7263` |
| `run_id` generation | `reasoning_multiagent_demo.py:7280` |
| `save_plan` / `load_plan` | search `plans_dir` in `reasoning_multiagent_demo.py` |
| 4 catalog caps | `config.py` (search `_CAP =`) |
| S3 layout | path helpers + `S3Bucket` class |

**Strengths and gaps**
- vs **product-A** — product-A has loose workspace + transcript-as-manifest; my-product has typed 4-catalog system. my-product wins on explicit caps + lineage; product-A wins on flexibility.
- vs **product-B** — product-B has `FileStateRegistry` per-path RLock + 3-tier staleness + shadow git checkpoints; my-product has NONE of these. **my-product weakness** — no per-path locks (concurrent multi-agent writes are NOT serialized), no staleness warnings, no pre-write checkpoints. Borrow product-B's `FileStateRegistry` for ECS.
- **my-product strength** — run_id tagging is cleaner than product-B's session messages table for lineage queries.

**AWS ECS recipe**
- Local `S3Bucket` → real S3 (one bucket per environment, prefixes per tenant + session)
- Local `FakeRedis` → ElastiCache (Redis cluster mode disabled for catalog cache; cluster mode enabled if you exceed 25GB)
- Catalog JSON → DynamoDB partition_key = `(tenant_id, session_id)` + sort_key = `(catalog_type, name)` for O(1) cap enforcement
- Port product-B's `FileStateRegistry` analog: DynamoDB conditional writes (CAS on version column) for distributed per-path locks
- S3 versioning ON for workspace bucket; save VersionId on every write for product-B-style rollback
- Plan persistence: S3 `<session>/plans/<plan_id>.json` + DynamoDB pointer for fast list

**Related zones** — EXEC (sandbox writes go through path helpers), MEMORY (function_registry sits alongside `code` catalog), SUB-AGENT (each step's outputs are added to running_catalog).

---

### 4.4 🟣 Zone EXEC — Sandbox with AST pre-check + ~80-package allowlist (observed)

**Key features**
- `validate_sandbox_imports(code)` at `reasoning_multiagent_demo.py:140` — AST static check; rejects `import` statements outside the allowlist BEFORE the subprocess is spawned
- `SANDBOX_ALLOWED_IMPORTS` — **~80 packages** including `pandas`, `numpy`, `scipy`, `sklearn`, `matplotlib`, `seaborn`, `plotly`, `statsmodels`, `nltk`, `transformers`, `torch`, `tensorflow`, `xgboost`, `lightgbm`, `geopandas`, `pillow`, `openpyxl`, `pyarrow`, `fastparquet`, plus the standard library
- `SANDBOX_BLOCKED_IMPORTS` — `subprocess`, `os.system`, `socket`, `requests`, `urllib`, `ftplib`, `smtplib`, `multiprocessing`, `threading`, `ctypes` (network + concurrency + ffi escape vectors)
- Subprocess preamble — every script gets `sys.path` patched, `pd.set_option('display.max_rows', N)`, matplotlib backend forced to `Agg`, working dir cd'd to session root
- **stdout cap** `MAX_STDOUT_BYTES = 100_000`; **stderr cap** `MAX_STDERR_BYTES = 50_000`; **wall-clock timeout** `SANDBOX_TIMEOUT_SECONDS = 90`
- `_umod_<id>` prefix for user-uploaded Python — stored separately, never auto-loaded; explicit `register_user_function(...)` required to expose
- Generated charts/CSVs land in the run's `visuals/` or `datasets/` dir via path helpers
- **No Docker/SSH/Modal/Daytona backends** — subprocess only; only one sandbox backend

**Key benefit** — fast, predictable, no container overhead per call. AST pre-check is significantly cheaper than runtime ImportError. The allowlist covers the data-science long tail; the blocklist covers network/concurrency escapes.

**Process map** — [10_code_execution.html](10_code_execution.html)

**Key terminology** — AST pre-check, allowlist, blocklist, sandbox preamble, _umod_ prefix, stdout/stderr cap, wall-clock timeout

**Key method/technology** — Python AST static analysis + ~80-package allowlist + subprocess isolation + runtime preamble patches + I/O caps

**Code locator**
| Concept | File:line |
|---|---|
| `validate_sandbox_imports(code)` | `reasoning_multiagent_demo.py:140` |
| `SANDBOX_ALLOWED_IMPORTS` | `reasoning_multiagent_demo.py` (search constant) |
| `SANDBOX_BLOCKED_IMPORTS` | `reasoning_multiagent_demo.py` (search constant) |
| Subprocess preamble | inside `code_executor_run_code` |
| Output caps | `config.py` (search MAX_STDOUT) |

**Strengths and gaps**
- vs **product-A** — product-A has subprocess + openshell + Docker/SSH; my-product has subprocess only. product-A wins on backend flexibility.
- vs **product-B** — product-B has Programmatic Tool Calling + 7 sandboxes; my-product has zero PTC, one sandbox. **my-product weakness** — each tool call is one round trip with the LLM; on multi-step pipelines my-product pays ~10× more tokens than product-B.
- **my-product strength** — AST pre-check is more rigorous than product-B's runtime-only allowlist; the ~80-package allowlist is broader for data-science than either competitor.

**AWS ECS recipe**
- Port AST check + allowlist verbatim — bullet-proof Python
- Subprocess on the same ECS task is fine for trusted code; for untrusted, spawn Lambda (provisioned concurrency 10) with EFS attached for input files
- For long jobs (>15s), Fargate task on same EFS mount
- Network egress at ECS task definition: deny all → allowlist `pypi.org`, `cdn.jsdelivr.net` (for matplotlib map tiles), VPC endpoint for S3
- Copy `MAX_STDOUT_BYTES = 100_000`, `MAX_STDERR_BYTES = 50_000`, `SANDBOX_TIMEOUT_SECONDS = 90` verbatim

**Related zones** — ART (sandbox writes go through path helpers), MEMORY (succeeded scripts get registered in function_registry), PERM (the validation gates check that code_executor's output is well-formed).

---

### 4.5 🟡 Zone SKILL — `StepContract` 50-field dataclass + 8 JSON schemas with CoT injection ⭐ (observed)

**Key features**
- `StepContract` at `common.py:70-115` — frozen dataclass with **50 fields** describing one planner step: `step_id`, `agent_id`, `instructions`, `requires_documents`, `requires_datasets`, `requires_code`, `expected_output_files`, `expected_output_types`, `expected_output_deliverables`, `must_register_in_catalog`, `requires_qc`, `max_attempts`, `escalation_policy`, `evidence_requirements`, … and ~35 more
- `build_contract(step: Dict) -> StepContract` at `common.py:126` — converts a raw planner-emitted step dict into a typed contract; raises `ValueError` for unknown fields (strict mode)
- `Severity` enum at `common.py:26` — `info | warn | escalate | fail`
- `ValidationIssue` at `common.py:33` — `(severity, code, message, where)`
- `ValidationResult` at `common.py:46` — `(ok: bool, issues: List[ValidationIssue])`
- **8 JSON schemas** at `reasoning_multiagent_demo.py:1073-1303` — one per planner-visible agent + planner + synthesizer; every schema includes `reasoning_steps` after `_inject_cot_in_schema` is applied
- The contract drives the validation gates (zone PERM) — each gate reads contract fields to decide what to check

**Key benefit** — every step is typed before execution. Field mismatches between planner emission and agent output surface IMMEDIATELY at the gate, not as a downstream NaN. The 8 schemas make every LLM call deterministic in output shape.

**Process map** — [11_skill_management.html](11_skill_management.html)

**Key terminology** — StepContract, build_contract, Severity, ValidationIssue, ValidationResult, JSON schema, CoT injection, reasoning_steps field

**Key method/technology** — Frozen Python dataclass with 50 fields + strict JSON-schema validation + per-call CoT-in-schema injection

**Code locator**
| Concept | File:line |
|---|---|
| `Severity` enum | `common.py:26` |
| `ValidationIssue` | `common.py:33` |
| `ValidationResult` | `common.py:46` |
| `StepContract` | `common.py:70-115` |
| `build_contract` | `common.py:126` |
| 8 JSON schemas | `reasoning_multiagent_demo.py:1073-1303` |
| `_inject_cot_in_schema` | `reasoning_multiagent_demo.py:1058` |
| `COT_IN_SCHEMA_ENABLED` | `config.py:580` |

**Strengths and gaps**
- vs **product-A** — product-A has 60 skills + 3-level disclosure (markdown-based, operator-extensible); my-product has 8 schemas + 50-field StepContract (code-defined, engineer-extensible). product-A wins on operator agility; my-product wins on type safety.
- vs **product-B** — product-B has YAML frontmatter + curator daemon + inline shell expansion; my-product has zero markdown skills. **my-product weakness** — adding a new agent capability requires Python code + a new JSON schema, not a markdown PR.
- **my-product strength ⭐** — the StepContract + 8-schema combo is the strongest type-safety story of the three products. No competitor checks 50 fields per step.

**AWS ECS recipe**
- Port `StepContract` to Pydantic v2 with `frozen=True, extra='forbid'` — same strictness, modern syntax
- Port `Severity` + `ValidationIssue` + `ValidationResult` verbatim
- The 8 JSON schemas → JSON files in S3 `s3://my-product-schemas/<version>/` for hot-swap without redeploy
- For future operator agility: add a YAML-skill layer on top (borrow product-A's pattern) but keep StepContract as the underlying invariant

**Related zones** — TOOL (8 schemas are the LLM contract), PERM (11 gates check StepContract fields), SUB-AGENT (executor builds contract per step).

---

### 4.6 💙 Zone MEMORY — 3-layer memory architecture (observed)

**Key features**
- **Layer 1: `function_registry.py` SQLite + FTS5** (`function_registry.py:1-339`) — persistent code library across sessions. Schema: `functions(id, name, signature, body, description, tags, created_at, last_used_at, use_count)` + `functions_fts USING fts5(name, description, tags)`
- **6 API functions** in function_registry.py:
  - `register_function(name, signature, body, description, tags)` — insert/update
  - `search_functions(query, limit)` — FTS5 lookup
  - `get_function(name)` — exact lookup
  - `list_functions(limit, offset)` — pagination
  - `delete_function(name)` — soft delete
  - `bump_use_count(name)` — usage tracking
- **Layer 2: `running_catalog`** (per-execution) — 4 lists in memory during `execute_plan`; written to disk at end of each step
- **Layer 3: 4 disk catalogs** (cross-session) — same shape as running_catalog but materialized into `datasets/`, `documents/`, `code/`, `visuals/` under the session root
- **No free-text cross-session memory** — my-product does NOT have product-A/B's MemoryProvider-style plugin; sessions are independent except for the function_registry (which is global, not session-scoped)
- **No StreamingContextScrubber** — because my-product never re-injects prior session content, no scrubber is needed

**Key benefit** — code reuse without re-generation. When `code_generator` is asked for a sentiment-pareto recipe and the function_registry has one tagged `sentiment, pareto`, the planner pulls it as a hint and `code_generator` adapts it. FTS5 search is sub-millisecond.

**Process map** — [12_memory_management.html](12_memory_management.html)

**Key terminology** — function_registry, FTS5, running_catalog, disk catalog, 3-layer memory, code reuse

**Key method/technology** — SQLite + FTS5 cross-session code library + per-execution in-memory catalog + disk-materialized cross-session catalog

**Code locator**
| Concept | File:line |
|---|---|
| `function_registry.py` (entire file) | `function_registry.py:1-339` |
| Schema definition | `function_registry.py` (search `CREATE TABLE`) |
| 6 API functions | `function_registry.py` module top |
| `running_catalog` | inside `execute_plan` `reasoning_multiagent_demo.py:7263` |
| Cross-session disk catalogs | path helpers `reasoning_multiagent_demo.py:1944-2052` |

**Strengths and gaps**
- vs **product-A** — product-A has 4 plugin choices + dreaming subsystem; my-product has function_registry only. product-A wins on free-text recall.
- vs **product-B** — product-B has 8 plugins + always-on SQLite+FTS5 + StreamingContextScrubber; my-product has SQLite+FTS5 but only for CODE, not for text. **my-product weakness** — users asking "what did we conclude last time about churn?" get nothing; my-product has no answer.
- **my-product strength** — function_registry's code-reuse is more disciplined than either competitor's general-purpose memory; the FTS5 schema is purpose-built.

**AWS ECS recipe**
- Local SQLite → DynamoDB `functions` table + OpenSearch FTS index
- Builtin provider: always-on; add one external plugin slot for free-text recall — recommend **mem0** (lowest setup, circuit breaker, server-side LLM extraction)
- Per-tenant partition: `(tenant_id, name)` primary key in DynamoDB
- Async warm-up via EventBridge + Lambda (port product-B's `queue_prefetch_all` pattern)
- Borrow product-B's MemoryProvider ABC for the free-text plugin slot

**Related zones** — EXEC (succeeded scripts get registered), TOOL (the 8 schemas include a `recipes_used` field that references function_registry entries), SUB-AGENT (`code_generator` searches function_registry per task).

---

### 4.7 🔴 Zone PERM — 11 deterministic validation gates ⭐ (observed)

**Key features**
- **11 functions in `common.py:187-863`** — every gate is pure Python, NO LLM call:
  - `validate_inputs_exist(contract, available_catalogs)` `common.py:187` — required datasets/documents/code present
  - `validate_instruction_exists(contract)` `common.py:253` — non-empty `instructions`
  - `validate_evidence_quality(contract, result)` `common.py:353` — required evidence fields present
  - `validate_output_types(contract, result)` `common.py:406` — `expected_output_types` match
  - `validate_output_deliverables(contract, result)` `common.py:434` — `expected_output_deliverables` present
  - `validate_catalog_registration(contract, result, catalog)` `common.py:475` — required catalog entries created
  - `validate_llm_output_nonempty(result)` `common.py:513` — output is not empty/null
  - `validate_plan_step_contracts(plan)` `common.py:536` — every step's contract is buildable
  - `validate_plan_deliverable_consistency(plan)` `common.py:684` — declared deliverables flow through the graph
  - `validate_code_compliance(code)` `common.py:746` — AST check + allowlist (called by EXEC zone too)
  - `validate_schema_compatibility(result, schema)` `common.py:793` — output validates against agent's JSON schema
- `route_feedback(...)` at `common.py:840` — given a list of `ValidationIssue`s, decides per-issue: `retry_local` / `retry_global` / `escalate_to_planner` / `fail`
- `merge_results(*results: ValidationResult) -> ValidationResult` at `common.py:863` — combines parallel gate results into one verdict
- All gates return `ValidationResult(ok: bool, issues: List[ValidationIssue])` — composable, inspectable

**Key benefit** — production safety without LLM cost. Every step passes through gates; bad output is caught BEFORE downstream agents consume it. No "judge LLM" overhead. The 4-level severity (`info | warn | escalate | fail`) drives the 2-tier retry policy (see SUB-AGENT zone).

**Process map** — [13_permission_approval.html](13_permission_approval.html)

**Key terminology** — validation gate, deterministic check (no LLM), Severity, route_feedback, merge_results

**Key method/technology** — 11 pure-Python validation functions + 4-severity outcome + per-issue routing policy

**Code locator**
| Concept | File:line |
|---|---|
| 11 validation gates | `common.py:187-863` |
| `route_feedback` | `common.py:840` |
| `merge_results` | `common.py:863` |
| `Severity` / `ValidationIssue` / `ValidationResult` | `common.py:26, 33, 46` |

**Strengths and gaps**
- vs **product-A** — product-A has 4 permission modes + deny+reason loopback (focused on dangerous-command approval); my-product has 11 gates for OUTPUT validation (focused on agent correctness). DIFFERENT problem class.
- vs **product-B** — product-B has 12 HARDLINE + 47+ DANGEROUS pattern gates for command approval; my-product has 0 command approval gates. **my-product weakness** — `code_executor` can be tricked into emitting `rm -rf /tmp/<session>` since validate_code_compliance only checks imports, not commands. Borrow product-B's HARDLINE patterns for ECS.
- **my-product strength ⭐** — the 11 deterministic OUTPUT-validation gates are unique to my-product. Neither competitor has any equivalent. This is my-product's signature technology.

**AWS ECS recipe**
- Port all 11 gates verbatim — pure Python, zero dependencies
- ADD a 12th gate: `validate_terminal_command` borrowing product-B's HARDLINE list
- For 50-user ECS: gates run inline (sub-millisecond); no Redis needed
- Audit log every escalation to S3 → Kinesis → DynamoDB (per-tenant)
- Per-gate latency tracked in CloudWatch (alarm if any single gate exceeds 50ms)

**Related zones** — SKILL (gates read StepContract fields), SUB-AGENT (route_feedback drives 2-tier retry), EXEC (validate_code_compliance is called pre-subprocess).

---

### 4.8 🔵 Zone SUB-AGENT — `execute_plan` + 4 query modes + 2-tier retry ⭐ (observed)

**Key features**
- `execute_plan(plan, run_id, mode)` at `reasoning_multiagent_demo.py:7263` — the orchestrator. Iterates over plan steps; for each step:
  1. `build_contract(step)` (common.py:126)
  2. `validate_inputs_exist(...)` + `validate_instruction_exists(...)`
  3. Dispatch to the named agent function (`text_analyzer_run`, `code_generator_run`, etc.)
  4. Validate result via remaining gates
  5. `route_feedback(issues)` → retry_local / retry_global / escalate / fail
  6. Add result to `running_catalog`
- **4 query modes**:
  - `shallow` — gateway_arbitrator answers directly (no planning, no execution)
  - `deep_plan` — gateway → planner → return plan (no execution; user reviews)
  - `deep_execute` — load saved plan → execute → return results (no planning)
  - `deep_auto` — gateway → planner → executor → synthesizer (one-shot full pipeline)
- **2-tier retry**:
  - `LOCAL_RETRY_MAX = 2` (`config.py:230`) — per-agent retry with feedback (the agent sees its prior bad output + issues + tries again)
  - `GLOBAL_RETRY_MAX = 1` (`config.py:231`) — planner re-evaluation (planner sees the failed step + issues, can emit an alternate plan)
- Agent execution is **sequential** — no parallel children; my-product trades parallelism for plan-graph readability
- Result-only return: synthesizer sees `running_catalog` + `qc_verifier` verdict, not raw LLM transcripts

**Key benefit** — the planner is in charge. Steps execute deterministically against typed contracts. Bad output triggers structured feedback (local first, planner second) rather than free-form retries. The 4 query modes map directly to product use-cases: shallow Q&A, plan-review, plan-replay, full auto.

**Process map** — [14_subagent_delegation.html](14_subagent_delegation.html)

**Key terminology** — execute_plan, planner, executor, shallow/deep_plan/deep_execute/deep_auto, LOCAL_RETRY_MAX, GLOBAL_RETRY_MAX, route_feedback, qc_verifier

**Key method/technology** — Single-process sequential plan executor + 4 modes + 2-tier retry driven by route_feedback verdicts

**Code locator**
| Concept | File:line |
|---|---|
| `execute_plan` | `reasoning_multiagent_demo.py:7263` |
| 4 query modes | dispatch logic inside `gateway_arbitrator_route` |
| `LOCAL_RETRY_MAX` / `GLOBAL_RETRY_MAX` | `config.py:230-231` |
| `PLANNER_AGENT_IDS` | `config.py:61` |
| `qc_verifier` | search `qc_verifier_check` in `reasoning_multiagent_demo.py` |
| `synthesizer` | search `synthesizer_compose` in `reasoning_multiagent_demo.py` |

**Strengths and gaps**
- vs **product-A** — product-A has 10+ named sub-types + worktree isolation; my-product has 4 query modes + 1 executor loop. product-A wins on parallel exploration; my-product wins on deterministic ordering.
- vs **product-B** — product-B has `delegate_task` + ThreadPoolExecutor + per-task_id isolation across 6 subsystems; my-product has 0 parallel children. **my-product weakness** — `text_analyzer` over 20 PDFs runs sequentially; product-B would `delegate_task` and run 3 in parallel.
- **my-product strength ⭐** — the 4 modes + 2-tier retry combo is unique. Neither competitor offers `deep_plan` (plan-only, no execution) — invaluable for user trust and debugging.

**AWS ECS recipe**
- Keep sequential execution as the default for v1 — debuggability wins
- Add parallelism for `dataset_profiler` / `representation_builder` (pre-pipeline, no dependencies between datasets) via `asyncio.gather`
- For `text_analyzer` over many documents: borrow product-B's `delegate_task` pattern with `MAX_DEPTH = 1`
- Each agent → ECS task (1 task per agent) is overkill; keep them as functions in one container
- Long jobs (>5min) → Lambda + DynamoDB status row + WebSocket back to UI

**Related zones** — TOOL (PLANNER_AGENT_IDS gates planner emissions), PERM (route_feedback drives retry decisions), ART (running_catalog accumulates step outputs).

---

### 4.9 🟢 Zone COMPACT — Upstream chunking BEFORE LLM (17 constants) ⭐ (observed)

**Key features**
- **17 chunking constants** at `config.py:30-50` (verbatim):
  - `CHUNK_TOKEN_BUDGET_PER_CALL`, `CHUNK_TOKEN_BUDGET_DOC_FRACTION = 0.60`, `CHUNK_TOKEN_BUDGET_CSV_FRACTION = 0.30`
  - `CHUNK_OUTPUT_TOKENS_FRACTION = 0.04`, `CHUNK_OVERLAP_FRACTION = 0.05`
  - `MAX_CHUNKS_PER_DOC = 50`, `MAX_CHUNKS_PER_CSV = 200`
  - `CSV_ROW_BUDGET_FRACTION = 0.02`, `MIN_CSV_ROWS = 100`, `MAX_CSV_ROWS = 50_000`
  - … and 8 more
- `compute_chunk_size(model_name)` at `reasoning_multiagent_demo.py:3051-3086` — derives `(chunk_size_chars, overlap_chars, max_chunks, output_tokens)` from the model's context window × the doc-fraction. **Real number for gpt-4.1 (1M ctx): chunk_size = 47,680 chars, overlap = 2,384, max_chunks = 50, output_tokens = 1,907.**
- `compute_csv_budget(model_name)` — same idea for CSV: `csv_token_budget = 300_000`, `csv_max_rows = 6,000` (for gpt-4.1)
- `_bm25_retrieve(query, chunks, top_k)` at `reasoning_multiagent_demo.py:1819` — for documents over `MAX_CHUNKS_PER_DOC`, BM25 picks the top-k relevant chunks BEFORE LLM injection
- **LLM continuation system** — `_chat_with_continuation` at `reasoning_multiagent_demo.py:3864-3890` stitches up to `LLM_MAX_CONTINUATIONS = 3` partial outputs into one validated JSON
- **No mid-conversation compaction** — my-product never summarizes chat_history; it chunks INPUTS so chat_history never grows past one round-trip's worth

**Key benefit** — predictable token cost per LLM call. The 60% doc / 30% CSV / 10% overhead split is hard-coded and well-tuned. BM25 retrieval is sub-millisecond. The continuation system handles long outputs without breaking JSON schema validation.

**Process map** — [15_compaction_summarization.html](15_compaction_summarization.html)

**Key terminology** — chunking, chunk_size_chars, overlap, BM25 retrieval, doc fraction, CSV row budget, continuation, max_continuations

**Key method/technology** — Upstream chunking (BEFORE LLM call) + BM25 in-memory retrieval + multi-call output stitching (LLM_MAX_CONTINUATIONS)

**Code locator**
| Concept | File:line |
|---|---|
| 17 chunking constants | `config.py:30-50` |
| `compute_chunk_size` | `reasoning_multiagent_demo.py:3051-3086` |
| `compute_csv_budget` | `reasoning_multiagent_demo.py` (search) |
| `_bm25_retrieve` | `reasoning_multiagent_demo.py:1819` |
| `_chat_with_continuation` | `reasoning_multiagent_demo.py:3864-3890` |
| `LLM_MAX_CONTINUATIONS = 3` | `config.py:243` |

**Strengths and gaps**
- vs **product-A** — product-A has 9-section summary structure + focus directive (LLM-driven mid-conversation); my-product has upstream chunking (deterministic). Different philosophies.
- vs **product-B** — product-B has ContextCompressor + TrajectoryCompressor + pre-summarize tool results (LLM-driven mid-conversation); my-product has none. **my-product weakness** — if a session's chat_history grows past the model window, my-product's planner call fails (no graceful degradation).
- **my-product strength ⭐** — upstream chunking is cheaper and more predictable than LLM-driven compaction. No "summary failed" cooldown, no auxiliary-LLM cost, no head/tail protection bugs.

**AWS ECS recipe**
- Port all 17 constants verbatim
- BM25 retrieval — use `rank_bm25` Python package (10 lines of code) or migrate to OpenSearch BM25 (more scalable)
- For chat_history overflow: add product-B-style ContextCompressor as a backup safety net (port `_SUMMARY_RATIO=0.20`, `protect_first_n=3`, `protect_last_n=20`)
- Cache `compute_chunk_size(model)` result in module-level dict (it's a pure function of model name)

**Related zones** — TEXT (chunking feeds BM25 retrieval), CTX (chunked inputs make context budget predictable), TOOL (LLM_MODEL_CONTEXT_WINDOWS drives the chunking math).

---

### 4.10 🟤 Zone TEXT — Auto-profilers + BM25 retrieval + chunked extraction (observed)

**Key features**
- `dataset_profiler_profile()` at `reasoning_multiagent_demo.py:2913` — auto-profiles uploaded CSV/Parquet: column types, missing %, unique counts, sample rows, distribution histograms, derived semantic-role tags (`temporal`, `categorical`, `numeric_continuous`, `id_like`, `text_freeform`)
- `representation_builder_profile()` at `reasoning_multiagent_demo.py:3233` — for free-text or mixed-type columns, builds embedding-friendly representations + cluster summaries
- `text_analyzer_run()` at `reasoning_multiagent_demo.py:6014` — runs over chunked document text; per-chunk extraction; cross-chunk merge using deterministic rules
- `_bm25_retrieve(query, chunks, top_k)` at `reasoning_multiagent_demo.py:1819` — pure-Python BM25 (no Elasticsearch dependency) for top-k chunk selection
- Document extraction: PDF via `pypdf`, DOCX via `python-docx`, TXT verbatim; results cached under `temp_extract_dir`
- **No glob/grep** — no equivalent to product-B's `ShellFileOperations.search`; my-product is dataset/document/code-centric, not codebase-search-centric
- **No browser** — no equivalent to product-B's `browser_navigate` / `browser_snapshot`
- **No web search** — no equivalent to product-A's `web_search` / `web_fetch`

**Key benefit** — auto-profiling means the planner sees the data shape BEFORE deciding what to do. The semantic-role tags (`temporal`, `id_like`) drive plan emission (planner knows to call `text_analyzer` on `text_freeform` columns, `code_generator` on `numeric_continuous`). BM25 retrieval keeps PDF analysis tractable.

**Process map** — [16_document_retrieval.html](16_document_retrieval.html)

**Key terminology** — dataset_profiler, representation_builder, text_analyzer, BM25 retrieval, semantic-role tag, chunked extraction, temp_extract_dir

**Key method/technology** — Pre-pipeline auto-profilers + pure-Python BM25 + per-chunk LLM extraction + deterministic cross-chunk merge

**Code locator**
| Concept | File:line |
|---|---|
| `dataset_profiler_profile` | `reasoning_multiagent_demo.py:2913` |
| `representation_builder_profile` | `reasoning_multiagent_demo.py:3233` |
| `text_analyzer_run` | `reasoning_multiagent_demo.py:6014` |
| `_bm25_retrieve` | `reasoning_multiagent_demo.py:1819` |
| Document extraction | inline in dataset/document agents |

**Strengths and gaps**
- vs **product-A** — product-A has Glob + Grep + document_extract + cache; my-product has BM25 + auto-profile + no Glob/Grep. product-A wins on codebase search.
- vs **product-B** — product-B has unified ripgrep search + 7 web backends + accessibility-tree browser; my-product has none. **my-product weakness** — user asking "who wrote X across these PDFs" works (BM25 + text_analyzer); user asking "what's the current price of stock X on the web" gets nothing.
- **my-product strength** — auto-profilers are unique; neither competitor pre-profiles uploaded data before deciding what to do.

**AWS ECS recipe**
- Keep `dataset_profiler` / `representation_builder` / `text_analyzer` as-is
- For codebase search: borrow product-B's `ShellFileOperations.search` (ripgrep)
- For web: add `web_search` (Brave/Tavily) + `web_fetch` (httpx + trafilatura) via a new `web_researcher` agent
- For browser: defer to v2 unless a clear use-case emerges
- BM25 → start with `rank_bm25` Python package; migrate to OpenSearch BM25 when documents exceed 10K

**Related zones** — COMPACT (chunking feeds BM25), ART (extracted text cached in documents/), SUB-AGENT (`text_analyzer` is a planner-visible agent).

---

### 4.11 ⚫ Zone SURFACE — FastAPI routes + single-HTML UI + fake-S3/fake-Redis (observed) — *Phase 3 gap-fill*

**Key features**
- **21 FastAPI routes** with two distinct chat paths: legacy synchronous `POST /chat_legacy` at `reasoning_multiagent_demo.py:9975-10040` + new async **Job Bridge** `POST /chat` at `reasoning_multiagent_demo.py:11374-11478` (returns `job_id` + 202)
- **2 SSE channels**: `GET /progress/stream` at L10183-10205 (per-agent progress narration) + `GET /sse/jobs/{job_id}` at L11626-11683 (async-job status with ticket+SSE+poll trio)
- **Chat reply is NOT token-streamed** — only progress narration streamed; final answer arrives atomically (artifact of multi-step orchestration model)
- **2 middlewares**: body-size guard (Content-Length 411/413) at L9827-9847 + sliding-window per-IP rate limiter at L9849-9910
- **One static HTML file** served raw: `static/demo.html` (2,489 lines, vanilla HTML+CSS+JS, no React/Vue/Svelte). External CDN: Google Fonts (Inter) + JSZip 3.10.1
- **File upload**: `MAX_FILES_PER_REQUEST = 20` (config.py:603), `MAX_UPLOAD_BYTES = 200MB` (config.py:114), `MAX_FIELD_LENGTH = 200`. **Extension-based routing, NO MIME allowlist** — unknown extensions stored silently as `{"kind": "other"}` (weaker than product-A/B)
- **Local fake-S3 + fake-Redis backends** auto-created at startup: `LOCAL_STORAGE_ROOT=_local_s3/` (L113), `LOCAL_REDIS_ROOT=_local_redis/` (L114) — 3 tiered folders (10min/2hr/20hr) simulating Redis TTL via file IO. Sandbox denylist BLOCKS `boto3`/`botocore`/`awscli` (config.py:188) so user code cannot touch real AWS
- **AWS ECS target** per HARD CONSTRAINT, marked by `# AWS_REFRACTOR` comments at L1584, L2050, L2055, L10418. One explicit ECS reference at L5210: `# R8-1: Memory limit for Linux/ECS`. **NO Dockerfile / docker-compose / IaC committed yet.**
- **uvicorn entry**: `host=127.0.0.1, port=5000, workers=1` (L11740-11747)

**Key benefit** — clean async-job pattern (ticket + SSE + poll) is ECS-friendly. Strict CSP at `/artifacts/`, traversal-guard at `/download`, body-size + rate-limit middlewares give production-grade surface security.

**Process map** — [17_surface.html](17_surface.html)

**Key terminology** — Async Job Bridge, SSE ticket, fake-S3, fake-Redis (3-tier TTL), `AWS_REFRACTOR` markers, static-HTML UI, progress narration (vs token-streamed reply)

**Key method/technology** — FastAPI + uvicorn + vanilla-JS static UI + ticket-SSE-poll async pattern + file-IO Redis simulator

**Code locator**
| Concept | File:line |
|---|---|
| `app = FastAPI(...)` | `reasoning_multiagent_demo.py:9792` |
| 21 FastAPI routes | `reasoning_multiagent_demo.py:9914-11737` (full table in [17_surface.html](17_surface.html)) |
| Body-size + rate-limit middlewares | `reasoning_multiagent_demo.py:9827-9910` |
| `POST /chat_legacy` (synchronous) | `reasoning_multiagent_demo.py:9975-10040` |
| `POST /chat` (async job bridge) | `reasoning_multiagent_demo.py:11374-11478` |
| `GET /progress/stream` (SSE) | `reasoning_multiagent_demo.py:10183-10205` |
| `GET /sse/jobs/{job_id}` (SSE) | `reasoning_multiagent_demo.py:11626-11683` |
| `static/demo.html` UI | `static/demo.html:1-2489` |
| `addUserMsg / addAgentThinking / addProgressLine / finalizeAgentMsg` | `static/demo.html:808, 821, 837, 850` |
| `LOCAL_STORAGE_ROOT` / `LOCAL_REDIS_ROOT` | `reasoning_multiagent_demo.py:113, 114` |
| `ensure_local_redis_layout` / `redis_get_tier` / `redis_set_tier` | `reasoning_multiagent_demo.py:2362, 2411-2426` |
| `# AWS_REFRACTOR` markers | `reasoning_multiagent_demo.py:1584, 2050, 2055, 10418` + ECS hint L5210 |
| uvicorn entry | `reasoning_multiagent_demo.py:11740-11747` |

**Strengths and gaps**
- vs **product-A** — product-A has 24 channels + 35 CLI modules + 5 native apps + Vite SPA + Docker + render.yaml + fly.toml + 22-module wizard. **my-product has none of these.** Largest single-zone gap of the entire teardown.
- vs **product-B** — product-B has 25 channels + OpenAI-compatible HTTP API (`/v1/...`) + ACP adapter + ~80 CLI modules + ink/React TUI + Vite/React 19 SPA + Docker + flake.nix + Homebrew + install scripts + 10 TTS + 5 STT + accessibility-tree browser. **my-product has none.**
- **my-product partial strength** — the Async-Job-Bridge ticket+SSE+poll pattern is cleaner than product-B's `/v1/runs/{id}/events` (no ticket layer). CSP/traversal-guard/rate-limit middlewares are competitive.
- **my-product unique anti-pattern** — `OPENAI_API_KEY` set inside `config.py` (a Python source file), not env/Secrets-Manager/SSM. Must move before ECS production.

**AWS ECS recipe**
- **Week 1**: containerize (Dockerfile with Python 3.13 + uv + multi-stage + non-root); move API key to Secrets Manager + SSM Parameter Store
- **Week 2**: add OpenAI-compatible `/v1/` routes (borrow product-B's `gateway/platforms/api_server.py` shape); add WebSocket support to ALB
- **Week 2-3**: implement token-streamed `synthesizer` output through SSE; reuse the `/sse/jobs/` ticket pattern
- **Week 3-4**: add 1 channel (Slack — highest ICP signal) using product-B's `BasePlatformAdapter` ABC; add Webhook adapter for generic ingress
- **Week 5+**: optional — browser tool via Lambda+Playwright; defer voice/image-gen/MCP/ACP/native-apps/Nix-Homebrew until ICP demands
- **Cross-cutting**: real S3 + ElastiCache (Redis cluster) + DynamoDB conditional writes for per-path locks (borrow product-B's `FileStateRegistry`) + Kinesis audit log

**Related zones** — ART (uploads land in catalogs), EXEC (sandbox writes go through path helpers), all other zones consume FastAPI surface.

---

### 4.12 ⚪ Zone OBSERVABILITY — 4-tier retry + pipeline trace + per-IP rate limit + manifest (observed) — *Phase 3 gap-fill*

**Key features**
- **4-tier retry / repair**: `LOCAL_RETRY_MAX=2` (per-agent, config.py:230) + `GLOBAL_RETRY_MAX=1` (planner re-eval at L9057-9092, config.py:231) + `LLM_JSON_REPAIR_ATTEMPTS=2` (on `JSONDecodeError` at L3485-3503, config.py:565) + `LLM_HTTP_RETRIES=4` (at L3705-3775, config.py:562) with `LLM_BACKOFF_MAX_SEC=30`, `LLM_RETRY_AFTER_MAX_SEC=60`. Plus `LLM_MAX_CONTINUATIONS=3` on `finish_reason=length`.
- **Token tracking (no $ rollup)**: `_track_llm_call(agent, call_type, attempt, prompt_tokens, completion_tokens, finish_reason, ...)` at L1345; `_compute_llm_stats()` at L1363 returns `by_agent` breakdown. **Cleared per-request** at L10017 — not persisted.
- **Pipeline trace events**: `_ptrace(session_id, task_id, phase, event, agent_id, step_id, **detail)` at L1718-1750; in-memory `_PIPELINE_TRACE_STORE` (`Dict[str, List]`) only flushed if `PIPELINE_TRACE_TO_FILE=True`.
- **LLM payload ring buffer**: `_LLM_PAYLOAD_LOG = deque(maxlen=100)` at L1321 + `_dump_llm_payloads(filepath)` at L1330 for forensic dump.
- **Per-step `wall_time_ms`** at L7447-8478 (uses `time.time()` not `perf_counter` — clock skew risk).
- **Sliding-window per-IP rate limiter** at L9849-9910 with FIFO eviction at `FOLDER_RATE_BUCKET_MAX_SIZE=100_000`; folder routes `5/minute write`, `30/minute read`. **slowapi Async-Job limiter** at L10964-10965 with per-route limits (`60/min, 30/min, 10/min`).
- **Concurrency semaphores**: `_GATEWAY_SEMAPHORE = Semaphore(20)`, `_LLM_SEMAPHORE = Semaphore(20)`, `_slot_manager = TieredSlotManager(7)` at L9720-9724.
- **Schema strict-mode startup gate** at L9747-9763 — 7 schemas validated, **FATAL on fail** (`raise RuntimeError(...)`). Fail-closed posture.
- **CoT scrubber**: `_strip_cot_from_result(result, agent_label)` at L3855-3861 removes `reasoning_steps`; called on every json path.
- **Sanitization**: CSV header/cell at L2909-2999 (cell truncation 200 chars); CSP on `/artifacts/` at L11731-11735; `_bleach.clean()` + iframe sandbox at L10750-10833; force-download `application/octet-stream` at L10180.
- **Per-run artifact manifest**: `_write_manifest()` at L2292-2323 writes `mfst-{run_id}.json`; global `manifest_index.json` at L2288, L2318-2321.

**Key benefit** — production-shape retry depth (4 tiers + continuation) and fail-closed schema gate are mature. The artifact manifest is run-replay-grade audit at the artifact level. Rate-limit + FIFO eviction handles abusive clients at scale (100k IPs cap).

**Process map** — [18_observability.html](18_observability.html)

**Key terminology** — 2-tier retry, JSON repair, HTTP retry, LLM continuation, `_ptrace`, `_PIPELINE_TRACE_STORE`, payload ring buffer, `wall_time_ms`, sliding-window rate limit, FIFO eviction, slowapi limiter, schema strict-mode startup gate, CoT scrubber, per-run manifest, manifest index

**Key method/technology** — Defence-in-depth retry + fail-closed schema gate + ring-buffer payload capture + manifest-level audit + sliding-window rate limit

**Code locator**
| Concept | File:line |
|---|---|
| `LOCAL_RETRY_MAX` / `GLOBAL_RETRY_MAX` | `config.py:230, 231` |
| `LLM_JSON_REPAIR_ATTEMPTS` | `config.py:565` |
| `LLM_HTTP_RETRIES` / `LLM_BACKOFF_MAX_SEC` / `LLM_RETRY_AFTER_MAX_SEC` | `config.py:562, 563, 564` |
| `LLM_MAX_CONTINUATIONS` | `config.py:1067` |
| `_track_llm_call()` / `_compute_llm_stats()` | `reasoning_multiagent_demo.py:1345, 1363` |
| `_llm_call_log.clear()` (per-request) | `:10017` |
| `_ptrace()` / `_PIPELINE_TRACE_STORE` | `:1718-1750, 1651` |
| `_LLM_PAYLOAD_LOG` (`deque(maxlen=100)`) | `:1321` |
| `_dump_llm_payloads()` | `:1330` |
| Per-step `wall_time_ms` | `:7447-8478` |
| Sliding-window per-IP middleware | `:9849-9910` |
| `FOLDER_RATE_BUCKET_MAX_SIZE`, `FOLDER_RATE_LIMIT_*` | `config.py + :9812-9813, 773-774` |
| slowapi Async-Job limiter | `:10964-10965` |
| Per-route limits (60/30/10 per minute) | `:11484, 11518, 11557` |
| `_GATEWAY_SEMAPHORE` / `_LLM_SEMAPHORE` / `_slot_manager` | `:9720-9724` |
| Schema strict-mode startup gate | `:9747-9763` |
| `_strip_cot_from_result()` | `:3855-3861` |
| CSV sanitization | `:2909-2999` |
| CSP on `/artifacts/` | `:11731-11735` |
| Bleach + iframe sandbox | `:10750, 10821-10833` |
| `_write_manifest()` per-run | `:2292-2323` |
| Plan persistence (`save_plan`, `load_latest_plan`) | `:5145-5163` |

**Strengths and gaps**
- vs **product-A** — product-A has full OTLP traces+metrics+logs + ~50 instruments + Prometheus + boundary-marker prompt cache + 3 QA evaluation plugins + 30+ token-name pricing normalization + K8s `/health-/ready` + 50+ security-audit modules + trajectory JSONL. **my-product has none.**
- vs **product-B** — product-B has dual-TTL Anthropic prompt cache + Langfuse plugin + 18-value error taxonomy with action hints + per-token-type pricing table + MCP 3-state circuit breaker + StreamingContextScrubber fail-closed + tirith pre-exec scanner + `/health-/detailed-/v1/health` + per-platform health + InsightsEngine SQLite analytics. **my-product has none.**
- **my-product partial strength**: 4-tier retry is deeper than competitors' single-tier; schema strict-mode startup gate (fail-closed) is unique; FIFO eviction at 100k-IP cap on rate-limit is unique; per-run artifact manifest (`mfst-{run_id}.json`) provides run-replay-grade audit cleaner than product-B's trajectory.
- **my-product critical gap**: **no `/health` endpoint** — ECS task health checks will fail. Ship-blocker for AWS deployment.

**AWS ECS recipe**
- **Week 1 (BLOCKING)**: add `GET /health` (dependency-free 200) + `GET /ready` (checks ElastiCache + S3 + LLM-provider quota; 503 on not-ready; `Cache-Control: no-store`)
- **Week 1**: move `OPENAI_API_KEY` from `config.py` to AWS Secrets Manager + SSM Parameter Store
- **Week 2**: port product-B's 18-value `FailoverReason` + `ClassifiedError` action-hint dataclass; replace bare `RuntimeError`
- **Week 2-3**: add OpenTelemetry via ADOT (AWS Distro for OpenTelemetry) — start with ~10 instruments; borrow product-A's GenAI semconv
- **Week 3**: port product-B's per-token-type pricing table; add `InsightsEngine`-style 30-day cost rollup to DynamoDB
- **Week 3-4**: port product-A's positive-only-jitter `Retry-After` honoring; add provider circuit breaker borrowing product-B's MCP 3-state machine
- **Week 4-5**: port product-A's `SYSTEM_PROMPT_CACHE_BOUNDARY` literal-string approach for Anthropic-via-Bedrock prompt cache
- **Week 5**: port product-A's `EXTERNAL_UNTRUSTED_CONTENT` wrapper with random-ID anti-spoof + 15-regex detector
- **Week 5+**: port product-A's TrajectoryRuntimeRecorder JSONL writer (50MB cap, mode 0o600) → S3
- **Skip for v1**: Prometheus exporter (use AWS Managed Prometheus instead), full eval harness, A/B testing framework

**Related zones** — SUB-AGENT (retry policy drives `execute_plan`), PERM (validation gates feed `route_feedback`), ART (per-run manifest), SURFACE (rate-limit middlewares + CSP + bleach are surface-zone defenses).

---

## 5. The CSV-pareto worked example traversing 7 zones

User asks: *"Create a sentiment pareto from feedback.csv for the southwest region."*

| Step | Zone(s) | What happens |
|---|---|---|
| 1. Upload | ART | feedback.csv lands in `datasets/`; `dataset_profiler` auto-runs |
| 2. Profile | TEXT | `dataset_profiler_profile()` tags columns: `region` (categorical), `feedback` (text_freeform), `timestamp` (temporal) |
| 3. Mode pick | SUB-AGENT | gateway_arbitrator picks `deep_auto` (no saved plan, multi-step query) |
| 4. Planner | TOOL + CTX | `_build_planning_guidance_block()` + `_format_agent_catalog_for_planner()` + chat_history → planner LLM call with `SCHEMA_PLAN`; planner emits 4 steps |
| 5. Plan validation | PERM | `validate_plan_step_contracts()` + `validate_plan_deliverable_consistency()` both pass |
| 6. Plan persist | ART | `save_plan(plan, run_id)` writes `plans_dir/plan_<run_id>.json` |
| 7. Step 1 (filter) | SUB-AGENT + EXEC | `code_generator` writes pandas filter; `validate_sandbox_imports` passes; `code_executor` runs subprocess; output CSV registered to running_catalog |
| 8. Step 2 (sentiment) | SUB-AGENT + EXEC + MEMORY | `code_generator` searches `function_registry` for `sentiment`; finds VADER recipe; adapts; executes; output column added |
| 9. Step 3 (pareto compute) | SUB-AGENT + EXEC | `code_generator` writes value_counts + cumulative sum; executes |
| 10. Step 4 (chart) | SUB-AGENT + EXEC | `code_generator` writes matplotlib bar+line chart; executes; PNG written to `visuals/` |
| 11. QC | PERM | `qc_verifier` runs `validate_output_deliverables` + `validate_catalog_registration` per step; all green |
| 12. Synthesize | TOOL | `synthesizer` produces final user-facing message with embedded image link |
| 13. Persist final | ART | run_id-tagged catalog written to disk |

**Zones exercised: 7 of 10** (TOOL, CTX, ART, EXEC, SUB-AGENT, PERM, TEXT). SKILL is implicit (every step uses StepContract); MEMORY activates when function_registry has a relevant recipe; COMPACT activates only if any single chunk exceeds the budget.

---

## 6. Common modifications — which zone to edit

| What you want to change | Zone | Where |
|---|---|---|
| Add a new agent | TOOL | Add to `ALLOWED_AGENT_IDS` config.py:48 + write a `<name>_run` function + register in `build_agent_catalog` |
| Make a new agent planner-visible | TOOL + SUB-AGENT | Add to `PLANNER_AGENT_IDS` config.py:61 + add JSON schema at reasoning_multiagent_demo.py:1073-1303 |
| Add a new validation gate | PERM | Append function to `common.py`; call from `execute_plan` reasoning_multiagent_demo.py:7263 |
| Change retry policy | SUB-AGENT | `LOCAL_RETRY_MAX` / `GLOBAL_RETRY_MAX` config.py:230-231 |
| Tune chunking | COMPACT | 17 constants config.py:30-50 |
| Add a new model | TOOL | Add to `LLM_MODEL_CONTEXT_WINDOWS` registry |
| Tune sandbox allowlist | EXEC | `SANDBOX_ALLOWED_IMPORTS` in reasoning_multiagent_demo.py |
| Add a new file format | TEXT | Extend `document_extractor` dispatch in reasoning_multiagent_demo.py |
| Tune catalog cap | ART | `MAX_*_CATALOG_ENTRIES` constants config.py |
| Disable CoT injection | TOOL | `COT_IN_SCHEMA_ENABLED = False` config.py:580 |
| Add a new query mode | SUB-AGENT | Extend dispatch in `gateway_arbitrator_route` |
| Register a code recipe | MEMORY | `function_registry.register_function(...)` |
| Persist a plan | ART | Already automatic via `save_plan` — see `plans_dir` |
| Resume a session | ART + SUB-AGENT | `load_plan(session_id)` + `execute_plan(plan, mode='deep_execute')` |

---

## 7. Troubleshooting — symptom → zone

| Symptom | Likely zone | What to check |
|---|---|---|
| Planner emits unknown agent_id | TOOL + CTX | `PLANNER_AGENT_IDS` config.py:61 + `_build_planning_guidance_block` reasoning_multiagent_demo.py:4123 |
| Agent output fails JSON schema | TOOL | The 8 schemas reasoning_multiagent_demo.py:1073-1303 + `_chat_json_schema` |
| Step retries 2 times then escalates | PERM + SUB-AGENT | `LOCAL_RETRY_MAX = 2` + `route_feedback` common.py:840 |
| LLM hits output cap mid-JSON | COMPACT | `_chat_with_continuation` + `LLM_MAX_CONTINUATIONS = 3` |
| Long document analysis is slow | TEXT + COMPACT | BM25 only picks top-k; if your doc is 1000+ chunks, lower `MAX_CHUNKS_PER_DOC` |
| `code_executor` rejects valid code | EXEC | `SANDBOX_ALLOWED_IMPORTS` missing a package — add it and reload |
| `code_executor` runs `rm -rf` | PERM | **You have a gap** — borrow product-B's HARDLINE patterns + add `validate_terminal_command` gate |
| Catalog runaway (>100 docs) | ART | Cap is enforced; check cap constants in config.py |
| Plan persist fails | ART | `plans_dir` not writable or session_root unset — check path helpers reasoning_multiagent_demo.py:1944-2052 |
| Sessions break at model context limit | COMPACT | chat_history grew unchecked — port product-B's ContextCompressor |
| Cross-session "you forgot last week's analysis" | MEMORY | Expected — my-product has no free-text cross-session memory; borrow product-B's MemoryProvider |
| function_registry recipes not found | MEMORY | FTS5 index missing — re-init function_registry.db |
| qc_verifier always fails | PERM | A gate is too strict — read the issue.code in `ValidationIssue` and patch the gate |
| Plan deliverable inconsistency | PERM | `validate_plan_deliverable_consistency` common.py:684 — step N's output is referenced as step M's input but types don't match |
| running_catalog over cap | ART | Cap from config.py being hit — increase or evict older entries |
| Synthesizer drops chart references | TOOL + ART | `synthesizer` schema doesn't include the visual; check `SCHEMA_SYNTHESIZER` |
| Agent output has stale CoT | CTX | `_strip_cot_from_result` reasoning_multiagent_demo.py:3855 not called — check execute_plan loop |

---

## 8. The handbook self-test

A maintenance engineer should answer these 20 questions in <30 seconds each using this handbook + the deep-dive HTMLs.

| # | Question | Answered in |
|---|---|---|
| 1 | Where is the agent catalog and how do agents register themselves? | §4.1 + [02](02_tool_registry.html) |
| 2 | What fields does StepContract contain? | §4.5 (50 fields, common.py:70-115) |
| 3 | How is the LLM payload composed? | §4.2 + [03](03_llm_call_flow.html) |
| 4 | How is an agent selected by the planner? | §4.1 (PLANNER_AGENT_IDS) + §4.8 |
| 5 | How is a step dispatched and result fed back? | §4.8 + [03](03_llm_call_flow.html) |
| 6 | What determines when retry escalates? | §4.7 (route_feedback) + §4.8 (LOCAL/GLOBAL_RETRY_MAX) |
| 7 | How does the agent remember code recipes across sessions? | §4.6 (function_registry SQLite+FTS5) |
| 8 | Does my-product gate dangerous commands? | §4.7 — **NO**. Borrow product-B's HARDLINE for ECS. |
| 9 | How does my-product investigate huge documents without blowing context? | §4.9 (BM25 + chunking) |
| 10 | What happens when the conversation gets too long? | §4.9 — chunking is upstream; chat_history overflow is currently unhandled. |
| 11 | How does the agent find answers across PDFs? | §4.10 (BM25 + text_analyzer) |
| 12 | Does my-product browse the web? | §4.10 — **NO**. Defer to v2. |
| 13 | Where do intermediate files (CSVs, charts) live? | §4.3 (4 catalogs + path helpers) |
| 14 | What's the sandbox model for running user code? | §4.4 (AST + ~80-package allowlist) |
| 15 | What's a "skill" in my-product? | §4.5 — StepContract + 8 JSON schemas (code-defined, not markdown) |
| 16 | What's distinctive about my-product's tool calling? | §4.5 + §4.7 + §4.8 (the trio: StepContract + 11 gates + 4 query modes) |
| 17 | How does my-product differ from product-A and product-B on memory? | §4.6 (code library only; no free-text recall) |
| 18 | The worked example traversing zones | §5 |
| 19 | Which zone do I edit for symptom X? | §7 |
| 20 | How does each pattern map to AWS ECS? | §4.X "AWS ECS recipe" subsections |

---

## 9. Glossary

The plain-English glossary with ~50 terms is in **[07_quick_start.md](07_quick_start.md) §6** — go there for any unfamiliar word. Search by Ctrl-F on the term.

---

## 10. Bundle file index

| File | Purpose |
|---|---|
| [00_manual.md](00_manual.md) | This handbook |
| [01_process_map.html](01_process_map.html) | Master overview diagram (10 zones, zoomable) |
| [02_tool_registry.html](02_tool_registry.html) | TOOL deep-dive: agent catalog & LLM call surface |
| [03_llm_call_flow.html](03_llm_call_flow.html) | TOOL deep-dive: one-iteration call flow |
| [04_architecture.html](04_architecture.html) | TOOL deep-dive: 9-layer file/module drilldown |
| [05_python_demo.py](05_python_demo.py) | Runnable demo with REAL my-product class signatures (`--selftest` passes 12 checks) |
| [06_process_map_demo.html](06_process_map_demo.html) | Demo .py process map (file structure → runtime flow) |
| [07_quick_start.md](07_quick_start.md) | Function/class index + common mods + debugging + glossary |
| [08_artifact_management.html](08_artifact_management.html) | ART deep-dive |
| [09_context_management.html](09_context_management.html) | CTX deep-dive |
| [10_code_execution.html](10_code_execution.html) | EXEC deep-dive |
| [11_skill_management.html](11_skill_management.html) | SKILL deep-dive ⭐ |
| [12_memory_management.html](12_memory_management.html) | MEMORY deep-dive |
| [13_permission_approval.html](13_permission_approval.html) | PERM deep-dive ⭐ |
| [14_subagent_delegation.html](14_subagent_delegation.html) | SUB-AGENT deep-dive ⭐ |
| [15_compaction_summarization.html](15_compaction_summarization.html) | COMPACT deep-dive ⭐ |
| [16_document_retrieval.html](16_document_retrieval.html) | TEXT deep-dive |
| [17_surface.html](17_surface.html) | SURFACE deep-dive *(Phase 3 gap-fill)* |
| [18_observability.html](18_observability.html) | OBSERVABILITY deep-dive *(Phase 3 gap-fill)* — caching, telemetry, eval, A/B, cost, retry, breakers, injection defense, health, audit |
| [19_adapt_learn.html](19_adapt_learn.html) | ADAPT_LEARN deep-dive *(Phase 3 gap-fill, USER'S #1 ICP)* — dead-letter findings + 5-step fix recipe + Phase 5 INVENT opportunity |

**17 files. 10 function groups. One coherent picture of how my-product works.**

---

## 11. Side-by-side with product-A and product-B

This bundle's structure intentionally mirrors the product-A and product-B bundles so that 3-way side-by-side comparison is trivial. For each zone in §4 above, the corresponding product-A and product-B handbook sections discuss the same zone for those products — same template, same headings, same code-locator format.

| Zone | product-A signature | product-B signature | my-product signature | Best of three |
|---|---|---|---|---|
| TOOL | Descriptor-contract + availability predicate language | ToolEntry __slots__ + check_fn TTL + 9 adapters + coerce_tool_args | 9-agent catalog + 8 JSON schemas + CoT injection | depends on problem (tools vs agents) |
| CTX | ContextEngine plugin pipeline | **@-reference parser + dual budget** | hardcoded planner-guidance + chat_history | product-B for flexibility |
| ART | Workspace + transcript-as-manifest (loose) | **FileStateRegistry + 3-tier staleness + shadow git** | 4-catalog + run_id-tagged + plan persistence | product-B for safety; my-product for lineage |
| EXEC | subprocess + openshell + Docker/SSH | **Programmatic Tool Calling + 7 sandboxes** | AST pre-check + ~80-package allowlist + 1 backend | product-B for token efficiency; my-product for safety |
| SKILL | 60 skills + 3-level disclosure | YAML frontmatter + curator daemon + inline shell expansion | ⭐ **StepContract 50-field + 8 JSON schemas + CoT-in-schema** | **my-product** for type safety; product-A/B for operator agility |
| MEMORY | 4 plugin choices + dreaming subsystem | **8 plugins + SQLite+FTS5 + StreamingContextScrubber** | function_registry SQLite+FTS5 (code only) | product-B for free-text; my-product for code recipes |
| PERM | 4 modes + deny+reason loopback | 12 HARDLINE + 47+ DANGEROUS + smart approval | ⭐ **11 deterministic OUTPUT-validation gates (LLM-free)** | **my-product** for output validation; product-B for command approval |
| SUB-AGENT | 10+ named sub-types + worktree isolation | delegate_task + per-task_id isolation | ⭐ **4 query modes + 2-tier retry + plan-as-data** | **my-product** for deterministic plans; product-B for parallelism |
| COMPACT | 9-section summary + focus | Pre-summarize tool results to 1-liners + image flat-estimate | ⭐ **Upstream chunking (17 constants) + LLM continuation** | **my-product** for predictability; product-B for chat session length |
| TEXT | Glob + Grep + document_extract + cache | **Unified search + 7 web backends + accessibility-tree browser** | dataset/document auto-profiler + BM25 | product-B for retrieval breadth; my-product for data shape |
| SURFACE *(Phase 3 gap-fill)* | ⭐ **24 channels + 12 image + 16 video + 3 music + 28 TTS + 5 native apps + 35 CLI + 22-module wizard + Docker+PaaS+3 daemon installers + pairing-default security** | 25 channels + **OpenAI-compat `/v1/...` API** + **ACP adapter** + ~80 CLI + 10 TTS (3 local) + 5 STT + accessibility-tree browser + Docker+Nix+Homebrew | **0 channels / 0 voice / 0 image-gen / 0 CLI / 0 native apps / no Dockerfile committed**; 21 FastAPI routes + vanilla-JS UI; AWS_REFRACTOR markers throughout | product-A for channel/multi-modal/native-app breadth; product-B for OpenAI-compat API + ACP + accessibility-tree browser |
| OBSERVABILITY *(Phase 3 gap-fill)* | ⭐ **Full OTLP traces+metrics+logs + ~50 named instruments + custom Prometheus + 3 QA plugins + character/discovery evals + positive-jitter Retry-After + boundary-marker prompt cache + random-ID anti-spoof injection wrapper + K8s `/health-/ready` + 50+ security-audit modules + trajectory JSONL** | ⭐ **Dual-TTL prompt cache + Langfuse plugin (deterministic trace_id) + 18-value error taxonomy with action hints + per-token-type pricing + MCP 3-state circuit breaker + StreamingContextScrubber + tirith pre-exec scanner + AccountUsageSnapshot plan-limit retrieval + InsightsEngine SQLite analytics + cross-session rate guard + jittered backoff** | **No OTel/Prometheus/Datadog (only stdlib logging + in-memory pipeline trace) / NO eval harness / NO A/B / NO $/cost rollup / NO `/health` endpoint (ECS-blocker) / NO audit log / NO circuit breaker / NO typed error taxonomy**; **partial strengths**: 4-tier retry depth + schema strict-mode startup gate (fail-closed) + per-run artifact manifest + FIFO-eviction sliding-window rate limit at 100k IPs | product-A for telemetry+eval+health; product-B for error-taxonomy+circuit-breaker+cost-table |
| **ADAPT_LEARN** *(Phase 3 gap-fill, ⭐ USER'S #1 ICP)* | 2 PARTIAL signals: **dreaming** (`extensions/memory-core/`) with 6 static ranking weights + recall-frequency feedback + 3-phase Light/Deep/REM cron; **skill-workshop** (`extensions/skill-workshop/`) with 6 correction-pattern regexes + LLM reviewer mutating SKILL.md. Trajectory is local-only JSONL flight recorder. **NO RLHF/DPO/bandits, NO function registry, NO tool routing adaptation, NO few-shot bank, NO user-rating ingest.** Score ~2/10 | 3 STRONGEST signals: ⭐ **Holographic `fact_feedback`** with `trust_score REAL DEFAULT 0.5` + asymmetric +0.05/-0.10 reward + retrieval `score = relevance × trust_score` (in-session RLAIF); ⭐ **Honcho dialectic** 5,000 LOC + 3-pass cold/self-audit/reconciliation + 4 daemon threads (hosted service); ⭐ **Trajectory → HF SFT pipeline** with `moonshotai/Kimi-K2-Thinking` tokenizer + 5 HF SFT datasets + `huggingface-cli upload` (offline upstream training). Plus `tools/rl_training_tool.py:1-106` Tinker-Atropos scaffold. **NO in-product RLHF, NO user thumbs, NO `function_registry` equivalent, curator is TIME-based only, prompt builder STATELESS, InsightsEngine REPORTING-only.** Score ~3/10 | **HEADLINE: 0/10 today** — multiple dead-letter signals (`quality_score_0_to_1` 1 producer/0 readers; `usage_count` + `increment_usage()` ZERO callers — dead code in live schema). But **`function_registry.py` SQLite+FTS5 is the BEST scaffolding of the three products**. **5-step fix (~200 LOC) moves 0/10 → 4-5/10.** Phase 5 INVENT opportunity: explicit per-step user-acceptance signal (👍/👎 per agent output) — no competitor has this | **None of the 3 products has true closed-loop learning from explicit user signals — this is the WHITE-SPACE ⭐ INVENT row for Phase 5.** my-product's 5-step fix path PLUS explicit per-step user-acceptance UI is the differentiating story |

⭐ = the product is strongest in this zone

**The synthesis target (an even better hybrid that compensates all weaknesses):**
- TOOL: my-product's 8 JSON schemas + product-B's `ToolEntry.__slots__` + product-B's `coerce_tool_args`
- CTX: my-product's hardcoded planner-guidance + product-B's @-reference parser (additive)
- ART: my-product's 4 catalogs + run_id + product-B's `FileStateRegistry` (per-path locks) + product-B's shadow git checkpoints
- EXEC: my-product's AST pre-check + product-B's Programmatic Tool Calling pattern (huge token savings)
- SKILL ⭐: my-product's StepContract + 8 schemas (KEEP) + product-A's markdown skill PR-style (operator agility on top)
- MEMORY: my-product's function_registry + product-B's MemoryProvider ABC slot (for free-text recall)
- PERM ⭐: my-product's 11 gates (KEEP) + product-B's 12 HARDLINE patterns (additive)
- SUB-AGENT ⭐: my-product's 4 modes + 2-tier retry (KEEP) + product-B's `delegate_task` for parallelism within `text_analyzer`
- COMPACT ⭐: my-product's upstream chunking (KEEP) + product-B's ContextCompressor as overflow safety net
- TEXT: my-product's auto-profilers (KEEP) + product-B's ripgrep `ShellFileOperations.search` + a small web_researcher agent
- SURFACE *(Phase 3 gap-fill)*: borrow product-B's `BasePlatformAdapter` ABC + product-B's OpenAI-compatible `/v1/...` API server (highest-leverage borrow); add 1 channel (Slack) for ECS v1; port product-A's pairing-default security; defer voice/image-gen/native-apps/MCP/ACP until ICP demands
- OBSERVABILITY *(Phase 3 gap-fill)*: **BLOCKING — add `/health` + `/ready`**; keep my-product's 4-tier retry + schema gate + per-run manifest; borrow product-B's 18-value `FailoverReason` + `ClassifiedError` (replaces bare RuntimeError) + per-token-type pricing table + MCP-style 3-state circuit breaker + StreamingContextScrubber; borrow product-A's positive-jitter Retry-After + `SYSTEM_PROMPT_CACHE_BOUNDARY` + `EXTERNAL_UNTRUSTED_CONTENT` anti-spoof wrapper + TrajectoryRuntimeRecorder JSONL→S3; add OpenTelemetry via ADOT (skip Prometheus, use AWS Managed Prometheus)
- **ADAPT_LEARN** *(Phase 3 gap-fill, ⭐ USER'S #1 ICP)*: execute the **5-step fix on `function_registry.py`** (~200 LOC) to wire the dead-letter signals: (1) call `increment_usage()` after planner `search_exact_batch`; (2) add `success_count, failure_count, last_qc_score` columns + update from `qc_verifier`; (3) generalize `register_function` → `register_artifact(kind, ...)` for plan templates + few-shot exemplars + user feedback; (4) rerank `get_evidence_block()` by `BM25 × log(1+success_count) / (1+failure_count)`; (5) add `POST /feedback {run_id, rating: -1|0|+1}` endpoint. Then borrow product-B's `trust_score` asymmetric +0.05/-0.10 reward pattern for plan templates. Then borrow product-A's `skill-workshop` correction-pattern regexes for plan-template auto-revision. **Phase 5 INVENT differentiator**: add explicit per-step user-acceptance UI (👍/👎 per agent output) wired to `trust_score` — no competitor has this

The hybrid keeps my-product's 4 ⭐ signature technologies intact and bolts on product-B's 4 ⭐ technologies as additive layers. Net result: stronger than any single product alone.

---

*End of my-product architecture handbook.*
