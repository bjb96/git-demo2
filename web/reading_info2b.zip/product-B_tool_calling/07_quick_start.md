# product-B — Quick Start

> Companion to [00_manual.md](00_manual.md) (the comprehensive handbook), [01_process_map.html](01_process_map.html) (the visual nav hub), and [05_python_demo.py](05_python_demo.py) (the runnable real-technology demo).
>
> Use this file as: the **function/class index** (Ctrl-F here), **common modifications recipe**, **debugging cheat sheet**, and **plain-English glossary**.

---

## 1. Run the demo in 60 seconds

The demo uses real product-B class signatures, constants, and patterns. It runs without an API key — the self-test exercises 8+ subsystems end-to-end.

```powershell
cd temp/deep_dives/product-B_tool_calling
python 05_python_demo.py --selftest
```

You should see:

```
[1] ToolRegistry — 4 tools registered
[2] dispatch(search_files, pattern='def ') — 3 matches in current dir
[3] PERM gate — hardline block: 'rm -rf /' -> allowed=False, hardline=True
[3b] PERM gate — dangerous overridable (default-deny without callback)
[3c] PERM gate — dangerous with user-approves-session callback
[4] MemoryManager + SQLite+FTS5 builtin provider — Recalled fenced memory
[5] StreamingContextScrubber — strip <memory-context> from output
[6] ContextCompressor — Before: 44 msgs, after: 9 msgs
[7] delegate_task — 3 parallel sub-agents finished in ~12ms
[8] generate_product-b_tools_module — Generated valid stub
[9] PTC end-to-end (UDS) — POSIX only (SKIPPED on Windows)

[OK] product-B demo self-test passed.
```

If you see this, every signature subsystem of product-B is correctly mirrored.

---

## 2. The 10 function groups (zones)

| Zone | Color | Deep-dive | What's distinctive about product-B's approach |
|---|---|---|---|
| 🟢 TOOL | green | [02](02_tool_registry.html) · [03](03_llm_call_flow.html) · [04](04_architecture.html) · [06](06_process_map_demo.html) | `ToolEntry.__slots__`, `_CHECK_FN_TTL_SECONDS = 30.0`, shadowing rejection, 9 provider adapters, `coerce_tool_args` for LLM type discipline |
| 🔵 CTX | cyan | [09](09_context_management.html) | **6-type @-reference parser**, **dual budget 50%/25%** hard/soft, `file_safety` deny list |
| 🟠 ART | orange | [08](08_artifact_management.html) | `FileStateRegistry` per-path RLock, 3-tier staleness warnings, **shadow git checkpoints**, SQLite+FTS5+WAL transcript, session chains |
| 🟣 EXEC | purple | [10](10_code_execution.html) ⭐ | **Programmatic Tool Calling (PTC)** — LLM writes script, stub-RPC roundtrip; **7 swappable sandboxes** |
| 🟡 SKILL | yellow | [11](11_skill_management.html) | YAML frontmatter, **inline shell expansion**, **Curator daemon** (active→stale@30d→archived@90d), platform gating |
| 💙 MEMORY | indigo | [12](12_memory_management.html) ⭐ | **8 swappable plugins** + always-on SQLite+FTS5 builtin, `MemoryManager` 4 hooks, `StreamingContextScrubber` |
| 🔴 PERM | red | [13](13_permission_approval.html) | **12 HARDLINE + 47+ DANGEROUS** patterns, contextvars per-session keys, smart approval auxiliary LLM |
| 🔵 SUB-AGENT | deep blue | [14](14_subagent_delegation.html) | `delegate_task` + `DELEGATE_BLOCKED_TOOLS` frozenset, `MAX_DEPTH=1`, per-task_id isolation across 6 subsystems |
| 🟢 COMPACT | teal | [15](15_compaction_summarization.html) | `ContextCompressor` + `TrajectoryCompressor`; **pre-summarize tool results to 1-liners** signature trick |
| 🟤 TEXT | brown | [16](16_document_retrieval.html) | Unified `search(target='files'\|'content')` via ripgrep, **7 web backends + lazy SDK**, **accessibility-tree browser snapshots** (NOT screenshots) |
| ⚫ SURFACE *(Phase 3 gap-fill)* | gray | [17](17_surface.html) | 25 channels (CJK-heavy + Western) + `BasePlatformAdapter` ABC + **OpenAI-compatible `/v1/...` HTTP API** on port 8642 + **ACP adapter** for IDE integration + ~80 CLI modules + 10 TTS (3 local) + 5 STT + browser + Docker+Nix+Homebrew |
| ⚪ OBSERVABILITY *(Phase 3 gap-fill)* | light-gray | [18](18_observability.html) | ⭐ **Dual-TTL Anthropic prompt cache** (`prompt_caching.py` 178 lines, 2 strategies) + Langfuse plugin (deterministic `trace_id`, 6 hooks, per-token-type cost) + ⭐ **18-value `FailoverReason` enum** with action hints + ⭐ **MCP server 3-state circuit breaker** (dedicated tests) + per-token-type pricing table + `AccountUsageSnapshot` plan-limit retrieval + `InsightsEngine` 30-day SQLite analytics + `StreamingContextScrubber` (fail-closed) + tirith pre-exec scanner + `/health, /health/detailed, /v1/health` + 6 per-platform endpoints. **No OTel/Prometheus** (only Langfuse); no eval harness. |
| 🟢 ADAPT_LEARN *(Phase 3 gap-fill, ⭐ USER'S #1 ICP)* | green | [19](19_adapt_learn.html) | ⭐⭐⭐ **product-B has the 3 STRONGEST adaptive signals** — (1) Holographic `fact_feedback` with `trust_score REAL DEFAULT 0.5` + asymmetric +0.05/-0.10 reward + retrieval `score = relevance × trust_score` (in-session RLAIF); (2) Honcho dialectic 5,000 LOC + 5 tool schemas + 4 daemon threads + 3-pass dialectic depth at hosted endpoint; (3) Trajectory → HF SFT pipeline with `moonshotai/Kimi-K2-Thinking` tokenizer + 5 HF SFT datasets + `huggingface-cli upload`. Plus `tools/rl_training_tool.py:1-106` Tinker-Atropos scaffold. **NO in-product RLHF/DPO; NO user thumbs ingest; curator TIME-based only; prompt builder STATELESS.** |

---

## 3. Function & class index — Ctrl-F here

### TOOL zone

| Identifier | What it does | Where (real product-B) | Where (demo) |
|---|---|---|---|
| `ToolEntry` | Tool metadata record with `__slots__` | `tools/registry.py` | SECTION A |
| `ToolRegistry` | Thread-safe singleton; register/dispatch | `tools/registry.py` | SECTION A |
| `registry.register(name, toolset, schema, handler, ...)` | Tool registration (called at module import) | `tools/registry.py` | SECTION A + G |
| `registry.dispatch(name, args)` | Run handler; JSON-error swallow; truncate | `tools/registry.py` | SECTION A |
| `registry.get_definitions(tool_names, quiet)` | OpenAI-format function schemas; check_fn TTL filter | `tools/registry.py` | SECTION A |
| `_check_fn_cached(fn)` | TTL'd availability cache (30s) | `tools/registry.py` | SECTION A |
| `_CHECK_FN_TTL_SECONDS = 30.0` | TTL constant | `tools/registry.py` | SECTION A |
| `_generation` (int) | Bumped on every register/deregister | `tools/registry.py` | SECTION A |
| `coerce_tool_args(tool_name, args)` | LLM type discipline (str→int/bool/list) | `model_tools.py` | (referenced) |
| `dynamic_schema_overrides` | Per-call schema mutation (delegate_task limits) | `tools/registry.py` | SECTION A |
| `_FirecrawlProxy` | Lazy SDK loading pattern | `tools/web_tools.py` | (documented in 16) |

### CTX zone

| Identifier | What it does | Where |
|---|---|---|
| `ContextEngine` | Abstract base for per-turn prompt assembly | `agent/context_engine.py` |
| `parse_context_references(message)` | Regex scan for @-tokens | `agent/context_references.py` |
| `preprocess_context_references(...)` | Expand and inject; enforce budgets | `agent/context_references.py` |
| `hard_limit = int(context_length * 0.50)` | 50% rejection threshold (verbatim) | `agent/context_references.py` |
| `soft_limit = int(context_length * 0.25)` | 25% warning threshold (verbatim) | `agent/context_references.py` |
| `_expand_file_reference` / `_expand_folder_reference` / `_expand_git_reference` / `_expand_url_reference` | Per-type expanders | `agent/context_references.py` |
| `_is_binary_file` / `_code_fence_language` | Helpers | `agent/context_references.py` |
| `_rg_files(path, cwd, limit)` | Ripgrep-backed folder listing | `agent/context_references.py` |
| `file_safety.is_write_denied(path)` | Sensitive-path deny check | `agent/file_safety.py` |
| `file_safety.is_reference_path_allowed(path)` | Read-allowed check | `agent/file_safety.py` |

### ART zone

| Identifier | What it does | Where |
|---|---|---|
| `FileStateRegistry` | Per-task ReadStamp + writes_since cursor | `tools/file_state.py` |
| `_MAX_PATHS_PER_AGENT = 4096` | Per-task dict cap (verbatim) | `tools/file_state.py` |
| `_MAX_GLOBAL_WRITERS = 4096` | Global writes cap (verbatim) | `tools/file_state.py` |
| `record_read(task_id, path, *, partial=False)` | Stamp a read | `tools/file_state.py` |
| `note_write(task_id, path)` | Stamp a write | `tools/file_state.py` |
| `check_stale(task_id, path) -> Optional[str]` | 3-tier staleness check | `tools/file_state.py` |
| `lock_path(path)` | Per-path RLock context manager | `tools/file_state.py` |
| `writes_since(...)` | Find writes after a timestamp | `tools/file_state.py` |
| `CheckpointManager` | Shadow git store, per-project branches | `tools/checkpoint_manager.py` |
| `SessionDB` | SQLite + FTS5 + WAL transcript | `product-b_state.py` |
| `messages_fts USING fts5(content)` | Virtual table for full-text search | `product-b_state.py` |
| `parent_session_id` | Session-chain FK for fork/resume | `product-b_state.py` |

### EXEC zone (PTC)

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `execute_code(code, task_id, enabled_tools)` | The PTC entry point | `tools/code_execution_tool.py` | SECTION F |
| `generate_product-b_tools_module(enabled, transport)` | Stub Python module generator | `tools/code_execution_tool.py` | SECTION F |
| `SANDBOX_ALLOWED_TOOLS` (frozenset) | 7 allowed tools (verbatim) | `tools/code_execution_tool.py` | SECTION F |
| `DEFAULT_TIMEOUT = 300` | 5-minute wall-clock cap | `tools/code_execution_tool.py` | SECTION F |
| `DEFAULT_MAX_TOOL_CALLS = 50` | RPC call counter cap | `tools/code_execution_tool.py` | SECTION F |
| `MAX_STDOUT_BYTES = 50_000` | Stdout truncation | `tools/code_execution_tool.py` | SECTION F |
| `MAX_STDERR_BYTES = 10_000` | Stderr truncation | `tools/code_execution_tool.py` | SECTION F |
| `_rpc_server_loop(...)` | Parent's UDS accept-and-dispatch loop (NOT `_rpc_server_loop_uds`) | `tools/code_execution_tool.py:439` | SECTION F |
| `_rpc_poll_loop(...)` | Parent's file-poll variant for remote sandboxes (modal/daytona/singularity/vercel) | `tools/code_execution_tool.py:699` | (not in demo) |
| `_call()` (UDS variant in generated stub) | Child-side RPC call | `tools/code_execution_tool.py:344` | SECTION F |
| `_call()` (file-poll variant in generated stub) | Child-side RPC call for remote sandboxes | `tools/code_execution_tool.py:383` | (not in demo) |
| `BaseEnvironment` (ABC) | Verified interface — `__init__(cwd, timeout, env)`, `get_temp_dir()`, **only ONE `@abstractmethod`: `cleanup()`** (line 342); concrete defaults: `init_session()`, `_run_bash()`, `_wrap_command()`, `_wait_for_process()`, `_kill_process()`, `_before_execute()`, `execute()`, `stop()`. NO `upload_file`/`download_file` on base — file-transfer is per-backend via `tools/environments/file_sync.py`. | `tools/environments/base.py:288` | — |
| `ProcessHandle` (Protocol) + `_ThreadedProcessHandle` | poll/kill/wait + stdout/returncode | `base.py:187, 205` | — |
| `LocalEnvironment(BaseEnvironment)` | Example concrete impl: `__init__`, `get_temp_dir`, `_run_bash`, `_kill_process`, `_update_cwd`, `cleanup` | `tools/environments/local.py:374` | — |
| 7 backends | `local`, `docker`, `ssh`, `modal`, `daytona`, `singularity`, `vercel_sandbox` | `tools/environments/<name>.py` | — |
| Modal supporting modules | `managed_modal.py`, `modal_utils.py` (helpers around `modal.py`) | `tools/environments/` | — |
| File-sync helper (shared by remote backends) | `file_sync.py` | `tools/environments/` | — |
| `environments/agent_loop.py` | Reusable loop for sub-agents | top-level | — |

### SKILL zone

| Identifier | What it does | Where |
|---|---|---|
| `curator.load_state()` / `save_state()` | Persistent scheduler state in `.curator_state` JSON | `agent/curator.py` |
| `DEFAULT_INTERVAL_HOURS = 24 * 7` | 7 days between full sweeps (verbatim) | `agent/curator.py` |
| `DEFAULT_MIN_IDLE_HOURS = 2` | Min idle before curator fires | `agent/curator.py` |
| `DEFAULT_STALE_AFTER_DAYS = 30` | Stale threshold | `agent/curator.py` |
| `DEFAULT_ARCHIVE_AFTER_DAYS = 90` | Archive threshold | `agent/curator.py` |
| `scan_skill_commands()` | Full re-scan | `agent/skill_commands.py` |
| `get_skill_commands()` | Cache-aware lookup | `agent/skill_commands.py` |
| `build_skill_invocation_message(command, payload, dir)` | Skill → prompt block | `agent/skill_commands.py` |
| `parse_frontmatter(content) -> Tuple[Dict, str]` | YAML header parser | `agent/skill_utils.py` |
| `skill_matches_platform(frontmatter) -> bool` | Platform gating | `agent/skill_utils.py` |
| `preprocess_skill_content(body)` | Template subst + inline shell expansion | `agent/skill_preprocessing.py` |
| `PLATFORM_MAP` | OS name → sys.platform map | `agent/skill_utils.py` |

### MEMORY zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `MemoryProvider` | Abstract base (4 required + 7 optional hooks) | `agent/memory_provider.py` | SECTION C |
| `MemoryManager` | Routes 4 lifecycle hooks to providers | `agent/memory_manager.py` | SECTION C |
| `MemoryManager.add_provider(provider)` | Register a provider | `agent/memory_manager.py` | SECTION C |
| `MemoryManager.build_system_prompt()` | Boot-time | `agent/memory_manager.py` | SECTION C |
| `MemoryManager.prefetch_all(query, *, session_id="")` | PRE-TURN recall (sync). Verbatim — positional `query` (NOT `user_message`), keyword-only `session_id` | `agent/memory_manager.py:285` | SECTION C |
| `MemoryManager.sync_all(user_content, assistant_content, *, session_id="")` | POST-TURN write; keyword-only session_id | `agent/memory_manager.py:317` | SECTION C |
| `MemoryManager.queue_prefetch_all(query, *, session_id="")` | Async warm-up; same shape | `agent/memory_manager.py:304` | SECTION C |
| `StreamingContextScrubber.feed(delta) / flush()` | Strip `<memory-context>` from output stream | `agent/memory_manager.py` | SECTION C |
| `<memory-context>` / `</memory-context>` | Fence markers | `agent/memory_manager.py` | SECTION C |
| 8 plugins (per-plugin verified facts) | See below | `plugins/memory/<name>/` | (metadata table in SECTION C) |
| `byterover` — CLI wrapper | `_QUERY_TIMEOUT=10`s, `_CURATE_TIMEOUT=120`s, `_MIN_QUERY_LEN=10`, `_MIN_OUTPUT_LEN=20`. Shells out to `brv` binary via `_run_brv(args, timeout)`. 3 tool schemas: QUERY/CURATE/STATUS | `plugins/memory/byterover/__init__.py` | — |
| `hindsight` — knowledge graph | `_DEFAULT_API_URL="https://api.hindsight.vectorize.io"`, `_DEFAULT_LOCAL_URL="http://localhost:8888"`, `_DEFAULT_TIMEOUT=120`s, **recall budgets `_VALID_BUDGETS={"low","mid","high"}`**, `_MIN_CLIENT_VERSION="0.4.22"`, `_DEFAULT_IDLE_TIMEOUT=300`s | `plugins/memory/hindsight/__init__.py` | — |
| `holographic` — HRR algebraic | `HolographicMemoryProvider(MemoryProvider)` at line 115. Split files: `holographic.py`, `retrieval.py`, `store.py`. 2 tool schemas: `fact_store`, `fact_feedback`. `register(ctx)` entry at line 404. | `plugins/memory/holographic/` (multi-file) | — |
| `honcho` — dialectic + peer cards | `HonchoMemoryProvider(MemoryProvider)` at line 191. Files: `client.py`, `session.py`, `cli.py`. **5 tool schemas** in `ALL_TOOL_SCHEMAS` (PROFILE/SEARCH/REASONING/CONTEXT/CONCLUDE). 2 daemon threads: `honcho-prewarm-dialectic`, `honcho-prefetch-first` | `plugins/memory/honcho/` | — |
| `mem0` — circuit-breaker | `Mem0MemoryProvider(MemoryProvider)` at line 119. **Circuit breaker**: `_BREAKER_THRESHOLD=5`, `_BREAKER_COOLDOWN_SECS=120`. 3 tool schemas: PROFILE/SEARCH/CONCLUDE. 2 daemon threads: `mem0-prefetch`, `mem0-sync` | `plugins/memory/mem0/__init__.py` | — |
| `openviking` — filesystem URIs | `_VikingClient` HTTP class at line 88, `_DEFAULT_ENDPOINT="http://127.0.0.1:1933"`, `_TIMEOUT=30.0`. Accepted URI families: `http(s)://`, `git@`, `ssh://`, `git://`. 4 tool schemas: SEARCH/READ/BROWSE/REMEMBER. `_atexit_commit_sessions()` commits on shutdown | `plugins/memory/openviking/__init__.py` | — |
| `retaindb` — vector + relational | `_DEFAULT_BASE_URL="https://api.retaindb.com"`. Async queue with `_ASYNC_SHUTDOWN` sentinel. **8 tool schemas** (most of any plugin): PROFILE/SEARCH/CONTEXT/REMEMBER/FORGET/FILE_UPLOAD/FILE_LIST/FILE_READ | `plugins/memory/retaindb/__init__.py` | — |
| `supermemory` — hybrid LTM | `_CONVERSATIONS_URL="https://api.supermemory.ai/v4/conversations"`, `_DEFAULT_CONTAINER_TAG="product-b"`, `_DEFAULT_MAX_RECALL_RESULTS=10`, `_DEFAULT_PROFILE_FREQUENCY=50`, `_DEFAULT_CAPTURE_MODE="all"`, **`_DEFAULT_SEARCH_MODE="hybrid"` with `_VALID_SEARCH_MODES=("hybrid","memories","documents")`**, `_DEFAULT_API_TIMEOUT=5.0`s, **`_MAX_ENTITY_CONTEXT_LENGTH=1500` (entity context clamping)**, `_MIN_CAPTURE_LENGTH=10` | `plugins/memory/supermemory/__init__.py` | — |
| `session_search(query, max_sessions, max_chars)` | FTS5 + auxiliary summarize | `tools/session_search_tool.py` | — |
| `MAX_SESSION_CHARS = 100_000` | Truncation around matches | `tools/session_search_tool.py` | — |

### PERM zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `HARDLINE_PATTERNS` | 12 unconditional block patterns (verbatim) | `tools/approval.py` | SECTION B |
| `HARDLINE_PATTERNS_COMPILED` | Pre-compiled at module load | `tools/approval.py` | SECTION B |
| `DANGEROUS_PATTERNS` | 47+ overridable patterns | `tools/approval.py` | SECTION B (sample) |
| `detect_hardline_command(cmd)` | Returns (bool, key, desc) | `tools/approval.py:258` | SECTION B |
| `detect_dangerous_command(cmd)` | Returns (bool, key, desc) | `tools/approval.py:445` | SECTION B |
| `prompt_dangerous_approval(cmd, desc, timeout_seconds=None, allow_permanent=True, approval_callback=None)` | Returns 'once'/'session'/'always'/'deny' | `tools/approval.py:673` | SECTION B |
| `is_approved(session_key, pattern_key)` | True iff in session_approved or permanent_approved | `tools/approval.py:609` | SECTION B |
| `is_session_yolo_enabled(session_key)` | True iff session_key in _session_yolo | `tools/approval.py:596` | SECTION B |
| `approve_session(session_key, pattern_key)` | Add to _session_approved set | `tools/approval.py:558` | SECTION B |
| `approve_permanent(pattern_key)` | Add to _permanent_approved set | `tools/approval.py:623` | SECTION B |
| **NOTE — no `check_dangerous_command()`** | product-B's approval is DISPERSED: calling tool composes the primitives above | — | demo helper `evaluate_terminal_command()` |
| `_session_approved: Dict[str, set]` | Per-session approved pattern_keys | `tools/approval.py:465` | SECTION B |
| `_session_yolo: set` | Sessions with all-skip mode | `tools/approval.py` | SECTION B |
| `_permanent_approved: set` | Globally allowlisted patterns | `tools/approval.py` | SECTION B |
| `_current_session_key: contextvars.ContextVar` | Per-thread/async session key | `tools/approval.py` | SECTION B |
| `_smart_approve(command, description) -> str` | Auxiliary LLM verdict — returns LOWERCASE `'approve'`/`'deny'`/`'escalate'` (prompt asks for uppercase but function returns lowercase). Uses `auxiliary_client.call_llm(task="approval", temperature=0)` | `tools/approval.py:841` | (referenced) |
| `register_gateway_notify(key, cb)` | Gateway WebSocket integration | `tools/approval.py` | — |

### SUB-AGENT zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `delegate_task(goal, context, toolsets, tasks, role, parent_agent)` | The tool | `tools/delegate_tool.py` | SECTION E |
| `DELEGATE_BLOCKED_TOOLS: frozenset` | 5 tools stripped from children (verbatim) | `tools/delegate_tool.py` | SECTION E |
| `DEFAULT_MAX_ITERATIONS = 50` | Per-child iteration cap | `tools/delegate_tool.py` | SECTION E |
| `DEFAULT_CHILD_TIMEOUT = 600` | Per-child wall-clock cap | `tools/delegate_tool.py` | SECTION E |
| `_DEFAULT_MAX_CONCURRENT_CHILDREN = 3` | Parallel cap | `tools/delegate_tool.py` | SECTION E |
| `MAX_DEPTH = 1` | Default flat (orchestrator unlocks 2-3) | `tools/delegate_tool.py` | SECTION E |
| `DelegateEvent` (enum) | **7 event types** for TUI observability (TASK_SPAWNED/PROGRESS/COMPLETED/FAILED/THINKING/TOOL_STARTED/TOOL_COMPLETED) | `tools/delegate_tool.py:527` | SECTION E |
| `_LEGACY_EVENT_MAP: Dict[str, DelegateEvent]` | Normalises legacy event strings (`_thinking`, `tool.started`, etc.) to enum | `tools/delegate_tool.py` | SECTION E |
| `_normalize_role(r)` | 'leaf' or 'orchestrator' | `tools/delegate_tool.py` | SECTION E |
| `_strip_blocked_tools(toolsets)` | Filter | `tools/delegate_tool.py` | SECTION E |
| `_build_child_system_prompt(...)` | Focused prompt builder | `tools/delegate_tool.py` | SECTION E |
| `list_active_subagents()` / `interrupt_subagent(task_id)` | Live control | `tools/delegate_tool.py` | — |

### COMPACT zone

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `ContextCompressor` | Live per-turn compactor | `agent/context_compressor.py` | SECTION D |
| `TrajectoryCompressor` | Batch (training data) compactor | `trajectory_compressor.py` | — |
| `SUMMARY_PREFIX` | Verbatim ~13-sentence string prepended to summary | `agent/context_compressor.py:37` | SECTION D |
| `LEGACY_SUMMARY_PREFIX = "[CONTEXT SUMMARY]:"` | Backward-compat marker | `agent/context_compressor.py` | SECTION D |
| `_MIN_SUMMARY_TOKENS = 2000` | Floor | `agent/context_compressor.py:55` | SECTION D |
| `_SUMMARY_RATIO = 0.20` | Target compression ratio | `agent/context_compressor.py:57` | SECTION D |
| `_SUMMARY_TOKENS_CEILING = 12_000` | Ceiling | `agent/context_compressor.py:59` | SECTION D |
| `_CHARS_PER_TOKEN = 4` | Estimator | `agent/context_compressor.py:65` | SECTION D |
| `_IMAGE_TOKEN_ESTIMATE = 1600` | Multimodal flat-estimate | `agent/context_compressor.py:71` | SECTION D |
| `_SUMMARY_FAILURE_COOLDOWN_SECONDS = 600` | 10-min cooldown after failed summarization | `agent/context_compressor.py:76` | SECTION D |
| **`protect_first_n: int = 3`** | NUMERIC head protection (NOT role-specific booleans as earlier drafts said) | `agent/context_compressor.py:408` | SECTION D |
| **`protect_last_n: int = 20`** | NUMERIC tail protection — **20 messages, NOT 4 turns** | `agent/context_compressor.py:409` | SECTION D |
| `ContextCompressor(ContextEngine)` | Extends `ContextEngine` ABC | `agent/context_compressor.py:346` | SECTION D |
| `ContextCompressor.compress(messages, current_tokens, focus_topic, summarizer)` | The work | `agent/context_compressor.py` | SECTION D |
| `_summarize_tool_result(name, args, content)` | Tool result → 1-liner | `agent/context_compressor.py` | SECTION D |
| `_content_length_for_budget(content)` | Multimodal char count | `agent/context_compressor.py` | SECTION D |
| `summarize_manual_compression(...)` | User-facing /compress feedback | `agent/manual_compression_feedback.py` | — |

### TEXT zone

| Identifier | What it does | Where |
|---|---|---|
| `ShellFileOperations.search(pattern, path, target, file_glob, limit, offset, output_mode, context)` | Unified glob/grep | `tools/file_operations.py` |
| `SearchResult` (dataclass) | Returns matches, files, counts, truncated | `tools/file_operations.py` |
| `SearchMatch` (dataclass) | Per-match record (path, line_number, content, mtime) | `tools/file_operations.py` |
| `_search_content` / `_search_files_rg` / `_search_files` | Internal dispatchers (ripgrep + find fallback) | `tools/file_operations.py` |
| `browser_navigate(url, task_id)` | Per-task browser session navigate | `tools/browser_tool.py` |
| `browser_snapshot(full, task_id, user_task)` | Accessibility tree (NOT screenshot) | `tools/browser_tool.py` |
| `SNAPSHOT_SUMMARIZE_THRESHOLD = 8000` | Auto-summarize trigger | `tools/browser_tool.py` |
| `browser_click(ref, task_id)` / `browser_type(ref, text, task_id)` / `browser_back(task_id)` | Per-element interactions | `tools/browser_tool.py` |
| `web_search_tool(query, limit)` | Returns ranked URL list | `tools/web_tools.py` |
| `web_extract_tool(urls, format, instruction)` | Extract page content + auxiliary summarize | `tools/web_tools.py` |
| `_get_backend()` | Picks one of 7 providers | `tools/web_tools.py` |
| `_FirecrawlProxy` | Lazy SDK loading (~200ms saved cold start) | `tools/web_tools.py` |
| `session_search(query, max_sessions, max_chars)` | FTS5 + auxiliary summarize | `tools/session_search_tool.py` |
| `MAX_SESSION_CHARS = 100_000` / `MAX_SUMMARY_TOKENS = 10_000` | Caps | `tools/session_search_tool.py` |

### SURFACE zone *(Phase 3 gap-fill)*

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `class Platform(Enum)` (21 entries) | Channel enum (LOCAL, TELEGRAM, DISCORD, WHATSAPP, SLACK, SIGNAL, MATTERMOST, MATRIX, HOMEASSISTANT, EMAIL, SMS, DINGTALK, API_SERVER, WEBHOOK, MSGRAPH_WEBHOOK, FEISHU, WECOM, WECOM_CALLBACK, WEIXIN, BLUEBUBBLES, QQBOT, YUANBAO) | `gateway/config.py:82-111` | SECTION K |
| `class PlatformConfig` | Per-channel config | `gateway/config.py:263` | (referenced) |
| `class BasePlatformAdapter(ABC)` | Channel ABC | `gateway/platforms/base.py:1259` | SECTION K |
| `@abstractmethod async def connect / disconnect / send / get_chat_info` | 4 abstract methods | `base.py:1532, 1541, 1546, 3463` | SECTION K |
| 13 concrete-default media methods (`send_typing, send_voice, send_image, send_animation, send_video, send_document, send_multiple_images, send_draft`) | Base class defaults | `base.py:1349, 1766, 1775, 1783, 1840, 1859, 1930, 1965, 1985` | (referenced) |
| `class DiscordAdapter(BasePlatformAdapter)` | Discord channel | `gateway/platforms/discord.py:532` (+ `on_message` L715, `send` L1366) | (referenced) |
| `class SlackAdapter(BasePlatformAdapter)` (interactive approvals) | Slack channel | `gateway/platforms/slack.py:268` (+ `send_exec_approval` L2201) | (referenced) |
| `class TelegramAdapter(BasePlatformAdapter)` (Bot API 9.5 send_draft) | Telegram | `gateway/platforms/telegram.py:316` (+ `send_draft` L1972) | (referenced) |
| **4 plugin-channels** (teams, line, irc, google_chat) | Plugin platforms | `plugins/platforms/{teams,line,irc,google_chat}/adapter.py` | (referenced) |
| `class PlatformEntry` (plugin registration record) | Plugin registry | `gateway/platform_registry.py:39` | (referenced) |
| `PluginContext.register_platform(...)` | Plugin SDK | `product-b_cli/plugins.py:547` | (referenced) |
| `class APIServerAdapter(BasePlatformAdapter)` (OpenAI-compat) | HTTP API server | `gateway/platforms/api_server.py:578` (connect 3334, disconnect 3437, send 3449) | SECTION K |
| `DEFAULT_HOST = "127.0.0.1"` / `DEFAULT_PORT = 8642` / `MAX_REQUEST_BYTES = 10_000_000` | API server constants | `api_server.py:57-60` | SECTION K |
| `class ResponseStore` (`MAX_STORED_RESPONSES = 100`) | OpenAI Responses-API store | `api_server.py:291` | (referenced) |
| `class _IdempotencyCache` | Idempotency | `api_server.py:482` | (referenced) |
| `POST /v1/chat/completions` / `POST /v1/responses` / `POST /v1/runs` (returns run_id 202) / `GET /v1/runs/{id}/events` (SSE) / `POST /v1/runs/{id}/approval` / `POST /v1/runs/{id}/stop` / `GET /v1/models` / `GET /v1/capabilities` / `GET /health` / `GET /health/detailed` | Endpoint inventory | `api_server.py:4-21` docstring | SECTION K |
| `X-product-B-Session-Id` / `X-product-B-Session-Key` headers | Session continuity | `api_server.py:4-21` | (referenced) |
| `class product-BACPAgent(acp.Agent)` (IDE integration) | ACP server | `acp_adapter/server.py:445` (initialize 737, authenticate 780, new_session 930, prompt 1071) | SECTION K |
| ACP registry manifest | Distribution metadata | `acp_registry/agent.json:1-12` | (referenced) |
| `product-b`, `product-b chat`, `product-b gateway`, `product-b setup`, `product-b doctor`, `product-b honcho`, `product-b acp`, `product-b product-a migrate` (etc.) | CLI subcommands | `product-b_cli/main.py:1-44` (~80 modules total) | SECTION K |
| TTS providers list (10) | Edge default, ElevenLabs, OpenAI, MiniMax, Mistral Voxtral, Gemini, xAI Grok, **NeuTTS local**, **KittenTTS local 25MB**, **Piper local VITS 44 langs** | `tools/tts_tool.py:1-16` | (referenced) |
| TTS custom command providers | `tts.providers.<name>: type: command` | `tools/tts_tool.py:17-23` | (referenced) |
| STT providers list (5) | `local` (faster-whisper default ~150MB auto-DL), `groq`, `openai`, `mistral` Voxtral, `xai` Grok | `tools/transcription_tools.py:1-26` | (referenced) |
| Push-to-talk CLI | sounddevice + lazy import + headless fallback | `tools/voice_mode.py:1-49` | (referenced) |
| `_auto_tts_default` / `_auto_tts_enabled_chats` / `_auto_tts_disabled_chats` (per-chat TTS via `/voice on\|tts\|off`) | Per-chat auto-TTS | `gateway/platforms/base.py:1302-1316` + `_should_auto_tts_for_chat` L1392-1405 | (referenced) |
| `class ImageGenProvider(abc.ABC)` (single abstract `generate()`) | Image-gen ABC | `agent/image_gen_provider.py:51, 131` | (referenced) |
| `VALID_ASPECT_RATIOS = ("landscape", "square", "portrait")` | Image constraints | `agent/image_gen_provider.py:42` | (referenced) |
| `register_provider(provider)` (thread-safe global) | Image-gen registry | `agent/image_gen_registry.py:36` | (referenced) |
| 3 image-gen plugins: openai, openai-codex, xai + fal legacy | Built-in | `plugins/image_gen/{openai,openai-codex,xai}/` + `tools/image_generation_tool.py:370` | (referenced) |
| `class _ManagedFalSyncClient` | fal.ai client wrapper | `tools/image_generation_tool.py:370` | (referenced) |
| `image_routing.py` 2 modes (`native` OpenAI image_url parts vs `text` vision_analyze precall) | Vision input routing | `agent/image_routing.py:46` — `_VALID_MODES = frozenset({"auto", "native", "text"})` | (referenced) |
| `browser_navigate / browser_snapshot / browser_click / browser_type / browser_scroll / browser_back / browser_press / browser_console / browser_get_images / browser_vision` (a11y-tree first) | Browser dispatch | `tools/browser_tool.py:2144, 2344, 2413, 2450, 2490, 2539, 2571, 2606, 2841, 2902` | (referenced) |
| `browser_cdp(...)` (CDP escape hatch) | Raw Chrome DevTools | `tools/browser_cdp_tool.py:295` | (referenced) |
| `class CloudBrowserProvider(ABC)` | Cloud browser providers ABC | `tools/browser_providers/base.py:7` (3 concrete: browserbase, browser_use, firecrawl) | (referenced) |
| Camofox stealth browser | Stealth mode | `tools/browser_camofox.py` + `tools/browser_camofox_state.py` | — |
| MCP server (10 tools: `conversations_list, conversation_get, messages_read, attachments_fetch, events_poll, events_wait, messages_send, permissions_list_open, permissions_respond, channels_list`) | FastMCP server | `mcp_serve.py:2-13, 450, 472-734` | (referenced) |
| `class QueueEvent` / `class EventBridge` | MCP event bridge | `mcp_serve.py:196, 204` | (referenced) |
| MCP client (3 transports: stdio, HTTP/StreamableHTTP, SSE) | External MCP integration | `tools/mcp_tool.py:1-48` (reads `mcp_servers:` block in `~/.product-b/config.yaml`) | (referenced) |
| Web dashboard (Vite + React 19, 12 pages: Analytics, Chat, Config, Cron, Docs, Env, Logs, Models, Plugins, Profiles, Sessions, Skills) | Web UI | `web/package.json:15-30`, `web/src/pages/` | (referenced) |
| ink/React TUI dashboard | Terminal UI | `ui-tui/package.json:18-26`, `ui-tui/src/`, `tui_gateway/` | (referenced) |
| Dockerfile (Debian 13.4 + uv + Playwright Chromium baked, non-root UID 10000) | Container | `Dockerfile:1-3, 17, 21, 53` | (referenced) |
| docker-compose.yml (host networking) | Compose | `docker-compose.yml:24-50` | (referenced) |
| Nix flake (3 systems: x86_64-linux, aarch64-linux, aarch64-darwin) | Nix package | `flake.nix:1-45`, `nix/packages.nix:7-25` | (referenced) |
| Homebrew formula | Mac/Linux install | `packaging/homebrew/product-b.rb:1-30` | (referenced) |
| `install.sh` / `install.ps1` (Windows bundles MinGit ~45MB) | One-liner installers | `README.md:36-37, 45-47` | (referenced) |
| Windows UTF-8 bootstrap (idempotent) | Cross-platform stdio fix | `product-b_bootstrap.py:1-44` | (referenced) |
| `cli-config.yaml.example` (17 provider IDs documented) | Onboarding config | `cli-config.yaml.example:8-65` | (referenced) |
| `product-b product-a migrate [--dry-run \| --preset user-data \| --overwrite]` (imports config from product-A) | Cross-product migration | `README.md:126-148` | (referenced) |
| `SNAPSHOT_SUMMARIZE_THRESHOLD = 8000` | Browser snapshot auto-summarize trigger | `tools/browser_tool.py` | (referenced) |

### OBSERVABILITY zone *(Phase 3 gap-fill)*

| Identifier | What it does | Where (real) | Where (demo) |
|---|---|---|---|
| `apply_anthropic_cache_control(api_messages, cache_ttl="5m")` (system_and_3 strategy) | system + last 3 messages, single TTL | `agent/prompt_caching.py:59` | SECTION L |
| ⭐ `apply_anthropic_cache_control_long_lived(api_messages, long_lived_ttl="1h", rolling_ttl="5m")` (prefix_and_2 strategy) | 4 cache_control breakpoints, dual TTL | `prompt_caching.py:133` | SECTION L |
| `mark_tools_for_long_lived_cache(tools, long_lived_ttl="1h")` | Tools-array caching | `prompt_caching.py:178` | (referenced) |
| `_apply_cache_marker(msg, cache_marker, native_anthropic=False)` | Marker apply helper | `prompt_caching.py:25` | (referenced) |
| `_build_marker(ttl)` → `{"type": "ephemeral", "ttl": "1h"}` | Marker builder | `prompt_caching.py:51` | (referenced) |
| Anthropic adapter forwards markers (OpenAI-format → native) | Defensive strip from thinking blocks | `agent/anthropic_adapter.py:1307-1313, 1745, 1821-1825` | (referenced) |
| `build_or_headers(or_config)` + `X-OpenRouter-Cache: true` + `X-OpenRouter-Cache-TTL: N` | OpenRouter HTTP-layer cache (default 300s) | `agent/auxiliary_client.py:321-370` (env `PRODUCT_B_OPENROUTER_CACHE`) | (referenced) |
| Tool result spill cache (`MAX_TURN_BUDGET_CHARS=200K`, `/tmp/product-b-results`) | Three-level defence: per-tool cap + per-result persistence + per-turn budget | `tools/tool_result_storage.py:1-39` | (referenced) |
| `_CHECK_FN_TTL_SECONDS = 30.0` (check_fn TTL cache) | Tool-availability probes | `tools/registry.py:109-134` | (referenced) |
| Langfuse plugin metadata + 6 hooks | Hooks: `pre/post_api_request, pre/post_llm_call, pre/post_tool_call` | `plugins/observability/langfuse/plugin.yaml:1-15` | (referenced) |
| `TraceState` dataclass (trace_id, root_ctx, root_span, generations, tools, turn_tool_calls) | Per-task trace state | `plugins/observability/langfuse/__init__.py:43-51` | SECTION L |
| `_STATE_LOCK = threading.Lock()` + `_TRACE_STATE: Dict[str, TraceState]` | Thread-safe per-task state | `langfuse/__init__.py:55-56` | (referenced) |
| `_get_langfuse() → Optional[Langfuse]` (fail-open lazy SDK + `_INIT_FAILED` sentinel) | Lazy initialization | `langfuse/__init__.py:89` | (referenced) |
| `_usage_and_cost(response, *, provider, api_mode, model, base_url)` | Per-token-type cost (5 categories) | `langfuse/__init__.py:383` | (referenced) |
| `client.create_trace_id(seed=f"{session_id}::{task_id}")` | Deterministic trace_id (replays land on same trace) | `langfuse/__init__.py:447` | SECTION L |
| `_start_root_trace(task_key, ...)` (root: "product-B turn") | Per-turn root observation | `langfuse/__init__.py:445` | (referenced) |
| `on_pre_llm_request(...)` + `on_post_llm_call(...)` | Per-LLM-call generation | `langfuse/__init__.py:629, 691` | (referenced) |
| `on_pre_tool_call(...)` + `on_post_tool_call(...)` (span: `Tool: {tool_name}`) | Per-tool-call span | `langfuse/__init__.py:811, 834` | (referenced) |
| `register(ctx)` — registers all 6 hooks | Hook installer | `langfuse/__init__.py:865-874` | (referenced) |
| `setup_logging()` → `agent.log, errors.log, gateway.log` rotating | Centralized logging | `product-b_logging.py:1-23` | (referenced) |
| `set_session_context(session_id)` / `clear_session_context()` (thread-local) | Session correlation | `product-b_logging.py:72-83, 90` | (referenced) |
| `RedactingFormatter` + `_ComponentFilter` (`COMPONENT_PREFIXES = {gateway, agent, tools, cli, cron}`) | Secret redaction + component routing | `product-b_logging.py:126, 143-149, 298` | (referenced) |
| `tests/` 1000+ pytest unit/integration | No quality eval, only contract tests | `tests/` | (referenced) |
| `scripts/benchmark_browser_eval.py` | Performance benchmark only, NOT quality eval | `scripts/` | — |
| **NO `qa/, eval/, evals/` dir; NO golden snapshots; NO rouge/bleu/llm-judge** | Eval gap | — | — |
| `CanonicalUsage` frozen dataclass (`input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, reasoning_tokens, request_count, raw_usage`) | 5-category usage normalization | `agent/usage_pricing.py:30-37` | SECTION L |
| `BillingRoute(provider, model, base_url, billing_mode)` | Pricing context | `usage_pricing.py:49` | (referenced) |
| `PricingEntry` (per-token-type cost + `source: CostSource`) | Per-model entry | `usage_pricing.py:57` | (referenced) |
| `CostSource` literal: `provider_cost_api \| provider_generation_api \| provider_models_api \| official_docs_snapshot \| user_override \| custom_contract \| none` | 7 source types | `usage_pricing.py` | (referenced) |
| `CostResult(amount_usd, status, source, label, fetched_at, pricing_version, notes)` | Cost output | `usage_pricing.py:70` | SECTION L |
| `normalize_usage(response_usage, *, provider, api_mode)` (Anthropic/Codex/OpenAI + proxy-aware) | Multi-shape normalizer | `usage_pricing.py:672` | (referenced) |
| `estimate_usage_cost(model_name, usage, *, provider, base_url, api_key)` | Cost estimator | `usage_pricing.py:745` | (referenced) |
| `has_known_pricing(...)` | Pricing presence check | `usage_pricing.py:824` | (referenced) |
| ⭐ `_OFFICIAL_DOCS_PRICING` table | claude-opus-4-7 = input $5/M, output $25/M, cache_read $0.50/M, cache_write $6.25/M | `usage_pricing.py:85-100` | SECTION L |
| `AccountUsageWindow(label, used_percent, reset_at, detail)` | Plan-window record | `agent/account_usage.py:19` | (referenced) |
| `AccountUsageSnapshot(provider, source, fetched_at, plan, windows, details, unavailable_reason)` | Plan-level snapshot | `account_usage.py:27` | SECTION L |
| `fetch_account_usage(provider, *, base_url, api_key)` (Codex/Anthropic/OpenRouter) | Plan-limit retrieval | `account_usage.py:308` | (referenced) |
| `_fetch_codex_account_usage / _fetch_anthropic_account_usage / _fetch_openrouter_account_usage` | Provider extractors | `account_usage.py:127, 175, 236` | (referenced) |
| `render_account_usage_lines(snapshot, *, markdown=False)` | UI rendering | `account_usage.py:88` | (referenced) |
| `InsightsEngine.generate(days=30, source=None)` | 30-day SQLite rollup: tokens, cost, tool usage, activity, model/platform breakdowns | `agent/insights.py:93, 111` | SECTION L |
| `RateLimitBucket(limit, remaining, reset_seconds, captured_at)` (derived `used, usage_pct, remaining_seconds_now`) | Per-window bucket | `agent/rate_limit_tracker.py:31` | (referenced) |
| `RateLimitState(requests_min, requests_hour, tokens_min, tokens_hour, captured_at, provider)` | Rate limit state | `rate_limit_tracker.py:57` | (referenced) |
| `parse_rate_limit_headers(...)` (12-header schema) | Header parser | `rate_limit_tracker.py:92` | (referenced) |
| ⭐ `FailoverReason` 18-value enum (`auth, auth_permanent, billing, rate_limit, overloaded, server_error, timeout, context_overflow, payload_too_large, image_too_large, model_not_found, provider_policy_blocked, format_error, thinking_signature, long_context_tier, oauth_long_context_beta_forbidden, llama_cpp_grammar_pattern, unknown`) | Error taxonomy | `agent/error_classifier.py:24` | SECTION L |
| ⭐ `ClassifiedError(reason, status_code, provider, model, message, error_context, retryable, should_compress, should_rotate_credential, should_fallback)` | Action-hint result | `error_classifier.py:67-87` | SECTION L |
| `classify_api_error(error, *, provider, model, approx_tokens, context_length, num_messages)` | 8-step priority pipeline | `error_classifier.py:345` | SECTION L |
| `_classify_by_status / _classify_402 / _classify_400 / _classify_by_error_code / _classify_by_message` | Pipeline stages | `error_classifier.py:589, 712, 741, 838, 878` | (referenced) |
| `_BILLING_PATTERNS` + `_RATE_LIMIT_PATTERNS` | Provider-quirk lists | `error_classifier.py:93-105, 108-120` | (referenced) |
| ⭐ MCP server breaker (3-state machine: closed → open → half-open) | `_CIRCUIT_BREAKER_THRESHOLD=3, _CIRCUIT_BREAKER_COOLDOWN_SEC=60.0` | `tools/mcp_tool.py:1607-1629` | SECTION L |
| `_bump_server_error` / `_reset_server_error` | Breaker state mutation | `mcp_tool.py:1632, 1645` | (referenced) |
| Call-site guard (prevents 90-iteration burn loop) | Returns "server unreachable" during open state | `mcp_tool.py:2176-2180` | (referenced) |
| `test_mcp_circuit_breaker.py` (dedicated tests: half-opens, reopens-on-probe, cleared-on-reconnect) | Breaker test coverage | `tests/tools/` | (referenced) |
| mem0 breaker (`_BREAKER_THRESHOLD=5, _BREAKER_COOLDOWN_SECS=120`) | Memory plugin breaker | `plugins/memory/mem0/__init__.py:31-33, 180-201` | (referenced) |
| `nous_rate_guard.py` (cross-session shared file) | Prevents retry amplification across CLI/gateway/cron | `agent/nous_rate_guard.py:1-11` | SECTION L |
| `jittered_backoff(attempt, *, base_delay=5.0, max_delay=120.0, jitter_ratio=0.5)` | Decorrelated jitter | `agent/retry_utils.py:19` | (referenced) |
| `StreamingContextScrubber` (state machine across stream deltas; fail-closed on unterminated) | Memory-context fence scrubber | `agent/memory_manager.py:62, 151-153` | SECTION L |
| `_OPEN_TAG = "<memory-context>"` / `_CLOSE_TAG = "</memory-context>"` | Tag constants | `memory_manager.py:88, 89` | (referenced) |
| `feed(text)` / `flush()` / `_max_partial_suffix(buf, tag)` | Streaming methods | `memory_manager.py:99, 142, 158` | (referenced) |
| `_FENCE_TAG_RE` / `_INTERNAL_CONTEXT_RE` / `_INTERNAL_NOTE_RE` | Case-insensitive fence regex + system note stripper | `memory_manager.py:43-51` | (referenced) |
| `sanitize_context(text)` / `build_memory_context_block(raw_context)` | One-shot sanitizer + wrapper | `memory_manager.py:54, 173` | (referenced) |
| `StreamingThinkScrubber` (`<think>` tag scrubber, same pattern) | Per-delta think-tag handling | `agent/think_scrubber.py:1-26` | (referenced) |
| `mask_secret(...)` / `redact_sensitive_text(text, *, force=False, code_file=False)` | Secret redaction | `agent/redact.py:190, 311` | (referenced) |
| `_REDACT_ENABLED = os.getenv("PRODUCT_B_REDACT_SECRETS", "true")` (default on) | Master toggle | `redact.py:67` | (referenced) |
| `_SENSITIVE_QUERY_PARAMS` / `_SENSITIVE_BODY_KEYS` frozensets | Exact-match sensitive keys | `redact.py:19-36, 41-65` | (referenced) |
| `RedactingFormatter` (installed on every rotating handler) | Per-log redaction | `redact.py:395` | (referenced) |
| `check_command_security(command)` (tirith pre-exec scanner) | Detects homograph URLs, pipe-to-interpreter, terminal injection; SHA-256 + cosign verification | `tools/tirith_security.py:1-21, 615` | SECTION L |
| `GET /health` (returns `{"status": "ok", "platform": "product-b"}`) | Simple health | `gateway/platforms/api_server.py:865-867` | SECTION L |
| `GET /health/detailed` (returns gateway_state, platforms, active_agents, exit_reason, updated_at, pid) | Rich health | `api_server.py:869-888` | SECTION L |
| `GET /v1/health` (OpenAI-compat alias) | OpenAI-compat health | `api_server.py:3344-3346` | (referenced) |
| Per-platform `/health` on 6 channels (webhook, bluebubbles, sms, wecom_callback, msgraph_webhook, whatsapp) | Platform health | `gateway/platforms/{webhook,bluebubbles,sms,wecom_callback,msgraph_webhook,whatsapp}.py` | (referenced) |
| `write_runtime_status / read_runtime_status / is_gateway_runtime_lock_active` | Runtime status file | `gateway/status.py:492-534, 537-539, 444` | (referenced) |
| `trajectory_compressor.py` (out-of-process, `Kimi-K2-Thinking` tokenizer, `target_max_tokens=15250, protect_last_n_turns=4`) | ML-grade compressor | `trajectory_compressor.py:1-31, 83, 332, 1290` | SECTION L |
| `TrajectoryMetrics` / `AggregateMetrics` | Per-run + aggregate metrics | `trajectory_compressor.py:183, 228` | (referenced) |
| `save_trajectory(trajectory, model, ...)` / `convert_scratchpad_to_think` / `has_incomplete_scratchpad` | Runtime trajectory persistence | `agent/trajectory.py:30, 16, 23` | (referenced) |
| **NO OTel, NO Prometheus, NO Datadog, NO Honeycomb** | Telemetry gap (only Langfuse opt-in) | — | — |
| **NO dedicated audit log** | Relies on log rotation + Langfuse + SQLite | — | — |
| **NO A/B framework** | Only env-var boolean flags | — | — |
| **NO per-tool QPS limit** | Tools gated by approval + tirith only | — | — |
| **NO application-level LLM-response cache** | Only Anthropic prompt-cache + OpenRouter HTTP cache | — | — |

---

## 4. Common modifications — recipe per task

| What you want to change | Which zone | Where | Recipe |
|---|---|---|---|
| Add a new tool | TOOL | `tools/<your-tool>.py` | Define handler; call `registry.register(...)` at module top; ensure module imported by `tools/__init__.py` |
| Add new HARDLINE pattern | PERM | `tools/approval.py` | Append tuple to `HARDLINE_PATTERNS`; `HARDLINE_PATTERNS_COMPILED` auto-rebuilds at module load |
| Add new DANGEROUS pattern | PERM | `tools/approval.py` | Append to `DANGEROUS_PATTERNS`; users can approve once/session/always |
| Change compaction threshold | COMPACT | Per-tenant config | Override `0.75` → 0.70 if you want compaction to fire earlier |
| Add a new memory provider | MEMORY | `plugins/memory/<your-plugin>/` | Subclass `MemoryProvider`; implement 4 required hooks; register via `MemoryManager.add_provider` at boot |
| Add a new sandbox backend | EXEC | `tools/environments/<your-backend>.py` | Implement `BaseEnvironment` abstract; transport choice (UDS for local, file-poll for remote) |
| Add a new skill | SKILL | `skills/<category>/<your-skill>/SKILL.md` | YAML frontmatter (name + description required) + Markdown body; curator picks it up on next idle tick |
| Add a new @-reference type | CTX | `agent/context_references.py` | Add regex to parser; implement `_expand_<type>_reference`; add to dispatch table |
| Add a new web backend | TEXT | `tools/web_tools.py` | Implement backend in `_get_backend()` dispatch; add env-var check; lazy-load SDK if heavy |
| Change MAX_DEPTH for sub-agents | SUB-AGENT | `tools/delegate_tool.py` | Bump `MAX_DEPTH = 1` to your preferred max; test with role='orchestrator' explicit cases |
| Add a new file-safety deny path | CTX/ART | `agent/file_safety.py` | Add to deny list; both read (`is_reference_path_allowed`) and write (`is_write_denied`) check it |
| Add a new provider adapter | TOOL | `agent/<provider>_adapter.py` | Implement request shaping + response parsing; register in `model_tools.py` dispatch |
| Pin a skill (exempt from auto-archive) | SKILL | Config flag | Curator's `is_pinned(skill_name)` check returns True for pinned skills |
| Enable yolo mode for a session | PERM | Runtime call | `enable_session_yolo(session_key)` — careful, HARDLINE still applies |

---

## 5. Debugging cheat sheet — symptom → which zone

| Symptom | Likely zone | First thing to check |
|---|---|---|
| Tool not visible to LLM | TOOL | `check_fn` returning False; check_fn TTL cache stale → call `invalidate_check_fn_cache()` |
| LLM ignores a tool that exists | TOOL + CTX | Tool description quality; SOUL.md / TOOLS.md guidance |
| Sessions break after ~30 turns | COMPACT | `last_prompt_tokens` not being updated from response; threshold never fires |
| Agent does `rm -rf` something | PERM | Yolo mode active? Or pattern not in HARDLINE / DANGEROUS? |
| Agent re-reads the same PDF every turn | TEXT/ART | No extraction cache yet — borrow product-A's pattern |
| Workspace files vanish between turns | ART | Sandbox is ephemeral; check `BaseEnvironment` backend choice |
| Cross-session "you keep forgetting me" | MEMORY | No active external plugin; only builtin SQLite is on. Add mem0 or supermemory |
| User asks "find me X across PDFs" → nothing | TEXT | document_extract not chained after Glob; or running search on raw PDF bytes |
| Context blows up after one big git diff | COMPACT/TOOL | Per-tool `max_result_size_chars` not set on the responsible handler |
| Sub-agents not running in parallel | SUB-AGENT | ThreadPoolExecutor `max_workers` capped at `_DEFAULT_MAX_CONCURRENT_CHILDREN = 3` |
| StreamingScrubber lets memory leak | MEMORY | Fence open spans 2 deltas? Check buffer-tail logic |
| Skill not showing in /skills list | SKILL | Platform gate (`platforms: [...]` mismatch)? Curator archived it after 90 days? |
| Concurrent sessions interfere | PERM | `contextvars` propagation broken? Async boundary missed? |
| Browser snapshot too big | TEXT | `SNAPSHOT_SUMMARIZE_THRESHOLD = 8000` not triggering? Provide `user_task` for focused extraction |
| @file:path inlines refused | CTX | Hit 50% hard_limit? Or `file_safety.is_reference_path_allowed` returning False? |
| MCP tool disappears mid-session | TOOL | MCP server sent `notifications/tools/list_changed`; cache by generation counter |

---

## 6. Glossary — Terms in plain English

> Plain-English definition + everyday analogy + concrete project example. Search by Ctrl-F.

### **ToolEntry**
- **Plain English:** The full description of one tool — name, what it takes, what it returns, who runs it, when it's available.
- **Like:** An employee's badge with name, role, department, schedule, and security clearance.
- **In this project:** A frozen Python class with `__slots__`; 11 fields including `name`, `toolset`, `schema`, `handler`, `check_fn`, `max_result_size_chars`. Created by `registry.register()` at module-import time.

### **ToolRegistry**
- **Plain English:** The central index of every tool product-B knows about.
- **Like:** The phone directory of all the company's departments — looks up "terminal" or "search_files" and tells you who to call.
- **In this project:** Thread-safe singleton at `tools/registry.py`; mutations bump a generation counter so external callers can memoize safely.

### **check_fn TTL cache (30s)**
- **Plain English:** Each tool can have a "is this still available?" check (Docker daemon running? Modal SDK installed?). We remember the answer for 30 seconds to avoid re-checking on every turn.
- **Like:** "Is the printer working?" — checked once at 9:00 am, the answer is good until 9:00:30.
- **In this project:** `_CHECK_FN_TTL_SECONDS = 30.0`. Call `invalidate_check_fn_cache()` after config changes.

### **Shadowing rejection**
- **Plain English:** A plugin cannot overwrite a built-in tool by registering a tool with the same name. Same-toolset re-registration is allowed.
- **Like:** "An intern cannot impersonate the CEO" — but two interns from the same team can swap a job number.
- **In this project:** Prevents plugin attacks on safety-gated built-ins like `terminal`.

### **@-reference**
- **Plain English:** A shorthand the user can type to inline file contents, folder listings, git diffs, or URLs without copy-pasting.
- **Like:** "See attachment A" in a letter — the post office auto-includes the attachment.
- **In this project:** Six types: `@file:path:10-20`, `@folder:src/`, `@git:HEAD~3`, `@diff`, `@staged`, `@url:https://...`. Parsed by `parse_context_references()`.

### **Hard limit (50%) / Soft limit (25%)**
- **Plain English:** The fraction of the context window any single @-injection is allowed to consume. Over 50% = rejected. Over 25% = warning.
- **Like:** Carry-on bag size limit (hard) vs "you're close to the data plan limit" warning (soft).
- **In this project:** Verbatim in `agent/context_references.py`. Without them, pasting `@folder:src/` on a huge repo could blow the entire window.

### **FileStateRegistry**
- **Plain English:** Per-task record of "what files this task has read" + global log of "what files have been written".
- **Like:** Library checkout slips per visitor (reads) + the master check-in log (writes).
- **In this project:** `tools/file_state.py`. Caps at 4096 entries each (`_MAX_PATHS_PER_AGENT`, `_MAX_GLOBAL_WRITERS`). Powers 3-tier staleness warnings.

### **3-tier staleness warning**
- **Plain English:** When the agent re-reads a file it's seen before, the system warns at three levels: another sub-agent wrote it / external mtime changed / safe.
- **Like:** Three flags on a returning library book: "another student wrote in it" / "the cover is different" / "untouched".
- **In this project:** Returned by `check_stale(task_id, path)`; strongest tier wins.

### **Shadow git store**
- **Plain English:** A hidden git repo outside your project that takes snapshots before every destructive op.
- **Like:** Time Machine auto-saving every time the AI is about to delete or overwrite something.
- **In this project:** `tools/checkpoint_manager.py`. Single shared object store + per-project branches. Rollback is one git command.

### **SessionDB + FTS5**
- **Plain English:** SQLite database that stores every conversation, with full-text search over all of them.
- **Like:** Google for your entire chat history.
- **In this project:** `product-b_state.py`. WAL mode prevents readers from blocking writers. `messages_fts USING fts5(content)` is the search index.

### **parent_session_id chain**
- **Plain English:** A pointer from this session to the one it forked from — like git commit parents.
- **Like:** Reply-thread vs starting a new email.
- **In this project:** Enables `/fork` and `/resume`; original session preserved when you branch.

### **Programmatic Tool Calling (PTC)**
- **Plain English:** Instead of one tool call at a time, the LLM writes a Python script that calls many tools in a single shot — only the script's final printed output reaches the LLM.
- **Like:** Sending an assistant to the grocery store with a written list, vs phoning to ask "should I buy milk? ... ok, eggs?" for each item.
- **In this project:** `tools/code_execution_tool.py`. 5-20× more token-efficient on multi-step pipelines. **The distinctive product-B technology.**

### **product-b_tools stub module**
- **Plain English:** An auto-generated Python file with one function per allowed tool — each function actually phones back to the parent agent.
- **Like:** A receptionist's intercom — buttons look real but each one rings someone else.
- **In this project:** Built fresh per `execute_code` call by `generate_product-b_tools_module(enabled_tools, transport)`; child process imports it.

### **RPC (UDS vs file polling)**
- **Plain English:** The phone line the stub uses to call back to the parent. Two implementations: UDS (super-fast local socket) and file polling (slower but works across machines/containers).
- **Like:** A speaking tube between adjacent rooms vs leaving notes in an inbox.
- **In this project:** UDS for `local` sandbox; file polling for all 6 remote sandbox backends (Docker has its own UDS-via-mount variant).

### **SANDBOX_ALLOWED_TOOLS**
- **Plain English:** The locked-down list of tools the LLM's PTC script is allowed to call.
- **Like:** "From this room you can only use the phone, fax, and shredder — not the safe."
- **In this project:** Verbatim frozenset of 7: `web_search`, `web_extract`, `read_file`, `write_file`, `search_files`, `patch`, `terminal`. Excludes `execute_code` itself (no recursion).

### **7 sandbox backends + BaseEnvironment**
- **Plain English:** Seven different places the LLM's script can run — local, Docker, SSH, Modal, Daytona, Singularity, Vercel — all behind one common interface.
- **Like:** "Where do you want to do your homework — kitchen / library / friend's house / coffee shop / hotel?" Same homework, different venue.
- **In this project:** `tools/environments/base.py` defines the abstract; each concrete backend implements `start`, `execute`, `stop`, `upload_file`, `download_file`.

### **MemoryProvider** & **the 4 hooks**
- **Plain English:** A standardized interface every memory backend implements — like a USB port. Plus the 4 moments per turn where memory is consulted: build_system_prompt / prefetch_all / sync_all / queue_prefetch_all.
- **Like:** USB plug — any compatible drive works. The 4 hooks are like restaurant routine: read reservations / check incoming / log today's diner / look at tomorrow.
- **In this project:** `agent/memory_provider.py` defines 4 required + 7 optional. `agent/memory_manager.py` routes the hooks to all registered providers.

### **8 memory plugins**
- **Plain English:** Eight pluggable memory backends — pick the one matching your data shape.
- **In this project:** `byterover` (hierarchical CLI tree), `hindsight` (knowledge graph), `holographic` (HRR algebraic), `honcho` (dialectic peer cards), `mem0` (LLM fact extraction), `openviking` (filesystem URIs), `retaindb` (vector + relational), `supermemory` (semantic LTM). Always-on builtin SQLite+FTS5 alongside.

### **StreamingContextScrubber**
- **Plain English:** A safety filter on the AI's output that removes any quoted memory before it reaches the user.
- **Like:** A copy-editor who deletes text marked "internal reference only" before publishing.
- **In this project:** State machine across stream deltas; suppresses `<memory-context>...</memory-context>` even when fence-open spans two deltas.

### **HARDLINE patterns (12)**
- **Plain English:** Command patterns that are forbidden no matter what — no override possible.
- **Like:** A lock on the nuclear silo door — you can't talk the guard into opening it.
- **In this project:** Verbatim list in `tools/approval.py` includes `rm -rf /`, `mkfs`, fork bomb, shutdown variants. Pre-compiled regex at module load.

### **DANGEROUS patterns (47+)**
- **Plain English:** Command patterns that are risky but legitimately needed sometimes — user can approve once/session/always.
- **Like:** "Are you sure?" prompt before deleting an email.
- **In this project:** Includes `rm` in root path, curl pipe to sh, git push --force, sudo, chmod 777.

### **Smart approval (auxiliary LLM)**
- **Plain English:** A cheaper auxiliary AI looks at flagged commands and decides if the user even needs to be asked.
- **Like:** A junior assistant pre-screens questions for the boss — only escalates real ones.
- **In this project:** Verdicts: APPROVE / DENY / ESCALATE. Cuts prompt fatigue ~5×; ~$0.001 per check. Never overrides HARDLINE.

### **contextvars per-session keys**
- **Plain English:** Python's tool for keeping per-session state that survives async `await` boundaries.
- **Like:** A name tag that follows you around even when you change rooms.
- **In this project:** Each user's approval queue is independent even when many sessions share one event loop.

### **delegate_task**
- **Plain English:** The tool that hands off work to freshly-hired sub-AI workers.
- **Like:** "You handle Q3 forecast, I'll do Q4" — junior does it, reports back.
- **In this project:** `tools/delegate_tool.py`. Spawns up to 3 children in parallel via `ThreadPoolExecutor`.

### **DELEGATE_BLOCKED_TOOLS**
- **Plain English:** Five tools children are NEVER allowed to use.
- **Like:** "The intern can't sign contracts, fire people, or order lunch on the company card."
- **In this project:** Frozen set verbatim — `delegate_task`, `clarify`, `memory`, `send_message`, `execute_code`. Auto-stripped from child's toolset.

### **role='leaf' vs 'orchestrator'**
- **Plain English:** Whether the child can hire its own children.
- **Like:** Junior employee (leaf) vs middle manager (orchestrator).
- **In this project:** Default leaf; orchestrator unlocks recursion up to `MAX_DEPTH = 3`.

### **task_id**
- **Plain English:** The unique handle that isolates a child's work from everyone else's.
- **Like:** Job number on a work order — every subsystem uses this number to find the job.
- **In this project:** Used by `FileStateRegistry`, terminal env, browser context, `CheckpointManager`, approval callback, `SessionDB`.

### **DelegateEvent**
- **Plain English:** Progress messages the child sends back while running.
- **Like:** Status updates from a contractor — "started", "found issue", "fixing", "done".
- **In this project:** 6 event types: `TASK_SPAWNED`, `TASK_PROGRESS`, `TASK_COMPLETED`, `TASK_THINKING`, `TASK_TOOL_STARTED`, `TASK_TOOL_COMPLETED`. TUI renders them as a live tree.

### **ContextCompressor**
- **Plain English:** When the conversation gets too long, the middle gets replaced with a summary so the AI's memory window doesn't overflow.
- **Like:** Editing a 100-page meeting transcript down to 10 pages — keep the start, keep the end, summarize the middle.
- **In this project:** `agent/context_compressor.py`. Fires at 75% context-fill; auxiliary LLM does the summarization.

### **Pre-summarize tool result**
- **Plain English:** Replacing an old tool's full output with a one-line description BEFORE the main summarization.
- **Like:** "npm test → 47 lines output" instead of pasting all 47 lines.
- **In this project:** `_summarize_tool_result(tool_name, tool_args, tool_content)` — the signature compaction trick. 80-95% size reduction before main pass.

### **Head + tail protection**
- **Plain English:** Always keep the first few messages (intent anchors) and the last few (active reasoning) exactly as written.
- **Like:** Keep the meeting agenda + action items verbatim; summarize the middle discussion.
- **In this project:** 4 head (first system / user / assistant / tool) + 4 tail (last 4 turns).

### **Image flat-estimate (1600 tokens)**
- **Plain English:** Count every image as 1600 tokens for budget purposes, regardless of provider.
- **Like:** Reserving the same suitcase space per photo, even though photos are different sizes.
- **In this project:** `_IMAGE_TOKEN_ESTIMATE = 1600`. Prevents under-budgeting on multimodal sessions.

### **Unified search (target='files' | 'content')**
- **Plain English:** One tool for "find a file" AND "find text in files" with a simple switch.
- **Like:** One library catalog that searches by title OR by content.
- **In this project:** `ShellFileOperations.search()`. Backed by ripgrep with .gitignore awareness.

### **Ripgrep (rg)**
- **Plain English:** A super-fast file content search tool — replaces grep.
- **Like:** A photocopier that flips through every page of every book in seconds.
- **In this project:** 200× faster than find/grep; auto-respects .gitignore.

### **Accessibility tree (NOT screenshot)**
- **Plain English:** A structured plain-text description of a webpage's interactive elements — what screen-reader users get.
- **Like:** A wheelchair-accessible map of a building — labels every door, button, sign.
- **In this project:** `browser_snapshot()` returns this. Text-only LLMs can interpret directly; no vision model needed; 10× fewer tokens than screenshot descriptions.

### **SNAPSHOT_SUMMARIZE_THRESHOLD (8000)**
- **Plain English:** If a browser snapshot is too big, an auxiliary AI extracts only the relevant elements.
- **Like:** "If the meeting transcript is over 50 pages, write a summary instead."
- **In this project:** Set to 8000 tokens. Provide `user_task` to focus the extraction.

### **SSRF protection**
- **Plain English:** Preventing the LLM from being tricked into fetching private internal URLs.
- **Like:** "Hey assistant, while you're out, peek inside the boss's office."
- **In this project:** product-B auto-routes private IPs (RFC1918 + localhost) to a local sandbox sidecar.

### **Lazy SDK loading (`_FirecrawlProxy`)**
- **Plain English:** Deferring the import of a heavy library until it's actually used.
- **Like:** Not turning on the espresso machine until the first coffee order.
- **In this project:** Avoids 200ms cold-start cost for users who never call Firecrawl.

### **Session search (FTS5)**
- **Plain English:** Full-text search over every past conversation, ranked by relevance.
- **Like:** Google for your own private chat history.
- **In this project:** `session_search_tool.py`. Truncates large matches to 100k chars centered on hits; auxiliary LLM summarizes each.

### **Browser-history monitoring (the explicit non-feature)**
- **Plain English:** product-B does NOT watch your browser in the background. Every URL fetched is the result of an explicit tool call.
- **Like:** A personal assistant who helps when asked — not one who shadows you everywhere.
- **In this project:** Privacy by design. Do NOT build passive monitoring into my-product.

### **Curator daemon**
- **Plain English:** A background process that maintains the skill library — archives unused skills, keeps things tidy.
- **Like:** A librarian who tidies shelves between visitors — never during a visitor's reading.
- **In this project:** Idle-triggered (`DEFAULT_MIN_IDLE_HOURS = 2`), NOT scheduled. Archives skills after 90 days idle; pinned skills exempt.

### **Inline shell expansion**
- **Plain English:** Letting a markdown file include "live" commands that run when the file is loaded.
- **Like:** A document with auto-updating fields like "Today's date is {{today}}".
- **In this project:** `` !`cmd` `` in skill body becomes current command output at invocation time. `preprocess_skill_content`.

### **Platform gating (`platforms: [linux, macos, windows]`)**
- **Plain English:** Hiding skills that won't work on the user's OS.
- **Like:** Grocery store doesn't show winter coats in July.
- **In this project:** `skill_matches_platform()` runs before scan results are returned.

---

## 7. The minimum mental model

If you remember three things about product-B:

1. **Programmatic Tool Calling (PTC)** is the distinguishing pattern. Instead of one tool_call at a time, the LLM writes a Python script that calls many tools via auto-generated stubs. Intermediate tool results stay invisible to the LLM; only the script's final `print()` output reaches it. This is 5-20× more token-efficient on multi-step pipelines.

2. **8 memory plugins + always-on builtin SQLite+FTS5** is the memory architecture. One swappable external provider plus the always-on transcript. The `MemoryManager` calls 4 lifecycle hooks (`build_system_prompt` / `prefetch_all` / `sync_all` / `queue_prefetch_all`) on all registered providers. The `StreamingContextScrubber` strips `<memory-context>` fence spans from output before they reach the user.

3. **Two-tier approval** is the safety model. 12 HARDLINE patterns are unconditional blocks; 47+ DANGEROUS patterns are user-overridable once/session/always. A smart-approval auxiliary LLM can second-guess flagged commands to relieve false-positive fatigue. All destructive ops get a pre-write shadow-git checkpoint snapshot.

Everything else in product-B is supporting infrastructure for these three: how the 7 sandbox backends route PTC scripts, how the `@-reference` parser feeds the context, how the curator manages the skill library, how `delegate_task` spawns isolated children, how `ContextCompressor` keeps long sessions alive.

---

*End of product-B quick start.*
