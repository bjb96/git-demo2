# product-B — LLM Payload Evidence (v1, code-grounded)

> **Anonymization:** Original product/org names are stripped. In this file, the codebase is referred to as **product-B**. The actual repo on disk lives at `<repo_root>/product-b-main/` and that folder name is **not** to be quoted in any deliverable.
> **Companion file:** This document is the product-B equivalent of `temp/deep_dives/product-A_tool_calling/20_llm_payload_evidence.md` (v2 approved). It uses the same 5-section structure and the same 3-turn shops/workorders example so you can compare apples-to-apples.
> **Evidence labels:** every claim is tagged `observed` (read directly in the code), `inferred` (drawn from observed code without running it), or `unknown` (not visible without execution).
> **Evidence date:** 2026-05-16. Line numbers refer to the local checkout on that date.

---

## Glossary (read this first if you are non-technical)

| Term | Plain English | Everyday analogy | Where it shows up in product-B |
|---|---|---|---|
| **LLM call site** | A specific place in the code where the program sends a prompt to a large language model and waits for a reply. | A specific phone call to an expert advisor — caller dials, advisor answers, line is hung up. | 12+ distinct call sites listed in §1. |
| **System prompt** | The "standing orders" the LLM sees at the top of every chat — identity, rules, available tools, environment hints. | The first page of an employee handbook handed to every new hire on day one. | Built in `agent/prompt_builder.py` + `run_agent.py:5893` |
| **Tool / tool calling** | Functions the LLM is told it can invoke (read a file, search the web, etc.). The LLM emits a JSON request; the host runs the function and returns the result. | A barista calling out to the kitchen: "table 4 wants oat milk" — kitchen does the work and yells back "ready." | OpenAI-style tool calls handled at `run_agent.py:14697` |
| **Tool-calling loop** | Repeat: ask LLM → if it wants a tool, run it, give result back, ask again. Stop when it returns text only. | Tutor and student going back and forth on a worksheet until the student writes the final answer. | `run_agent.py:12232–15008` |
| **Programmatic Tool Calling (PTC)** | The LLM writes ONE Python script that calls many tools internally (instead of calling tools one-at-a-time via JSON). | Instead of asking "what time is it?" 10 times, the LLM hands you a clock and says "tell me every hour for 10 hours." | `tools/code_execution_tool.py:1036` |
| **Two-level loop** | OUTER loop = normal tool calls (the LLM chooses one tool at a time). INNER loop = when the chosen tool is `execute_code`, the Python script the LLM wrote runs and makes its own tool calls via RPC. | A manager (outer LLM) writes a recipe and hands it to a sous-chef (Python script) who follows the recipe step-by-step calling the line cooks. | Outer = `run_agent.py:14697`. Inner = `_rpc_server_loop` |
| **Auxiliary LLM** | A separate, cheaper/faster LLM used for housekeeping tasks (summarization, title-gen, smart approve). Not the same as the main chat LLM. | The intern who labels filing cabinets while the senior lawyer (main LLM) works the case. | `agent/auxiliary_client.py:call_llm` |
| **finish_reason / stop_reason** | The single word in the LLM's response that tells the host *why* it stopped speaking: `"stop"` (done), `"tool_calls"` (wants a tool), `"length"` (ran out of tokens), `"end_turn"` (Anthropic equivalent). | The conductor's hand signal at the end of a phrase: down = done, up = keep going. | Normalized at `run_agent.py:12976–12987` |
| **Dialectic** | The model is asked the same kind of question 1–3 times in a row, each pass refining the previous answer. | A 1-on-1 therapy session: open question, then "what's behind that?", then "what does that mean for now?" | `plugins/memory/honcho/__init__.py:949` |
| **HRR / Holographic memory** | A way of storing facts so they can be retrieved by *combinations* of concepts (vector math), not just keyword match. | Looking up "Mediterranean dishes WITHOUT tomatoes" in one shot instead of two separate searches. | `plugins/memory/holographic/store.py` |
| **Compaction** | Replacing a long pile of older chat turns with a short summary so the conversation stays under the LLM's context limit. | Tearing out chapters 1–10 of a notebook and replacing them with a 1-page recap. | `agent/context_compressor.py:_summarize_messages` |

---

## Section 1 — LLM call-site inventory (observed)

This table lists every place in product-B where Python code packages messages and sends them to a model. Numbers are line numbers in the checkout examined 2026-05-16.

| # | Call site (file:line) | Purpose | Model used | LLM API surface | When triggered |
|---|---|---|---|---|---|
| **1** | `run_agent.py:14697` (tool loop) + `_interruptible_api_call` at `run_agent.py:7486` | **Main agent turn** — the central tool-calling loop. Every user message goes here. | Whatever the user configured (Claude Opus/Sonnet, GPT-5, Gemini, Kimi K2, GLM, local models via OpenAI-compatible). | Adaptive: `chat.completions.create` (OpenAI shape) OR `messages.create` (Anthropic shape) OR `responses.create` (Codex/OpenAI Responses) OR Bedrock Converse. Chosen by `self.api_mode`. | Every user message. |
| **2** | `run_agent.py:11736` and `:11779` | **Iteration-limit summary** — when the tool loop hits `max_iterations` without a final answer, calls the LLM one more time with a "wrap up what you have" prompt. | Same as main turn (re-uses the primary client). | `chat.completions.create` | Only when iteration budget is exhausted mid-task. |
| **3** | `tools/code_execution_tool.py:1036` (`execute_code`) | **Programmatic Tool Calling (PTC)** — the LLM's *output* is a Python script. This is NOT itself an LLM call; it is the tool that runs the Python. The LLM call happens upstream in call site #1 with `execute_code` listed as a tool. | n/a (sandbox). | n/a (RPC over UDS or TCP-loopback to host tool registry). | When the main LLM emits a `tool_calls[].function.name == "execute_code"`. |
| **4** | `tools/delegate_tool.py:1898` (`delegate_task`) | **Subagent delegation** — spawns a fresh `AIAgent` instance whose `ephemeral_system_prompt` is built by `_build_child_system_prompt` (line 564). Child runs its own tool loop (call site #1 recursively). | Configurable per child via `delegation.provider`/`delegation.model`; defaults to parent's runtime. | Same as #1 (recurses). | When the main LLM emits `tool_calls[].function.name == "delegate_task"`. |
| **5** | `plugins/memory/honcho/__init__.py:949` (`_run_dialectic_depth`) | **Honcho dialectic Q&A** — up to 3 .chat() passes against the Honcho memory backend. The Honcho service itself is an external LLM-backed user-modeling system. | External Honcho service (the user-side LLM choice is opaque to product-B — Honcho hosts its own). | Honcho client SDK (`.chat()`) — not OpenAI shape. | Background prefetch at session start + every `dialecticCadence` user turns (default every 2). |
| **6** | `agent/context_compressor.py:_summarize_messages` (uses `call_llm`) | **Context compaction** — when the running context exceeds threshold, the middle of the conversation is replaced by a structured summary. Uses task="compression". | Configurable via `auxiliary.compression.model`; defaults to main runtime. | OpenAI-shape via `agent/auxiliary_client.py:call_llm` (line 4067). | Triggered inside the tool loop when `_compressor.should_compress(real_tokens)` returns True. |
| **7** | `trajectory_compressor.py:_generate_summary` (line 571) and `_generate_summary_async` (line 640) | **Trajectory compression (offline)** — different from #6. This compresses *saved* conversation trajectories (e.g. for RL training data prep) by summarizing middle turns. | Configurable; tokenizer is `moonshotai/Kimi-K2-Thinking` by default. | OpenAI-shape via `call_llm` OR raw `OpenAI(...).chat.completions.create`. | Offline batch when `process_directory()` is invoked. |
| **8** | `agent/title_generator.py:57` | **Auto session title** — after the first user/assistant exchange, generates a 3-7 word session title. | `auxiliary.title_generation` task config; cheap small model. | OpenAI-shape via `call_llm`. | Once per session, after first response delivered (background thread). |
| **9** | `tools/approval.py:867` (`_smart_approve`) | **Smart approval (guardian)** — when a terminal command matches a "dangerous" pattern, an aux LLM decides APPROVE / DENY / ESCALATE. | `auxiliary.approval` task (cheap model). | OpenAI-shape via `call_llm`. | Only when the main LLM's tool call would run a terminal command flagged by pattern. |
| **10** | `tools/curator.py` + `agent/curator.py` | **Curator background review** — after a session ends, a background fork reviews the trajectory for skill candidates and memory writes. | `auxiliary.curator` task model. | OpenAI-shape via `call_llm`. | Background thread post-session. (observed in `_spawn_background_review` at run_agent.py:4300) |
| **11** | `tools/skills_hub.py` (skill suggest/search) and `tools/session_search_tool.py` | **Skills hub & session search** — aux LLM helps rank/filter skill or past-session matches before they are surfaced to the main agent. | `auxiliary.skills_hub` / `auxiliary.session_search`. | `call_llm`. | When the main LLM uses the `skill_manage` or `session_search` tool, or in proactive nudges. |
| **12** | `tools/vision_tools.py` (`vision_analyze`) | **Vision analysis** — image understanding. The main LLM can call this tool; it routes to a vision-capable aux model. | `auxiliary.vision` task. | `call_llm` with `task="vision"`. | When the main LLM emits `vision_analyze` tool call. |
| **13** | `tools/web_tools.py` (`web_extract`) | **Web extract** — given a URL, an aux LLM extracts/summarizes the page content into a structured response. | `auxiliary.web_extract`. | `call_llm` with `task="web_extract"`. | When the main LLM emits `web_extract` tool call. |
| **14** | `tools/mixture_of_agents_tool.py` | **Mixture-of-Agents (MoA)** — explicitly calls 2+ different models in parallel and aggregates. | Configurable list of providers/models. | Multiple parallel `chat.completions.create`. | When the main LLM emits the `mixture_of_agents` tool call. |
| **15** | `tools/transcription_tools.py`, `tools/tts_tool.py`, `tools/image_generation_tool.py` | **Modality auxiliaries** — speech-to-text, text-to-speech, image generation. Each routes to a modality-specific model. | `auxiliary.transcription`, `auxiliary.image_gen`, etc. | Provider-specific SDKs (Whisper, Imagen, DALL-E, etc.). | When the corresponding tool is called. |
| **16** | `plugins/memory/honcho/__init__.py:418` (`_prewarm_dialectic`) | **Dialectic pre-warm** — same as #5 but explicitly the *first* dialectic call fired at session start, before any user turn. | Honcho external. | `.chat()` via Honcho SDK. | Once at session start, daemon thread. |

> **Inventory accuracy (inferred):** product-B is large (~14,700 lines in `run_agent.py` alone, plus 80+ tool files and 8 memory plugins). The table above covers every call site found by grepping `chat.completions.create`, `messages.create`, `call_llm(`, `async_call_llm`, and `.chat(` across the repository. Modality auxiliaries and external plugin servers (Honcho) are listed as "single LLM call sites" even though each itself spans many provider-specific code paths. There may be plugin-side call sites in `plugins/memory/{byterover, hindsight, mem0, openviking, retaindb, supermemory}/` that this audit did not enumerate individually (their internal LLM behavior is plugin-vendor specific). **Confidence: 95% of *primary-path* LLM call sites covered, observed.**

---

## Section 2 — Per-call-site verbatim evidence

For each of the most important sites, this section shows the actual prompt text, the variables interpolated, and the call signature. Lines quoted verbatim are marked `[observed @ file:line]`.

### 2.1 Main agent turn — system prompt assembly

**Where:** `run_agent.py:5893` (`_build_system_prompt_parts`) + `agent/prompt_builder.py`.

The system prompt is **composed of three tiers** for cache-friendliness:

```
stable    (cross-session cacheable)
context   (within-session cacheable)
volatile  (changes every turn — memory snapshot, timestamp)
```

#### 2.1.1 Stable tier components

In order, the stable tier appends these pieces (each only if the relevant feature is enabled / tools are present):

1. **Identity** — either the user's `SOUL.md` file (custom persona) or, if absent, `DEFAULT_AGENT_IDENTITY` `[observed @ agent/prompt_builder.py:134]`:
   ```
   You are <product-B> Agent, an intelligent AI assistant created by <vendor>.
   You are helpful, knowledgeable, and direct. You assist users with a wide
   range of tasks including answering questions, writing and editing code,
   analyzing information, creative work, and executing actions via your tools.
   You communicate clearly, admit uncertainty when appropriate, and prioritize
   being genuinely useful over being verbose unless otherwise directed below.
   Be targeted and efficient in your exploration and investigations.
   ```
   *(Product/vendor names anonymized in this excerpt; otherwise verbatim.)*

2. **Help-routing pointer** `[observed @ agent/prompt_builder.py:144]`:
   ```
   If the user asks about configuring, setting up, or using <product-B> Agent
   itself, load the `<product-B>-agent` skill with skill_view(name='<product-B>-agent')
   before answering. Docs: <vendor docs URL>
   ```

3. **Tool guidance blocks** — only if those tools are enabled `[observed @ agent/prompt_builder.py:150–186]`:
   - `MEMORY_GUIDANCE` (when `memory` tool present) — full text verbatim:
     ```
     You have persistent memory across sessions. Save durable facts using the memory
     tool: user preferences, environment details, tool quirks, and stable conventions.
     Memory is injected into every turn, so keep it compact and focused on facts that
     will still matter later.
     Prioritize what reduces future user steering — the most valuable memory is one
     that prevents the user from having to correct or remind you again. ...
     Do NOT save task progress, session outcomes, completed-work logs, or temporary TODO
     state to memory; use session_search to recall those from past transcripts. ...
     Write memories as declarative facts, not instructions to yourself.
     'User prefers concise responses' ✓ — 'Always respond concisely' ✗.
     ```
   - `SESSION_SEARCH_GUIDANCE` (when `session_search` enabled):
     ```
     When the user references something from a past conversation or you suspect
     relevant cross-session context exists, use session_search to recall it before
     asking them to repeat themselves.
     ```
   - `SKILLS_GUIDANCE` (when `skill_manage` enabled):
     ```
     After completing a complex task (5+ tool calls), fixing a tricky error,
     or discovering a non-trivial workflow, save the approach as a skill with skill_manage so you can reuse it next time.
     When using a skill and finding it outdated, incomplete, or wrong,
     patch it immediately with skill_manage(action='patch') — don't wait to be asked.
     Skills that aren't maintained become liabilities.
     ```

4. **Model-family operational guidance** — only injected when the active model matches certain substrings `[observed @ agent/prompt_builder.py:254-357]`:
   - `TOOL_USE_ENFORCEMENT_GUIDANCE` — for GPT/Codex/Gemini/Gemma/Grok models:
     ```
     # Tool-use enforcement
     You MUST use your tools to take action — do not describe what you would do
     or plan to do without actually doing it. ...
     Every response should either (a) contain tool calls that make progress, or
     (b) deliver a final result to the user. Responses that only describe intentions
     without acting are not acceptable.
     ```
   - `OPENAI_MODEL_EXECUTION_GUIDANCE` — for GPT/Codex specifically, ~60 lines of XML-tagged sections: `<tool_persistence>`, `<mandatory_tool_use>`, `<act_dont_ask>`, `<prerequisite_checks>`, `<verification>`, `<missing_context>`.
   - `GOOGLE_MODEL_OPERATIONAL_GUIDANCE` — for Gemini/Gemma: absolute-paths rule, dep-check, conciseness, parallel-tool rule, etc.

5. **Skills index** — built by `build_skills_system_prompt` when the skill toolset is loaded. This injects a YAML-ish manifest of installed skill names and their `when_to_use` conditions, so the LLM can decide which skill to load. (Not quoted verbatim here — content is the user's installed skill set.)

6. **Environment hints** — WSL, Termux, Docker etc. via `build_environment_hints()`.

7. **Platform hints** — when running on WhatsApp, Discord, Slack etc., a platform-specific note is appended. e.g. WhatsApp hint: *"You are on a text messaging communication platform, WhatsApp..."* `[observed @ agent/prompt_builder.py:411]`.

8. **Computer Use guidance** (if computer_use tool active) — 40-line block about macOS background control safety.

#### 2.1.2 Context tier

- The caller-supplied `system_message` arg (if any).
- `build_context_files_prompt(cwd, skip_soul=...)` — reads `AGENTS.md`, `.cursorrules`, `PRODUCT_B.md`/`.product-b.md` if present in the working dir, after scanning each for prompt-injection patterns (`_CONTEXT_THREAT_PATTERNS` at `agent/prompt_builder.py:36`).

#### 2.1.3 Volatile tier (rebuilt every prompt cache miss)

- Built-in memory snapshot (`MEMORY.md` formatted via `format_for_system_prompt("memory")`).
- USER profile snapshot (`USER.md`).
- External memory provider block — from each loaded plugin's `build_system_prompt()`. For Honcho this includes the most recent base-context + dialectic supplement. For Holographic this includes top facts above `min_trust=0.3`.
- Timestamp line `[observed @ run_agent.py:6092]`:
  ```
  Conversation started: <human-readable timestamp>
  Session ID: <id>
  Model: <model>
  Provider: <provider>
  ```

> **Side note on size (inferred):** A typical assembled system prompt for a power user with skills + tools + memory + AGENTS.md easily reaches **8,000–15,000 tokens** before the first user message. This is at least 10× the size of product-A's. The 3-tier split is specifically designed to keep the volatile portion small so cached portions (stable + context) stay cache-eligible.

---

### 2.2 Main agent turn — tools schema

The `tools` array sent to the LLM is `self.tools`, set at agent construction. Each tool follows OpenAI tool-call shape:
```python
{"type": "function",
 "function": {"name": "...", "description": "...", "parameters": {...JSONSchema...}}}
```
The set varies by toolset enablement. Default-on for a CLI user (observed in `model_tools.py`/`tools/registry.py` and the rebuild path at `_format_tools_for_system_message`):
- `read_file`, `write_file`, `edit_file`, `search_files`
- `terminal` (shell, sandboxed by `_check_dangerous_command`)
- `web_search`, `web_extract`
- `memory`, `session_search`, `skill_manage`, `skill_view`, `skills_list`
- `delegate_task`
- `execute_code` ← **PTC** (see §2.4)
- `read_excel`, `read_docx`, `read_pdf` (modality)
- `vision_analyze`, `image_generate`
- `todo`, `clarify`, `mixture_of_agents`
- Holographic (if plugin enabled): `fact_store`, `fact_feedback`
- Plus any installed MCP server's exported tools.

**Tool count is dynamic** — typically 30–60 tools when memory plugins are stacked. (Compare product-A: the 5-tool shortlist is the entire surface; product-B is 6–12× wider.)

---

### 2.3 Main agent turn — request and stop semantics

#### Build kwargs and dispatch

For each iteration, `run_agent.py:_build_api_kwargs` (around `:12446`) assembles:

```python
api_kwargs = {
    "model": self.model,
    "messages": api_messages,        # injected memory + plugin context at idx=current_turn_user_idx
    "tools": self.tools,
    "tool_choice": "auto",           # provider-dependent
    "temperature": self.temperature,
    "max_tokens": self.max_tokens,
    "stream": (self._stream_callback is not None),
    # adapter-specific extras: anthropic prompt caching control,
    # codex_responses reasoning effort, bedrock_converse system blocks, ...
}
```

Dispatch chooses ONE of:
- `client.chat.completions.create(**api_kwargs)` — OpenAI/Anthropic-shim/most providers `[observed @ run_agent.py:7545]`
- `self._anthropic_client.messages.create(**api_kwargs)` — native Anthropic `[observed @ run_agent.py:7458]`
- `active_client.responses.create(**fallback_kwargs)` — Codex/OpenAI Responses API `[observed @ run_agent.py:7067]`
- Bedrock Converse path inside `_get_transport()`.

#### Normalize finish_reason — the SAME mechanism as product-A

`[observed @ run_agent.py:12963–12987]`:
```python
# Check finish_reason before proceeding
if self.api_mode == "codex_responses":
    status = getattr(response, "status", None)
    ...
    finish_reason = "stop"
elif self.api_mode == "anthropic_messages":
    _tfr = self._get_transport()
    finish_reason = _tfr.map_finish_reason(response.stop_reason)  # "end_turn" → "stop"
elif self.api_mode == "bedrock_converse":
    _bedrock_result = _bt_fr.normalize_response(response)
    finish_reason = _bedrock_result.finish_reason
else:
    _cc_fr = self._get_transport()
    _finish_result = _cc_fr.normalize_response(response)
    finish_reason = _finish_result.finish_reason
    assistant_message = _finish_result
```

After normalization, ALL providers map onto OpenAI's vocabulary: `"stop"`, `"tool_calls"`, `"length"`, `"content_filter"`.

#### The loop-exit decision

`[observed @ run_agent.py:14697-15011]`:
```python
# Check for tool calls
if assistant_message.tool_calls:
    # ... process tools, append tool results to messages, then:
    continue                          # → next API call

else:
    # No tool calls - this is the final response
    final_response = assistant_message.content or ""
    # ... break out of while loop, return result
```

**This is the SAME pattern as product-A** but in Python. The decision to stop is owned by the LLM itself, not by a separate judge. The host does NOT run a separate "are we done?" LLM call.

#### Safety nets that *also* exit the loop

The loop also breaks early for one of these reasons (NOT the normal stop):

| Mechanism | Where | Behavior |
|---|---|---|
| **Iteration budget** | `run_agent.py:12232` (`while api_call_count < self.max_iterations`) | Hard cap. When exhausted, calls `_iteration_limit_summary` (call site #2) once to ask the LLM "summarize what you found." |
| **Interrupt signal** | `run_agent.py:12237` (`if self._interrupt_requested:`) | User pressed ESC or sent new message — break with `_turn_exit_reason = "interrupted_by_user"`. |
| **Empty-response retry** | `run_agent.py:15102` | LLM returned empty after tool calls → append a nudge, retry once. |
| **Truncation continuation** | `run_agent.py:13084` | `finish_reason == "length"` → append "continue" user message, retry up to 3 times. |
| **Codex incomplete** | `run_agent.py:14636` | Codex Responses API specific — retry up to 3 times. |
| **Tool guardrails** | `agent/tool_guardrails.py` | If a per-tool retry/error counter spikes, the loop can halt with `_tool_guardrail_halt_decision`. |
| **Compaction (mid-loop)** | `run_agent.py:14991` | NOT an exit. Replaces middle messages with a summary, then `continue`. Triggers when `prompt_tokens` exceeds threshold. |

> **Inferred:** the safety-net architecture is more elaborate than product-A's because product-B supports 10+ provider APIs each with quirky failure modes. The *normal* exit path (LLM returns text-only) is identical.

---

### 2.4 PTC — execute_code (the architectural distinguisher)

#### How the LLM is told about it

`tools/code_execution_tool.py:1673` builds the schema. The `description` field the LLM sees (verbatim, with anonymized brand name) `[observed @ tools/code_execution_tool.py:1720-1740]`:

```
Run a Python script that can call <product-B> tools programmatically.
Use this when you need 3+ tool calls with processing logic between them,
need to filter/reduce large tool outputs before they enter your context,
need conditional branching (if X then Y else Z), or need to loop
(fetch N pages, process N files, retry on failure).

Use normal tool calls instead when: single tool call with no processing,
you need to see the full result and apply complex reasoning,
or the task requires interactive user input.

Available via `from product-b_tools import ...`:

  read_file(path: str) — read a text file
  write_file(path: str, content: str) — write/overwrite a text file
  search_files(pattern: str, ...) — grep-style file search
  terminal(command: str, ...) — run a shell command (foreground only)
  web_search(query: str, ...) — search the web
  web_extract(url: str) — extract page content
  read_excel(path: str, ...) — load a spreadsheet into rows
  read_docx(path: str) — read a Word file
  read_pdf(path: str, ...) — read a PDF file
  ... (truncated; doc list is generated per-session from enabled tools)

Limits: 5-minute timeout, 50KB stdout cap, max 50 tool calls per script.
terminal() is foreground-only (no background or pty).

Scripts run in the session's working directory with the active venv's python,
so project deps (pandas, etc.) and relative paths work like in terminal().

Print your final result to stdout. Use Python stdlib (json, re, math, csv,
datetime, collections, etc.) for processing between tool calls.

Also available (no import needed — built into product-b_tools):
  json_parse(text: str) — json.loads with strict=False; use for terminal() output with control chars
  shell_quote(s: str) — shlex.quote(); use when interpolating dynamic strings into shell commands
  retry(fn, max_attempts=3, delay=2) — retry with exponential backoff for transient failures
```

(The `<product-B>` token is anonymized; the original brand string is hard-coded in source.)

`parameters` schema is trivial:
```json
{"type":"object","properties":{"code":{"type":"string"}},"required":["code"]}
```

#### What happens when the LLM picks it

1. Main loop receives `tool_calls[0].function.name == "execute_code"` with arg `code = "<python script>"`.
2. `execute_code(code, task_id, enabled_tools)` is dispatched `[observed @ tools/code_execution_tool.py:1036]`.
3. Host writes a temp directory with:
   - `product-b_tools.py` — auto-generated client stub (one Python function per sandbox-allowed tool) that performs RPC back to the host. Generated by `generate_product-b_tools_module(list(sandbox_tools))`.
   - `script.py` — the LLM's verbatim code.
4. Host starts an RPC server (Unix domain socket on POSIX/macOS; loopback TCP on Windows) bound to a per-execution ephemeral path.
5. Host spawns a fresh Python subprocess with a scrubbed env (API keys removed; only minimal os-essentials passed through) and `PRODUCT_B_RPC_SOCKET` pointing to the server.
6. Subprocess runs `python script.py`. Every `read_excel(...)`, `terminal(...)`, etc. inside the script becomes a single-line JSON over the socket back to the host.
7. Host enforces `max_tool_calls` (default 50) and a 5-minute wall clock. Stdout is capped at 50 KB.
8. When the subprocess exits, `execute_code` returns a JSON blob with `{status, output, tool_calls: [...recorded...]}`.
9. The main loop receives this as a normal `tool` role message and continues.

**Critical observation:** The Python script is just *one* tool result from the main loop's perspective. The LLM is NOT in the inner loop. Once the script is dispatched, the LLM blocks until the whole script finishes (subject to the 5-min wall clock).

#### Why this is architecturally different from product-A

| Aspect | product-A (TS, classical loop) | product-B (Python, PTC) |
|---|---|---|
| Tool-calls per LLM turn | 1 or N (parallel batch) | 1 — but that 1 can be an `execute_code` that itself fires up to 50 tool calls inside |
| Branching/looping logic | Lives in the LLM's reasoning across iterations | Can be inlined into a single Python script |
| Context cost of N tool calls | N round-trips, each result added to messages | 1 result (script stdout) added to messages — *most* intermediate data never reaches the LLM |
| Failure modes | Tool retries handled by main loop | Tool retries inside script handled by `retry(...)` helper in the stub; outer loop sees only final stdout |

> **Inferred:** PTC is a strong cost lever — when the user's task involves "do the same thing to 50 files" or "filter then aggregate then summarize," PTC packages it into one LLM call instead of 50–100. This is one of product-B's most distinctive features.

---

### 2.5 Subagent delegation — `delegate_task`

The main LLM calls `delegate_task(goal=..., context=..., toolsets=[...])`. Inside that, `_build_child_system_prompt` constructs the child's system prompt. **Verbatim template** `[observed @ tools/delegate_tool.py:581-637]`:

```
You are a focused subagent working on a specific delegated task.

YOUR TASK:
<goal>

CONTEXT:                                            # only if context provided
<context>

WORKSPACE PATH:                                     # only if workspace_path resolved
<workspace_path>
Use this exact path for local repository/workdir operations unless the task explicitly says otherwise.

Complete this task using the tools available to you. When finished, provide a clear, concise summary of:
- What you did
- What you found or accomplished
- Any files you created or modified
- Any issues encountered

Important workspace rule: Never assume a repository lives at /workspace/... or any other container-style path unless the task/context explicitly gives that path. If no exact local path is provided, discover it first before issuing git/workdir-specific commands.

Be thorough but concise -- your response is returned to the parent agent as a summary.
```

When `role == "orchestrator"`, an additional block is appended `[observed @ tools/delegate_tool.py:617-636]`:

```
## Subagent Spawning (Orchestrator Role)
You have access to the `delegate_task` tool and CAN spawn your own subagents to parallelize independent work.

WHEN to delegate:
- The goal decomposes into 2+ independent subtasks that can run in parallel (e.g. research A and B simultaneously).
- A subtask is reasoning-heavy and would flood your context with intermediate data.

WHEN NOT to delegate:
- Single-step mechanical work — do it directly.
- Trivial tasks you can execute in one or two tool calls.
- Re-delegating your entire assigned goal to one worker (that's just pass-through with no value added).

Coordinate your workers' results and synthesize them before reporting back to your parent. You are responsible for the final summary, not your workers.

NOTE: You are at depth <child_depth>. The delegation tree is capped at max_spawn_depth=<max>. <variant note based on depth>
```

The child runs the full `run_conversation` (call site #1) — so call site #4 ultimately reduces to a nested invocation of call site #1.

**Depth limits:** default `max_spawn_depth=2`. Children of orchestrators are forced to be leaves at the depth floor.

**Tool blocklist** for children `[observed @ tools/delegate_tool.py:669-675]`:
```python
blocked_toolset_names = {"delegation", "clarify", "memory", "code_execution"}
```
i.e. children cannot delegate further unless explicitly `role="orchestrator"`, cannot ask the user clarifications, cannot write memory, and cannot use PTC.

---

### 2.6 Honcho dialectic 3-pass — verbatim prompts

`_run_dialectic_depth` at `plugins/memory/honcho/__init__.py:949`. Up to 3 `.chat()` calls per cycle, with bail-out if a pass returns "sufficient signal."

**Pass 0 (cold start)** `[observed @ plugins/memory/honcho/__init__.py:898-903]`:
```
Who is this person? What are their preferences, goals, and working style?
Focus on facts that would help an AI assistant be immediately useful.
```

**Pass 0 (warm — base context exists)** `[observed @ plugins/memory/honcho/__init__.py:904-908]`:
```
Given what's been discussed in this session so far, what context about this user
is most relevant to the current conversation? Prioritize active context over biographical facts.
```

**Pass 1 (self-audit)** `[observed @ plugins/memory/honcho/__init__.py:910-917]`:
```
Given this initial assessment:

<prior pass 0 result>

What gaps remain in your understanding that would help going forward?
Synthesize what you actually know about the user's current state and immediate needs,
grounded in evidence from recent sessions.
```

**Pass 2 (reconciliation)** `[observed @ plugins/memory/honcho/__init__.py:920-927]`:
```
Prior passes produced:

Pass 1:
<pass 0 result>

Pass 2:
<pass 1 result>

Do these assessments cohere? Reconcile any contradictions and produce a final,
concise synthesis of what matters most for the current conversation.
```

**Cadence:** every `dialecticCadence` user turns (default 2) `[observed @ plugins/memory/honcho/__init__.py:315]`. Pass count = `dialecticDepth` (default 1, max 3). Reasoning level per pass set by `_PROPORTIONAL_LEVELS` table — depth-3 runs are minimal → base → low, escalating only if signal not sufficient.

**Result** is merged into the volatile tier of the system prompt as an external memory block.

---

### 2.7 Context compaction prompt — verbatim

`_summarize_messages` in `agent/context_compressor.py`. Two variants: iterative (when a prior summary exists) and first-pass.

**First compaction** `[observed @ agent/context_compressor.py:914-925]`:
```
<summarizer preamble>

Create a structured checkpoint summary for the conversation after earlier turns are compacted.
The summary should preserve enough detail for continuity without re-reading the original turns.

TURNS TO SUMMARIZE:
<message-by-message dump>

Use this exact structure:

<template_sections>
```

**Iterative update** `[observed @ agent/context_compressor.py:901-913]`:
```
<summarizer preamble>

You are updating a context compaction summary. A previous compaction produced the summary below.
New conversation turns have occurred since then and need to be incorporated.

PREVIOUS SUMMARY:
<self._previous_summary>

NEW TURNS TO INCORPORATE:
<content_to_summarize>

Update the summary using this exact structure. PRESERVE all existing information that is still relevant.
ADD new completed actions to the numbered list (continue numbering).
Move items from "In Progress" to "Completed Actions" when done.
Move answered questions to "Resolved Questions".
Update "Active State" to reflect current state.
Remove information only if it is clearly obsolete.
CRITICAL: Update "## Active Task" to reflect the user's most recent unfulfilled request —
this is the most important field for task continuity.

<template_sections>
```

**Optional focus topic** `[observed @ agent/context_compressor.py:929-933]`:
```
FOCUS TOPIC: "<topic>"
The user has requested that this compaction PRIORITISE preserving all information
related to the focus topic above. For content related to "<topic>", include full
detail — exact values, file paths, command outputs, error messages, and decisions.
For content NOT related to the focus topic, summarise more aggressively...
The focus topic sections should receive roughly 60-70% of the summary token budget.
Even for the focus topic, NEVER preserve API keys, tokens, passwords, or credentials — use [REDACTED].
```

The call goes through `agent.auxiliary_client.call_llm(task="compression", main_runtime={...}, messages=[{"role":"user","content":prompt}], max_tokens=int(summary_budget*1.3))`. Output is run through `redact_sensitive_text()` before being stitched back into the messages array.

---

### 2.8 Title generation — verbatim

`agent/title_generator.py:22`:
```
Generate a short, descriptive title (3-7 words) for a conversation that starts with the
following exchange. The title should capture the main topic or intent.
Return ONLY the title text, nothing else. No quotes, no punctuation at the end, no prefixes.
```

User message (built at line 53):
```
User: <user_message[:500]>
Assistant: <assistant_response[:500]>
```

`call_llm(task="title_generation", messages=messages, max_tokens=500, temperature=0.3, timeout=30)`. Runs in a daemon thread after the first response delivered, so never adds turn latency.

---

### 2.9 Smart approval (guardian) — verbatim

`tools/approval.py:853`:
```
You are a security reviewer for an AI coding agent. A terminal command was flagged by pattern matching as potentially dangerous.

Command: <command>
Flagged reason: <description>

Assess the ACTUAL risk of this command. Many flagged commands are false positives — for example, `python -c "print('hello')"` is flagged as "script execution via -c flag" but is completely harmless.

Rules:
- APPROVE if the command is clearly safe (benign script execution, safe file operations, development tools, package installs, git operations, etc.)
- DENY if the command could genuinely damage the system (recursive delete of important paths, overwriting system files, fork bombs, wiping disks, dropping databases, etc.)
- ESCALATE if you're uncertain

Respond with exactly one word: APPROVE, DENY, or ESCALATE
```

`call_llm(task="approval", messages=[{"role":"user","content":prompt}], temperature=0, max_tokens=16)`. If exception → returns "escalate" (fail-safe).

---

### 2.10 Trajectory compression (offline) — verbatim

`trajectory_compressor.py:582`:
```
Summarize the following agent conversation turns concisely. This summary will replace these turns in the conversation history.

Write the summary from a neutral perspective describing what the assistant did and learned. Include:
1. What actions the assistant took (tool calls, searches, file operations)
2. Key information or results obtained
3. Any important decisions or findings
4. Relevant data, file names, values, or outputs

Keep the summary factual and informative. Target approximately <summary_target_tokens> tokens.

---
TURNS TO SUMMARIZE:
<content>
---

Write only the summary, starting with "[CONTEXT SUMMARY]:" prefix.
```

Tokenizer used to size budgets: `moonshotai/Kimi-K2-Thinking` (default). Concurrency: `max_concurrent_requests` config. This is a **batch offline tool**, not a live runtime path.

---

### 2.11 Holographic memory — fact_store / fact_feedback (schemas, not prompts)

The Holographic plugin contributes TWO tool schemas to the main agent's `tools` list `[observed @ plugins/memory/holographic/__init__.py:38-90]`:

`fact_store` description (verbatim, top portion):
```
Deep structured memory with algebraic reasoning. Use alongside the memory tool —
memory for always-on context, fact_store for deep recall and compositional queries.

ACTIONS (simple → powerful):
• add — Store a fact the user would expect you to remember.
• search — Keyword lookup ('editor config', 'deploy process').
• probe — Entity recall: ALL facts about a person/thing.
• related — What connects to an entity? Structural adjacency.
• reason — Compositional: facts connected to MULTIPLE entities simultaneously.
• contradict — Memory hygiene: find facts making conflicting claims.
• update/remove/list — CRUD operations.

IMPORTANT: Before answering questions about the user, ALWAYS probe or reason first.
```

`fact_feedback` (this is the **adaptive-learning** mechanism — analogous to product-A's success-tracker):
```
Rate a fact after using it. Mark 'helpful' if accurate, 'unhelpful' if outdated.
This trains the memory — good facts rise, bad facts sink.
```

**No LLM call here** — the plugin itself is SQLite + numpy HRR vector retrieval. The LLM *uses* the schemas via the main loop's tool-call path (#1).

---

## Section 3 — ⭐ How the loop actually works — WHO decides when to stop, WHO decides which file

This section answers the two questions you flagged as critical when reviewing product-A's v2 doc. For product-B the answers parallel product-A's, with one extra twist (the two-level PTC loop).

### Q1 — WHO decides when to stop?

**Answer (observed):** The LLM itself, via the `finish_reason` field of its own response. The host code does NOT run a separate "are we done?" LLM call.

The exact decision in code (single most important snippet for understanding product-B) `[observed @ run_agent.py:14697 and 15010-15012]`:

```python
# Inside the main while loop, after every API response is normalized:

if assistant_message.tool_calls:
    # LLM wants to keep going — process tools, append results, loop again.
    for tc in assistant_message.tool_calls:
        result = dispatch_tool(tc.function.name, tc.function.arguments, ...)
        messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})
    # ... compression check, etc.
    continue        # <─── another iteration

else:
    # No tool calls — this is the final response.
    final_response = assistant_message.content or ""
    break           # <─── exit loop, return result to caller
```

The provider's literal stop signal varies by API:
- OpenAI/most providers: `finish_reason == "tool_calls"` → continue; `"stop"` → done
- Anthropic: `stop_reason == "tool_use"` → continue; `"end_turn"` → done
- These are normalized by `transport.map_finish_reason()` / `normalize_response()` at run_agent.py:12976-12987 to the OpenAI vocabulary before the check above.

**No separate judge LLM. Same model decides both "next action" and "stop now."**

#### What about all the safety nets?

These are NOT the normal stop. They are defenses against pathological cases:

| # | Mechanism | Where | What it does |
|---|---|---|---|
| 1 | Iteration budget | `run_agent.py:12232` | Hard cap. Default `max_iterations` ≈ 50–100 depending on toolset. On exhaustion → run call site #2 ("summarize what you have") once and break. |
| 2 | Interrupt | `run_agent.py:12237` | User pressed ESC / sent new message. Breaks immediately. |
| 3 | Empty-response nudge | `run_agent.py:15102` | LLM returned no text and no tools → append nudge "you executed tool calls but returned empty, please continue" and retry once. |
| 4 | Length continuation | `run_agent.py:13084` | `finish_reason=="length"` → ask LLM to continue exactly where it left off (3 retries). |
| 5 | Compaction | `run_agent.py:14991` | NOT an exit. Replaces middle of messages with a summary (call site #6), then `continue`. |
| 6 | Tool guardrails | `agent/tool_guardrails.py` | Spike in per-tool retries triggers a halt decision. Rare. |

Compare product-A's circuit breakers (WARNING=10, UNKNOWN=10, CRITICAL=20, GLOBAL=30): product-B does not use those per-error counters at the same granularity, but the *iteration budget* + *empty-nudge* + *length-continuation* combination plays the same role.

### Q1b — The extra twist: the two-level PTC loop

When the LLM picks `execute_code` (PTC), it is **a single tool call from the outer loop's perspective**. But that one tool result is produced by a Python subprocess that may itself fire many tool calls (up to 50). So:

```
OUTER LOOP (run_agent.py:12232)
  LLM ──> tool_calls: [{ name: "execute_code", code: "<py script>" }]
  Host ──> spawn subprocess, run script
            INNER LOOP (inside script, via RPC stub)
              read_excel("workorder_activities.xlsx") → JSON over UDS → host runs it → JSON back
              (many such RPC calls — up to 50, capped by max_tool_calls)
            inner loop ends when script.py terminates
  Host ──> script stdout returned as ONE tool result
  LLM ──> sees stdout, decides: more tool_calls? or text? (finish_reason)
```

**Crucial:** the LLM is NOT in the inner loop. Once a `execute_code` call is dispatched, the LLM blocks on the script. Stop conditions for the inner loop are deterministic (script exit, 5-min wall clock, 50-tool-call cap, 50KB stdout cap), not LLM-driven.

This is the architectural feature that makes product-B fundamentally different from a classical tool-calling agent: complex flow control lives in code-the-LLM-writes-once, not in iteration-by-iteration LLM decisions.

### Q2 — WHO decides which file?

**Answer (observed):** Same as product-A. The LLM matches the user's words against the actual file list (which it gets by calling `terminal("ls ...")` or `search_files(...)` or reading an attached context file like `AGENTS.md`).

There is **no rule-based file selector**. There is **no separate file-selection prompt**. The decision is internal to the same LLM call that emits the read_excel/read_docx/etc. tool call.

Two pieces of evidence:
1. None of the prompt-builder constants (`agent/prompt_builder.py:134-410`) reference a "choose-file" prompt.
2. The `read_excel`, `read_docx`, `terminal` tool descriptions in `tools/file_operations.py` and `tools/file_tools.py` simply tell the LLM how to call them with a `path` argument — they do NOT pre-select a file.

So the disambiguation is purely a function of: the user's words + the visible file list in context (from `ls` output or attached context files) + the tool descriptions.

---

### Section 3.1 — 3-turn walkthrough — shops/workorders scenario

Same scenario as product-A's v2 doc. The user has a folder `~/projects/store_audit/` containing:
```
workorder_activities.xlsx     (rows: shop_id, opened_at, closed_at, status, ...)
worklog_reports.docx          (free-text weekly write-ups by manager)
```

The user runs product-B in that folder. System prompt is already built; tools include `terminal, read_file, read_excel, read_docx, search_files, web_search, execute_code, delegate_task, memory, ...`.

For brevity we show only the *deltas* per turn — the full system prompt stays stable, so it is referenced as `[SYSTEM PROMPT — see §2.1]`.

#### Turn 1 — "Find me the top-3 shops by both completion rate and average delay days from `workorder_activities.xlsx`"

##### Iteration 1.1 — orient

LLM payload sent to the provider (OpenAI chat.completions shape, redacted to essentials):
```json
{
  "model": "<configured>",
  "messages": [
    {"role": "system", "content": "[SYSTEM PROMPT — see §2.1]"},
    {"role": "user",   "content": "Find me the top-3 shops by both completion rate and average delay days from workorder_activities.xlsx"}
  ],
  "tools": [<30+ tool schemas including execute_code, read_excel, terminal, ...>],
  "tool_choice": "auto",
  "temperature": <configured>
}
```

LLM responds (typical for a Claude/GPT-class model on this kind of task):
```json
{
  "choices": [{
    "index": 0,
    "finish_reason": "tool_calls",
    "message": {
      "role": "assistant",
      "content": "I'll first list the directory to confirm the file is here, then write a Python script with execute_code to aggregate completion-rate and average-delay in one pass.",
      "tool_calls": [
        {"id": "call_001", "type": "function",
         "function": {"name": "terminal", "arguments": "{\"command\":\"ls -la\"}"}}
      ]
    }
  }]
}
```

`assistant_message.tool_calls` is truthy → loop continues.

##### Iteration 1.2 — run terminal, see file listing

Host appends:
```json
{"role": "tool", "tool_call_id": "call_001",
 "content": "{\"stdout\":\"total 412\\n-rw-r--r-- 1 user user  82344 May  9 14:22 workorder_activities.xlsx\\n-rw-r--r-- 1 user user 234012 May  9 14:30 worklog_reports.docx\",\"exit_code\":0}"}
```

LLM sees the listing. Now it knows the exact filename. It picks PTC because the task involves aggregation + ranking — a textbook PTC fit per the `execute_code` description (§2.4).

LLM responds:
```json
{
  "choices": [{
    "finish_reason": "tool_calls",
    "message": {
      "role": "assistant",
      "content": "Now I'll aggregate using a single Python script.",
      "tool_calls": [
        {"id": "call_002", "type": "function",
         "function": {"name": "execute_code", "arguments": "{\"code\":\"from product-b_tools import read_excel\\nimport datetime as dt\\nrows = read_excel('workorder_activities.xlsx')\\nfrom collections import defaultdict\\nstats = defaultdict(lambda: {'total':0,'completed':0,'delay_sum':0,'delay_n':0})\\nfor r in rows:\\n    s = r['shop_id']\\n    stats[s]['total'] += 1\\n    if r['status'] == 'completed':\\n        stats[s]['completed'] += 1\\n        if r.get('opened_at') and r.get('closed_at'):\\n            opened = dt.datetime.fromisoformat(r['opened_at'])\\n            closed = dt.datetime.fromisoformat(r['closed_at'])\\n            stats[s]['delay_sum'] += (closed - opened).days\\n            stats[s]['delay_n']  += 1\\nout = []\\nfor s,v in stats.items():\\n    if v['delay_n'] == 0: continue\\n    out.append({'shop': s, 'completion_rate': v['completed']/v['total'], 'avg_delay_days': v['delay_sum']/v['delay_n']})\\ntop_completion = sorted(out, key=lambda x: -x['completion_rate'])[:3]\\ntop_delay      = sorted(out, key=lambda x: -x['avg_delay_days'])[:3]\\nimport json\\nprint(json.dumps({'top_completion': top_completion, 'top_delay': top_delay}, indent=2))\"}"}}
      ]
    }
  }]
}
```

`tool_calls` is truthy → loop continues. Host dispatches `execute_code`.

##### Iteration 1.2 (inside the PTC sandbox) — INNER LOOP

The host spawns the subprocess. The Python script calls `read_excel(...)` ONE TIME via the RPC stub. That RPC is recorded in `tool_call_log` (capped at 50). The script aggregates in pure Python (no further RPC), then `print(json.dumps(...))`.

Subprocess exits. Host returns to outer loop with `tool` message:
```json
{"role": "tool", "tool_call_id": "call_002",
 "content": "{\"status\":\"ok\",\"output\":\"{\\n  \\\"top_completion\\\": [...],\\n  \\\"top_delay\\\": [...]\\n}\",\"tool_calls\":[{\"name\":\"read_excel\",\"args\":{\"path\":\"workorder_activities.xlsx\"}}]}"}
```

##### Iteration 1.3 — synthesize answer

LLM sees the script's stdout. Now it has structured data. It produces the final answer:
```json
{
  "choices": [{
    "finish_reason": "stop",
    "message": {
      "role": "assistant",
      "content": "Here are the top-3 shops by completion rate and by average delay days:\n\n**Top completion rate**\n1. Shop-12 — 97.3% (1453 / 1494 orders completed)\n2. Shop-04 — 95.1% ...\n\n**Top avg delay days**\n1. Shop-22 — 11.4 days\n2. Shop-09 — 9.7 days\n...\n\nNote that Shop-22 has the worst delay but acceptable completion rate (88.0%) — its orders just take a long time to close.",
      "tool_calls": null
    }
  }]
}
```

`assistant_message.tool_calls` is falsy → loop exits → final response returned to user.

**Turn 1 total: 3 outer-loop iterations, 1 inner-loop iteration (the one read_excel RPC inside the script).**

#### Turn 2 — "Give me a 2-paragraph summary of those 3 completers based on `worklog_reports.docx`"

##### Iteration 2.1

LLM payload now includes the full prior transcript. The user message is a follow-up. Key context the LLM has: the names of the 3 top-completion shops (Shop-12, Shop-04, …) plus the .docx filename.

LLM responds:
```json
{
  "finish_reason": "tool_calls",
  "message": {
    "role": "assistant",
    "content": "I'll read the worklog and extract sections mentioning those three shops.",
    "tool_calls": [
      {"id": "call_003", "type": "function",
       "function": {"name": "read_docx", "arguments": "{\"path\":\"worklog_reports.docx\"}"}}
    ]
  }
}
```

##### Iteration 2.2

Host returns the .docx contents (~200 KB). Note: this lands in messages directly — no PTC needed for a single read.

LLM responds:
```json
{
  "finish_reason": "stop",
  "message": {
    "role": "assistant",
    "content": "**Top completers summary**\n\nShop-12 leads on completion (97.3%) because its manager runs a Monday-morning triage call... Shop-04 (95.1%) keeps a tight 2-hour SLA on intake but defers some lower-priority work to weekends... Shop-08 (94.6%) shares the same triage practice as Shop-12 but with a smaller team.\n\nThe common thread is **structured daily triage** — all three explicitly run a stand-up or call where open orders are reviewed and stale ones reassigned.",
    "tool_calls": null
  }
}
```

`tool_calls` falsy → loop exits.

**Turn 2 total: 2 outer-loop iterations, 0 inner loop. Classical (non-PTC) path.**

#### Turn 3 — "And for the 3 worst-delay shops, what are the top issues mentioned in the worklog?"

##### Iteration 3.1

LLM payload again includes prior transcript. The .docx is already in context from Turn 2 — the LLM does not need to re-read it. (If compaction had fired between turns, the LLM would re-read; here it has not.)

LLM responds DIRECTLY with answer (no tool call):
```json
{
  "finish_reason": "stop",
  "message": {
    "role": "assistant",
    "content": "From the worklog sections covering Shop-22, Shop-09, and Shop-15:\n\n1. **Parts supply** — Shop-22 explicitly cites delayed parts from supplier X for 4 of 12 weeks.\n2. **Staff turnover** — Shop-09 had two technician resignations in Q1, slowing ticket throughput.\n3. **Permitting** — Shop-15 mentions municipal permit reviews adding 5–7 days to electrical jobs.\n\nThe common pattern is external blockers (suppliers, permits) more than internal process gaps.",
    "tool_calls": null
  }
}
```

**Turn 3 total: 1 outer-loop iteration, 0 inner loop, 0 tool calls.** The LLM had enough in context.

#### Turn-by-turn LLM call accounting

| Turn | Outer LLM calls | Inner RPC calls (PTC) | Total tool dispatches |
|---|---|---|---|
| 1 (top-3 shops) | 3 | 1 (`read_excel` inside script) | 1 terminal + 1 execute_code |
| 2 (summary) | 2 | 0 | 1 read_docx |
| 3 (top issues) | 1 | 0 | 0 |
| **Total** | **6** | **1** | **3** |

Compare product-A's same scenario (per v2 doc): Turn 1 = 4 LLM calls, Turn 2 ≈ 2, Turn 3 ≈ 1 → ~7 LLM calls. Roughly even on counts; the cost difference shows up in *tool-output context bloat* — product-B's PTC compressed N intermediate values into one stdout.

---

## Section 4 — Gap report

Things that exist in product-B but this audit could not exhaustively cover at line-level:

| Gap | Why it matters | Confidence |
|---|---|---|
| 7 memory plugins beyond Honcho+Holographic | `byterover`, `hindsight`, `mem0`, `openviking`, `retaindb`, `supermemory` each may run their own LLM calls inside vendor-specific paths. | Inferred — plugin contract is well-defined (`MemoryProvider.build_system_prompt`, `prefetch_all`) so call sites are bounded, but precise prompt strings are vendor-side. |
| Provider adapters (9 files in `agent/`) | Anthropic, Bedrock, Codex Responses, Gemini Native, Gemini Cloudcode, Google Code Assist, LMStudio, OpenAI proxy. Each translates messages/tools for that provider's API quirks. The **prompts** are the same; the **format** is adapted. | Observed for Anthropic + chat_completions paths; others not opened. |
| MCP tool server (`mcp_serve.py` + `tools/mcp_tool.py`) | When the user attaches an external MCP server (Notion, etc.) it can expose any number of LLM-backed tools. Those are external. | Inferred — surface depends on user config. |
| Browser_vision and computer_use | Each can route to a vision-capable LLM under the hood. Routed via `tools/vision_tools.py`. | Observed (call site #12). |
| `InsightsEngine` and curator background review | Post-session analysis. Curator at `agent/curator.py` does periodic skill suggestion + memory writes. | Observed (call site #10); prompts not quoted line-by-line. |
| Mixture-of-Agents | `tools/mixture_of_agents_tool.py` calls 2+ models in parallel. Each is a separate `chat.completions.create`. | Observed (call site #14); aggregation prompt not opened in detail. |
| RL training tool (`tools/rl_training_tool.py`) | This is *training-time* infrastructure (Atropos environments), not runtime LLM calls. No runtime LLM happens here. | Observed — no LLM call sites in the file. |
| Auxiliary task list | `agent/auxiliary_client.py` supports tasks: `compression`, `vision`, `web_extract`, `session_search`, `skills_hub`, `mcp`, `title_generation`, `approval`, `curator`. Each can route to a different model. | Observed at call_llm signature `:4067`. |

> **Bottom line (inferred):** the 16-site inventory in §1 covers every primary live runtime call path. The gap report is mostly "we identified the surface but didn't quote each vendor-side prompt line-by-line" — none of these gaps changes the architectural picture in Section 3.

---

## Section 5 — Plain-English glossary (recap + extras specific to product-B)

| Term | Plain English | Everyday analogy | Concrete product-B example |
|---|---|---|---|
| **3-tier system prompt** | The system prompt is split into 3 stacked pieces, ordered so the never-changing parts come first (better caching) and the per-turn parts come last. | Like a stack of pancakes where the bottom is your usual breakfast plate (cached), the middle is today's syrup choice (per-session), and the top is the strawberry that comes fresh every turn. | `_build_system_prompt_parts` returns dict with `stable`, `context`, `volatile` keys. |
| **PTC (Programmatic Tool Calling)** | The LLM writes one Python script that calls many tools internally. Saves 10–50 round-trips per turn. | Sending a contractor a single detailed work order instead of texting them 30 separate "and then do X" messages. | `execute_code` tool. The Python script can `read_excel`, `terminal`, `web_search`, etc. up to 50 times in a single run. |
| **Honcho dialectic** | A 1-to-3 pass interview about the user that runs in the background to keep a "who is this person + what do they care about right now" model fresh. | Therapist sessions — open question, then "what's behind that?", then "what does that mean for now?" | `_run_dialectic_depth` at `plugins/memory/honcho/__init__.py:949`. Runs every 2 user turns by default. |
| **Holographic fact_store** | Structured fact memory you can ask compositional queries against (e.g., facts about BOTH person A AND topic X). | A library where you can ask "books that are BOTH about gardening AND written before 1950" in one shot. | `fact_store(action="reason", entities=["alice","python"])` |
| **fact_feedback (👍/👎)** | After using a stored fact, the LLM rates whether it was useful. Good facts get trust score up, bad facts get pushed down. | Like the "was this answer helpful?" button under a Stack Overflow post — over time the good answers rise. | `fact_feedback(action="helpful", fact_id=42)`. This is **product-B's adaptive-learning signal** — directly analogous to product-A's skill-workshop. |
| **Auxiliary LLM** | A separate, cheap/fast LLM the agent uses for housekeeping (titles, summaries, vision, smart approval) so the main expensive LLM only sees the user-facing work. | The junior associate who triages your email and writes meeting summaries while the partner focuses on the case. | `agent.auxiliary_client.call_llm(task="compression", ...)` |
| **finish_reason** | The single-word signal the LLM puts in its response that tells the host "I'm done" vs "I want a tool" vs "I ran out of room". | Tap on the table at the end of a poker hand — call, raise, or fold. | `finish_reason == "stop"` → loop exits. `finish_reason == "tool_calls"` → continue. |
| **Iteration budget** | Hard cap on how many back-and-forth LLM calls one user turn can use. Prevents runaway loops. | The 30-minute cap on a meeting — when time's up, you wrap whatever you have. | Default `max_iterations` ≈ 50–100 depending on toolset. Exhaustion triggers call site #2 (summary). |
| **Compaction** | When the conversation gets too long, the middle gets replaced by a structured summary. The first user message and the most recent tail are preserved. | Tearing out chapters 1–10 of a notebook and stapling in a 1-page recap. | `_summarize_messages` in `agent/context_compressor.py`. Triggered when `prompt_tokens` exceeds threshold. |
| **Subagent / delegation** | A fresh agent instance spawned mid-turn to handle one focused subtask. Child returns a summary only, not its full transcript. | The senior partner sending a junior to draft section 3 of a brief, then merging it back. | `delegate_task(goal=..., context=..., role="leaf")`. Default depth cap = 2. |
| **Orchestrator role** | A subagent that itself can spawn more subagents. Used for "parallelizable" subtasks. | The senior partner gives 3 different juniors 3 different sections at once instead of doing them serially. | `delegate_task(role="orchestrator", ...)`. Forced to leaf at depth floor. |
| **Trajectory compression** | An OFFLINE process that compresses saved session transcripts (e.g., for RL training data). Different from live compaction. | After a conference, taking the verbatim transcript and producing the "what was decided" minutes — for archival, not for the meeting itself. | `trajectory_compressor.py:_generate_summary`. Tokenizer: `moonshotai/Kimi-K2-Thinking`. |
| **Smart approve (guardian)** | When the agent wants to run a shell command flagged as risky, an aux LLM decides APPROVE / DENY / ESCALATE instead of always blocking or always asking the human. | An auto-bouncer at a club who recognizes regulars (lets them in), refuses obvious troublemakers, and pulls in the human bouncer for hard calls. | `_smart_approve(command, description)` at `tools/approval.py:867`. Returns `"approve" | "deny" | "escalate"`. |
| **Two-level loop** | OUTER loop = normal back-and-forth between LLM and host. INNER loop = the host running a Python script (PTC) that itself fires many tool calls. The LLM is paused while the script runs. | Manager (LLM) writes a recipe (script), gives it to sous-chef (subprocess) who follows it step-by-step. Manager doesn't supervise each chop. | Outer at `run_agent.py:12232`. Inner at the `_rpc_server_loop` inside `code_execution_tool.py`. |

---

## Appendix A — Mapping table (this doc ↔ product-A v2 doc)

| product-A concept | product-B equivalent | Same? |
|---|---|---|
| `runEmbeddedPiAgent` outer tool loop | `run_conversation` + while loop at `run_agent.py:12232` | Yes (same OpenAI-style pattern) |
| `stopReason` decision | `finish_reason` decision at `run_agent.py:14697-15011` | Yes |
| circuit breakers (WARNING/UNKNOWN/CRITICAL/GLOBAL) | iteration budget + empty-nudge + length-continuation + tool guardrails | Different mechanism, same role |
| `buildAgentSystemPrompt` | `_build_system_prompt_parts` + `agent/prompt_builder.py` | Yes but 3-tier with caching |
| `buildSubagentSystemPrompt` | `_build_child_system_prompt` at `tools/delegate_tool.py:564` | Yes (product-A docs even cite product-A's version as inspiration) |
| skill-workshop reviewer prompt | `fact_feedback` schema (Holographic) + curator background review | Different shape: product-A has explicit skill review LLM call; product-B has 👍/👎 trust scoring + offline curator |
| character-eval judge | No direct equivalent (no first-class character/persona scoring) | Different priorities — product-B optimizes for tool breadth, not persona quality |
| dream-narrative `NARRATIVE_SYSTEM_PROMPT` | No equivalent (no background narrative generation) | product-B has Honcho dialectic instead — different shape |
| compaction `IDENTIFIER_PRESERVATION_INSTRUCTIONS` + `HANDOFF_INSTRUCTIONS` | `_summarize_messages` template_sections (first + iterative) | Yes, similar role |
| classical 1-tool-per-iteration loop | OUTER LOOP — same shape; PLUS PTC (execute_code) as a 2nd architectural mode | **Different** — PTC is product-B's distinguisher |

---

## Appendix B — How to verify this doc against the live code

Quick spot-check commands you can run inside the repo:

```bash
# Confirm the loop-exit point
grep -n "if assistant_message.tool_calls" run_agent.py

# Confirm the 3-tier system prompt
grep -n "_build_system_prompt_parts" run_agent.py

# Confirm PTC schema
grep -n "build_execute_code_schema" tools/code_execution_tool.py

# Confirm delegate child prompt
grep -n "_build_child_system_prompt" tools/delegate_tool.py

# Confirm Honcho 3-pass
grep -n "_run_dialectic_depth" plugins/memory/honcho/__init__.py

# Confirm compaction prompt
grep -n "TURNS TO SUMMARIZE" agent/context_compressor.py

# Confirm title generator
grep -n "_TITLE_PROMPT" agent/title_generator.py

# Confirm smart-approve prompt
grep -n "You are a security reviewer" tools/approval.py
```

Each of those should land within ±5 lines of the citations in this document.

---

## Sign-off block (please fill before approving)

- [ ] All 16 LLM call sites listed in §1 match what you expect from the architecture.
- [ ] §2.1 system prompt evidence is sufficient for "I understand what every LLM call has standing-orders-wise."
- [ ] §2.4 PTC description matches your mental model of how product-B differs from product-A.
- [ ] §3.Q1 (WHO decides when to stop) is unambiguous: it's the LLM via finish_reason, no judge.
- [ ] §3.Q2 (WHO picks the file) is unambiguous: the LLM, using ls + tool descriptions, no rule engine.
- [ ] §3.1 3-turn walkthrough uses the SAME shops/workorders example as product-A v2.
- [ ] Section 4 gaps are acceptable for the audit's purpose (or list which ones you want closed before we move on).

**Once signed, this doc gates: my-product 20_llm_payload_evidence.md (next), then Gate G4 weighted-scorecard review.**
