# product-B — Architecture Handbook

> **A maintenance manual for the 10 function groups that make product-B what it is.**
> Same shape as the product-A handbook — pick a function group, get its key features, benefit, process map, terminology, method, code locator, my-product gap, and AWS ECS recipe in one consistent format. Side-by-side comparable.

---

## Anonymization & audience

- **Anonymization (HARD RULE):** Only `my-product`, `product-A`, `product-B` are used as labels. Real product names, brand names, marketplace names, or file names from the original source never appear in any artifact.
- **Audience:** A non-technical product owner who needs to understand each subsystem in plain English with everyday analogies, plus a junior-to-mid engineer who needs precise code locators to make changes.
- **Deployment target for my-product:** AWS ECS, 50 concurrent users on 2 containers. Every recommendation is translated to Python-on-ECS terms.

---

## 0. How to use this handbook

Drop in at any function group (zone) and get the same five things every time:

| Drop-in question | Where to look |
|---|---|
| "What does this zone DO?" | §3.X — Key features |
| "Why should I care?" | §3.X — Key benefit |
| "Show me the picture" | §3.X — Process map (links to the zoomable HTML) |
| "What are these weird words?" | §3.X — Key terminology (links to glossary in [07_quick_start.md](07_quick_start.md)) |
| "What technology / method drives it?" | §3.X — Key method |
| "Where in the code does it live?" | §3.X — Code locator |
| "Does my-product have this today?" | §3.X — my-product gap |
| "What should we build on AWS ECS?" | §3.X — AWS ECS recipe |

If you're new: read §1 (the big picture) and §2 (the master process map) first, then drop into any zone.

---

## 1. The big picture in one paragraph

product-B is an LLM-agent built around three signature technologies: **Programmatic Tool Calling (PTC)** (the LLM writes a Python script that uses auto-generated stubs to invoke many tools through one round-trip, saving 5-20× tokens on multi-step pipelines), **8 swappable memory plugins behind a uniform `MemoryProvider` interface** with always-on SQLite+FTS5 transcript and `StreamingContextScrubber` injection defense, and a **two-tier approval gate** (12 unconditional HARDLINE patterns + 47+ overridable DANGEROUS patterns with auxiliary-LLM smart approval). Around these are 7 sandbox backends, 9 provider adapters, a `@-reference` context parser with hard/soft budgets, a curator daemon for skill lifecycle, the strongest artifact-management story of any of the three products (FileStateRegistry per-path locks + shadow git checkpoints + session chains), and a single ripgrep-backed search interface for files/content + accessibility-tree browser snapshots for web. **my-product has 4 of these 10 zones today** — the other 6 are this teardown's build-list.

---

## 2. The master process map (10 zones overview)

The full diagram is in **[01_process_map.html](01_process_map.html)** — zoomable, with every zone color-coded and yellow signature-callouts highlighting product-B's distinguishing technologies.

| Zone | Color | What it covers | Deep-dive |
|---|---|---|---|
| 🟢 **TOOL** | green | Tool registry (ToolEntry __slots__, register/dispatch, check_fn TTL 30s, 9 provider adapters, MCP refresh) | [02](02_tool_registry.html) · [03](03_llm_call_flow.html) · [04](04_architecture.html) · [06](06_process_map_demo.html) |
| 🔵 **CTX** | cyan | Context engine + @-reference parser (6 types, 50% hard / 25% soft budget, file_safety) | [09](09_context_management.html) |
| 🟠 **ART** | orange | FileStateRegistry + 3-tier staleness + shadow git checkpoints + SQLite+FTS5+WAL + session chains | [08](08_artifact_management.html) |
| 🟣 **EXEC** | purple | ⭐ **PTC + 7 sandbox backends** (local/docker/ssh/modal/daytona/singularity/vercel) | [10](10_code_execution.html) |
| 🟡 **SKILL** | yellow | YAML frontmatter + inline shell expansion + Curator daemon (active→stale→archived) | [11](11_skill_management.html) |
| 💙 **MEMORY** | indigo | ⭐ **MemoryManager 4 hooks + 8 plugins + StreamingContextScrubber** | [12](12_memory_management.html) |
| 🔴 **PERM** | red | 12 HARDLINE + 47+ DANGEROUS + smart approval auxiliary LLM + contextvars sessions | [13](13_permission_approval.html) |
| 🔵 **SUB-AGENT** | deep blue | delegate_task + DELEGATE_BLOCKED_TOOLS + per-task_id isolation across 6 subsystems | [14](14_subagent_delegation.html) |
| 🟢 **COMPACT** | teal | ContextCompressor + TrajectoryCompressor + pre-summarize tool results + image flat-estimate | [15](15_compaction_summarization.html) |
| 🟤 **TEXT** | brown | Unified ripgrep search + 7 web backends + accessibility-tree browser + session search | [16](16_document_retrieval.html) |
| ⚫ **SURFACE** *(Phase 3 gap-fill)* | gray | 25 channels (CJK-heavy: DingTalk, Feishu, WeCom, Weixin, Yuanbao, QQBot + Western: Discord, Slack, Telegram, WhatsApp, Signal); `BasePlatformAdapter` ABC at `gateway/platforms/base.py:1259`; **OpenAI-compatible `/v1/...` HTTP API** on port 8642 (`api_server.py`); **ACP adapter** for IDE integration (`acp_adapter/server.py`); ~80 CLI modules in `product-b_cli/`; 10 TTS + 5 STT (3 local TTS); accessibility-tree browser; Docker + flake.nix + Homebrew + install.sh/.ps1; **no native apps** | [17](17_surface.html) |
| ⚪ **OBSERVABILITY** *(Phase 3 gap-fill)* | light-gray | ⭐ **Dual-TTL Anthropic prompt cache** (`prompt_caching.py` 178 lines, `system_and_3` + `prefix_and_2` strategies, 1h+5m, 4 breakpoints); Langfuse plugin only (deterministic `trace_id` `seed={session}::{task}`, 6 hooks, per-token-type cost); ⭐ **18-value `FailoverReason` enum** with action hints (`should_compress, should_rotate_credential, should_fallback`) at `error_classifier.py:24`; ⭐ **MCP server circuit breaker** (3-state machine, 60s cooldown, dedicated tests); per-token-type pricing in `_OFFICIAL_DOCS_PRICING` table; `AccountUsageSnapshot` plan-limit retrieval from Codex/Anthropic/OpenRouter APIs; `InsightsEngine` 30-day SQLite analytics; `StreamingContextScrubber` + `StreamingThinkScrubber` (fail-closed); `RedactingFormatter` + `mask_secret`; tirith pre-exec command scanner; cross-session `nous_rate_guard` shared file; jittered backoff; `/health, /health/detailed, /v1/health` + 6 per-platform endpoints + `gateway/status.py` runtime status file; `trajectory_compressor.py` ML-grade out-of-process. **No OTel/Prometheus/Datadog** (only Langfuse); no eval harness (only pytest); no A/B framework; no per-tool QPS limit; no app-level LLM-response cache. | [18](18_observability.html) |
| 🟢 **ADAPT_LEARN** *(Phase 3 gap-fill, USER'S #1 ICP)* | green | **product-B has the 3 STRONGEST adaptive-learning signals of the three products** — but NONE are RLHF over user feedback. (1) ⭐ **Holographic plugin `fact_feedback`** (`plugins/memory/holographic/__init__.py:76-90` + `store.py:353-392`) — `trust_score REAL DEFAULT 0.5`, asymmetric `helpful=+0.05`/`unhelpful=-0.10`, retrieval ranks by `score = relevance * trust_score`. **Genuine in-session RLAIF** (reward agent-generated, not user). (2) ⭐ **Honcho plugin dialectic** (`plugins/memory/honcho/__init__.py:191` + 4 supporting files = ~5,000 LOC) — 5 tool schemas, 4 daemon threads, 3-pass dialectic depth (cold→self-audit→reconciliation), per-turn user-model synthesis at hosted endpoint. **Behavioral closed loop, but at hosted-service layer.** (3) ⭐ **Trajectory → HuggingFace SFT pipeline** — `agent/trajectory.py:30-56` ShareGPT-format saves, `trajectory_compressor.py:86` `moonshotai/Kimi-K2-Thinking` tokenizer, `scripts/sample_and_compress.py:30-36` pulls 5 HF SFT datasets + emits `huggingface-cli upload`. **OFFLINE SFT for upstream foundation-model release.** Plus `tools/rl_training_tool.py:1-106` Tinker-Atropos scaffold (manually invoked, `tinker-atropos/` is empty submodule). **NO in-product RLHF/DPO** (only website docs as skills); NO user-thumbs ingest; `curator.py:256-296` is TIME-BASED archival only; `prompt_builder.py:1-30` STATELESS; `InsightsEngine` is REPORTING-only; MEMORY.md/USER.md write via `memory_tool` uses FROZEN-SNAPSHOT pattern (changes take effect NEXT session); SOUL.md is READ-ONLY (`honcho/__init__.py:324-327` explicitly removed sync). | [19](19_adapt_learn.html) |

**Companion artifacts (always read alongside):**
- [05_python_demo.py](05_python_demo.py) — runnable Python demo with real product-B class signatures (run `python 05_python_demo.py --selftest`)
- [07_quick_start.md](07_quick_start.md) — function/class index + common modifications + debugging cheat sheet + plain-English glossary (~50 terms)

---

## 3. The 10 function groups, drop-in style

Every zone below follows the uniform 8-part template.

---

### 3.1 🟢 Zone TOOL — Tool registry & dispatch

**Key features**
- `ToolEntry.__slots__` with 11 fields: `name`, `toolset`, `schema`, `handler`, `check_fn`, `requires_env`, `is_async`, `description`, `emoji`, `max_result_size_chars`, `dynamic_schema_overrides`
- `ToolRegistry` thread-safe singleton; bumps `_generation` counter on every mutation so external callers can memoize against generation
- Per-tool TTL'd availability checks (`_CHECK_FN_TTL_SECONDS = 30.0`) — `check_fn` probes external state (Docker daemon, Modal SDK install, browser binary) without per-turn re-probe waste
- **Shadowing rejection** — `register()` REJECTS cross-toolset name clashes; MCP-to-MCP overwrites are permitted for legitimate server refresh
- `dispatch()` with **JSON-error exception swallow** + per-tool `max_result_size_chars` truncation — keeps the agent loop alive under handler crashes
- `coerce_tool_args()` normalizes LLM type casualness ("50" → 50, "true" → True, "x" → ["x"])
- `dynamic_schema_overrides` callable applied per `get_definitions()` so the LLM sees CURRENT config (delegate_task's max_concurrent_children)
- **9 provider adapters**: Anthropic, Bedrock, Codex Responses, Gemini Native, Gemini CloudCode, Copilot ACP, LM Studio Reasoning, Google Code Assist, OpenAI default
- MCP dynamic refresh via generation-counter snapshots — coherent under <code>notifications/tools/list_changed</code>

**Key benefit** — adding a new tool is a single `registry.register(...)` call at module-import time. Every tool gets typed metadata, TTL'd availability, JSON-error survival, per-tool truncation, and per-provider normalization for free.

**Process map** — [02_tool_registry.html](02_tool_registry.html) + [03_llm_call_flow.html](03_llm_call_flow.html)

**Key terminology** — ToolEntry, ToolRegistry, check_fn TTL cache, generation counter, shadowing rejection, dynamic_schema_overrides, coerce_tool_args, provider adapter, JSON-error swallow (all in [07_quick_start.md](07_quick_start.md))

**Key method/technology** — Python <code>__slots__</code> records + thread-safe singleton + per-tool TTL'd availability + per-provider adapter normalization

**Code locator**
| Concept | File |
|---|---|
| ToolEntry + ToolRegistry | `tools/registry.py` |
| Auto-import discovery | `tools/__init__.py` |
| Toolset composition | `toolsets.py` + `toolset_distributions.py` |
| Public API + memoization + coerce_tool_args | `model_tools.py` |
| 9 provider adapters | `agent/{anthropic,bedrock,codex_responses,gemini_native,gemini_cloudcode,copilot_acp}_adapter.py` + `lmstudio_reasoning.py` + `google_code_assist.py` |
| MCP bridge | `mcp_serve.py` + `tools/mcp_tool.py` |

**my-product gap** — function_registry is a plain dict; no typed contract, no shadowing protection, no TTL'd availability, no per-tool truncation, no per-provider adapter.

**AWS ECS recipe**
- Port `ToolEntry` to Pydantic v2 with frozen ConfigDict
- Module-level singleton: `registry = ToolRegistry()`; same import-time registration pattern
- Port `_CHECK_FN_TTL_SECONDS = 30.0` verbatim
- Port shadowing rejection — prevents plugin tampering with built-ins
- Start with 2 adapters: anthropic (via Bedrock) + openai; add more as needed
- Port `coerce_tool_args` — single biggest reliability win on multi-provider
- Cache tool plan by `(generation, enabled_toolsets)` in Redis with 60s TTL

**Related zones** — CTX (consumes tool plan), PERM (gate runs between tool_call and dispatch), SUB-AGENT (delegate_task is a tool too).

---

### 3.2 🔵 Zone CTX — Context engine + @-reference parser

**Key features**
- `parse_context_references(message)` — regex scan for **6 types**: `@file:path:10-20`, `@folder:`, `@git:ref`, `@diff`, `@staged`, `@url:`
- Per-type expanders: `_expand_file_reference`, `_expand_folder_reference`, `_expand_git_reference`, `_expand_url_reference`
- **Dual budget** (verbatim): `hard_limit = int(context_length * 0.50)` — over 50% REFUSES injection; `soft_limit = int(context_length * 0.25)` — over 25% WARNS but allows
- `file_safety.is_reference_path_allowed()` deny list catches even explicit user `@file:~/.aws/credentials`
- Binary file detection via `_is_binary_file`; language-aware code-fence via `_code_fence_language`
- Ripgrep-backed folder listing (`_rg_files`) with fallback to pathlib
- Async URL parallelism via `asyncio.gather` over multiple `@url:` references

**Key benefit** — operators can write workflows using natural shorthand. Power users can inline 30 files into one query without copy-pasting. Budgets prevent accidental context blow-up.

**Process map** — [09_context_management.html](09_context_management.html)

**Key terminology** — @-reference, line range syntax, hard limit (50%), soft limit (25%), file_safety deny list, inline expansion

**Key method/technology** — Regex-based parser + per-type async expanders + dual-budget enforcement + pre-expansion deny list

**Code locator**
| Concept | File |
|---|---|
| ContextEngine abstract | `agent/context_engine.py` |
| @-reference parser + expansion | `agent/context_references.py` |
| Hard/soft budget enforcement | `agent/context_references.py` — `preprocess_context_references` |
| file_safety | `agent/file_safety.py` |
| Code fence + binary detection | `agent/context_references.py` |

**my-product gap** — system prompt is hardcoded; no @-reference parser at all; no budget enforcement.

**AWS ECS recipe**
- Port @-reference parser with one regex + named groups + `asyncio.gather` for parallel URL fetches
- Paths resolve against S3 keys (workspace files); URLs go through `httpx`
- Port hard 50% / soft 25% budgets verbatim — well-tuned
- Centralize deny list in `permissions/deny_paths.py` + per-tenant DynamoDB overrides
- Cache URL responses in ElastiCache (1h TTL)
- Per-reference timeouts: 5s @url, 1s @file, 500ms @folder

**Related zones** — TOOL (tool plan composed here), TEXT (document_extract feeds into context), COMPACT (token-budget delegation when full), MEMORY (recalled memory injected here).

---

### 3.3 🟠 Zone ART — Artifact management

**Key features**
- `FileStateRegistry` with **per-path RLock** (NOT global) — parallel reads/writes on different files don't serialize
- `_MAX_PATHS_PER_AGENT = 4096` per-task ReadStamp cap (LRU on overflow)
- `_MAX_GLOBAL_WRITERS = 4096` writes_since cursor cap
- Three primary APIs: `record_read(task_id, path, *, partial)`, `note_write(task_id, path)`, `check_stale(task_id, path) -> Optional[str]`
- **3-tier staleness warnings** on next read: sibling-subagent-write > external-mtime-change > safe
- `CheckpointManager` with **shadow git store** (single shared object store, per-project branches) — snapshots BEFORE every destructive op
- `SessionDB` SQLite + FTS5 + **WAL mode** (readers don't block writers)
- `parent_session_id` chains for session fork/resume
- `tool_calls` JSON column preserves structured metadata
- Jitter retry on lock conflicts tolerates concurrent agent processes

**Key benefit** — production-grade durability: undo-anything via shadow git, cross-session search via FTS5, fork-and-experiment via session chains, multi-process safety via WAL + jitter. **The strongest artifact-management story of the three products.**

**Process map** — [08_artifact_management.html](08_artifact_management.html)

**Key terminology** — ReadStamp, writes_since cursor, 3-tier staleness, per-path lock, shadow git store, SessionDB, parent_session_id chain, FTS5

**Key method/technology** — Per-path RLocks + content-addressed shadow git + SQLite WAL + FTS5 virtual table

**Code locator**
| Concept | File |
|---|---|
| FileStateRegistry + ReadStamp | `tools/file_state.py` |
| FileOperations abstract + dataclasses | `tools/file_operations.py` |
| Checkpoint manager (shadow git) | `tools/checkpoint_manager.py` |
| SessionDB SQLite + FTS5 + WAL | `product-b_state.py` |
| Trajectory recording | `trajectory_compressor.py` (batch) + session messages table (live) |

**my-product gap** — has a workspace concept (in-container `/tmp/<session>/`) but no lineage tracker, no per-path locks, no staleness warnings, no pre-write checkpoints, no FTS5, no session chains.

**AWS ECS recipe**
- DynamoDB `(session_id, path) → {last_read_mtime, last_read_size, last_writer_task_id}` for FileStateRegistry analog
- DynamoDB conditional writes (CAS on version column) for distributed per-path locks
- S3 ETag comparison for staleness (replaces local mtime)
- S3 versioning ON for workspace bucket; save VersionId in DynamoDB for shadow-git-like rollback
- DynamoDB session_messages + OpenSearch FTS5 analog
- `parent_session_id` GSI for "show all children of session X"
- `permissions/deny_paths.py` for write_safe_root analog

**Related zones** — EXEC (sandbox writes go here), TEXT (extracted text cached here), PERM (CheckpointManager triggered before destructive ops).

---

### 3.4 🟣 Zone EXEC — Programmatic Tool Calling (signature technology)

**Key features**
- **PTC pattern** — LLM emits one `execute_code` with a Python script; script imports auto-generated `product-b_tools` stub; stub functions RPC back to parent
- Only the script's <code>stdout</code> reaches the LLM — intermediate RPC results stay invisible (5-20× token savings on multi-step pipelines)
- `generate_product-b_tools_module(enabled_tools, transport)` builds the stub fresh per call with only the requested tools
- **Dual transport**: UDS sockets for local (TCP loopback on Windows); file-polling for remote sandboxes (works across machines/containers)
- `SANDBOX_ALLOWED_TOOLS = frozenset([...])` — 7 tools allowed inside the sandbox; `execute_code` deliberately NOT in the list (no recursion)
- Constants: `DEFAULT_TIMEOUT = 300`, `DEFAULT_MAX_TOOL_CALLS = 50`, `MAX_STDOUT_BYTES = 50_000`, `MAX_STDERR_BYTES = 10_000`
- **7 sandbox backends** behind one `BaseEnvironment(ABC)` at `tools/environments/base.py:288`: `local` / `docker` / `ssh` / `modal` / `daytona` / `singularity` / `vercel_sandbox`. Plus 3 supporting modules: `managed_modal.py`, `modal_utils.py`, `file_sync.py`.
- `BaseEnvironment` has only ONE `@abstractmethod` (`cleanup()` at line 342). Other interface methods (`get_temp_dir`, `execute`, `stop`, `init_session`, `_run_bash`, `_kill_process`) have concrete defaults — subclasses override what they need. NO `upload_file`/`download_file` on the base class (file transfer is per-backend via `file_sync.py`).
- Environment reuse across tools by `task_id` — terminal state, browser context, file cache stay coherent within one task

**Key benefit** — the distinguishing product-B technology. For data pipelines, research syntheses, multi-step file edits — anywhere the LLM would otherwise emit 5-20 sequential tool_calls — PTC drops token cost ~10× while preserving full control.

**Process map** — [10_code_execution.html](10_code_execution.html)

**Key terminology** — PTC, stub module, RPC (UDS vs file polling), SANDBOX_ALLOWED_TOOLS, 7 sandbox backends, BaseEnvironment, counter enforcement

**Key method/technology** — Auto-generated Python stub + UDS or file-poll RPC + 7-backend abstract sandbox interface

**Code locator**
| Concept | File:line |
|---|---|
| PTC orchestration (execute_code) | `tools/code_execution_tool.py:1036` |
| Stub generator | `tools/code_execution_tool.py:230` — `generate_product-b_tools_module` |
| UDS RPC server (local) | `tools/code_execution_tool.py:439` — `_rpc_server_loop` (NOT `_rpc_server_loop_uds`) |
| File-poll RPC server (remote sandboxes) | `tools/code_execution_tool.py:699` — `_rpc_poll_loop` |
| Generated stub `_call()` (UDS) | `tools/code_execution_tool.py:344` |
| Generated stub `_call()` (file-poll) | `tools/code_execution_tool.py:383` |
| BaseEnvironment abstract | `tools/environments/base.py` |
| 7 backends | `tools/environments/{local,docker,ssh,modal,daytona,singularity,vercel_sandbox}.py` |
| Supporting modules | `tools/environments/{managed_modal,modal_utils,file_sync}.py` |
| Reusable agent loop | `environments/agent_loop.py` |

**my-product gap** — uses in-container Python subprocess for ALL execution; one round trip per tool; won't scale to 50 concurrent users on 2 containers.

**AWS ECS recipe** — copy the PTC pattern; pick fewer backends:
- Port `generate_product-b_tools_module` directly (already Python)
- Backend A (short jobs, <15s): AWS Lambda + provisioned concurrency 10 + EFS for file-poll transport
- Backend B (long jobs / large deps): Fargate task + same EFS mount
- Copy constants verbatim: `DEFAULT_TIMEOUT=300`, `MAX_TOOL_CALLS=50`, stdout/stderr caps
- Allowlist same 7 tools; counter-enforce parent-side
- Cold-start mitigation: 10 provisioned Lambda slots (~$5/month each)

**Related zones** — TOOL (execute_code is dispatched like any tool), PERM (terminal inside PTC still gated), ART (sandbox writes update FileStateRegistry).

---

### 3.5 🟡 Zone SKILL — Skill management

**Key features**
- Declarative SKILL.md files with **YAML frontmatter**: `name`, `description`, `platforms`, `tags`, `related_skills`, `metadata.product-b`, `emoji`
- `parse_frontmatter(content)` using PyYAML CSafeLoader (SafeLoader fallback)
- Three-level **progressive disclosure**: metadata always in prompt (~100 words/skill) / body loaded only on invocation / `scripts/` and `references/` loaded only when agent reads explicitly
- `scan_skill_commands()` full re-scan; `get_skill_commands()` cache-aware lookup; `build_skill_invocation_message()` → prompt block
- **Platform gating** — `platforms: [linux, macos, windows]` in frontmatter; `skill_matches_platform()` filters out OS-mismatched skills before scan returns
- **Inline shell expansion** — <code>!`cmd`</code> in skill body executes at load time, making docs context-aware
- **Curator daemon** — `DEFAULT_INTERVAL_HOURS = 24 * 7`, idle-triggered (`DEFAULT_MIN_IDLE_HOURS = 2`); auto-transitions skills active → stale (`DEFAULT_STALE_AFTER_DAYS = 30`) → archived (`DEFAULT_ARCHIVE_AFTER_DAYS = 90`)
- Pinning exempts skills from auto-archive

**Key benefit** — adding domain-specific behavior is a markdown-file PR, not a code change. Operators (not engineers) can extend the agent. Inline shell expansion keeps skill docs always-current. Curator keeps the skill library tidy without manual gardening.

**Process map** — [11_skill_management.html](11_skill_management.html)

**Key terminology** — Frontmatter, inline shell expansion, platform gating, curator, stale/archived skill, pinning, progressive disclosure

**Key method/technology** — Markdown frontmatter parsing + filesystem discovery + three-tier prompt-budget management + idle-triggered lifecycle daemon

**Code locator**
| Concept | File |
|---|---|
| Curator daemon | `agent/curator.py` + `curator_backup.py` |
| Slash command routing | `agent/skill_commands.py` |
| Frontmatter parsing | `agent/skill_utils.py` |
| Template + inline shell expansion | `agent/skill_preprocessing.py` |
| Core skills (25+ categories) | `skills/` |
| Optional skills (18 categories) | `optional-skills/` |
| User skills | `~/.product-B/workspace/skills/` |

**my-product gap** — **No skill system at all.** Highest-leverage borrowed pattern.

**AWS ECS recipe**
- Skills as S3 objects: `s3://my-product-skills/<tenant_id>/<skill>/SKILL.md` + scripts/refs as siblings
- Port `parse_frontmatter` directly (~30 lines)
- Keep platform gating — repurpose for capability category gating
- **Skip inline shell expansion in v1** — adds attack surface; not needed for MVP
- EventBridge scheduled rule once/week + DynamoDB last-activity for Curator analog
- Cache skill metadata in Redis 5-min TTL; invalidate on S3 PutObject via EventBridge
- Start with 5 skills: Jupyter Live Kernel / CSV Analysis / Plotting / Web Research / Code Review

**Related zones** — CTX (skill metadata at top of prompt), MEMORY (skills can read MEMORY.md), TOOL (skills can declare tools).

---

### 3.6 💙 Zone MEMORY — Memory management (signature technology)

**Key features**
- `MemoryProvider` abstract base: **4 required hooks** (`initialize`, `prefetch`, `sync_turn`, `get_tool_schemas`) + 7 optional (`build_system_prompt`, `on_turn_start`, `on_session_end`, `on_delegation`, `warm_cache`, `export_state`, `import_state`)
- `MemoryManager` routes **4 lifecycle hooks** (verbatim names + signatures at `agent/memory_manager.py:264, 285, 304, 317`):
  - `build_system_prompt() -> str` (boot)
  - `prefetch_all(query: str, *, session_id: str = "") -> str` (PRE-TURN sync, returns fenced text — positional `query`, keyword-only `session_id`)
  - `sync_all(user_content: str, assistant_content: str, *, session_id: str = "") -> None` (POST-TURN write, keyword-only session_id)
  - `queue_prefetch_all(query: str, *, session_id: str = "") -> None` (async warm-up)
  - Plus `add_provider(provider)` at line 204 for registration
- **8 swappable plugins** + always-on builtin SQLite+FTS5 transcript (per-plugin facts verified against each `plugins/memory/<name>/__init__.py`):
  - `byterover` — function-based CLI wrapper around the <code>brv</code> binary. Constants: <code>_QUERY_TIMEOUT=10</code>s, <code>_CURATE_TIMEOUT=120</code>s. 3 tool schemas (QUERY / CURATE / STATUS).
  - `hindsight` — knowledge graph (HTTP client). Cloud <code>https://api.hindsight.vectorize.io</code> OR embedded daemon <code>http://localhost:8888</code>. <code>_DEFAULT_TIMEOUT=120</code>s. Recall budgets <code>{low, mid, high}</code>. Min client version 0.4.22.
  - `holographic` — `HolographicMemoryProvider(MemoryProvider)`. Multi-file plugin (`holographic.py`, `retrieval.py`, `store.py`). 2 tool schemas (`fact_store`, `fact_feedback`) — user-feedback loop drives trust scoring.
  - `honcho` — `HonchoMemoryProvider(MemoryProvider)`. Multi-file (`client.py`, `session.py`, `cli.py`). **5 tool schemas** (PROFILE/SEARCH/REASONING/CONTEXT/CONCLUDE) — most LLM-callable surface of any plugin. 2 daemon threads (`honcho-prewarm-dialectic`, `honcho-prefetch-first`).
  - `mem0` — `Mem0MemoryProvider(MemoryProvider)`. **Circuit breaker**: 5 failures → 120s cooldown. 3 tool schemas (PROFILE/SEARCH/CONCLUDE). 2 daemon threads (`mem0-prefetch`, `mem0-sync`).
  - `openviking` — `_VikingClient` HTTP class. Endpoint `http://127.0.0.1:1933`, 30s timeout. Accepts http(s)/git@/ssh:// URI families. 4 tool schemas (SEARCH/READ/BROWSE/REMEMBER). Commits sessions on `atexit`.
  - `retaindb` — `https://api.retaindb.com`. **8 tool schemas** (PROFILE/SEARCH/CONTEXT/REMEMBER/FORGET/FILE_UPLOAD/FILE_LIST/FILE_READ) — only plugin with file CRUD alongside memory.
  - `supermemory` — `https://api.supermemory.ai/v4/conversations`. 5s API timeout (much shorter than hindsight). Search modes `{hybrid, memories, documents}` (default `hybrid`). **Entity context clamping at 1500 chars**. Default 10 recall results, capture-everything mode, profile-every-50-turns frequency.
- `<memory-context>...</memory-context>` fence with system-note prefix wraps recalled memory before LLM call
- **`StreamingContextScrubber`** — stateful state machine across stream deltas; strips fence spans from LLM output even when fence-open spans two deltas; final `flush()` drops any unclosed fence (safest behavior)
- Plugin contributes its own tools via `get_tool_schemas()` (e.g. `mem0.profile`, `honcho.search`)

**Key benefit** — cross-session continuity with 8-way pluggability. Pick the memory plugin matching your data shape; everything else just works. The fence + scrubber prevents compounding self-injection across turns.

**Process map** — [12_memory_management.html](12_memory_management.html)

**Key terminology** — MemoryProvider, 4 lifecycle hooks, always-on builtin transcript, StreamingContextScrubber, memory-context fence, injection defense, session chain, FTS5 (all in [07_quick_start.md](07_quick_start.md))

**Key method/technology** — Plugin slot architecture + 4-hook lifecycle + fenced injection + state-machine scrubber

**Code locator**
| Concept | File |
|---|---|
| MemoryManager + StreamingContextScrubber | `agent/memory_manager.py` |
| MemoryProvider abstract | `agent/memory_provider.py` |
| SessionDB SQLite + FTS5 + WAL | `product-b_state.py` |
| 8 plugins | `plugins/memory/{byterover,hindsight,holographic,honcho,mem0,openviking,retaindb,supermemory}/` |
| Session search tool | `tools/session_search_tool.py` |

**my-product gap** — **No cross-session memory at all.** Sessions are independent.

**AWS ECS recipe**
- Port `MemoryProvider` ABC verbatim (4 + 7 hooks)
- Builtin provider: DynamoDB (`session_messages` partitioned by session_id) + OpenSearch (FTS analog)
- Start with one external plugin: **mem0** (lowest setup, server-side LLM extraction, circuit breaker means outage doesn't break agent)
- Copy memory-context fence format verbatim
- Port `StreamingContextScrubber` directly (~80 lines)
- Add `parent_session_id` GSI for fork/resume
- EventBridge → Lambda for async `queue_prefetch_all` warm-up
- Per-plugin tool schemas: if you add mem0, its tools become available to the LLM automatically

**Related zones** — CTX (recalled memory injected into prompt), COMPACT (different system, same problem class), SKILL (skills can read MEMORY.md).

---

### 3.7 🔴 Zone PERM — Permission & approval gate

**Key features**
- **Two-tier pattern model**: `HARDLINE_PATTERNS` (12 unconditional, `approval.py:187-209`) + `DANGEROUS_PATTERNS` (**exactly 47**, `approval.py:305-393`, verified verbatim) overridable. The 47 cluster into 12 categories: recursive delete (3) / permissions (4) / format-disk (3) / SQL (3) / system-config-lifecycle (5) / shell-via-flag (5) / tee-redirect (4) / find-xargs (3) / **product-b-lifecycle self-protection (4)** / **self-termination (3)** / cp-mv-sed (4) / git-destructive (6) / sudo-escalation (2 covering 8 flag forms)
- HARDLINE blocks: `rm -rf /`, system dir delete, `~`/`$HOME` delete, `mkfs`, `dd` to block device, redirect to block device, fork bomb, `kill -1`, `shutdown`/`reboot`/`halt`/`poweroff`, `init 0/6`, `systemctl poweroff`, `telinit 0/6` — pre-compiled at module load
- DANGEROUS overridable: rm in root path, curl pipe to sh, git reset/push-force, sudo, chmod 777, etc.
- Three session-state dicts: `_session_approved: dict[str, set]`, `_session_yolo: set`, `_permanent_approved: set`
- Per-session keys via `contextvars.ContextVar` — concurrent gateway threads have independent approval queues
- **Smart approval auxiliary LLM** (`_smart_approve` at `approval.py:841`) — returns LOWERCASE `'approve'`/`'deny'`/`'escalate'` (the prompt asks the LLM to emit uppercase APPROVE/DENY/ESCALATE; function returns lowercase). Uses `auxiliary_client.call_llm(task="approval", temperature=0)`. Cuts prompt fatigue ~5×.
- **DISPERSED flow — no single `check_dangerous_command()` function.** Calling tool (e.g. `terminal_tool.py`) composes: `detect_hardline_command` → `is_session_yolo_enabled` → `detect_dangerous_command` → `is_approved` → optional `_smart_approve` → `prompt_dangerous_approval(command, description, timeout_seconds=None, allow_permanent=True, approval_callback=None)` → `approve_session` / `approve_permanent`
- CLI prompt (prompt_toolkit) vs Gateway WebSocket queue (`register_gateway_notify` + `submit_pending` + `resolve_gateway_approval`)
- Yolo mode (`enable_session_yolo`) skips DANGEROUS prompts but HARDLINE still applies
- **`CheckpointManager` snapshots before destructive ops** — rollback safety even after approval

**Key benefit** — production safety without prompt fatigue. The HARDLINE/DANGEROUS split lets ops define "never overridable" vs "ask first"; smart approval handles legitimate workflows that look dangerous (e.g. `rm -rf /tmp/cache-*`).

**Process map** — [13_permission_approval.html](13_permission_approval.html)

**Key terminology** — HARDLINE / DANGEROUS, scope (once/session/always/deny), permission mode (yolo), contextvars sessions, smart approval, pre-destructive checkpoint

**Key method/technology** — Two-tier pre-compiled regex + 3 session-state dicts + auxiliary LLM second opinion + pre-write shadow-git snapshots

**Code locator**
| Concept | File |
|---|---|
| Hardline + dangerous patterns + state | `tools/approval.py` |
| Smart approval auxiliary LLM | `tools/approval.py` — `_smart_approve` |
| Gateway WebSocket integration | `tools/approval.py` — `register_gateway_notify` |
| Per-tool budget config | `tools/budget_config.py` |
| Pre-write checkpoint | `tools/checkpoint_manager.py` |

**my-product gap** — **No permission gate at all.** Ship-blocking for 50-user ECS.

**AWS ECS recipe**
- Port 12 HARDLINE patterns verbatim into `permissions/hardline.py`
- Start with 20 DANGEROUS; expand as production uncovers gaps
- DynamoDB for `_session_approved` + `_permanent_approved` (per-tenant); in-memory `_session_yolo`
- Pass `session_key` explicitly through async; use `contextvars` if single event loop
- Smart approval: Bedrock + Claude Haiku 4.5; cache verdicts by `(pattern_key, args_hash)` in Redis 1h
- WebSocket-back-to-UI like Gateway path; agent loop pauses with state in DynamoDB
- Default deny for cron / non-interactive
- EventBridge → Kinesis → S3 audit log
- S3 versioning for pre-destructive snapshots; VersionId saved in DynamoDB

**Related zones** — TOOL (gate runs between LLM tool_call and Dispatch), SUB-AGENT (per-task approval callback), EXEC (gate is what stops dangerous code execution; also applies inside PTC scripts).

---

### 3.8 🔵 Zone SUB-AGENT — Task delegation

**Key features**
- `delegate_task(goal, context, toolsets, tasks, role, parent_agent)` — accepts single goal OR list of `tasks` (parallel) — at `tools/delegate_tool.py:1898`
- `DELEGATE_BLOCKED_TOOLS = frozenset(["delegate_task", "clarify", "memory", "send_message", "execute_code"])` — auto-stripped from child toolset (verbatim `delegate_tool.py:40`)
- `MAX_DEPTH = 1` default (flat: parent → leaf children); `role='orchestrator'` unlocks recursion up to depth 3 (`delegate_tool.py:128`)
- `_DEFAULT_MAX_CONCURRENT_CHILDREN = 3`; `ThreadPoolExecutor` parallelism (line 127)
- `DEFAULT_MAX_ITERATIONS = 50`; `DEFAULT_CHILD_TIMEOUT = 600`s wall-clock (lines 507-508)
- Per-`task_id` isolation across 6 subsystems: FileStateRegistry, terminal env, browser context, CheckpointManager, approval callback, SessionDB
- `DelegateEvent` enum — **7 event types** (line 527): `TASK_SPAWNED`, `TASK_PROGRESS`, `TASK_COMPLETED`, `TASK_FAILED`, `TASK_THINKING`, `TASK_TOOL_STARTED`, `TASK_TOOL_COMPLETED`. SPAWNED/COMPLETED/FAILED are reserved for future orchestrator lifecycle and not yet emitted. `_LEGACY_EVENT_MAP` normalises legacy event strings.
- `_set_subagent_approval_cb(task_id, cb)` — per-worker approval callback (cron auto-deny, interactive inherit)
- `list_active_subagents()` / `interrupt_subagent(task_id)` for live control
- Result-only return: parent sees only children's `final_message`, intermediate transcripts discarded

**Key benefit** — context-budget protection (parent's context grows by summary, not by sub-agent transcript) + parallelism (max(t) wall-clock vs sum(t)) + isolation (per-task_id everywhere).

**Process map** — [14_subagent_delegation.html](14_subagent_delegation.html)

**Key terminology** — delegate_task, DELEGATE_BLOCKED_TOOLS, role='leaf' vs 'orchestrator', task_id, DelegateEvent, per-worker approval callback, interrupt_subagent

**Key method/technology** — `ThreadPoolExecutor` parallel children + per-task_id isolation across subsystems + opt-in recursion via role

**Code locator**
| Concept | File |
|---|---|
| delegate_task orchestration | `tools/delegate_tool.py` |
| Reusable agent loop (used by children) | `environments/agent_loop.py` |
| DELEGATE_BLOCKED_TOOLS + MAX_DEPTH | `tools/delegate_tool.py` constants |
| Per-worker approval cb installer | `tools/delegate_tool.py` — `_set_subagent_approval_cb` |
| DelegateEvent enum | `tools/delegate_tool.py` |

**my-product gap** — **No sub-agent primitive.** Single context = whole conversation = blows past 200k tokens fast.

**AWS ECS recipe**
- Python `SubAgent` class with own `messages`, `tools`, `provider_client`; new `asyncio.Task` instead of OS thread
- `asyncio.gather` for parallelism (lighter than ThreadPoolExecutor)
- Port `DELEGATE_BLOCKED_TOOLS` frozenset verbatim
- S3 prefix per task_id, DynamoDB rows keyed by `(session_id, task_id)`
- Start with `MAX_DEPTH = 1`; unlock 2-3 only for explicit orchestrator use cases
- SNS topic + WebSocket for DelegateEvent equivalents to UI
- Long children → Lambda + DynamoDB tracked + EventBridge notify

**Related zones** — TOOL (delegate_task is a tool), PERM (inheritance + per-task approval), EXEC (parent's PTC can't be inside child's toolset).

---

### 3.9 🟢 Zone COMPACT — Compaction & compression

**Key features**
- `ContextCompressor` (LIVE per-turn) vs `TrajectoryCompressor` (BATCH for training-data) — same protection rules, different lifetimes
- `SUMMARY_PREFIX` (verbatim ~13 sentences, line 37 of `context_compressor.py`) prepended to spliced summary tells the LLM "REFERENCE ONLY ... do NOT answer questions or fulfill requests mentioned in this summary; they were already addressed ... your current task is in the '## Active Task' section"
- `LEGACY_SUMMARY_PREFIX = "[CONTEXT SUMMARY]:"` for backward compat
- Constants (all verbatim from `context_compressor.py`): `_MIN_SUMMARY_TOKENS = 2000`, `_SUMMARY_RATIO = 0.20`, `_SUMMARY_TOKENS_CEILING = 12_000`, `_CHARS_PER_TOKEN = 4`, `_IMAGE_TOKEN_ESTIMATE = 1600`, `_SUMMARY_FAILURE_COOLDOWN_SECONDS = 600` (10-min cooldown after failed summarization)
- **Protection defaults: `protect_first_n = 3` head + `protect_last_n = 20` tail** (NUMERIC counts; NOT role-specific boolean flags as an earlier draft said. Verbatim from lines 408-409. **The 20-message tail is 5× larger than I originally claimed.**)
- `ContextCompressor` extends `ContextEngine` ABC (line 346)
- **Signature trick — pre-summarize tool results to 1-liners** BEFORE the main summarization: `[terminal] "npm test" → 47 lines output`. 80-95% size reduction before auxiliary LLM call.
- Multimodal flat-estimate: every image counted as 1600 tokens regardless of provider (picks the ceiling across Anthropic/OpenAI/Gemini)
- Splice convention: summary lands as `role: user` with SUMMARY_PREFIX header
- User-facing `/compress` with optional focus directive; `summarize_manual_compression` generates friendly user explanation

**Key benefit** — keeps long sessions alive without losing the goal anchor or recent reasoning. Pre-summarization signature trick makes the auxiliary LLM call 5-10× cheaper.

**Process map** — [15_compaction_summarization.html](15_compaction_summarization.html)

**Key terminology** — Compaction, pre-summarize tool result, SUMMARY_RATIO, head + tail protection, image flat-estimate, TrajectoryCompressor, /compress with focus

**Key method/technology** — Tokenizer budget check + cheap-model summarization + pre-pass tool-result reduction + structured splice

**Code locator**
| Concept | File |
|---|---|
| Live per-turn compaction | `agent/context_compressor.py` |
| Batch trajectory compaction | `trajectory_compressor.py` |
| Manual /compress feedback | `agent/manual_compression_feedback.py` |
| Constants | `agent/context_compressor.py` module top |

**my-product gap** — **No token counter, no compaction.** Sessions break at the context limit.

**AWS ECS recipe**
- `tiktoken` in agent container + Redis cache per-message-hash 60s TTL
- Threshold 0.75 of model context_length; per-tenant override in DynamoDB
- Bedrock + Claude Haiku 4.5 for summarization (~10× cheaper than main)
- Port constants verbatim — battle-tested values
- Port 4 head + 4 tail protection
- **Implement pre-summarize tool results FIRST** — single biggest win on context bloat
- Splice as `role: user` with SUMMARY_PREFIX
- Pre-compaction transcript → S3 audit trail; enables `/uncompact`
- Implement focus-directed compaction (~50 LOC, high value)
- Implement image flat-estimate — most providers under-count, easy to overshoot without

**Related zones** — CTX (delegate runs here), MEMORY (different system, same problem class), SUB-AGENT (sub-agents are preventive compaction).

---

### 3.10 🟤 Zone TEXT — Document retrieval & browser

**Key features**
- `ShellFileOperations.search(pattern, path, target='content'|'files', file_glob, limit, offset, output_mode, context)` — **unified glob/grep** API
- Backed by `ripgrep` (200× faster than find) with `.gitignore` awareness; falls back to GNU find
- `SearchResult` + `SearchMatch` dataclasses with path / line_number / content / mtime
- Pagination: limit 50 default, offset 0, `truncated` flag
- **Web tools with 7 swappable backends** (via `_get_backend()`): `parallel`, `firecrawl`, `tavily`, `exa`, `searxng`, `brave-free`, `ddgs`
- **`_FirecrawlProxy` lazy SDK loading** — defers `from firecrawl import Firecrawl` ~200ms cold cost until first use
- Browser uses **accessibility-tree snapshots** (NOT screenshots) — text-only LLMs comprehend pages directly without vision model
- `SNAPSHOT_SUMMARIZE_THRESHOLD = 8000` — auxiliary LLM extracts task-relevant elements if snapshot too big
- **SSRF protection** — private IPs auto-route to local sandbox sidecar
- `session_search` with FTS5 + auxiliary summarization; `MAX_SESSION_CHARS = 100_000`, `MAX_SUMMARY_TOKENS = 10_000`
- **NO passive browser-history monitoring** — by design

**Key benefit** — fastest file search of the three products; lowest-friction web research (just pick a backend); most token-efficient browser automation (accessibility tree, not screenshots); cross-session recall via FTS5.

**Process map** — [16_document_retrieval.html](16_document_retrieval.html)

**Key terminology** — Unified search, ripgrep, accessibility tree, ref token, SSRF, auto-summarize threshold, lazy SDK loading, session search, no passive monitoring

**Key method/technology** — Ripgrep shell-out + 7-backend lazy-loaded web layer + accessibility-tree (not screenshot) browser + FTS5 session search

**Code locator**
| Concept | File |
|---|---|
| ShellFileOperations + SearchResult/SearchMatch | `tools/file_operations.py` |
| Agent-facing file tools | `tools/file_tools.py` |
| Browser tool (accessibility tree) | `tools/browser_tool.py` |
| Browser CDP (lower-level) | `tools/browser_cdp_tool.py` |
| Web tools (7 backends + lazy SDK) | `tools/web_tools.py` |
| Session search (FTS5 + auxiliary summarize) | `tools/session_search_tool.py` |
| Browser-history monitoring | **None — by design.** |

**my-product gap** — no Glob, no Grep, no document_extract, no web fetch / readability, no browser tool, no cross-session search. User with 20-PDF folder asking "who wrote X" cannot be answered today.

**AWS ECS recipe**
- Shell out to `ripgrep` binary in container; Python wrapper with `target='files'|'content'`
- **Borrow product-A's pattern** for PDF/DOCX extraction (pdfplumber + python-docx + extraction cache keyed by sha256(s3_key + etag + size))
- Web search via Brave Search API or Tavily; lazy-load SDKs like product-B
- `httpx` + `trafilatura` for readability; auxiliary LLM summarize for >8000 tokens
- Playwright on Lambda or Fargate; expose accessibility-tree snapshots (NOT screenshots)
- Block RFC1918 + localhost at httpx adapter
- OpenSearch FTS analog for cross-session search
- 8000-token auto-summarize threshold for all "could be large" tool results
- **Do NOT build browser-history monitoring** — same privacy stance as product-B

**Related zones** — CTX (extracted text feeds into context via @file/@folder), SUB-AGENT (large corpora → spawn Explore sub), MEMORY (vector recall uses same plugin slot as memory).

---

### 3.11 ⚫ Zone SURFACE — Channels + OpenAI-compat API + ACP + voice + browser + deployment (observed) — *Phase 3 gap-fill*

**Key features**
- **25 channels** = 21 built-in `Platform` enum entries at `product-B/gateway/config.py:82-111` (`LOCAL, TELEGRAM, DISCORD, WHATSAPP, SLACK, SIGNAL, MATTERMOST, MATRIX, HOMEASSISTANT, EMAIL, SMS, DINGTALK, API_SERVER, WEBHOOK, MSGRAPH_WEBHOOK, FEISHU, WECOM, WECOM_CALLBACK, WEIXIN, BLUEBUBBLES, QQBOT, YUANBAO`) + 4 plugin-channels (teams, line, irc, google_chat). **CJK-heavy** vs product-A's Western+decentralized lean
- **Abstract base** at `product-B/gateway/platforms/base.py:1259`: `class BasePlatformAdapter(ABC)` with 4 abstract methods (`connect, disconnect, send, get_chat_info` at L1532, L1541, L1546, L3463) + 13 concrete-default media methods (`send_typing, send_voice, send_image, send_animation, send_video, send_document, send_multiple_images, send_draft`) — Telegram's `send_draft` (L1972) supports Bot API 9.5 animated streaming preview
- **OpenAI-compatible HTTP API server** at `product-B/gateway/platforms/api_server.py:578` (port 8642 default, L57-60). Endpoints: `POST /v1/chat/completions`, `POST /v1/responses` + stateful `ResponseStore` at L291 (cap 100), `POST /v1/runs` returns `run_id` + 202, `GET /v1/runs/{id}/events` SSE, `POST /v1/runs/{id}/approval`, `POST /v1/runs/{id}/stop`, `GET /v1/models`, `GET /v1/capabilities`, `GET /health`, `GET /health/detailed`. Session continuity via `X-product-B-Session-Id` + `X-product-B-Session-Key` headers. **Any OpenAI-compatible frontend (Open WebUI, LobeChat, LibreChat, AnythingLLM, NextChat, ChatBox) connects directly.**
- **ACP (Agent Client Protocol) adapter** — `class product-BACPAgent(acp.Agent)` at `product-B/acp_adapter/server.py:445` with `initialize` (L737), `authenticate` (L780), `new_session` (L930), `prompt` (L1071). Manifest at `acp_registry/agent.json:1-12`. **product-B-unique IDE integration**
- **~80 CLI modules** at `product-B/product-b_cli/main.py:1-44`: `product-b chat / product-b gateway [start|stop|status|install|uninstall] / product-b setup / product-b doctor / product-b honcho [setup|status|sessions|map|peer|mode|tokens|identity|migrate] / product-b acp / product-b product-a migrate / product-b cron + ~70 more`. Interactive TUI via `cli.py` using `prompt_toolkit` for fixed-input-area
- **Voice: TTS 10 + STT 5 + push-to-talk** — `product-B/tools/tts_tool.py:1-16` lists 10 providers: Edge TTS (default, free), ElevenLabs, OpenAI, MiniMax, Mistral Voxtral, Gemini, xAI Grok, **NeuTTS (local), KittenTTS (local 25MB), Piper (local OHF-Voice VITS, 44 languages)**. STT at `product-B/tools/transcription_tools.py:1-26`: `local` (faster-whisper default, ~150MB auto-download), `groq`, `openai`, `mistral` (Voxtral), `xai` (Grok STT, 21 languages, diarization). Auto-transcribes inbound voice on Telegram/Discord/WhatsApp/Slack/Signal. Push-to-talk CLI at `product-B/tools/voice_mode.py:1-10` (sounddevice). Per-chat auto-TTS via `/voice on|tts|off` at `gateway/platforms/base.py:1302-1316`
- **Accessibility-tree-first browser** at `product-B/tools/browser_tool.py:11` (docstring): "uses agent-browser's accessibility tree (ariaSnapshot) for text-based page representation". Dispatch tools at L2144-2606: `browser_navigate, browser_snapshot, browser_click, browser_type, browser_scroll, browser_back, browser_press, browser_console, browser_get_images, browser_vision`. CDP escape hatch at `tools/browser_cdp_tool.py:295`. **3 cloud providers** (browserbase, browser_use, firecrawl) + Camofox stealth
- **Image generation** — `class ImageGenProvider(abc.ABC)` at `product-B/agent/image_gen_provider.py:51` with single abstract `generate()` at L131. 3 plugins (openai, openai-codex, xai) + fal legacy via `tools/image_generation_tool.py:370` `_ManagedFalSyncClient`. Image routing 2 modes (`native` OpenAI image_url parts vs `text` vision_analyze precall) at `agent/image_routing.py:46`
- **NO video/music generation built in** — only user-recipe skill markdown
- **NO native desktop bundle** — surface is terminal CLI + ink/React TUI (`product-B/ui-tui/`) + Vite + React 19 web dashboard (`product-B/web/` with 12 pages: Chat, Config, Cron, Docs, Env, Logs, Models, Plugins, Profiles, Sessions, Skills, Analytics)
- **MCP server + client**: `product-B/mcp_serve.py` FastMCP with 10 tools (`conversations_list, conversation_get, messages_read, attachments_fetch, events_poll, events_wait, messages_send, permissions_list_open, permissions_respond, channels_list`); MCP client at `product-B/tools/mcp_tool.py` supports 3 transports (stdio, HTTP/StreamableHTTP, SSE) reading `mcp_servers:` block in `~/.product-b/config.yaml`
- **Deployment**: `Dockerfile:1-3` (Debian 13.4 + uv + Playwright Chromium baked into image at L53 + non-root user UID 10000 at L21) + `docker-compose.yml:24-50` (host networking) + `flake.nix:1-45` (3 systems: x86_64-linux, aarch64-linux, aarch64-darwin) + Homebrew formula at `packaging/homebrew/product-b.rb:1-30` + `install.sh` / `install.ps1` (Windows bundles MinGit ~45MB). **NO render.yaml / fly.toml / PaaS configs**
- **Onboarding**: `product-b_bootstrap.py:1-19` applies Windows UTF-8 fix as first import in cli.py + gateway/run.py; `product-b setup` interactive wizard; `cli-config.yaml.example:8-65` with 17 provider IDs; **`product-b product-a migrate` imports config from product-A** at README L126-148 (mirror of product-A's `migrate-product-b` extension)

**Key benefit** — terminal-first + standards-compliant API + IDE integration. The OpenAI-compatible `/v1/...` surface means any modern AI front-end connects to product-B without bespoke client code. The ACP adapter unlocks Cursor/Zed/Cline IDE integration. CJK channel breadth gives a strong China/SEA story.

**Process map** — [17_surface.html](17_surface.html)

**Key terminology** — `BasePlatformAdapter` ABC, OpenAI-compat `/v1/...`, ACP (Agent Client Protocol), accessibility-tree browser (not screenshot), local TTS (NeuTTS/KittenTTS/Piper), auto-transcribe-inbound-voice, `product-b product-a migrate`

**Key method/technology** — Python ABC channels + OpenAI-shape FastAPI routes + ACP server + ink/React TUI + Vite/React 19 SPA + Docker + flake.nix multi-system + Homebrew

**Code locator**
| Concept | File:line |
|---|---|
| `class Platform(Enum)` | `product-B/gateway/config.py:82-111` |
| `class BasePlatformAdapter(ABC)` | `product-B/gateway/platforms/base.py:1259` |
| 4 abstract methods | `base.py:1532, 1541, 1546, 3463` |
| 13 concrete media methods | `base.py:1766, 1775, 1783, 1840, 1859, 1930, 1965, 1985, 1349` |
| Discord adapter | `gateway/platforms/discord.py:532` |
| Slack adapter (interactive approvals) | `gateway/platforms/slack.py:268` (+ `send_exec_approval` L2201) |
| Telegram adapter (send_draft Bot API 9.5) | `gateway/platforms/telegram.py:316` (+ `send_draft` L1972) |
| API server | `gateway/platforms/api_server.py:578` |
| Constants | `api_server.py:57-60` — `DEFAULT_PORT = 8642, MAX_REQUEST_BYTES = 10_000_000` |
| ResponseStore | `api_server.py:291` |
| ACP adapter | `acp_adapter/server.py:445` (initialize 737, authenticate 780, new_session 930, prompt 1071) |
| CLI subcommands | `product-b_cli/main.py:1-44` |
| TTS providers | `tools/tts_tool.py:1-23` |
| STT providers | `tools/transcription_tools.py:1-26` |
| Push-to-talk | `tools/voice_mode.py:1-49` |
| Per-chat auto-TTS | `gateway/platforms/base.py:1302-1316, 1392-1405` |
| Browser tool | `tools/browser_tool.py:11, 2144-2606` |
| Browser CDP escape hatch | `tools/browser_cdp_tool.py:295` |
| Image gen ABC | `agent/image_gen_provider.py:51, 131` |
| Image routing modes | `agent/image_routing.py:46` |
| MCP server | `mcp_serve.py:2-13, 450, 472-734` |
| MCP client | `tools/mcp_tool.py:1-48` |
| Web dashboard | `web/package.json:15-30`, `web/src/pages/` (12 pages) |
| TUI | `ui-tui/package.json:18-26`, `ui-tui/src/`, `tui_gateway/` |
| Dockerfile | `Dockerfile:1-3, 17, 21, 53` |
| docker-compose | `docker-compose.yml:24-50` |
| Nix flake | `flake.nix:1-45`, `nix/packages.nix:7-25` |
| Homebrew | `packaging/homebrew/product-b.rb:1-30` |
| Install one-liners | `README.md:36-37, 45-47` |
| Windows UTF-8 fix | `product-b_bootstrap.py:1-44` |
| `product-b product-a migrate` | `README.md:126-148` |

**Strengths and gaps**
- vs **product-A** — 25 vs 24 channels (parity); 3 vs 12 image-gen (product-A wins); 0 vs 16 video-gen (product-A wins); 10 vs 28 TTS (product-A wins on breadth, **product-B wins on 3 local TTS defaults**); push-to-talk vs continuous talk + wake-word (product-A wins on UX); 0 vs 5 native apps (product-A wins decisively); ~80 vs 35 CLI modules (product-B wins on raw count); **OpenAI-compat `/v1/...` API**: product-B unique; **ACP adapter**: product-B unique; **accessibility-tree browser**: product-B unique
- vs **my-product** — every dimension of SURFACE. **my-product has none of channels/multi-modal/voice/CLI/MCP/ACP/native-apps/deployment-recipes.**
- **product-B unique strengths** — OpenAI-compatible HTTP API (massive integration leverage), ACP adapter (IDE story), 3 local TTS defaults (privacy-by-default), `product-b product-a migrate` cross-product import, Windows UTF-8 bootstrap

**AWS ECS recipe (for borrowing into my-product)**
- **Top borrow: OpenAI-compatible `/v1/...` HTTP server** — port verbatim. ALB with WebSocket support for SSE
- **`BasePlatformAdapter` ABC pattern** is the cleanest channel-plugin design — already Python, just lift. 4 abstract + 13 concrete-default methods
- **Browser tool**: high-value borrow — Lambda + Playwright Chromium layer; ~$0.005 per snapshot. Accessibility-tree-first (NOT screenshot)
- **ACP adapter**: medium priority — only if IDE integration is wanted
- **Local-first TTS** (NeuTTS/KittenTTS/Piper): too operationally complex for ECS v1 — use Amazon Polly via Bedrock instead
- **Auto-transcribe inbound voice**: defer until voice-bearing channel wired in — use AWS Transcribe
- **Docker base + Playwright bake-in**: copy verbatim. `PLAYWRIGHT_BROWSERS_PATH` saves cold-start time
- **`product-b product-a migrate` pattern**: low priority — revisit after matrix-based comparison
- **Skip**: Nix flake (too Nix-specific), Homebrew (not ECS-relevant), native apps (not in ICP), video/music gen

**Related zones** — TOOL (channels surface as tool destinations), PERM (per-channel approval), SUB-AGENT (delegate_task results route through channels), EXEC (`browser_*` tools are dispatched here).

---

## 4. The CSV-pareto worked example traversing 7 zones

User asks: *"Create a sentiment pareto from feedback.csv for the southwest region."*

| Step | Zone(s) | What happens |
|---|---|---|
| 1. Session bootstrap | ART | SessionDB lookup; FileStateRegistry rebuilt from messages table |
| 2. RefParse | CTX | No @-refs in this message → straight to assembly |
| 3. Per-turn assembly | CTX + MEMORY + SKILL | SOUL.md/USER.md/MEMORY.md injected, memory recalled (fenced), skill metadata indexed |
| 4. Tool plan | TOOL | `get_definitions()` filters by check_fn TTL; `coerce_tool_args` ready |
| 5. Token check | COMPACT | Under threshold first turn — no compaction |
| 6. LLM call 1 | TOOL | LLM emits `execute_code` with PTC script + enabled_tools=["terminal", "read_file", "write_file"] |
| 7. PERM check | PERM | `execute_code` not in HARDLINE/DANGEROUS — pass silently |
| 8. PTC dispatch | EXEC | Generate `product-b_tools` stub; spawn child; UDS RPC server starts; child runs pandas filter via `terminal()` stub |
| 9. File state | ART | FileStateRegistry.record_read on input; CheckpointManager.snapshot before write; note_write on output |
| 10. Iterations 2-4 | EXEC + ART | Per-row sentiment + chart → produces `pareto.png`; each is one PTC call but many internal RPC calls |
| 11. Iteration 5 | TOOL | Final answer, no tool_calls |
| 12. Scrubber | MEMORY | StreamingContextScrubber strips any memory-context fences from final output |
| 13. Memory sync | MEMORY | Post-turn `sync_all` records "user wanted sentiment pareto for southwest" to all registered plugins |
| 14. Curator tick | SKILL | Curator's idle daemon — no archival needed this turn |

**Zones exercised: 7 of 10** (TOOL, CTX, ART, EXEC, MEMORY, SKILL, COMPACT). SUB-AGENT activates when corpus is too big for parent context; PERM in interactive mode activates on dangerous commands; TEXT activates on file-search or browser questions.

---

## 5. Common modifications — which zone to edit

| What you want to change | Zone | Where |
|---|---|---|
| Add a new tool | TOOL | `tools/<name>.py` + `registry.register(...)` at module top |
| Make a tool require approval | PERM | Add pattern to `tools/approval.py` DANGEROUS_PATTERNS |
| Tune workspace prompt | CTX | Edit `~/.product-B/workspace/SOUL.md` / `USER.md` / `MEMORY.md` |
| Add a sub-agent toolset | SUB-AGENT | Pass `toolsets=[...]` to `delegate_task` |
| Change compaction threshold | COMPACT | Override 0.75 → 0.70 in per-tenant config |
| Switch memory plugin | MEMORY | Config flag selects active plugin from 8 |
| Support a new file format | TEXT | Extend `file_tools.py` or use a skill |
| Block a category of operations | PERM | Add to `HARDLINE_PATTERNS` in `tools/approval.py` |
| Run in a different sandbox | EXEC | Config: `sandbox.backend` = `docker` / `modal` / etc. |
| Cap a noisy tool's output | TOOL | Set `max_result_size_chars` in registration |
| Make agent forget a workspace file | ART | Delete from S3 / workspace; SessionDB still has the read record |
| Add a new skill | SKILL | Create `~/.product-B/workspace/skills/<name>/SKILL.md` |

---

## 6. Troubleshooting — symptom → zone

| Symptom | Likely zone | What to check |
|---|---|---|
| Tool not visible to LLM | TOOL | `check_fn` returning False; TTL cache stale — call `invalidate_check_fn_cache()` |
| LLM loops forever | TOOL | `max_iterations` budget; missing stop signal in response |
| LLM ignores existing tool | TOOL + CTX | Tool description quality; SOUL.md / TOOLS.md guidance |
| Sessions break at ~30 turns | COMPACT | `last_prompt_tokens` not updated from response; threshold never fires |
| Agent runs `rm -rf` something | PERM | Yolo mode active? Pattern missing from HARDLINE? |
| Agent re-reads same PDF every turn | TEXT/ART | No extraction cache — borrow from product-A |
| Workspace files vanish | ART | Sandbox is ephemeral; check `BaseEnvironment` backend |
| "You keep forgetting me" | MEMORY | No active external plugin; only builtin SQLite. Add mem0 or similar |
| "Find X across PDFs" → nothing | TEXT | document_extract not chained after Glob, or running on raw PDF bytes |
| Context blows after big git diff | COMPACT/TOOL | Per-tool `max_result_size_chars` not set |
| Agent claims to see browser history | TEXT | **This should NEVER happen.** product-B has no passive monitoring — if reproducible, it's a hallucination — patch the system prompt |
| Sub-agent ignores parent instructions | SUB-AGENT | Self-contained briefing rule violated — sub doesn't see parent transcript |
| StreamingScrubber lets memory leak | MEMORY | Fence open spans 2 deltas? Check buffer-tail logic |
| Skill not in /skills list | SKILL | Platform gate mismatch? Curator archived after 90 days? |
| Concurrent sessions interfere | PERM | `contextvars` propagation broken? Async boundary missed? |

---

## 7. The handbook self-test

A maintenance engineer should answer these 20 questions in <30 seconds each using this handbook + the deep-dive HTMLs.

| # | Question | Answered in |
|---|---|---|
| 1 | Where is the tool registry and how do tools register themselves? | §3.1 + [02](02_tool_registry.html) |
| 2 | What fields does each tool's metadata contain? | §3.1 (ToolEntry __slots__) |
| 3 | How is the LLM payload composed? | §3.2 + [03](03_llm_call_flow.html) |
| 4 | How is a tool selected by the LLM? | §3.1 (description-driven) |
| 5 | How is a tool dispatched and result fed back? | §3.1 + [03](03_llm_call_flow.html) |
| 6 | What determines when the loop stops? | §3.1 (budget check, finish_reason) |
| 7 | How does the agent remember mid-session AND across sessions? | §3.6 + §3.9 |
| 8 | Who's allowed to do what — and how is that enforced? | §3.7 |
| 9 | How does the agent investigate huge codebases without blowing context? | §3.8 |
| 10 | What happens when the conversation gets too long? | §3.9 |
| 11 | How does the agent find answers across PDF/DOCX/TXT? | §3.10 |
| 12 | Does the agent watch the user's browser history? | §3.10 — **NO. Privacy-by-design.** |
| 13 | Where do intermediate files (CSVs, charts) live? | §3.3 |
| 14 | What's the sandbox model for running user code? | §3.4 |
| 15 | What's a "skill" and how do operators add new ones? | §3.5 |
| 16 | What's distinctive about product-B's tool calling? | §3.4 (PTC) |
| 17 | How does product-B differ from product-A on memory? | §3.6 (8 plugins vs 4-slot architecture) |
| 18 | The worked example traversing zones | §4 |
| 19 | Which zone do I edit for symptom X? | §5 |
| 20 | How does each pattern map to AWS ECS? | §3.X "AWS ECS recipe" subsections |

---

## 8. Glossary

The plain-English glossary with ~50 terms is in **[07_quick_start.md](07_quick_start.md) §6** — go there for any unfamiliar word. Search by Ctrl-F on the term.

---

## 9. Bundle file index

| File | Purpose |
|---|---|
| [00_manual.md](00_manual.md) | This handbook |
| [01_process_map.html](01_process_map.html) | Master overview diagram (10 zones, zoomable) |
| [02_tool_registry.html](02_tool_registry.html) | TOOL deep-dive: registry & dispatch |
| [03_llm_call_flow.html](03_llm_call_flow.html) | TOOL deep-dive: one-iteration call flow |
| [04_architecture.html](04_architecture.html) | TOOL deep-dive: file/module drilldown |
| [05_python_demo.py](05_python_demo.py) | Runnable demo with REAL product-B class signatures (`--selftest`) |
| [06_process_map_demo.html](06_process_map_demo.html) | Demo .py process map (file structure → runtime flow) |
| [07_quick_start.md](07_quick_start.md) | Function/class index + common mods + debugging + glossary |
| [08_artifact_management.html](08_artifact_management.html) | ART deep-dive |
| [09_context_management.html](09_context_management.html) | CTX deep-dive |
| [10_code_execution.html](10_code_execution.html) | EXEC deep-dive (PTC) ⭐ |
| [11_skill_management.html](11_skill_management.html) | SKILL deep-dive |
| [12_memory_management.html](12_memory_management.html) | MEMORY deep-dive ⭐ |
| [13_permission_approval.html](13_permission_approval.html) | PERM deep-dive |
| [14_subagent_delegation.html](14_subagent_delegation.html) | SUB-AGENT deep-dive |
| [15_compaction_summarization.html](15_compaction_summarization.html) | COMPACT deep-dive |
| [16_document_retrieval.html](16_document_retrieval.html) | TEXT deep-dive |
| [17_surface.html](17_surface.html) | SURFACE deep-dive *(Phase 3 gap-fill)* — channels, OpenAI-compat API, ACP, voice, browser, deployment |
| [18_observability.html](18_observability.html) | OBSERVABILITY deep-dive *(Phase 3 gap-fill)* — dual-TTL prompt cache, Langfuse, 18-value error taxonomy, MCP circuit breaker, cost table, injection defense, health, audit |
| [19_adapt_learn.html](19_adapt_learn.html) | ⭐ ADAPT_LEARN deep-dive *(Phase 3 gap-fill, USER'S #1 ICP)* — Holographic `fact_feedback` + Honcho dialectic + HF SFT pipeline + RL training scaffold |

**20 files. 13 function groups. One coherent picture of how product-B works.**

---

## 10. side-by-side with product-A

This bundle's structure intentionally mirrors the product-A bundle so that side-by-side comparison is trivial. For each zone in §3 above, the corresponding product-A handbook section discusses the same zone for product-A — same template, same headings, same code-locator format.

| Zone | product-A signature | product-B signature | my-product gap |
|---|---|---|---|
| TOOL | Descriptor-contract + availability predicate language | ToolEntry __slots__ + check_fn TTL + 9 adapters + coerce_tool_args | No typed contract |
| CTX | ContextEngine plugin pipeline | @-reference parser with 6 types + dual budget | None |
| ART | Workspace + transcript-as-manifest (loose) | **FileStateRegistry + 3-tier staleness + shadow git** ⭐ | None |
| EXEC | subprocess + openshell + Docker/SSH | **Programmatic Tool Calling + 7 sandboxes** ⭐ | One subprocess backend |
| SKILL | 60 skills + 3-level disclosure | **Curator daemon + inline shell expansion + platform gating** | No skills |
| MEMORY | 4 plugin choices + dreaming subsystem | **8 plugins + always-on SQLite+FTS5 + StreamingContextScrubber** ⭐ | No memory |
| PERM | 4 modes + deny+reason loopback | **HARDLINE/DANGEROUS two-tier + smart approval** | No gate |
| SUB-AGENT | 10+ named sub-types + worktree isolation | delegate_task + per-task_id isolation across 6 subsystems | None |
| COMPACT | 9-section summary structure + focus | **Pre-summarize tool results to 1-liners + image flat-estimate** ⭐ | None |
| TEXT | Glob + Grep + document_extract + cache | **Unified search + 7 web backends + accessibility-tree browser** | None |
| SURFACE *(Phase 3 gap-fill)* | ⭐ **24 channels + 12 image + 16 video + 3 music + 28 TTS + 5 native apps + 35 CLI + 22-module wizard + Docker+PaaS+3 daemon installers + pairing-default security** | 25 channels + OpenAI-compat `/v1/...` API + ACP adapter + ~80 CLI + 10 TTS (3 local) + 5 STT + accessibility-tree browser + Docker+Nix+Homebrew | **0 channels / 0 voice / 0 image-gen / 0 CLI / 0 native apps / no Dockerfile committed**; 21 FastAPI routes + vanilla-JS UI; AWS_REFRACTOR markers throughout |
| OBSERVABILITY *(Phase 3 gap-fill)* | ⭐ **Full OTLP traces+metrics+logs (~50 instruments, GenAI semconv) + custom Prometheus + 3 QA plugins (qa-lab/qa-matrix/qa-channel) + character/discovery/model-switch evals + LLM judge + boundary-marker prompt cache + multi-provider Usage normalization (30+ token-names) + positive-jitter Retry-After + random-ID anti-spoof injection wrapper + 15 detection regexes + K8s /health-/ready + 50+ security-audit modules + trajectory JSONL (mode 0o600, 50MB cap)** | ⭐ **Dual-TTL prompt cache (system_and_3 + prefix_and_2 with 4 breakpoints) + Langfuse plugin (deterministic trace_id) + 18-value FailoverReason with action hints + per-token-type pricing in _OFFICIAL_DOCS_PRICING + MCP 3-state circuit breaker + StreamingContextScrubber + StreamingThinkScrubber (fail-closed) + tirith pre-exec scanner + AccountUsageSnapshot plan-limits + InsightsEngine SQLite + nous_rate_guard cross-session + jittered backoff** | **No OTel/Prometheus/Datadog (only stdlib logging) / NO eval harness / NO A/B / NO $/cost rollup / NO `/health` endpoint (ECS-blocker) / NO audit log / NO circuit breaker / NO typed error taxonomy**; partial: 4-tier retry + schema strict-mode startup gate (fail-closed) + per-run artifact manifest + FIFO sliding-window rate-limit |
| **ADAPT_LEARN** *(Phase 3 gap-fill, ⭐ USER'S #1 ICP)* | ⭐ **2 PARTIAL** — **dreaming** (recall-frequency feedback, 6 static weights, 3-phase Light/Deep/REM cron) + **skill-workshop** (6 correction regexes + LLM reviewer mutates SKILL.md). Trajectory = local JSONL flight recorder only. NO RLHF/DPO. Score 2/10 | ⭐⭐⭐ **3 STRONGEST** — **Holographic `fact_feedback`** (in-session RLAIF, `trust_score` asymmetric +0.05/-0.10) + **Honcho dialectic** (5,000 LOC, 3-pass dialectic at hosted endpoint, behavioral closed loop) + **Trajectory → HF SFT pipeline** (`moonshotai/Kimi-K2-Thinking` tokenizer + `huggingface-cli upload` for upstream foundation-model release). Plus `rl_training_tool.py` Tinker-Atropos scaffold. **product-B wins this dimension decisively.** Score 3/10 | **HEADLINE: 0/10 today** — `quality_score_0_to_1` 1 producer/0 readers; `usage_count` + `increment_usage()` ZERO callers (dead code in live schema). **But `function_registry.py` is the BEST scaffolding** — 5-step fix (~200 LOC) moves to 4-5/10 |

⭐ = product-B's strongest position relative to the other two

---

*End of product-B architecture handbook. Next: my-product handbook (same shape, with the gap-closing build list).*
