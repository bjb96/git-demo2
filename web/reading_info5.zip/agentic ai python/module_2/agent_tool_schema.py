
# When integrating AI into real-world environments, tool descriptions must be explicit, structured, and informative. By following these principles:

# Use descriptive names.
# Provide structured metadata.
# Leverage JSON Schema for parameters.
# Ensure AI has contextual understanding.
# Include robust error handling.
# Provide informative error messages.
# Inject instructions into error messages.


def list_python_files():
    """Returns a list of all Python files in the src/ directory."""
    return [f for f in os.listdir("src") if f.endswith(".py")]

{
  "tool_name": "read_file",
  "description": "Reads the content of a specified file.",
  "parameters": {
    "type": "object",
    "properties": {
      "file_path": { "type": "string" }
    },
    "required": ["file_path"]
  }
}

{
  "tool_name": "write_doc_file",
  "description": "Writes a documentation file to the docs/ directory.",
  "parameters": {
    "type": "object",
    "properties": {
      "file_name": { "type": "string" },
      "content": { "type": "string" }
    },
    "required": ["file_name", "content"]
  }
}