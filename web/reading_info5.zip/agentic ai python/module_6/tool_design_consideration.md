A Complete Example of Prompting for Structured Data
Let’s create an invoice processing system that combines specialized extraction with a simple storage mechanism. The system will use the LLM’s capabilities to understand invoice content while maintaining strict data consistency through a fixed schema.

First, let’s create our specialized invoice extraction tool:

@register_tool(tags=["document_processing", "invoices"])
def extract_invoice_data(action_context: ActionContext, document_text: str) -> dict:
    """
    Extract standardized invoice data from document text.

    This tool ensures consistent extraction of invoice information by using a fixed schema
    and specialized prompting for invoice understanding. It will identify key fields like
    invoice numbers, dates, amounts, and line items from any invoice format.

    Args:
        document_text: The text content of the invoice to process

    Returns:
        A dictionary containing the extracted invoice data in a standardized format
    """
    invoice_schema = {
        "type": "object",
        "required": ["invoice_number", "date", "total_amount"],
        "properties": {
            "invoice_number": {"type": "string"},
            "date": {"type": "string"},
            "total_amount": {"type": "number"},
            "vendor": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "address": {"type": "string"}
                }
            },
            "line_items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "description": {"type": "string"},
                        "quantity": {"type": "number"},
                        "unit_price": {"type": "number"},
                        "total": {"type": "number"}
                    }
                }
            }
        }
    }

    # Create a focused prompt for invoice extraction
    extraction_prompt = f"""
            You are an expert invoice analyzer. Extract invoice information accurately and 
            thoroughly. Pay special attention to:
            - Invoice numbers (look for 'Invoice #', 'No.', 'Reference', etc.)
            - Dates (focus on invoice date or issue date)
            - Amounts (ensure you capture the total amount correctly)
            - Line items (capture all individual charges)
            
            Stop and think step by step. Then, extract the invoice data from:
            
            <invoice>
            {document_text}
            </invoice>
    """

    # Use prompt_llm_for_json with our specialized prompt
    return prompt_llm_for_json(
        action_context=action_context,
        schema=invoice_schema,
        prompt=extraction_prompt
    )

@register_tool(tags=["storage", "invoices"])
def store_invoice(action_context: ActionContext, invoice_data: dict) -> dict:
    """
    Store an invoice in our invoice database. If an invoice with the same number
    already exists, it will be updated.
    
    Args:
        invoice_data: The processed invoice data to store
        
    Returns:
        A dictionary containing the storage result and invoice number
    """
    # Get our invoice storage from context
    storage = action_context.get("invoice_storage", {})
    
    # Extract invoice number for reference
    invoice_number = invoice_data.get("invoice_number")
    if not invoice_number:
        raise ValueError("Invoice data must contain an invoice number")
    
    # Store the invoice
    storage[invoice_number] = invoice_data
    
    return {
        "status": "success",
        "message": f"Stored invoice {invoice_number}",
        "invoice_number": invoice_number
    }
Our agent includes two specialized tools that integrate to manage the invoice processing workflow:

The first tool, extract_invoice_data, acts as our intelligent document analyzer. This function uses self-prompting to take raw document text and transform it into structured data following a consistent schema. It uses a prompt that guides the LLM to identify crucial invoice elements like invoice numbers, dates, and line items. By enforcing a fixed JSON schema with required fields, the tool ensures data consistency regardless of the original invoice format. It is still possible that the LLM may hallucinate, so other techniques could be needed for a production use case, but this demonstrates the basic functionality.

The second tool, store_invoice, provides a simple persistence mechanism in a dictionary. Once an invoice has been properly extracted and structured, this function saves it to our invoice database, using the invoice number as a unique identifier. The invoices are stored separate from the memory so that they can be persisted across runs of the agent.

To use this system, we would set up our agent with these tools and configure it to handle invoice processing tasks. Here’s how we might create and run the agent:

def create_invoice_agent():
    # Create action registry with our invoice tools
    action_registry = PythonActionRegistry()
    
    # Create our base environment
    environment = PythonEnvironment()
    
    # Define our invoice processing goals
    goals = [
        Goal(
            name="Persona",
            description="You are an Invoice Processing Agent, specialized in handling and storing invoice data."
        ),
        Goal(
            name="Process Invoices",
            description="""
            Your goal is to process invoices by extracting their data and storing it properly.
            For each invoice:
            1. Extract all important information including numbers, dates, amounts, and line items
            2. Store the extracted data indexed by invoice number
            3. Provide confirmation of successful processing
            4. Handle any errors appropriately
            """
        )
    ]

    # Create the agent
    return Agent(
        goals=goals,
        agent_language=AgentFunctionCallingActionLanguage(),
        action_registry=action_registry,
        generate_response=generate_response,
        environment=environment
    )
This implementation provides several key benefits:

Consistent Data Structure: The fixed schema in extract_invoice_data ensures all invoices are processed into a consistent format. The prompting / logic for how to extract invoice data is separate from the agent’s core reasoning, making it easier to modify and maintain.

Modular Design: Each tool has a single, clear responsibility, making the system easy to maintain and extend. Details for how the tools are implemented are hidden from the overall Goals of the agent.

Error Handling: Built-in validation ensures required fields are present and data is properly formatted.

Persistent Storage: The simple dictionary-based storage can be easily replaced with a database or other persistence mechanism by modifying the storage tools. The work that the agent does can now be persisted across runs.

The specialized schema and focused prompting help ensure accurate extraction, while the storage tools maintain data organization. You can extend this system by adding more specialized tools for different types of invoices or additional processing capabilities.

Horizontal Scaling of Agents Through Tools
One of the most powerful aspects of this tool-based approach is how it enables horizontal scaling of agent capabilities. Rather than constantly expanding the core goals or system prompt of an agent—which can lead to prompt bloat and conflicting instructions—we can encapsulate specific functionality in well-defined tools that the agent can access as needed.

Encapsulating Complexity in Tools
Tools serve as specialized modules that hide implementation complexity from the agent’s core reasoning. Consider our invoice processing example:

Abstraction of Domain Knowledge: The extract_invoice_data tool encapsulates specialized knowledge about invoice formats, field identification, and data extraction. The agent doesn’t need to understand these details—it just needs to know when to use the tool.

Separation of Concerns: Each tool handles a specific function (extraction, storage), allowing the agent to focus on high-level coordination rather than implementation specifics. This separation makes the entire system more maintainable and easier to reason about.

Focused Prompting: By moving specialized prompting inside tools, we keep the agent’s core goals simple and focused. The extraction tool handles its own specialized prompt engineering, freeing the agent from needing to generate perfect prompts for every task.

Maintainability and Adaptability
Tools create a modular architecture that offers significant maintenance advantages:

Independent Development: Tools can be developed, tested, and improved independently of the agent’s core logic. This means specialized teams can work on different tools without needing to understand or modify the entire agent system.

Versioning and Updates: Individual tools can be updated without changing the agent’s core goals. For example, we could improve the invoice extraction algorithm without touching any other part of the system.

Plug-and-Play Functionality: New capabilities can be added by simply registering new tools with the action registry. The agent automatically gains access to these capabilities through its function-calling abilities.

Adapting Agents Through Tool Management
This architecture makes it remarkably easy to adapt agents for different use cases:

Tool Composition: Create specialized agents by selecting which tools they have access to. An invoice processing agent might have document tools, while a customer service agent might have access to CRM tools.

Capability Evolution: Start with simple implementations and gradually enhance capabilities by upgrading tools. For example, our simple dictionary-based invoice storage could be replaced with a database connector without changing the agent’s core logic.

Context Management: Tools can manage their own state and context, reducing the cognitive load on the agent. In our example, the storage tool manages its own data structure, allowing the agent to focus on process flow rather than data management.

Practical Implementation Considerations
When implementing a tool-based architecture for horizontal scaling:

Tool Discoverability: Ensure tools have clear descriptions and tags so the agent can understand when to use them. Well-documented tool interfaces help both human developers and AI agents.

Error Handling: Build robust error handling into tools to prevent failures from cascading through the system. Tools should provide clear error messages that guide the agent toward resolution.

Instrumentation: Add logging and monitoring to tools to track their usage and performance. This provides valuable insights for improving both the tools and the agent’s decision-making about when to use them.

Contextual Awareness: Design tools to preserve and utilize context when appropriate. For example, our invoice storage tool could be enhanced to track modification history or flag unusual changes.

Conclusion
Horizontal scaling through tools represents a paradigm shift in how we build and evolve agent systems. Rather than creating monolithic agents with ever-expanding capabilities encoded in their core prompts, we can build modular, adaptable systems that grow through the addition of specialized tools.

This approach mirrors successful software engineering practices—encapsulation, modularity, and separation of concerns—applied to the unique challenges of LLM-based agents. By focusing complexity in tools rather than core agnet reasoning, we create systems that are more maintainable, more adaptable, and ultimately more capable of solving complex, real-world problems.