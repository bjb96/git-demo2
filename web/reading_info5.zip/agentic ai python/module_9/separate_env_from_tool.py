# we can implement this logic in our environment system, which can examine each tool’s requirements and provide only the dependencies it specifically requests.
# The agent simply passes everything to the environment and lets it handle the details. The environment can then analyze each tool’s signature and provide exactly the dependencies it needs - no more, no less.
def handle_agent_response(self, action_context: ActionContext, response: str) -> dict:
    """Handle action without dependency management."""
    action_def, action = self.get_action(response)
    result = self.environment.execute_action(self, action_context, action_def, action["args"])
    return result

# mplement an environment that handles dependency injection:
class PythonEnvironment(Environment):
    def execute_action(self, agent, action_context: ActionContext, 
                      action: Action, args: dict) -> dict:
        """Execute an action with automatic dependency injection."""
        try:
            # Create a copy of args to avoid modifying the original
            args_copy = args.copy()

            # If the function wants action_context, provide it
            if has_named_parameter(action.function, "action_context"):
                args_copy["action_context"] = action_context

            # Inject properties from action_context that match _prefixed parameters
            for key, value in action_context.properties.items():
                param_name = "_" + key
                if has_named_parameter(action.function, param_name):
                    args_copy[param_name] = value

            # Execute the function with injected dependencies
            result = action.execute(**args_copy)
            return self.format_result(result)
        except Exception as e:
            return {
                "tool_executed": False,
                "error": str(e)
            }

@register_tool()
def query_database(action_context: ActionContext, 
                query: str, 
                _db_connection: DatabaseConnection, 
                _config: dict) -> dict:
    """Process data using external dependencies."""
    # Tool automatically receives db_connection and config
    ... use the database connection ...
    return query_results

# update our tool registration system to ignore these special parameters when building the schema that the agent uses
def get_tool_metadata(func, tool_name=None, description=None, 
                     parameters_override=None, terminal=False, 
                     tags=None):
    """Extract metadata while ignoring special parameters."""
    signature = inspect.signature(func)
    type_hints = get_type_hints(func)

    args_schema = {
        "type": "object",
        "properties": {},
        "required": []
    }

    for param_name, param in signature.parameters.items():
        # Skip special parameters - agent doesn't need to know about these
        if param_name in ["action_context", "action_agent"] or \
           param_name.startswith("_"):
            continue

        # Add regular parameters to the schema
        param_type = type_hints.get(param_name, str)
        args_schema["properties"][param_name] = {
            "type": "string"  # Simplified for example
        }

        if param.default == param.empty:
            args_schema["required"].append(param_name)

    return {
        "name": tool_name or func.__name__,
        "description": description or func.__doc__,
        "parameters": args_schema,
        "tags": tags or [],
        "terminal": terminal,
        "function": func
    }
# For example, a tool that needs user authentication and configuration
@register_tool(description="Update user settings in the system")
def update_settings(action_context: ActionContext, 
                   setting_name: str,
                   new_value: str,
                   _auth_token: str,
                   _user_config: dict) -> dict:
    """Update a user setting in the external system."""
    # Tool automatically receives auth_token and user_config
    headers = {"Authorization": f"Bearer {_auth_token}"}
    
    if setting_name not in _user_config["allowed_settings"]:
        raise ValueError(f"Setting {setting_name} not allowed")
        
    response = requests.post(
        "https://api.example.com/settings",
        headers=headers,
        json={"setting": setting_name, "value": new_value}
    )
    
    return {"updated": True, "setting": setting_name}

# The environment automatically injects the action_context, _auth_token, and _user_config dependencies. This keeps our agent’s orchestration logic clean while providing tools with the rich context they need to function.

# This system gives us a clean separation of concerns:

# The agent focuses on deciding what actions to take
# Tools declare what dependencies they need
# The environment handles dependency injection and result management
# ActionContext provides a flexible container for shared resources

